# MoInk 固件 R2.7.2 —— 「睡死」修复批变更说明

**基线**：R2.7.1（zip 包 `moink-esp32-R2.7.1.zip`）
**日期**：2026-11-06　**目标**：ESP32 / ESP-IDF v6.1
**主题**：根治「空闲入睡拦腰斩断 EPD 全屏刷新 → 屏幕定格半刷（外观睡死）」，
并按评审清单同步修复 WiFi 停机态误操作、版本漂移、NimBLE IRK 告警、
ext0 假唤醒空转。

---

## 0. 根因回顾（与实测日志对齐）

R2.7.1 的入睡序列（`power_enter_deep_sleep`）：

```
esp_wifi_stop() ──异步──▶ STA_DISCONNECTED
                            │ wifi_mgr: set_mode(APSTA) + netif_ap_apply
                            │          （set_config → ESP_ERR_WIFI_STOP_STATE）
                            │          + esp_wifi_connect()（对停机驱动无效）
                            └─ net_changed() ──▶ display_task 启动 15s 全屏重画
                                                  （此时才补报 busy 脉冲 —— 太晚）
power 路径继续：epd_panel_deep_sleep → 200ms → 写 RTC 标记 → esp_deep_sleep_start()
                            ▲ 无任何二次校验：重画 70ms/15s 处被断电
```

三个叠加缺陷：① 入睡序列**自己触发的活动**（掉线重连 + 重画）无法中止已启动的
入睡；② 判闲只看「各任务自觉上报的忙脉冲」，而入睡引发的重画发生在判闲
**之后**；③ 掉线处理器对**正在停机的驱动**做重配/重连。本批修复按用户清单
逐项闭合，未推倒重来。

---

## 1. 修复点 → 文件对照总表

| # | 优先级 | 修复点 | 涉及文件 |
|---|--------|--------|----------|
| 1 | 致命 | 入睡二次校验 + sleeping 标志 + 入睡顺序 | `main/power.c` `main/power.h` `main/main.c` `main/wifi_mgr.c` |
| 2 | 高 | `epd_panel_busy()` 面板忙硬判据 | `main/epd_drv.c` `main/epd_drv.h` `main/power.c` |
| 3 | 高 | STA_DISCONNECTED 驱动状态检查；`netif_ap_apply` 如实报错 | `main/wifi_mgr.c` `main/netif_ap.c` |
| 4 | 中 | 版本号统一 R2.7.2 | `CMakeLists.txt` `main/version.h` `page/index.html` `main/index_html.h` `README.md` |
| 5 | 中 | NimBLE IRK persist 告警消除 | `sdkconfig.defaults` |
| 6 | 低 | ext0 按键唤醒去抖确认 | `main/main.c` `main/power.c` `main/power.h` `main/epd_drv.c` |
| 附 | 低 | （评审第 10 项）轻唤醒不再空调 `esp_wifi_stop()` | `main/power.c` |
| 附 | — | 主机编译闸门桩头同步（新增 API/事件） | `scripts/idf_stubs/esp_wifi.h` `scripts/make_idf_stubs.py` |

---

## 2. 逐文件改动与理由

### 2.1 `main/power.h`

- **新增 `power_sleeping()`**：查询「入睡序列正在执行」。置位窗口内
  wifi_mgr 掉线/慢重试/探测一律短路、display_task 暂缓 UI 事件。
- **新增 `power_deep_sleep_now()`**：强制入睡口（跳过二次校验），仅限
  ext0 假唤醒去抖确认后的直接回睡等「确认无活动可打断」的调用点。
- **契约注释更新（硬性约束要求）**：
  - `power_should_sleep()`：判据 = boot 门控完成 && 按用途窗口已到 && 无忙
    脉冲 && **EPD 面板序列不在进行中（新硬判据）** && 空闲超窗；须在整个
    入睡窗口内可安全重入，且不受 `power_sleeping()` 标志影响。
  - `power_enter_deep_sleep()`：**可能返回**（旧契约「不返回」作废）。完整
    序列 ①标志 → ②唤醒计划 → ③按需停 WiFi → ④200ms 收尾 → ⑤二次校验
    （不过则中止返回）→ ⑥提交（断面板电 / 写 RTC 标记 / 入睡）。
- 理由：修复 1 的跨模块契约必须落到头文件，调用方（idle_monitor）与被
  短路方（wifi_mgr/display）都按同一份契约工作。

### 2.2 `main/power.c`

- **`s_sleeping` 全局标志 + `power_sleeping()`**（volatile 单字节，无锁）。
- **`power_enter_deep_sleep()` 主体重构为 `deep_sleep_seq(bool force)`**，
  两个公共入口分别走 `force=false/true`：
  1. **先置 sleeping 标志**（修复 1c：标志先行，随后停 WiFi 触发的掉线
     事件才会被 wifi_mgr 短路）；
  2. 评估唤醒计划（R2.6.2 的「计划先于停 WiFi」逻辑原样保留）；
  3. **`if (wifi_mgr_up())` 才 `esp_wifi_stop()`**（顺带修复评审低项 10：
     轻唤醒从未起射频，旧代码空调 stop、语义错误）；
  4. 200ms 收尾延时（从原「日志后」挪到「二次校验前」）：让停机引发的
     异步掉线/STOP 事件落地并被短路，二次校验看到的是真实外部活动；
  5. **二次校验 `power_should_sleep()`**（修复 1a 核心）：有活动则打
     `W power: sleep aborted: activity during entry (busy=.. panel=..)`
     并清标志返回；被停掉的 WiFi 交由 slow_retry 恢复（见 2.5）；
  6. 校验通过才进入「提交段」：`overlay_zone_invalidate()` →
     `epd_panel_deep_sleep()` → ext0/定时器配置 → 日志 → RTC 标记 →
     `esp_deep_sleep_start()`。
- **`power_should_sleep()` 新增 `epd_panel_busy()` 硬判据**（修复 2）：
  整刷/快刷/清屏进行中一律不睡，不再只依赖各任务自觉报忙脉冲。
- **`power_self_lock_off()`**：注释更新 —— 「关机」同样走二次校验，活动期
  会被推迟到空闲后执行（idle_monitor 每秒重试），不再拦腰斩断刷新。
- **未动**：RTC noinit 标记结构（`PWR_RTC_MAGIC` 等）**布局零变动**，
  未追加字段（本批修复不需要新字段）；唤醒计划数学、SYNC 升格、看护
  唤醒全部原样。

### 2.3 `main/epd_drv.c` / `main/epd_drv.h`

- **新增 `s_panel_busy` 标志与 `epd_panel_busy()` 查询口**（修复 2）：
  - `epd_display_2bpp_wh()` / `epd_display_2bpp_wh_src()`：入口置位，
    `epd_cycle()` 返回（成功/3 连败，含全部重试出口）清除；
  - `epd_clear_cycles()`：入口置位，三个返回口清除；
  - `epd_fast_refresh()`：改为单出口结构（循环内 `return 0` → `ret=0;
    break`，行为零变化），入口置位、出口清除。
- **`epd_panel_deep_sleep()` 空指针防护**（修复 6 配套）：`s_spi == NULL`
  （SPI 未初始化）时直接跳过 —— 假唤醒早期回睡路径上面板本就处于深睡态，
  重发 0x07 无意义，同时避免 `spi_device_polling_transmit(NULL)` 崩溃。
- 电气序列（命令字节 / LUT / BUSY 判据 / 重试次数）**零变动**。

### 2.4 `main/main.c`

- **`display_task`：sleeping 窗口内暂缓一切 UI 事件**（修复 1b）：
  `power_sleeping()` 为真时不投忙脉冲、不碰面板，事件**重新入队** + 100ms
  短歇轮询。入睡成功 → 事件随深睡消亡（下一次唤醒由 pwr_sched 目标事件 +
  overlay 补刷机制重发，无丢失语义）；入睡中止 → 事件照常处理。
  **对规格的一处有意扩展**：规格原文只要求丢弃 `UI_EV_NET_CHANGED`；
  实现为暂缓**全部**事件（含 BOX_TICK/TIME_STEP 等），理由：
  a) 入睡窗口（~250ms）内启动任何面板序列要么打断入睡（浪费一轮）、
     要么被断电斩断（睡死复发）—— 只有两种坏结局，不如不做；
  b) 每类调度事件在唤醒侧都有重发兜底（BOX/MOVE/REMOTE/CAROUSEL 有
     pwr_sched 目标事件 + 补刷；NET 由重连后状态变化重投；TIME_STEP 由
     唤醒后 overlay 重建定时器吸收），暂缓不产生永久丢失；
  c) 相比「丢弃」，**暂缓**在入睡中止时还能把事件补做回来，语义更优。
- **`idle_monitor_task`**：注释更新（入睡可能返回，每秒轮询重试即可）。
- **`app_main` 新增 ext0 去抖**（修复 6）：`s_wake_src == WAKE_SRC_BUTTON`
  时再等 50ms 采样 GPIO25：仍为低 = 真按住，正常开机；已回高 = 假唤醒，
  `power_deep_sleep_now()` 直接回睡。放在 `store_init`/`epd_init` 之后：
  唤醒计划评估依赖的 settings/store/面板状态与轻唤醒路径完全一致；
  此刻无射频、无刷屏任务（面板仍在深睡态），满足强制入睡口的前置条件。

### 2.5 `main/wifi_mgr.c`

- **新增 `s_drv_stopped` 驱动停机跟踪**（修复 3）：`WIFI_EVENT_STA_STOP` /
  `WIFI_EVENT_AP_STOP`（`esp_wifi_stop()` 完成）置位，`STA_START` /
  `AP_START` 清除。
- **STA_DISCONNECTED 入睡短路**（修复 1b/3，睡死链闭合点）：
  `power_sleeping()` 为真时不 set_mode / 不 netif_ap_apply / 不 connect /
  不 dns_guard / 不投 NET_CHANGED，只把状态记账退到「热点待命 + 慢重试」。
- **`sta_attempt()` / `probe_once()` / `slow_retry_cb()` 入睡与停机闸**：
  入睡中或驱动停机态不发 connect、不做 DNS 探测。
- **新增 `recover_driver_stopped()` 恢复分支（对规格的必要补强，见 §3.1）**：
  入睡被二次校验中止后，驱动停在 stop 态 —— `esp_wifi_connect()` 对停机
  驱动只会报错，**规格设想的「交由现有 slow_retry 恢复」在原实现上走不通**。
  恢复序列与 `wifi_mgr_restart_join()` 同源：`set_mode(APSTA)` →
  `netif_ap_apply()` →（有 STA 凭据则置 joining）→ `esp_wifi_start()`，
  STA_START 事件里自动 connect；纯热点开机（无凭据）只拉回热点。
  由 `slow_retry_cb()` 周期（2 分钟）触发，已在局域网则直接清标记跳过
  （防竞态残影把纯 STA 拖回 APSTA）。
- 未动：连败抑制（RTC 计数）、AP/STA 决策、SNTP/mDNS/探测三连确认。

### 2.6 `main/netif_ap.c`

- **`netif_ap_apply()` 如实报错**（修复 3）：`esp_wifi_set_config(WIFI_IF_AP)`
  失败时打 `E netif_ap: SoftAP set_config FAILED: .. (NOT configured)` 并
  **提前返回** —— 不再走完 DHCP 配置后照打 "SoftAP configured"（R2.7.1
  实测把 `ESP_ERR_WIFI_STOP_STATE` 掩盖成成功日志，严重误导排障）。

### 2.7 版本统一（修复 4）

| 文件 | 旧 | 新 |
|------|----|----|
| `CMakeLists.txt` `PROJECT_VER`（esp_app_desc / OTA 页） | R2.6.2 | **R2.7.2** |
| `main/version.h` `MOINK_VERSION`（开机横幅同源） | R2.7.1 | **R2.7.2** |
| `page/index.html` `<meta moink-page-version>`（页脚显示） | R2.7.0 | **R2.7.2** |
| `main/index_html.h` | — | 按 `tools/make_index_header.py` 重新固化（gzip 往返校验通过） |
| `README.md` | 「本版」停在 R2.7.0 | 补 R2.7.2 节 |

> 注：项目自带的 `make_index_header.py` 有「页面 meta == MOINK_VERSION」
> 防漂移断言，R2.7.1 源码树本身已无法通过该断言（R2.7.0 vs R2.7.1），
> 印证了漂移。四处必须一起改齐才能重新固化。

### 2.8 `sdkconfig.defaults`（修复 5）

- `CONFIG_BT_NIMBLE_NVS_PERSIST` **n → y**：NimBLE 主机启动时持久化本地
  IRK 需要 NVS 后端，关闭时每次开机报
  `Failed to persist local IRK (rc=8)`（rc=8 = BLE_HS_ENOTSUP）。开启后
  落到既有 nvs 分区（0x4000），写入量每次开机几个键，磨损可忽略。
- **生效条件**：sdkconfig.defaults 仅在重新生成 sdkconfig 时生效。开发机
  已有本机 `sdkconfig` 的，需删除后重跑 `idf.py set-target esp32`，或在
  menuconfig 手动同步该项。
- 子工程 `verify_fw/`、`video_fw/` 的 sdkconfig.defaults 无 BLE 配置，不涉及。

### 2.9 `scripts/idf_stubs/esp_wifi.h` + `scripts/make_idf_stubs.py`

- 桩头补 `esp_wifi_get_mode()` 声明与 `WIFI_EVENT_STA_STOP` / 
  `WIFI_EVENT_AP_STOP` 事件号（仅宿主编译闸门用，两处同步改，重新生成
  桩头不丢失）。真机构建使用 IDF 原头文件，不受影响。

---

## 3. 与规格的偏离 / 根因判断说明（不静默偏离）

### 3.1 「WiFi 交由现有 slow_retry 机制恢复」原样走不通 —— 已补强

规格 1a 设想：入睡中止后「被 esp_wifi_stop 打断的 WiFi 交由现有 slow_retry
机制恢复」。分析 `slow_retry_cb()` 原实现：它只调 `esp_wifi_connect()`，
而 **connect 要求驱动处于 start 态** —— 对被 `esp_wifi_stop()` 停掉的驱动
只会返回错误、不产生任何事件，永不恢复（设备离线直到下一次深睡唤醒）。
因此按规格意图补了 `recover_driver_stopped()`（见 §2.5），由原 slow_retry
定时器（2 分钟节拍）触发，恢复的是「驱动 + 热点 + STA 重连」整链。
**建议真机验证**：入睡中止场景（见 §4 用例 V3）后 ≤2 分钟应看到
`slow retry: driver stopped by aborted sleep, restarting wifi` 并重新入网。

### 3.2 display_task 从「丢弃 NET_CHANGED」扩展为「暂缓全部事件」

理由见 §2.4。若坚持只丢 NET_CHANGED，BOX_TICK/TIME_STEP 仍可能在入睡
提交段（`epd_panel_deep_sleep` 内部 200ms 稳定等待）启动面板序列 —— 那是
一个真实的斩断窗口。暂缓方案把该窗口彻底关死，且中止时事件可补做。
**行为差异**：入睡中止后，被暂缓事件的屏效最多延迟 ~100ms×队列深度
（≤800ms）执行，无功能损失。

### 3.3 入睡顺序中 `epd_panel_deep_sleep()` 挪到二次校验之后

规格 1a 描述的旧顺序是「… epd_panel_deep_sleep → 200ms 延时 → 写 RTC
标记」。若保持面板先断电再校验，中止路径就得面对「面板已睡、刷新半途」
的恢复难题。现顺序：200ms 收尾 → 二次校验 → **才** 断面板电（其内部自带
200ms 稳定等待保留），中止路径上面板与快刷基准均完好（`overlay_zone_
invalidate` 同样后移到提交段）。

### 3.4 已知残余风险（量级评估）

1. **提交段竞态窗口 ≈200ms**（`epd_panel_deep_sleep` 内部延时）：二次
   校验通过到断电之间，理论上仍可能有活动启动。逐入口排查：UI 事件
   （display_task，已暂缓）、上传刷屏（需先完成秒级 HTTP 传输，赶不上）、
   远端拉取（秒级传输后才上屏，且启动即报 90s 忙脉冲 —— 但校验已过，
   拉取会随断电作废，**面板无斩断风险**，只是浪费一次拉取）。面板被斩断
   的理论路径已全部关闭；最坏残余 = 断电杀死一个在途 HTTP 拉取/上传。
2. **迟到掉线事件**：STA_DISCONNECTED 在 200ms 收尾内未派发、入睡已中止
   才派发（事件循环严重滞后时）→ 旧重连逻辑会对停机驱动执行并报错
   （现在会如实打出错误日志）。`s_drv_stopped` 恢复网在 ≤2 分钟内兜底
   重新拉起驱动。概率低、后果为日志噪声 + 短暂离线。
3. **ext0 去抖的快击代价**（修复 6）：开机到采样点 ≈0.25s，**总按压时长
   < 采样点的真人快击会被判为抖动而回睡**（第二次按键可正常唤醒并切图，
   唤醒键语义仍完整）。若实测反馈「按键唤醒偶尔失灵」，优先把采样点
   提前（`power_init()` 后立即采样，需先确认 `overlay_next_wake_s` 在
   `store_init` 前的安全性）或把 50ms 缩到 20ms。
4. **「关机」档行为变化**：活动期（刷屏/拉取）收到「关机」不再立即断电，
   推迟到空闲后由 idle_monitor 执行 —— 这是修复 1a 的必然推论（否则
   「关机」自己就能复现睡死）。页面提示语如需跟进后续版本再改。

### 3.5 本环境的编译验证边界

本交付在无 ESP-IDF v6.1 工具链的环境中完成，已通过项目自带的**宿主机
编译闸门**（`scripts/check_host.sh`：全部 `main/*.c` 以
`gcc -c -O2 -Wall -Wextra -Werror` + IDF 桩头零错误编译，纯 C 单测
`test_pwr_sched_v270` / `test_shift_geom` / `test_lut_ghost` 全部通过）。
**真机 `idf.py build` 未在本环境执行**，新增的 IDF API
（`esp_wifi_get_mode`、`WIFI_EVENT_STA_STOP/AP_STOP`）均为 v6.x 存在的
公开接口，但请以真机构建为准。

---

## 4. 建议的真机验证用例（对应用户实测故障）

| # | 用例 | 步骤 | 预期（关键日志） |
|---|------|------|------------------|
| V1 | 睡死不复现（原故障） | 连上 LAN，静置到 300s 空闲入睡 | `I power: sleep sequence: armed (idle timeout)` → `sta disconnect during sleep entry: skip reconnect/redraw`（**无** `lost LAN, reopening hotspot`、**无** `display 768x552` 紧跟入睡行）→ `deep sleep (...)`；屏幕保持完整画面 |
| V2 | 面板忙硬判据 | 在整刷进行中（如换位/传图）恰好到 300s 空闲 | 入睡被拒：`sleep aborted: activity during entry (busy=1 panel=1)`，刷新完整结束后下一轮再睡 |
| V3 | 入睡中止 + WiFi 恢复 | 入睡 200ms 窗口内制造活动（如刚好有 HTTP 请求/分钟刷新撞上） | `sleep aborted: ...` → ≤2 分钟内 `slow retry: driver stopped by aborted sleep, restarting wifi` → 重新 `joined LAN` |
| V4 | 轻唤醒链路保持 | 分钟局刷轻唤醒观察一晚 | 轻唤醒仍**不起射频**（无 wifi 日志）、≈4s 收尾入睡；入睡行前**无** `esp_wifi_stop` 调用（wifi_mgr_up=false 跳过）；时钟踩点局刷正常 |
| V5 | ext0 去抖 | 用短导线碰一下 GPIO25-GND（模拟抖动） | `btn wake was a glitch (high after 50ms), back to sleep`，~1s 内回睡，**不**空转 300s；真按住唤醒正常进配置页 |
| V6 | 版本一致性 | `idf.py build` 后开机 + 打开控制页 | 开机横幅 `=== MoInk R2.7.2 ...`；`/api/info` 的 `fw`/`ver` = R2.7.2；页脚「版本 R2.7.2」；OTA 页 esp_app_desc 同号 |
| V7 | IRK 告警消除 | 连续深睡唤醒 5+ 次 | 串口不再出现 `Failed to persist local IRK (rc=8)` |
| V8 | netif_ap 如实报错（回归） | 配网改热点名（正常运行态） | 正常路径仍打 `SoftAP 'xxx' configured`；失败路径（人为制造）打 `SoftAP set_config FAILED`，不再假打成功 |
| V9 | OTA 升级 | 从 R2.7.1 OTA 本包 | 分区表未变，直接 OTA 成功；升级后 V1/V4 复测通过 |

---

## 5. 兼容性声明

- **分区表 / 双 OTA / 回滚机制**：零变动（R2.7.1 可直接 OTA）。
- **RTC noinit 标记**（`PWR_RTC_MAGIC` / `PWR_RTC_FULL_MAGIC` /
  wifi_mgr 连败计数 / overlay/remote/ble 各自标记）：**结构布局零变动**，
  本批未追加字段、未改校验逻辑。
- **轻唤醒（BOX tick）链路**：不起射频、门控捷径、4s 收尾行为全部保留；
  额外收益 = 入睡不再空调 `esp_wifi_stop()`。
- **epd 电气序列**：命令字节序 / LUT / BUSY 判据 / 重试次数零变动，
  仅增加状态标志与出口收尾。
- **NVS 键 / 帧格式 api=2**：零变动。

## 6. 主机闸门结果（本交付环境）

```
== [2/3] 全量源 -c 编译（gcc） ==
all main/*.c compiled clean          （唯一 warning：wifi_event_handler
                                       未用参数 data，R2.7.1 既有，非本批引入）
== [3/3] 纯 C 单测 ==
PASS: test_pwr_sched_v270
PASS: test_shift_geom
PASS: test_lut_ghost
```
