#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""moink_style —— 「墨印远端」的设备端配置页图像管线移植（R2.2.1 配套）。

与固件配置页（page/index.html 的 warmMap + quantize）逐式一致，
由 scripts/verify_pipeline.py 用 node 跑页面原 JS 函数多组用例对拍证明。
远端软件产出的图片与配置页上传的图片观感完全相同。

R2.2.1：管线从「仅风格 + 色彩强度」扩展为【完整复刻配置页全部参数】：
  预处理: 亮度 / 对比度 / Gamma / 饱和度 → 自动色阶(0.5% 裁剪, 18..246, 可关)
          → 锐化（[1 2 1]×[1 2 1]/16 边缘钳位模糊的 unsharp，强度可调）
  风格:   natural 自然暖调 / adaptive 全面暖色 / gray 纯灰度 / naive 原色直出
          （natural/adaptive 的全部暖色参数：中心/跨度/冷色抑制/冷色上限/
            冷色去饱和/暖色吸引/吸引上限 + 色彩强度）
  量化:   色域 std（γ=1.75 分通道解码 + 解码空间四色目标）/ linear（线性光）
          / sRGB（不解码）；抖动算法 Floyd-Steinberg / Stucki / Jarvis /
          Burkes / Sierra Lite / Atkinson（五核误差扩散，蛇形）+ Bayer 8×8 +
          无抖动；抖动强度可调。
文字（便签语义）: 纯调色板色 + 就近吸附（无抖动，边缘干净）——同页面 snapIdx。

cfg 为 dict（键与页面 DEF 同名同默认，见 DEF_CFG）；normalize_cfg 补默认并夹取。
有 numpy 自动走向量化路径（预处理/风格/解码注入，位级一致）；误差扩散本质
串行，保持纯 Python。本文件与 moink_remote.pyw 同目录分发，勿单独移动。
"""
import math

# ---------------- 默认参数（= 页面 DEF，键名一一对应） ----------------
DEF_CFG = {
    "mode": "natural",
    "brightness": 0.0,          # -100..100
    "contrast": 0.0,            # -100..100
    "gamma": 1.0,               # 0.5..2.5
    "saturation": 1.0,          # 0..1（页面存 0..1，滑杆显示 %）
    "warmCast": 0.40,           # adaptive 色彩强度
    "castRamp": "sunset",
    "warmCenter": 30.0,         # °
    "warmSpan": 58.0,           # °
    "warmBoost": 0.60,          # natural 色彩强度
    "coolPull": 0.25,
    "coolCap": 60.0,
    "coolDesat": 0.25,
    "warmPull": 0.12,
    "warmPullCap": 18.0,
    "autoLevels": 1,
    "sharpen": 0.30,
    "dither": "fs",
    "ditherStrength": 0.85,
    "space": "std",
    "alg": "std",               # R2.3.0：std = 本页风格管线；gold/texture/level/ink = 四档算法
}
# 兼容旧字段名（R2.2.0 项目文件用 style/core 存风格与强度）
ALIAS = {"style": "mode", "core": None}

WARM_SAT_K = 0.75
DEF_WARM_BOOST = 0.60      # 兼容导出（moink_remote 旧引用）
DEF_WARM_CAST = 0.40
AUTO_LEVELS_CLIP = 0.005
DITHER_STRENGTH = 0.85     # 兼容导出

PAL_RGB = ((0.0, 0.0, 0.0), (255.0, 255.0, 255.0), (255.0, 255.0, 0.0), (255.0, 0.0, 0.0))

# ---------------- R2.3.0 四档出图算法（墨小佳/Reink Case 移植，qpoll-lite 同源） ----------------
# 移植自 qpoll-lite ReinkRaster.java（其本身逐行复刻自墨小佳 Flutter 官方算法）。
# 四档共用 redmean 最近色 + 自家调色板（黄 F5CD00 / 红 C80000，与标准管线的
# 纯 RGB 调色板不同——设备端色码语义相同：0黑/1白/2黄/3红）：
#   gold    鎏金：原图 + Atkinson（不套色彩矩阵）
#   texture 质感：LOMO 色彩矩阵(增益1.7/偏置-73.1) + Atkinson
#   level   色阶：纯量化、完全不抖动
#   ink     水墨：BT.601 灰度 + Atkinson
# Atkinson 核与标准管线的 atkinson 档不同：非蛇形（恒左→右）、误差全额 6×1/8
#（故意丢 2/8）、不带强度系数。与 Java 原版的差异仅一处：误差累加用 float64
#（Java 为 float32），页面 JS 与本文件双方 float64 逐位一致（verify_pipeline 对拍）。
REINK_MODES = ("gold", "texture", "level", "ink")
REINK_NAMES = {"gold": "鎏金", "texture": "质感", "level": "色阶", "ink": "水墨"}
REINK_HINTS = {
    "gold":    "原图 + Atkinson 抖动 · 官方默认，细节最全",
    "texture": "LOMO 调色 + Atkinson · 大片推白只留深部，最像官方效果",
    "level":   "纯量化不抖动 · 色块最大，最省电也最糊",
    "ink":     "灰阶 + Atkinson · 素描感，人脸最柔和",
}
REINK_PAL = ((0, 0, 0), (255, 255, 255), (245, 205, 0), (200, 0, 0))
REINK_LOMO = (1.7, 0.1, 0.1, 0.0, -73.1,
              0.0, 1.7, 0.1, 0.0, -73.1,
              0.0, 0.1, 1.6, 0.0, -73.1)
REINK_ATK = ((1, 0), (2, 0), (-1, 1), (0, 1), (1, 1), (0, 2))

# std 档分通道解码 LUT：255*(i/255)^1.75（三通道同式共用一张，同页面 STD_LUT）
DEC_LUT = [255.0 * (i / 255.0) ** 1.75 for i in range(256)]
_STD_Y = DEC_LUT[230]
# 解码空间四色目标（页面 STD_PAL；黄(255,dec230,0) 红(dec230,0,0)）
STD_PAL = ((0.0, 0.0, 0.0), (255.0, 255.0, 255.0),
           (255.0, _STD_Y, 0.0), (_STD_Y, 0.0, 0.0))
# 线性光档（页面 S2L_LUT / PAL_LIN）
def _s2l(v):
    v = 0.0 if v < 0 else (255.0 if v > 255 else v)
    v /= 255.0
    return 255.0 * (v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4)
S2L_LUT = [_s2l(i) for i in range(256)]
PAL_LIN = tuple(tuple(_s2l(c) for c in p) for p in PAL_RGB)

RAMPS = {"sunset": ((0.0, (0, 0, 0)), (0.10, (26, 6, 4)), (0.26, (92, 18, 12)),
                    (0.42, (168, 40, 16)), (0.56, (214, 86, 18)), (0.70, (236, 140, 26)),
                    (0.84, (248, 200, 60)), (0.93, (255, 235, 150)), (1.0, (255, 255, 255))),
         "ember": ((0.0, (0, 0, 0)), (0.12, (40, 4, 0)), (0.28, (120, 10, 4)),
                   (0.44, (196, 28, 6)), (0.58, (232, 74, 6)), (0.72, (246, 140, 10)),
                   (0.86, (252, 204, 26)), (0.95, (255, 240, 110)), (1.0, (255, 255, 255))),
         "duotone": ((0.0, (0, 0, 0)), (0.30, (150, 20, 10)), (0.55, (235, 80, 10)),
                     (0.78, (250, 190, 20)), (1.0, (255, 255, 255))),
         "sepia": ((0.0, (22, 14, 8)), (0.25, (92, 66, 38)), (0.50, (150, 116, 72)),
                   (0.72, (202, 172, 124)), (0.88, (232, 212, 172)), (1.0, (255, 250, 236)))}

# 误差扩散核（与页面 KERN 逐项一致；(dx, dy, 权重)，dx 在蛇行反向行取反）
KERN = {
    "fs":      ((1, 0, 7.0 / 16.0), (-1, 1, 3.0 / 16.0), (0, 1, 5.0 / 16.0), (1, 1, 1.0 / 16.0)),
    "atkinson": ((1, 0, 1 / 8.0), (2, 0, 1 / 8.0), (-1, 1, 1 / 8.0), (0, 1, 1 / 8.0),
                 (1, 1, 1 / 8.0), (0, 2, 1 / 8.0)),
    "burkes":  ((1, 0, 8 / 32.0), (2, 0, 4 / 32.0), (-2, 1, 2 / 32.0), (-1, 1, 4 / 32.0),
                (0, 1, 8 / 32.0), (1, 1, 4 / 32.0), (2, 1, 2 / 32.0)),
    "sierra":  ((1, 0, 2 / 4.0), (-1, 1, 1 / 4.0), (0, 1, 1 / 4.0)),
    "stucki":  ((1, 0, 8 / 42.0), (2, 0, 4 / 42.0), (-2, 1, 2 / 42.0), (-1, 1, 4 / 42.0),
                (0, 1, 8 / 42.0), (1, 1, 4 / 42.0), (2, 1, 2 / 42.0),
                (-2, 2, 1 / 42.0), (-1, 2, 2 / 42.0), (0, 2, 4 / 42.0), (1, 2, 2 / 42.0), (2, 2, 1 / 42.0)),
    "jarvis":  ((1, 0, 7 / 48.0), (2, 0, 5 / 48.0), (-2, 1, 3 / 48.0), (-1, 1, 5 / 48.0),
                (0, 1, 7 / 48.0), (1, 1, 5 / 48.0), (2, 1, 3 / 48.0),
                (-2, 2, 1 / 48.0), (-1, 2, 3 / 48.0), (0, 2, 5 / 48.0), (1, 2, 3 / 48.0), (2, 2, 1 / 48.0)),
}
BAYER8 = (0, 32, 8, 40, 2, 34, 10, 42, 48, 16, 56, 24, 50, 18, 58, 26,
          12, 44, 4, 36, 14, 46, 6, 38, 60, 28, 52, 20, 62, 30, 54, 22,
          3, 35, 11, 43, 1, 33, 9, 41, 51, 19, 59, 27, 49, 17, 57, 25,
          15, 47, 7, 39, 13, 45, 5, 37, 63, 31, 55, 23, 61, 29, 53, 21)

_ramp_cache = {}


def ramp_lut(name):
    """页面 rampLut：256 级三通道分段线性插值。"""
    if name in _ramp_cache:
        return _ramp_cache[name]
    stops = RAMPS.get(name, RAMPS["sunset"])
    xs = [s[0] for s in stops]
    cs = [[s[1][k] for s in stops] for k in range(3)]
    out = [0.0] * (256 * 3)
    for i in range(256):
        t = i / 255.0
        k = 0
        while k < len(xs) - 2 and t >= xs[k + 1]:
            k += 1
        for c in range(3):
            slope = (cs[c][k + 1] - cs[c][k]) / (xs[k + 1] - xs[k])
            out[i * 3 + c] = slope * (t - xs[k]) + cs[c][k]
    _ramp_cache[name] = out
    return out


def normalize_cfg(cfg):
    """补默认值 + 夹取 + 字段别名（style→mode；core→对应强度键）。"""
    c = dict(DEF_CFG)
    if cfg:
        for k, v in cfg.items():
            if k == "style":
                c["mode"] = v if v in ("natural", "adaptive", "gray", "naive") else "natural"
            elif k == "core":
                if c["mode"] == "natural":
                    c["warmBoost"] = _f(v, c["warmBoost"], 0.0, 1.0)
                elif c["mode"] == "adaptive":
                    c["warmCast"] = _f(v, c["warmCast"], 0.0, 1.0)
            elif k in c:
                c[k] = v
    c["mode"] = c["mode"] if c["mode"] in ("natural", "adaptive", "gray", "naive") else "natural"
    c["brightness"] = _f(c["brightness"], 0.0, -100.0, 100.0)
    c["contrast"] = _f(c["contrast"], 0.0, -100.0, 100.0)
    c["gamma"] = _f(c["gamma"], 1.0, 0.5, 2.5)
    c["saturation"] = _f(c["saturation"], 1.0, 0.0, 1.0)
    c["warmCast"] = _f(c["warmCast"], 0.40, 0.0, 1.0)
    c["castRamp"] = c["castRamp"] if c["castRamp"] in RAMPS else "sunset"
    c["warmCenter"] = _f(c["warmCenter"], 30.0, 0.0, 60.0)
    c["warmSpan"] = _f(c["warmSpan"], 58.0, 10.0, 120.0)
    c["warmBoost"] = _f(c["warmBoost"], 0.60, 0.0, 1.0)
    c["coolPull"] = _f(c["coolPull"], 0.25, 0.0, 1.0)
    c["coolCap"] = _f(c["coolCap"], 60.0, 0.0, 60.0)
    c["coolDesat"] = _f(c["coolDesat"], 0.25, 0.0, 1.0)
    c["warmPull"] = _f(c["warmPull"], 0.12, 0.0, 1.0)
    c["warmPullCap"] = _f(c["warmPullCap"], 18.0, 0.0, 60.0)
    c["autoLevels"] = 1 if c.get("autoLevels") else 0
    c["sharpen"] = _f(c["sharpen"], 0.30, 0.0, 1.0)
    c["dither"] = c["dither"] if c["dither"] in KERN or c["dither"] in ("bayer", "none") else "fs"
    c["ditherStrength"] = _f(c["ditherStrength"], 0.85, 0.0, 1.0)
    c["space"] = c["space"] if c["space"] in ("std", "linear", "srgb") else "std"
    # R2.3.0 四档出图算法："std" = 本页风格管线（默认，行为不变）；其余四档
    # 走 reink_codes 独立管线（预处理/风格/抖动/色域参数对四档一律无效）。
    c["alg"] = c.get("alg", "std") if c.get("alg", "std") in REINK_MODES else "std"
    return c


def _f(v, d, lo, hi):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return d
    return lo if v < lo else (hi if v > hi else v)


# ---------------- 基础函数（与页面 JS 逐式一致） ----------------

def _clamp(v, a, b):
    return a if v < a else (b if v > b else v)


def _mod(a, n):
    """JS mod(a,n) = ((a%n)+n)%n —— % 为 C fmod（截断语义，非 Python floor%）。
    必须用 math.fmod 精确复刻：正数区间 JS 也会经历「+n 再 fmod 回来」的一次
    有损舍入往返，Python 的 %（floor 语义）会跳过该步骤而产生 1ulp 漂移。"""
    return math.fmod(math.fmod(a, n) + n, n)


def _luma(r, g, b):
    return r * 0.2126 + g * 0.7152 + b * 0.0722


def _rgb2hsl(r, g, b):
    mx = r if r > g else g
    if b > mx: mx = b
    mn = r if r < g else g
    if b < mn: mn = b
    l = (mx + mn) * 0.5
    d = mx - mn
    den = (2 - mx - mn) if l > 0.5 else (mx + mn)
    s = (d / (den if den > 1e-12 else 1e-12)) if d > 1e-12 else 0
    s = _clamp(s, 0, 1)
    if d > 1e-12:
        rc = (mx - r) / d
        gc = (mx - g) / d
        bc = (mx - b) / d
        if mx == r:
            hh = bc - gc
        elif mx == g:
            hh = 2 + rc - bc
        else:
            hh = 4 + gc - rc
        h = _mod(hh / 6.0, 1.0)
    else:
        h = 0.0
    return h, s, l


def _hue2rgb(p, q, t):
    t = _mod(t, 1.0)
    if t < 1.0 / 6.0:
        return p + (q - p) * 6.0 * t
    if t < 0.5:
        return q
    if t < 2.0 / 3.0:
        return p + (q - p) * (2.0 / 3.0 - t) * 6.0
    return p


def _hsl2rgb(h, s, l):
    q = l * (1 + s) if l < 0.5 else l + s - l * s
    p = 2 * l - q
    return (_hue2rgb(p, q, h + 1.0 / 3.0), _hue2rgb(p, q, h), _hue2rgb(p, q, h - 1.0 / 3.0))


def _warm_affinity(hd):
    t_hi = _clamp((hd - 300) / 50, 0, 1)
    t_lo = _clamp((hd - 60) / 50, 0, 1)
    if hd > 300:
        return t_hi * t_hi * (3 - 2 * t_hi)
    if hd < 110:
        return 1 - t_lo * t_lo * (3 - 2 * t_lo)
    return 0.0


# ---------------- 预处理 + 风格映射（buf 就地修改，同页面 warmMap 前半） ----------------

def _pre_stage(buf, w, h, cfg):
    """亮度/对比度/Gamma → 自动色阶（可关）→ 锐化（强度可调）。"""
    n = w * h
    bright = cfg["brightness"]
    contrast = cfg["contrast"]
    gamma = cfg["gamma"]
    if bright or contrast or gamma != 1.0:
        for i in range(n * 3):
            v = buf[i]
            if bright:
                v += bright
            if contrast:
                v = (v - 128) * (1 + contrast / 100.0) + 128
            if gamma != 1.0:
                v = 255 * (_clamp(v, 0, 255) / 255.0) ** gamma
            buf[i] = _clamp(v, 0, 255)
    if cfg["autoLevels"]:
        hist = [0] * 256
        for i in range(n):
            L = _luma(buf[i * 3], buf[i * 3 + 1], buf[i * 3 + 2])
            v = int(L + 0.5)
            if v < 0: v = 0
            elif v > 255: v = 255
            hist[v] += 1
        target = AUTO_LEVELS_CLIP * n
        c = 0
        lo, hi = 0, 255
        for i in range(256):
            c += hist[i]
            if c >= target:
                lo = i
                break
        c = 0
        for i in range(256):
            c += hist[i]
            if c >= (1 - AUTO_LEVELS_CLIP) * n:
                hi = i
                break
        if hi - lo >= 8:
            scale = (246 - 18) / float(hi - lo)
            for i in range(n * 3):
                buf[i] = (buf[i] - lo) * scale + 18
        for i in range(n * 3):
            v = buf[i]
            buf[i] = 0.0 if v < 0 else (255.0 if v > 255 else v)
    sharpen = cfg["sharpen"]
    if sharpen > 0:
        tmp = [0.0] * (n * 3)
        bl = [0.0] * (n * 3)
        for y in range(h):
            for x in range(w):
                xm = x - 1 if x - 1 >= 0 else 0
                xp = x + 1 if x + 1 < w else w - 1
                o = (y * w + x) * 3
                for c2 in range(3):
                    tmp[o + c2] = (buf[(y * w + xm) * 3 + c2] + 2 * buf[o + c2] +
                                   buf[(y * w + xp) * 3 + c2])
        for y in range(h):
            ym = y - 1 if y - 1 >= 0 else 0
            yp = y + 1 if y + 1 < h else h - 1
            for x in range(w):
                o = (y * w + x) * 3
                for c2 in range(3):
                    bl[o + c2] = (tmp[(ym * w + x) * 3 + c2] + 2 * tmp[o + c2] +
                                  tmp[(yp * w + x) * 3 + c2]) * 0.0625
        for i in range(n * 3):
            v = buf[i] + sharpen * (buf[i] - bl[i])
            buf[i] = 0.0 if v < 0 else (255.0 if v > 255 else v)


def _map_natural(buf, n, cfg):
    warm_boost = cfg["warmBoost"]
    sat = cfg["saturation"]
    out = [0.0] * (n * 3)
    for i in range(n):
        r, g, b = buf[i * 3], buf[i * 3 + 1], buf[i * 3 + 2]
        h, s, l = _rgb2hsl(r / 255.0, g / 255.0, b / 255.0)
        hd = h * 360.0
        wa = _warm_affinity(hd)
        g2 = _clamp(warm_boost * wa, 0, 1)
        s2 = s ** (1 - WARM_SAT_K * g2)
        s2 = s2 * (1 - _clamp(cfg["coolDesat"] * (1 - wa), 0, 1))
        s2 = _clamp(s2 * sat, 0, 1)
        drift = -cfg["coolPull"] * (1 - wa) * (hd - 60)
        drift = _clamp(drift, -cfg["coolCap"], 0)
        d2 = _mod(cfg["warmCenter"] - hd + 540, 360) - 180
        pull = _clamp(cfg["warmPull"] * d2, -cfg["warmPullCap"], cfg["warmPullCap"])
        h2 = _mod(hd + drift + wa * pull, 360)
        fr, fg, fb = _hsl2rgb(h2 / 360.0, s2, l)
        out[i * 3] = _clamp(fr * 255.0, 0, 255)
        out[i * 3 + 1] = _clamp(fg * 255.0, 0, 255)
        out[i * 3 + 2] = _clamp(fb * 255.0, 0, 255)
    return out


def _map_adaptive(buf, n, cfg):
    cast = cfg["warmCast"]
    lut = ramp_lut(cfg["castRamp"])
    sat = cfg["saturation"]
    out = [0.0] * (n * 3)
    for i in range(n):
        r, g, b = buf[i * 3], buf[i * 3 + 1], buf[i * 3 + 2]
        h, s, l = _rgb2hsl(r / 255.0, g / 255.0, b / 255.0)
        hda = _mod(cfg["warmCenter"] + (h - 0.5) * cfg["warmSpan"], 360)
        ya = _hsl2rgb(hda / 360.0, s, l)
        r0, g0, b0 = ya[0] * 255.0, ya[1] * 255.0, ya[2] * 255.0
        lm = int(_clamp(_luma(r0, g0, b0), 0, 255) + 0.5)
        if lm < 0: lm = 0
        elif lm > 255: lm = 255
        r0 = r0 * (1 - cast) + lut[lm * 3] * cast
        g0 = g0 * (1 - cast) + lut[lm * 3 + 1] * cast
        b0 = b0 * (1 - cast) + lut[lm * 3 + 2] * cast
        h3, s3, l3 = _rgb2hsl(_clamp(r0, 0, 255) / 255.0,
                              _clamp(g0, 0, 255) / 255.0,
                              _clamp(b0, 0, 255) / 255.0)
        s3 = _clamp(s3 * sat, 0, 1)
        fr, fg, fb = _hsl2rgb(h3, s3, l3)
        out[i * 3] = _clamp(fr * 255.0, 0, 255)
        out[i * 3 + 1] = _clamp(fg * 255.0, 0, 255)
        out[i * 3 + 2] = _clamp(fb * 255.0, 0, 255)
    return out


def _map_gray(buf, n):
    out = [0.0] * (n * 3)
    for i in range(n):
        Lg = _clamp(_luma(buf[i * 3], buf[i * 3 + 1], buf[i * 3 + 2]), 0, 255)
        out[i * 3] = out[i * 3 + 1] = out[i * 3 + 2] = Lg
    return out


def style_map_cfg(rgb_bytes, w, h, cfg):
    """RGB 字节流 -> 映射后浮点缓冲（list[float]，长 w*h*3）。cfg 先 normalize。"""
    cfg = normalize_cfg(cfg)
    n = w * h
    buf = [float(b) for b in rgb_bytes]
    _pre_stage(buf, w, h, cfg)
    if cfg["mode"] == "natural":
        return _map_natural(buf, n, cfg)
    if cfg["mode"] == "adaptive":
        return _map_adaptive(buf, n, cfg)
    if cfg["mode"] == "gray":
        return _map_gray(buf, n)
    return buf                     # naive：原样


# ---------------- 量化（std/linear/srgb + 全部抖动算法，蛇形） ----------------

def _pal_and_decode(space):
    """返回 (palette, decode_lut)；decode_lut=None 表示不解码（srgb）。"""
    if space == "std":
        return STD_PAL, DEC_LUT
    if space == "linear":
        return PAL_LIN, S2L_LUT
    return PAL_RGB, None


def _diffuse(flat, w, h, pal, kernel, strength):
    """通用误差扩散（蛇形）：与页面 quantize 的 kernel 分支逐式一致。"""
    n = w * h
    out = bytearray(n)
    st = strength
    for yy in range(h):
        ltr = (yy % 2 == 0)
        base = yy * w * 3
        row = yy * w
        for ii in range(w):
            xx = ii if ltr else (w - 1 - ii)
            oo = base + xx * 3
            r = flat[oo]; g = flat[oo + 1]; b = flat[oo + 2]
            bd = (r - pal[0][0]) ** 2 + (g - pal[0][1]) ** 2 + (b - pal[0][2]) ** 2
            best = 0
            for k in (1, 2, 3):
                d = (r - pal[k][0]) ** 2 + (g - pal[k][1]) ** 2 + (b - pal[k][2]) ** 2
                if d < bd:
                    bd, best = d, k
            out[row + xx] = best
            if st <= 0:
                continue
            pp = pal[best]
            er = (flat[oo] - pp[0]) * st
            eg = (flat[oo + 1] - pp[1]) * st
            eb = (flat[oo + 2] - pp[2]) * st
            for (kx, ky, wg) in kernel:
                nx = xx + (kx if ltr else -kx)
                ny = yy + ky
                if 0 <= nx < w and ny < h:
                    no = (ny * w + nx) * 3
                    flat[no] += er * wg
                    flat[no + 1] += eg * wg
                    flat[no + 2] += eb * wg
    return bytes(out)


def quantize_cfg(mapped, w, h, cfg):
    """映射后浮点缓冲（list 或 numpy 数组）-> 2bpp 码表（0..3）。
    逐式对齐页面 quantize()：解码注入（numpy 向量化），误差扩散蛇行串行。"""
    cfg = normalize_cfg(cfg)
    n = w * h
    mode = cfg["dither"]
    strength = cfg["ditherStrength"]
    pal, dec = _pal_and_decode(cfg["space"])
    if _np is not None and isinstance(mapped, _np.ndarray):
        v = _np.clip(mapped.reshape(-1), 0.0, 255.0)
        if dec is not None:
            lut = _DEC if dec is DEC_LUT else _S2L
            flat = lut[(v + 0.5).astype(_np.int64)].tolist()
        else:
            flat = v.tolist()
    else:
        flat = list(mapped)
        if dec is not None:
            for i in range(n * 3):
                v = flat[i]
                if v < 0: v = 0.0
                elif v > 255: v = 255.0
                flat[i] = dec[int(v + 0.5)]

    def nearest(o):
        r, g, b = flat[o], flat[o + 1], flat[o + 2]
        bd = (r - pal[0][0]) ** 2 + (g - pal[0][1]) ** 2 + (b - pal[0][2]) ** 2
        best = 0
        for k in (1, 2, 3):
            d = (r - pal[k][0]) ** 2 + (g - pal[k][1]) ** 2 + (b - pal[k][2]) ** 2
            if d < bd:
                bd, best = d, k
        return best

    out = bytearray(n)
    if mode == "none":
        for i in range(n):
            out[i] = nearest(i * 3)
        return bytes(out)
    if mode == "bayer":
        amp = strength * 128
        for y in range(h):
            rowb = (y & 7) * 8
            for x in range(w):
                o = (y * w + x) * 3
                off = (BAYER8[rowb + (x & 7)] / 64.0 - 0.5) * amp
                for c in range(3):
                    v = flat[o + c] + off
                    flat[o + c] = 0.0 if v < 0 else (255.0 if v > 255 else v)
                out[y * w + x] = nearest(o)
        return bytes(out)
    return _diffuse(flat, w, h, pal, KERN[mode], strength)


def device_codes_cfg(rgb_bytes, w, h, cfg):
    """RGB 字节流 -> 2bpp 码表（设备端配置页完整管线：预处理+风格+量化）。
    cfg 键见 DEF_CFG（style/core 兼容别名）。numpy 可用时自动加速预处理/风格。
    R2.3.0：cfg["alg"] ∈ REINK_MODES 时改走四档出图算法（reink_codes），
    预处理/风格/抖动/色域参数对四档无效（与页面 alg 下拉一致）。"""
    cfg = normalize_cfg(cfg)
    if cfg.get("alg", "std") in REINK_MODES:
        return reink_codes(rgb_bytes, w, h, cfg["alg"])
    if _np is not None:
        return quantize_cfg(_np_style_map(rgb_bytes, w, h, cfg), w, h, cfg)
    return quantize_cfg(style_map_cfg(rgb_bytes, w, h, cfg), w, h, cfg)


# ---------------- 兼容旧接口（R2.2.0：仅风格 + 色彩强度） ----------------

def style_map(rgb_bytes, w, h, mode, core):
    return style_map_cfg(rgb_bytes, w, h, {"mode": mode, "core": core})


def device_codes(rgb_bytes, w, h, mode, core):
    return device_codes_cfg(rgb_bytes, w, h, {"mode": mode, "core": core})


# ---------------- R2.3.0 四档出图算法（redmean + Atkinson，逐式移植 ReinkRaster） ----------------

def _reink_nearest(r, g, b):
    """redmean 最近色。整数运算（Java/JS/Py 三方逐式一致）：
    先对 0..255 浮点采样 round-half-up 取整，再按 redmean 加权距离选色。"""
    sr = int(math.floor(_clamp(r, 0.0, 255.0) + 0.5))
    sg = int(math.floor(_clamp(g, 0.0, 255.0) + 0.5))
    sb = int(math.floor(_clamp(b, 0.0, 255.0) + 0.5))
    best = 0
    bd = -1
    for k in range(4):
        pr = REINK_PAL[k][0]
        pg = REINK_PAL[k][1]
        pb = REINK_PAL[k][2]
        dr = sr - pr
        dg = sg - pg
        db = sb - pb
        mean = (sr + pr) // 2
        d = ((512 + mean) * dr * dr) >> 8
        d += 4 * dg * dg
        d += ((767 - mean) * db * db) >> 8
        if bd < 0 or d < bd:
            bd = d
            best = k
    return best


def reink_codes(rgb_bytes, w, h, alg):
    """RGB 字节流 -> 2bpp 码表（四档出图算法之一，cfg.alg=alg）。

    与页面 reinkQuantize() 逐式一致（verify_pipeline 对拍证明）：
      gold    原图 + Atkinson；texture LOMO 矩阵 + Atkinson；
      level   纯量化（不抖动）；ink     BT.601 灰度 + Atkinson。
    半透明像素按白底合成（RGBA 输入时）；四档共用 REINK_PAL 与 redmean 最近色。
    误差扩散恒左→右（非蛇形）、全额误差 6 邻居 × 1/8（故意丢 2/8）。
    """
    if alg not in REINK_MODES:
        raise ValueError("alg must be one of %s" % (REINK_MODES,))
    n = w * h
    src = bytes(rgb_bytes)
    # 通道拆分（+ alpha 白底合成）。输入多为 RGB 三字节流（alpha 恒 255）。
    if len(src) == n * 4:
        rs = [0.0] * n
        gs = [0.0] * n
        bs = [0.0] * n
        for i in range(n):
            a = src[i * 4 + 3] / 255.0
            rs[i] = src[i * 4] * a + 255.0 * (1.0 - a)
            gs[i] = src[i * 4 + 1] * a + 255.0 * (1.0 - a)
            bs[i] = src[i * 4 + 2] * a + 255.0 * (1.0 - a)
    elif len(src) == n * 3:
        rs = [float(src[i * 3]) for i in range(n)]
        gs = [float(src[i * 3 + 1]) for i in range(n)]
        bs = [float(src[i * 3 + 2]) for i in range(n)]
    else:
        raise ValueError("rgb_bytes length mismatch")

    # 预变换：质感 = LOMO 色彩矩阵；水墨 = BT.601 灰度；鎏金/色阶 = 原图
    if alg == "texture":
        m = REINK_LOMO
        for i in range(n):
            r0 = rs[i]
            g0 = gs[i]
            b0 = bs[i]
            rs[i] = _clamp(m[0] * r0 + m[1] * g0 + m[2] * b0 + m[3] * 255.0 + m[4], 0.0, 255.0)
            gs[i] = _clamp(m[5] * r0 + m[6] * g0 + m[7] * b0 + m[8] * 255.0 + m[9], 0.0, 255.0)
            bs[i] = _clamp(m[10] * r0 + m[11] * g0 + m[12] * b0 + m[13] * 255.0 + m[14], 0.0, 255.0)
    elif alg == "ink":
        for i in range(n):
            lum = 0.299 * rs[i] + 0.587 * gs[i] + 0.114 * bs[i]
            rs[i] = lum
            gs[i] = lum
            bs[i] = lum

    out = bytearray(n)

    if alg == "level":
        # 色阶：纯量化，一个点都不抖
        for i in range(n):
            out[i] = _reink_nearest(rs[i], gs[i], bs[i])
        return bytes(out)

    # Atkinson 误差扩散（gold / texture / ink 共用）
    er = [0.0] * n
    eg = [0.0] * n
    eb = [0.0] * n
    pal = REINK_PAL
    for y in range(h):
        rowb = y * w
        for x in range(w):
            i = rowb + x
            sr = _clamp(rs[i] + er[i], 0.0, 255.0)
            sg = _clamp(gs[i] + eg[i], 0.0, 255.0)
            sb = _clamp(bs[i] + eb[i], 0.0, 255.0)
            code = _reink_nearest(sr, sg, sb)
            out[i] = code
            pc = pal[code]
            dr = sr - pc[0]
            dg = sg - pc[1]
            db = sb - pc[2]
            for (kx, ky) in REINK_ATK:
                tx = x + kx
                ty = y + ky
                if tx < 0 or tx >= w or ty >= h:
                    continue
                t = ty * w + tx
                er[t] += dr / 8.0
                eg[t] += dg / 8.0
                eb[t] += db / 8.0
    return bytes(out)


# ---------------- 文字吸附（便签语义：纯色 + 就近，无抖动） ----------------

def snap_codes(rgb_bytes, w, h):
    """RGB 字节流 -> 就近吸附四色码表（页面 snapIdx：RGB 空间距离，无误差扩散）。"""
    if _np is not None:
        return _np_snap_codes(rgb_bytes, w, h)
    n = w * h
    out = bytearray(n)
    p0, p1, p2, p3 = PAL_RGB
    for i in range(n):
        r = rgb_bytes[i * 3]; g = rgb_bytes[i * 3 + 1]; b = rgb_bytes[i * 3 + 2]
        bd = (r - p0[0]) ** 2 + (g - p0[1]) ** 2 + (b - p0[2]) ** 2
        best = 0
        for k, p in ((1, p1), (2, p2), (3, p3)):
            d = (r - p[0]) ** 2 + (g - p[1]) ** 2 + (b - p[2]) ** 2
            if d < bd:
                bd, best = d, k
        out[i] = best
    return bytes(out)


# ================= numpy 加速路径（位级与纯 Python 一致，对拍验证） =================

try:
    import numpy as _np
except Exception:                                  # pragma: no cover
    _np = None

if _np is not None:
    _DEC = _np.array(DEC_LUT, dtype=_np.float64)
    _S2L = _np.array(S2L_LUT, dtype=_np.float64)
    _RAMP = {k: _np.array(ramp_lut(k), dtype=_np.float64).reshape(256, 3) for k in RAMPS}

    def _np_mod_js(a, n):
        return _np.fmod(_np.fmod(a, n) + n, n)

    def _np_rgb2hsl(r, g, b):
        mx = _np.maximum(_np.maximum(r, g), b)
        mn = _np.minimum(_np.minimum(r, g), b)
        l = (mx + mn) * 0.5
        d = mx - mn
        den = _np.where(l > 0.5, 2 - mx - mn, mx + mn)
        with _np.errstate(divide="ignore", invalid="ignore"):
            s = _np.where(d > 1e-12, d / _np.maximum(den, 1e-12), 0.0)
            rc = (mx - r) / d
            gc = (mx - g) / d
            bc = (mx - b) / d
        s = _np.clip(s, 0.0, 1.0)
        hh = _np.where(mx == r, bc - gc, _np.where(mx == g, 2 + rc - bc, 4 + gc - rc))
        h = _np.where(d > 1e-12, _np_mod_js(hh / 6.0, 1.0), 0.0)
        return h, s, l

    def _np_hue2rgb(p, q, t):
        t = _np_mod_js(t, 1.0)
        v1 = p + (q - p) * 6.0 * t
        v3 = p + (q - p) * (2.0 / 3.0 - t) * 6.0
        out = p
        out = _np.where(t < 2.0 / 3.0, v3, out)
        out = _np.where(t < 0.5, q, out)
        out = _np.where(t < 1.0 / 6.0, v1, out)
        return out

    def _np_hsl2rgb(h, s, l):
        q = _np.where(l < 0.5, l * (1 + s), l + s - l * s)
        p = 2 * l - q
        return (_np_hue2rgb(p, q, h + 1.0 / 3.0),
                _np_hue2rgb(p, q, h),
                _np_hue2rgb(p, q, h - 1.0 / 3.0))

    def _np_warm_affinity(hd):
        t_hi = _np.clip((hd - 300) / 50, 0, 1)
        t_lo = _np.clip((hd - 60) / 50, 0, 1)
        return _np.where(hd > 300, t_hi * t_hi * (3 - 2 * t_hi),
                         _np.where(hd < 110, 1 - t_lo * t_lo * (3 - 2 * t_lo), 0.0))

    def _np_pre(a, cfg):
        """a: (h, w, 3) float64 —— 亮度/对比度/Gamma → 自动色阶 → 锐化（就地）。
        顺序与 JS 逐式一致：brightness → contrast → gamma(对 clamp 后的值) → clamp。"""
        h, w, _ = a.shape
        n = w * h
        bright, contrast, gamma = cfg["brightness"], cfg["contrast"], cfg["gamma"]
        if bright or contrast or gamma != 1.0:
            v = a
            if bright:
                v = v + bright
            if contrast:
                v = (v - 128) * (1 + contrast / 100.0) + 128
            a[:] = v
            if gamma != 1.0:
                a[:] = 255.0 * _np.power(_np.clip(a, 0.0, 255.0) / 255.0, gamma)
            _np.clip(a, 0.0, 255.0, out=a)
        if cfg["autoLevels"]:
            flat = a.reshape(-1, 3)
            lum = flat[:, 0] * 0.2126 + flat[:, 1] * 0.7152 + flat[:, 2] * 0.0722
            idx = _np.clip(_np.floor(lum + 0.5).astype(_np.int64), 0, 255)
            hist = _np.bincount(idx, minlength=256).astype(_np.float64)
            csum = _np.cumsum(hist)
            lo = int(_np.searchsorted(csum, AUTO_LEVELS_CLIP * n, side="left"))
            lo = min(lo, 255)
            hi = int(_np.searchsorted(csum, (1 - AUTO_LEVELS_CLIP) * n, side="left"))
            hi = min(hi, 255)
            if hi - lo >= 8:
                scale = (246 - 18) / float(hi - lo)
                flat[:] = (flat - lo) * scale + 18
            _np.clip(a, 0.0, 255.0, out=a)
        if cfg["sharpen"] > 0:
            pp = _np.pad(a, ((1, 1), (1, 1), (0, 0)), mode="edge")
            core_rows = pp[1:-1]
            tmp = core_rows[:, :-2] + 2 * core_rows[:, 1:-1] + core_rows[:, 2:]
            q = _np.pad(tmp, ((1, 1), (0, 0), (0, 0)), mode="edge")
            bl = (q[:-2] + 2 * q[1:-1] + q[2:]) * 0.0625
            a += cfg["sharpen"] * (a - bl)
            _np.clip(a, 0.0, 255.0, out=a)
        return a

    def _np_map(a, cfg):
        """a: (h, w, 3) float64（已过 _np_pre）——> 映射后 (h, w, 3) float64。"""
        mode = cfg["mode"]
        if mode == "naive":
            return a
        if mode == "gray":
            lum = a[:, :, 0] * 0.2126 + a[:, :, 1] * 0.7152 + a[:, :, 2] * 0.0722
            lum = _np.clip(lum, 0.0, 255.0)
            return _np.stack([lum, lum, lum], axis=2)
        r = a[:, :, 0] / 255.0
        g = a[:, :, 1] / 255.0
        b = a[:, :, 2] / 255.0
        h, s, l = _np_rgb2hsl(r, g, b)
        if mode == "natural":
            hd = h * 360.0
            wa = _np_warm_affinity(hd)
            g2 = _np.clip(cfg["warmBoost"] * wa, 0.0, 1.0)
            s2 = _np.power(s, 1 - WARM_SAT_K * g2)
            s2 = s2 * (1 - _np.clip(cfg["coolDesat"] * (1 - wa), 0.0, 1.0))
            s2 = _np.clip(s2 * cfg["saturation"], 0.0, 1.0)
            drift = _np.clip(-cfg["coolPull"] * (1 - wa) * (hd - 60), -cfg["coolCap"], 0.0)
            d2 = _np_mod_js(cfg["warmCenter"] - hd + 540, 360) - 180
            pull = _np.clip(cfg["warmPull"] * d2, -cfg["warmPullCap"], cfg["warmPullCap"])
            h2 = _np_mod_js(hd + drift + wa * pull, 360)
            fr, fg, fb = _np_hsl2rgb(h2 / 360.0, s2, l)
        else:                                            # adaptive
            hda = _np_mod_js(cfg["warmCenter"] + (h - 0.5) * cfg["warmSpan"], 360)
            yr, yg, yb = _np_hsl2rgb(hda / 360.0, s, l)
            r0, g0, b0 = yr * 255.0, yg * 255.0, yb * 255.0
            lum = r0 * 0.2126 + g0 * 0.7152 + b0 * 0.0722
            lm = _np.clip(_np.floor(_np.clip(lum, 0.0, 255.0) + 0.5), 0, 255).astype(_np.int64)
            cast = cfg["warmCast"]
            ramp = _RAMP[cfg["castRamp"]]
            r0 = r0 * (1 - cast) + ramp[lm, 0] * cast
            g0 = g0 * (1 - cast) + ramp[lm, 1] * cast
            b0 = b0 * (1 - cast) + ramp[lm, 2] * cast
            h3, s3, l3 = _np_rgb2hsl(_np.clip(r0, 0, 255) / 255.0,
                                     _np.clip(g0, 0, 255) / 255.0,
                                     _np.clip(b0, 0, 255) / 255.0)
            s3 = _np.clip(s3 * cfg["saturation"], 0.0, 1.0)
            fr, fg, fb = _np_hsl2rgb(h3, s3, l3)
        out = _np.stack([fr * 255.0, fg * 255.0, fb * 255.0], axis=2)
        return _np.clip(out, 0.0, 255.0)

    def _np_style_map(rgb_bytes, w, h, cfg):
        a = _np.frombuffer(bytes(rgb_bytes), dtype=_np.uint8).astype(_np.float64)
        a = a.reshape(h, w, 3).copy()
        _np_pre(a, cfg)
        return _np_map(a, cfg)

    def _np_snap_codes(rgb_bytes, w, h):
        """就近吸附（numpy 路径）：与纯 Python 位级一致（对拍验证）。"""
        a = _np.frombuffer(bytes(rgb_bytes), dtype=_np.uint8).reshape(h, w, 3).astype(_np.float64)
        r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
        best = _np.zeros((h, w), dtype=_np.int64)
        pal = _np.array(PAL_RGB)
        bd = (r - pal[0][0]) ** 2 + (g - pal[0][1]) ** 2 + (b - pal[0][2]) ** 2
        for k in (1, 2, 3):
            d = (r - pal[k][0]) ** 2 + (g - pal[k][1]) ** 2 + (b - pal[k][2]) ** 2
            m = d < bd
            best[m] = k
            bd = _np.where(m, d, bd)
        return best.astype(_np.uint8).tobytes()
