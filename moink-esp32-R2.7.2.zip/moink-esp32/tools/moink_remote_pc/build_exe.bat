@echo off
chcp 65001 >nul
echo [MoInK] 安装打包依赖（首次较慢）...
python -m pip install pillow pyinstaller
echo.
echo [MoInK] 开始打包（产物在 dist\墨印远端.exe）...
python -m PyInstaller --noconfirm --onefile --windowed --name 墨印远端 moink_remote.pyw
echo.
if exist "dist\墨印远端.exe" (echo 打包完成：dist\墨印远端.exe) else (echo 打包失败，请把上面的报错发给开发者)
pause
