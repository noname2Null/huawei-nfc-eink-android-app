#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨印远端 · MoInk Remote — Windows 端远端内容服务器（R2.3.0 配套）
====================================================================

配合「墨印 MoInk」电子相框固件 R2.3.0 的远端拉取功能（设备端见
main/remote.c / 协议注释 main/remote.h）。在本机（或局域网内任意电脑）运行，
设备按你设置的间隔来拉取屏幕内容。

R2.3.0 相对 R2.2.2 的变更：
  - 新增「算法」四档出图（墨小佳/Reink Case 移植）：gold 鎏金 / texture 质感 /
    level 色阶 / ink 水墨，std = 原风格管线不变；选四档时标准调色/抖动/色域/
    自动色阶整体置灰（算法自带预变换与 Atkinson 抖动）。
  - 其余同 R2.2.2（完整配置复刻 / 屏幕方向 / 跟随上报 / 铺满裁切修复）。
R2.2.2 相对 R2.2.1 的变更：
  - 修复铺满裁切模式「图片缺失」：裁切位置钳制 _clamp_int 少传 default
    参数（TypeError → 白底红字占位图，重选图片无效）；
  - 其余同 R2.2.1（完整配置复刻 / 屏幕方向 / 跟随上报）。
R2.2.1 相对 R2.2.0 的变更：
  · ★ 图片配置【完整复刻设备端配置页】（对拍证明：scripts/verify_pipeline_r221.py
    69 组用例与页面真源 JS 逐字节一致）：
      裁切 —— 铺满裁切（横向/纵向裁切位置可调，同配置页拖动裁剪框）/
              完整留边（底色可选）；四边留白（px，逐边开关，同配置页「留白」）；
      旋转 —— 90° 步进（左旋/右旋）+ 角度微调（-180..180°，同配置页 rotRange）；
      抖动 —— Floyd-Steinberg / Stucki / Jarvis / Burkes / Sierra Lite /
              Atkinson / Bayer 8×8 / 无抖动，抖动强度可调；
      调色 —— 四风格 + 色彩强度 + 亮度/对比度/Gamma/饱和度 + 暖色全套
              （中心/跨度/冷色抑制/冷色上限/冷色去饱和/暖色吸引/吸引上限）+
              锐化 + 自动色阶 + 色域（标准/线性光/sRGB）；
  · ★ 屏幕方向（以屏幕排线为基准 0=下/1=左/2=上/3=右，同固件 settings.orient）：
      画布尺寸随方向（竖屏 552×768 / 横屏 768×552）、打包/分割子帧形状随方向
      （与固件 frame.c/overlay.c 同源，sim_orient_geom.py 机器证明）；
      设备每次拉取上报当前方向 —— 「跟随设备上报」开启时（默认）自动切换默认
      画布并提示；手动改过方向则以你的设置优先（仅提示不切换）。

R2.2.0 的修复保留：预览用 PIL.ImageTk（预览框正常显示）；管线逐字节对齐；
懒构建 + 0.35s 防抖；EXIF 方向转正；exe 打包路径感知；坏条目自愈。

运行：run.bat（或已装 Python 的机器双击本文件）；依赖安装：install_deps.bat；
成品打包：build_exe.bat。依赖：Python 3.8+，Pillow（必需）；numpy（建议，提速）。
同目录文件：moink_style.py（设备端图像管线，勿单独移动/删除）。
"""

import hashlib
import json
import os
import queue
import random
import struct
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk
except ImportError:
    print("缺少 Pillow：请先执行  pip install pillow")
    sys.exit(1)

try:                                    # 可选：仅提速（约 3 倍），缺了走纯 Python 回退
    import numpy as _np
except Exception:
    _np = None

try:
    import moink_style as MS            # 设备端图像管线（同目录，随本程序分发）
except ImportError:
    # 个别启动方式不把脚本目录放进 sys.path：手动补一次再试
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import moink_style as MS
    except ImportError:
        print("缺少 moink_style.py：请把它和 moink_remote.pyw 放在同一文件夹")
        sys.exit(1)

import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# PyInstaller 打包后 __file__ 指向解压临时目录（退出即删）→ 项目文件改放 exe 旁
if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(APP_DIR, "assets")
PROJECT_JSON = os.path.join(APP_DIR, "moink_remote_project.json")
LOG_PATH = os.path.join(APP_DIR, "moink_remote_log.txt")

# ---------------- 屏幕参数（与固件/控制页契约一致） ----------------
BOX_H = 160                        # 分割式顶部信息框条带高
ROWS = 552                         # 载荷行数（面板画布 PC 的列数）
RB_FULL = 192                      # 全帧每行字节数（768px/4）
PC_W, PC_H = 552, 768              # 面板画布 PC（固定；用户画布按方向旋转到 PC）

# R2.2.1：屏幕方向（以排线为基准，同固件 settings.h SETT_ORIENT_*）
ORIENT_NAMES = ["排线在下（竖屏 552×768）", "排线在左（横屏 768×552）",
                "排线在上（竖屏 552×768）", "排线在右（横屏 768×552）"]
ORIENT_SHORT = ["排线在下", "排线在左", "排线在上", "排线在右"]


def orient_user_dims(o):
    """方向 -> 用户视角画布（宽, 高）。竖屏 0/2 = 552×768；横屏 1/3 = 768×552。"""
    return (768, 552) if o in (1, 3) else (552, 768)


def sub_shape(o, split):
    """方向 + 样式 -> 分割子帧（行数, 每行字节）/ 全帧（552, 192）。
    与固件 remote.c sub_shape / frame.c 三方一致（sim_orient_geom.py 证明）。"""
    if not split:
        return ROWS, RB_FULL
    if o in (1, 3):
        return ROWS - 160, RB_FULL      # 392 段 × 整载荷行 192B
    return ROWS, RB_FULL - 40           # 552 段 × 152B 字节段


# 2bpp 色码：0=黑 1=白 2=黄 3=红（管线真源在 moink_style.PAL_RGB，浮点；
# 绘图/putpalette 需要 int 版）
PAL_RGB = [tuple(int(c) for c in rgb) for rgb in MS.PAL_RGB]

# 预览调色板（P 模式 putpalette 用：RGBRGB + 0 补齐到 768）
_PALETTE_PAD = [c for rgb in PAL_RGB for c in rgb] + [0] * 756

# 风格选项（文案与默认值 = 设备端配置页 CORE 表）
STYLES = [
    ("natural", "自然暖调", MS.DEF_CFG["warmBoost"],
     "只提亮画面里本来就是暖色的部分，冷色区域保持干净的黑白。"),
    ("adaptive", "全面暖色", MS.DEF_CFG["warmCast"],
     "把整圈色相压进红→黄这一段，红黄最多，但照片会明显偏暖。"),
    ("gray", "纯灰度", 0.0,
     "纯灰度，只做明暗抖动。适合文档、线条画。"),
    ("naive", "原色直出", 0.0,
     "不做任何色彩映射，直接四色抖动。"),
]
STYLE_NAMES = [s[1] for s in STYLES]
STYLE_BY_NAME = {s[1]: s[0] for s in STYLES}
STYLE_META = {s[0]: s for s in STYLES}

# 抖动算法（文案 = 设备端配置页 DMODE 表）
DITHERS = [
    ("fs", "Floyd-Steinberg"), ("stucki", "Stucki"), ("jarvis", "Jarvis"),
    ("burkes", "Burkes"), ("sierra", "Sierra Lite"), ("atkinson", "Atkinson"),
    ("bayer", "Bayer 8×8"), ("none", "无抖动"),
]
DITHER_NAMES = [d[1] for d in DITHERS]
DITHER_BY_NAME = {d[1]: d[0] for d in DITHERS}
SPACES = [("std", "标准"), ("linear", "线性光"), ("srgb", "sRGB")]
SPACE_NAMES = [s[1] for s in SPACES]
SPACE_BY_NAME = {s[1]: s[0] for s in SPACES}

# 高级调色滑杆（键/标签/最小/最大/刻度/换算 —— 同配置页 CTRL 表与滑杆范围）
ADV_SLIDERS = [
    ("brightness", "亮度", -100, 100, 1.0),
    ("contrast", "对比度", -100, 100, 1.0),
    ("gamma", "伽马", 50, 250, 100.0),          # 值/100
    ("saturation", "饱和度", 0, 100, 100.0),    # 值/100
    ("warmCenter", "暖色中心", 0, 60, 1.0),
    ("warmSpan", "暖色跨度", 10, 120, 1.0),
    ("coolPull", "冷色抑制", 0, 100, 100.0),
    ("coolCap", "冷色上限", 0, 60, 1.0),
    ("coolDesat", "冷色去饱和", 0, 100, 100.0),
    ("warmPull", "暖色吸引", 0, 100, 100.0),
    ("warmPullCap", "暖色吸引上限", 0, 60, 1.0),
    ("sharpen", "锐化", 0, 100, 100.0),
    ("ditherStrength", "抖动强度", 0, 100, 100.0),
]
ADV_DEFAULT = {k: MS.DEF_CFG[k] for k, _, _, _, _ in ADV_SLIDERS}


# ================= 2bit 数据管线（打包与设备逐字节一致，已机器证明） =================

def crc16_ccitt(data):
    crc = 0xFFFF
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if (crc & 0x8000) else (crc << 1) & 0xFFFF
    return crc


def _to_pc(flat, w, h, orient):
    """用户画布码表 -> 面板画布 PC（552×768）。方向旋转为纯索引置换
    （sim_orient_geom.py 证明；o0 恒等 —— 与历史字节完全一致）。"""
    n = PC_W * PC_H
    if orient == 0:
        return bytes(flat)
    out = bytearray(n)
    if _np is not None:
        a = _np.frombuffer(bytes(flat), dtype=_np.uint8).reshape(h, w)
        if orient == 2:
            pc = _np.rot90(a, 2)
        elif orient == 1:
            pc = _np.flipud(a.T)
        else:
            pc = _np.fliplr(a.T)
        out[:] = pc.tobytes()
        return bytes(out)
    if orient == 2:
        for dy in range(PC_H):
            for dx in range(PC_W):
                out[dy * PC_W + dx] = flat[(PC_H - 1 - dy) * w + (PC_W - 1 - dx)]
    elif orient == 1:
        for dy in range(PC_H):
            for dx in range(PC_W):
                out[dy * PC_W + dx] = flat[dx * w + (PC_H - 1 - dy)]
    else:
        for dy in range(PC_H):
            for dx in range(PC_W):
                out[dy * PC_W + dx] = flat[(PC_W - 1 - dx) * w + dy]
    return bytes(out)


def _pack_pc(pc_flat, rb):
    """PC 码表（552×768 行主序）-> 载荷段（rb=192 全帧；152 分割段用 _extract_sub）。
    契约 = 设备上传链路 packIdx(rotateCW(PC))（与页面/固件逐字节一致，已证明）。"""
    if _np is not None:
        a = (_np.frombuffer(bytes(pc_flat), dtype=_np.uint8).reshape(PC_H, PC_W) & 3)
        b = a[:, ::-1]                 # b[y][r] = PC[y][551-r]（列镜像）
        p = ((b[0::4] << 6) | (b[1::4] << 4) | (b[2::4] << 2) | b[3::4]).T
        return p.tobytes()             # (rb, ROWS) 转置后 C 序 = payload[r*rb + k]
    payload = bytearray(ROWS * rb)
    for r in range(ROWS):
        dx = ROWS - 1 - r
        base = r * rb
        for k in range(rb):
            y0 = 4 * k
            payload[base + k] = ((pc_flat[y0 * PC_W + dx] << 6) |
                                 (pc_flat[(y0 + 1) * PC_W + dx] << 4) |
                                 (pc_flat[(y0 + 2) * PC_W + dx] << 2) |
                                 pc_flat[(y0 + 3) * PC_W + dx])
    return bytes(payload)


def _full_payload(pc_flat):
    """PC -> 全帧载荷（552×192B）。"""
    return _pack_pc(pc_flat, RB_FULL)


def _split_sub(full, orient):
    """全帧载荷 -> 分割子帧（= 用户画布条带以下内容；随方向变形状）。
    形状与固件 frame.c provider 分支 / remote.c 校验三方一致（已证明）：
      o0：552 段 × 152B（载荷行字节 40..191）；o2：552 × 152B（字节 0..151）；
      o1：392 段 × 192B（载荷行 0..391 整行）；  o3：392 × 192B（载荷行 160..551）。"""
    rows, rb = sub_shape(orient, True)
    sub = bytearray(rows * rb)
    if orient in (0, 2):
        for p in range(ROWS):
            if orient == 0:
                sub[p * 152:(p + 1) * 152] = full[p * RB_FULL + 40:(p + 1) * RB_FULL]
            else:
                sub[p * 152:(p + 1) * 152] = full[p * RB_FULL:p * RB_FULL + 152]
    elif orient == 3:
        sub[:] = full[160 * RB_FULL:ROWS * RB_FULL]
    else:
        sub[:] = full[0:rows * RB_FULL]
    return bytes(sub)


def build_payload(user_flat, w, h, split, orient):
    """用户画布码表 -> MKRP 载荷（全帧或分割子帧）。"""
    pc = _to_pc(user_flat, w, h, orient)
    full = _full_payload(pc)
    if not split:
        return full
    return _split_sub(full, orient)


def content_id(payload):
    """内容唯一 id：载荷 sha1 前 8 字节（内容变 id 变；同内容同 id → 设备不刷新）。"""
    return int.from_bytes(hashlib.sha1(payload).digest()[:8], "big")


def mkrp_header(split, payload, cid, orient):
    """32B MKRP 应答头（与 main/remote.h 契约一致；rows/rb 随方向）。
    R2.3.0：偏移 24 = 打包方向 orient（0..3）、偏移 25 = 0xA5 方向字段标记、
    26-31 仍保留 0 —— 协议版本保持 1（老固件忽略保留字节，兼容）。
    新固件读到 [24]/[25]=orient/0xA5 时按【远端打包方向】显示：设备方向与
    远端设置不一致不再拉取失败（R2.2.1 的 BAD_HDR 几何校验按帧方向走）。"""
    rows, rb = sub_shape(orient, split)
    return (b"MKRP" +
            bytes([1, 1 if split else 0]) +
            struct.pack(">HH", rows, rb) +
            struct.pack(">I", len(payload)) +
            struct.pack(">H", crc16_ccitt(payload)) +
            struct.pack(">Q", cid) +
            bytes([orient & 0x3F, 0xA5]) + b"\x00" * 6)


# ================= 内容项 =================

def list_fonts():
    """Windows 常见字体（带中文名映射；找不到就回退默认）。"""
    fonts = []
    cand = [
        ("微软雅黑", "msyh.ttc"), ("微软雅黑(粗)", "msyhbd.ttc"),
        ("宋体", "simsun.ttc"), ("黑体", "simhei.ttf"),
        ("楷体", "simkai.ttf"), ("仿宋", "simfang.ttf"),
        ("等线", "Deng.ttf"), ("隶书", "SIMLI.TTF"),
    ]
    windir = os.environ.get("WINDIR", r"C:\Windows")
    for name, fn in cand:
        p = os.path.join(windir, "Fonts", fn)
        if os.path.exists(p):
            fonts.append((name, p))
    if not fonts:
        fonts.append(("默认", None))
    return fonts


def _clamp_int(v, default, lo, hi):
    try:
        return max(lo, min(hi, int(v)))
    except Exception:
        return default


def _clamp_float(v, default, lo, hi):
    try:
        return max(lo, min(hi, float(v)))
    except Exception:
        return default


def _default_style_cfg(style, core):
    """R2.2.0 项目兼容：style/core -> 管线 cfg（其余全默认）。"""
    cfg = dict(MS.DEF_CFG)
    cfg["mode"] = style
    if style == "natural":
        cfg["warmBoost"] = core
    elif style == "adaptive":
        cfg["warmCast"] = core
    return cfg


class Item:
    """一条远端内容。kind: image / text。payload 随设置重新计算并缓存。

    R2.2.1：图片项【完整复刻设备端配置页】—— 裁切（铺满裁切/完整留边 +
    裁切位置 + 四边留白）、旋转（90° 步进 + 角度微调）、抖动算法/强度、
    调色（风格/强度 + 高级滑杆全套 + 色域 + 自动色阶）。文字项不变（就近吸附）。"""

    _seq = 0

    def __init__(self, kind, name):
        Item._seq += 1
        self.kind = kind                    # "image" / "text"
        self.name = name or f"内容{Item._seq}"
        self.enabled = True
        # ---- 图片项：几何（裁切/旋转/留白） ----
        self.path = ""
        self.fit = "cover"                  # cover / contain
        self.bg = 1                         # contain 底色（2bpp 码）
        self.offx = 0                       # 铺满裁切：横向裁切位置 -100..100（%）
        self.offy = 0                       # 铺满裁切：纵向裁切位置 -100..100（%）
        self.rot90 = 0                      # 90° 步进 0..3（累计）
        self.rotfine = 0                    # 角度微调 -180..180
        self.pad_on = 0                     # 四边留白开关
        self.pad_t, self.pad_b = 0, 0       # 留白 px（上/下）
        self.pad_l, self.pad_r = 0, 0       # 留白 px（左/右）
        # ---- 图片项：调色（完整复刻配置页） ----
        self.style = "natural"              # natural/adaptive/gray/naive
        self.core = MS.DEF_CFG["warmBoost"]  # 色彩强度（natural=warmBoost / adaptive=warmCast）
        self.alg = "std"                    # R2.3.0 出图算法：std=风格管线；gold/texture/level/ink=四档（墨小佳移植）
        self.dither = "fs"                  # 抖动算法（8 种）
        self.space = "std"                  # 色域 std/linear/srgb
        self.autolv = 1                     # 自动色阶
        self.adv = dict(ADV_DEFAULT)        # 高级滑杆（键同页面 DEF）
        # ---- 文字项 ----
        self.text = ""
        self.font_idx = 0
        self.font_size = 64
        self.color = 0                      # 2bpp 码
        self.text_bg = 1
        self.align = "center"               # center / left
        self.margin = 24
        self.line_gap = 1.35
        # ---- 缓存（orient/split 进缓存键：方向变了自动失效） ----
        self._codes = None                  # (flat, w, h)
        self._payload = b""
        self._cid = 0
        self._cache_key = None              # (split, orient)
        self._bad = ""                      # 最近一次渲染失败原因；空 = 正常

    # ---- 管线 cfg（图片项） ----
    def pipeline_cfg(self):
        cfg = dict(self.adv)
        cfg["mode"] = self.style
        if self.style == "natural":
            cfg["warmBoost"] = self.core
        elif self.style == "adaptive":
            cfg["warmCast"] = self.core
        cfg["dither"] = self.dither
        cfg["space"] = self.space
        cfg["alg"] = self.alg             # R2.3.0：四档出图算法经 device_codes_cfg 分发
        cfg["autoLevels"] = 1 if self.autolv else 0
        return cfg

    def to_dict(self):
        d = {k: getattr(self, k) for k in
             ("kind", "name", "enabled", "path", "fit", "bg", "offx", "offy",
              "rot90", "rotfine", "pad_on", "pad_t", "pad_b", "pad_l", "pad_r",
              "style", "core", "alg", "dither", "space", "autolv", "adv",
              "text", "font_idx", "font_size", "color", "text_bg",
              "align", "margin", "line_gap")}
        return d

    @classmethod
    def from_dict(cls, d):
        """从 JSON 恢复，全部字段消毒（旧文件坏值不再能引发启动崩溃）。
        R2.2.0 旧项目无新字段 → 全默认（含 13 个高级滑杆默认值）。"""
        kind = d.get("kind")
        if kind not in ("image", "text"):
            kind = "text"
        it = cls(kind, d.get("name", ""))
        try:
            it.enabled = bool(d.get("enabled", True))
            if kind == "image":
                it.path = str(d.get("path") or "")
                it.fit = d.get("fit") if d.get("fit") in ("cover", "contain") else "cover"
                it.bg = _clamp_int(d.get("bg"), 1, 0, 3)
                it.offx = _clamp_int(d.get("offx"), 0, -100, 100)
                it.offy = _clamp_int(d.get("offy"), 0, -100, 100)
                it.rot90 = _clamp_int(d.get("rot90"), 0, 0, 3)
                it.rotfine = _clamp_int(d.get("rotfine"), 0, -180, 180)
                it.pad_on = 1 if d.get("pad_on") else 0
                it.pad_t = _clamp_int(d.get("pad_t"), 0, 0, 300)
                it.pad_b = _clamp_int(d.get("pad_b"), 0, 0, 300)
                it.pad_l = _clamp_int(d.get("pad_l"), 0, 0, 300)
                it.pad_r = _clamp_int(d.get("pad_r"), 0, 0, 300)
                st = d.get("style")
                it.style = st if st in ("natural", "adaptive", "gray", "naive") else "natural"
                dflt = STYLE_META[it.style][2] if it.style in ("natural", "adaptive") \
                    else MS.DEF_CFG["warmBoost"]
                it.core = _clamp_float(d.get("core"), dflt, 0.0, 1.0)
                algv = d.get("alg")
                it.alg = algv if algv in MS.REINK_MODES else "std"
                dit = d.get("dither")
                it.dither = dit if dit in dict(DITHERS) else "fs"
                sp = d.get("space")
                it.space = sp if sp in ("std", "linear", "srgb") else "std"
                it.autolv = 1 if d.get("autolv", 1) else 0
                adv = d.get("adv")
                if isinstance(adv, dict):
                    for k in ADV_DEFAULT:
                        if k in adv:
                            lo, hi = ADV_BOUNDS[k]
                            if k in ("brightness", "contrast"):
                                it.adv[k] = _clamp_float(adv[k], ADV_DEFAULT[k], lo, hi)
                            else:
                                it.adv[k] = _clamp_float(adv[k], ADV_DEFAULT[k], lo, hi)
            else:
                it.text = str(d.get("text") or "")
                it.font_idx = _clamp_int(d.get("font_idx"), 0, 0, 63)
                it.font_size = _clamp_int(d.get("font_size"), 64, 12, 240)
                it.color = _clamp_int(d.get("color"), 0, 0, 3)
                it.text_bg = _clamp_int(d.get("text_bg"), 1, 0, 3)
                it.align = d.get("align") if d.get("align") in ("center", "left") else "center"
                it.margin = _clamp_int(d.get("margin"), 24, 0, 200)
                try:
                    it.line_gap = max(0.8, min(3.0, float(d.get("line_gap", 1.35))))
                except Exception:
                    it.line_gap = 1.35
        except Exception:
            pass
        return it

    # ---- 渲染 ----
    def render_codes(self, width, height, fonts):
        """按用户画布（width×height）渲染 2bpp 码表。永不抛异常。"""
        self._bad = ""
        try:
            if self.kind == "image":
                return self._render_image(width, height)
            return self._render_text(width, height, fonts)
        except Exception as e:
            self._bad = str(e) or e.__class__.__name__
            try:
                return self._render_placeholder(width, height, fonts)
            except Exception:
                return b"\x01" * (width * height), width, height   # 白底兜底

    def _rotate_source(self, img):
        """旋转源图：90° 步进（累计）+ 角度微调（-180..180°）。
        微调用双三次插值、白底扩展（与配置页 Cropper 的旋转语义一致：
        先旋转，后按裁切/留白适配）。"""
        r90 = self.rot90 & 3
        if r90:
            img = img.rotate(-90 * r90, Image.BICUBIC, expand=True)
        fine = int(self.rotfine)
        if fine:
            img = img.rotate(fine, Image.BICUBIC, expand=True, fillcolor=(255, 255, 255))
        return img

    def _content_box(self, width, height):
        """留白后的内容区（同配置页 contentRect：勾选边让出 pad px）。"""
        if not self.pad_on:
            return 0, 0, width, height
        l = self.pad_l if self.pad_l else 0
        r = self.pad_r if self.pad_r else 0
        t = self.pad_t if self.pad_t else 0
        b = self.pad_b if self.pad_b else 0
        cw = max(30, width - l - r)
        ch = max(30, height - t - b)
        return l, t, cw, ch

    def _render_image(self, width, height):
        """R2.2.1：旋转 -> 裁切/留白适配 -> 设备端配置页完整管线
        （风格/强度/预处理/暖色/色域/抖动，全部参数可调）。"""
        if not self.path or not os.path.exists(self.path):
            raise FileNotFoundError("图片文件不存在" if self.path else "未选择图片")
        img = Image.open(self.path)
        img = ImageOps.exif_transpose(img)          # 手机照片方向自动转正
        img = self._rotate_source(img)
        x0, y0, cw, ch = self._content_box(width, height)
        if self.fit == "cover":
            s = max(cw / img.width, ch / img.height)
            nw, nh = max(1, round(img.width * s)), max(1, round(img.height * s))
            img = img.resize((nw, nh), Image.LANCZOS)
            # 裁切位置：-100..100（%）→ 大图内可滑动范围；0 = 居中
            fx = (nw - cw) * (self.offx + 100) / 200.0 if nw > cw else (nw - cw) / 2.0
            fy = (nh - ch) * (self.offy + 100) / 200.0 if nh > ch else (nh - ch) / 2.0
            left = _clamp_int(round(fx), 0, 0, max(0, nw - cw))
            top = _clamp_int(round(fy), 0, 0, max(0, nh - ch))
            img = img.crop((left, top, left + cw, top + ch))
            canvas = Image.new("RGB", (width, height), PAL_RGB[self.bg & 3])
            canvas.paste(img, (x0, y0))
            img = canvas
        else:
            s = min(cw / img.width, ch / img.height)
            nw, nh = max(1, round(img.width * s)), max(1, round(img.height * s))
            img = img.resize((nw, nh), Image.LANCZOS)
            bgc = PAL_RGB[self.bg & 3]
            canvas = Image.new("RGB", (width, height), bgc)
            canvas.paste(img, (x0 + (cw - nw) // 2, y0 + (ch - nh) // 2))
            img = canvas
        rgb = img.convert("RGB").tobytes()
        codes = MS.device_codes_cfg(rgb, width, height, self.pipeline_cfg())
        return codes, width, height

    def _render_text(self, width, height, fonts):
        """文字就近吸附四色（设备端便签语义：纯色矢量、边缘干净、
            无抖动网点），不做误差扩散。"""
        bgc = PAL_RGB[self.text_bg & 3]
        img = Image.new("RGB", (width, height), bgc)
        dr = ImageDraw.Draw(img)
        fname, fpath = fonts[min(self.font_idx, len(fonts) - 1)]
        try:
            font = ImageFont.truetype(fpath, self.font_size) if fpath else ImageFont.load_default()
        except Exception:
            font = ImageFont.load_default()
        fg = PAL_RGB[self.color & 3]
        m = self.margin
        maxw = width - 2 * m
        lines = []
        for para in str(self.text).split("\n"):
            if not para:
                lines.append("")
                continue
            cur = ""
            for ch in para:
                if dr.textlength(cur + ch, font=font) <= maxw or not cur:
                    cur += ch
                else:
                    lines.append(cur)
                    cur = ch
            lines.append(cur)
        lh = int(self.font_size * self.line_gap)
        total = lh * len(lines)
        y = max(m, (height - total) // 2)
        for ln in lines:
            if ln:
                w = dr.textlength(ln, font=font)
                x = m if self.align == "left" else (width - w) // 2
                dr.text((x, y), ln, font=font, fill=fg)
            y += lh
        codes = MS.snap_codes(img.tobytes(), width, height)
        return codes, width, height

    def _render_placeholder(self, width, height, fonts):
        """缺图/渲染失败的占位画面（白底红字，预览和上屏都可见；就近吸附）。"""
        img = Image.new("RGB", (width, height), (255, 255, 255))
        dr = ImageDraw.Draw(img)
        try:
            fpath = fonts[min(self.font_idx, len(fonts) - 1)][1]
            font = ImageFont.truetype(fpath, 40) if fpath else ImageFont.load_default()
        except Exception:
            font = ImageFont.load_default()
        title = "图片缺失" if self.kind == "image" else "渲染失败"
        y = max(8, height // 2 - 56)
        for ln in (title, (self._bad or "")[:90]):
            if ln:
                w = dr.textlength(ln, font=font)
                dr.text(((width - w) // 2, y), ln, font=font, fill=(255, 0, 0))
            y += 56
        codes = MS.snap_codes(img.tobytes(), width, height)
        return codes, width, height

    def build(self, split, orient, fonts, force=False):
        """生成（或取缓存）当前设置下的 payload + cid。
        缓存键 = (split, orient)——方向变了自动失效（画布尺寸/子帧形状全变）。
        单张渲染约 1~4s（视抖动算法）——懒构建，调用方注意频率。

        分割式：渲染内容区（用户画布第 160 行以下），先放回完整用户画布
        （条带区填白——打包后被子帧提取丢弃，与配置页分割式上传语义一致：
        照片让出顶部 160 行、框底纯白），再按方向旋转打包。"""
        key = (bool(split), orient)
        if force or not self._payload or self._cache_key != key:
            w, h = orient_user_dims(orient)
            height = h - BOX_H if split else h
            self._codes = self.render_codes(w, height, fonts)
            if split:
                full = bytearray(w * h)          # 条带区置白（2bpp 白 = 0b01）
                for row in range(BOX_H):
                    off = row * w
                    full[off:off + w] = b"\x55" * w
                for row in range(height):
                    src = row * w
                    dst = (BOX_H + row) * w
                    full[dst:dst + w] = self._codes[0][src:src + w]
                flat = bytes(full)
            else:
                flat = self._codes[0]
            self._payload = build_payload(flat, w, h, split, orient)
            self._cid = content_id(self._payload)
            self._cache_key = key
        return self._payload, self._cid


# 高级滑杆边界表（from_dict 消毒用）
ADV_BOUNDS = {k: (lo, hi) for k, _, lo, hi, _ in ADV_SLIDERS}


# ================= 应用状态 =================

class App:
    def __init__(self):
        self.items = []
        self.style_split = True             # True=分割式
        self.rotation = "seq"               # seq / rand / latest
        self.port = 8210
        # R2.2.1：屏幕方向（排线基准 0..3）+ 跟随设备上报开关
        self.orient = 0
        self.follow_orient = True           # True=设备上报优先（默认配置跟随设备）
        self.device_orient = None           # 最近一次设备上报的方向（提示/跟随用）
        self.orient_hinted = False          # 「以用户设置优先」的提示是否已给过
        self.seq_cursor = 0
        self.server = None
        self.server_thread = None
        self.lock = threading.Lock()
        self.fonts = list_fonts()
        self.pull_count = 0
        self.last_pull = "—"
        self.ui = None                      # UI 就绪前为 None（HTTP 线程判空）
        self.healed = []                    # 启动自愈时丢弃的坏条目（UI 弹一次提示）
        self.load_project()

    # ---- 项目存取（随手自动保存） ----
    def load_project(self):
        try:
            with open(PROJECT_JSON, encoding="utf-8") as f:
                d = json.load(f)
            if not isinstance(d, dict):
                return
        except Exception:
            return
        self.style_split = bool(d.get("split", True))
        r = d.get("rotation", "seq")
        self.rotation = r if r in ("seq", "rand", "latest") else "seq"
        self.port = _clamp_int(d.get("port"), 8210, 1, 65535)
        self.orient = _clamp_int(d.get("orient"), 0, 0, 3)
        self.follow_orient = bool(d.get("follow_orient", True))
        raw = d.get("items", [])
        if not isinstance(raw, list):
            return
        for x in raw:
            if not isinstance(x, dict):
                continue
            try:
                it = Item.from_dict(x)
            except Exception:
                self.healed.append("一条无法读取的条目（数据损坏）")
                continue
            # ★ R2.1.0 空/丢失路径图片项曾是「再也打不开」的元凶 → 直接丢弃
            if it.kind == "image" and (not it.path or not os.path.exists(it.path)):
                self.healed.append(f"「{it.name}」（图片缺失：{it.path or '未选'}）")
                continue
            self.items.append(it)

    def save_project(self):
        try:
            os.makedirs(ASSET_DIR, exist_ok=True)
            d = {"split": self.style_split, "rotation": self.rotation,
                 "port": self.port, "orient": self.orient,
                 "follow_orient": self.follow_orient,
                 "items": [it.to_dict() for it in self.items]}
            with open(PROJECT_JSON, "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=1)
        except Exception as e:
            print("save project failed:", e)

    # ---- 方向（UI 线程调用；HTTP 线程经 ui 队列转发） ----
    def set_orient(self, o, by_user):
        """切换默认画布方向。by_user=True 记为用户设置（之后设备上报只提示不改）。"""
        o = _clamp_int(o, 0, 0, 3)
        changed = (o != self.orient)
        if not changed:
            return False
        self.orient = o
        with self.lock:
            for it in self.items:           # 画布尺寸/子帧形状全变：全部缓存失效
                it._cache_key = None
        if by_user:
            self.follow_orient = False      # 用户设置优先
        self.save_project()
        return changed

    def on_device_orient(self, o):
        """设备拉取上报的方向（HTTP 线程调用，已持锁）。返回日志行。
        跟随模式 → 自动切换默认画布（提示）；用户已手动设置 → 仅提示不切换。"""
        o = _clamp_int(o, 0, 0, 3)
        first_report = (self.device_orient is None)
        self.device_orient = o
        ts = time.strftime("%H:%M:%S")
        if o == self.orient:
            return f"[{ts}] 设备上报屏幕方向：{ORIENT_SHORT[o]}（与当前一致）"
        if self.follow_orient:
            self.orient = o
            for it in self.items:
                it._cache_key = None
            self.save_project()
            msg = (f"[{ts}] 设备上报屏幕方向：{ORIENT_SHORT[o]} → 已自动切换默认画布"
                   f"（{ORIENT_NAMES[o]}），后续拉取按新方向打包")
            if self.ui:
                self.ui.log(msg)
                self.ui.apply_orient_ui(o)   # 经队列回主线程刷新控件
            return msg
        msg = (f"[{ts}] 设备上报屏幕方向：{ORIENT_SHORT[o]}，与当前设置（{ORIENT_SHORT[self.orient]}）不同"
               f"——以你的设置优先；如需跟随请勾选「跟随设备上报」")
        if self.ui and not self.orient_hinted:
            self.orient_hinted = True
            self.ui.log(msg)
            self.ui.apply_orient_ui(self.orient, note=msg)
        return msg

    # ---- 拉取处理（HTTP 线程调用，已持锁） ----
    def handle_pull(self, qs):
        try:
            return self._handle_pull(qs)
        except Exception as e:
            ts = time.strftime("%H:%M:%S")
            return None, f"[{ts}] 拉取处理异常：{e}"

    def _handle_pull(self, qs):
        style = qs.get("style", ["?"])[0]
        cid = qs.get("cid", ["0"])[0]
        fw = qs.get("fw", ["?"])[0]
        orient_q = qs.get("orient", [""])[0]
        try:
            dev_orient = int(orient_q) if orient_q != "" else None
        except ValueError:
            dev_orient = None
        if dev_orient is not None and dev_orient != self.orient:
            self.on_device_orient(dev_orient)     # 方向上报 → 默认画布跟随/提示
        try:
            cid_v = int(cid, 16) if cid else 0
        except ValueError:
            cid_v = -1                     # 解不出来就当不同内容，正常下发
        act = [it for it in self.items if it.enabled]
        ts = time.strftime("%H:%M:%S")
        if not act:
            return None, f"[{ts}] 拒绝：内容列表为空（先添加图片/文字）"
        if self.rotation == "latest":
            pick = act[-1]
        elif self.rotation == "rand":
            pick = random.choice(act)
        else:
            pick = act[self.seq_cursor % len(act)]
            self.seq_cursor = (self.seq_cursor + 1) % len(act)
        # 懒构建下首次拉到某项时才渲染（约 1~4s，设备端超时足够宽）
        payload, pcid = pick.build(self.style_split, self.orient, self.fonts)
        if cid_v == pcid:
            self.pull_count += 1
            self.last_pull = f"{ts} · {pick.name} 内容未变（304）"
            return 304, f"[{ts}] 设备(style={style}, fw={fw}, orient={self.orient}) → {pick.name}：内容未变，304"
        self.pull_count += 1
        self.last_pull = f"{ts} · {pick.name} 上屏（id {pcid:016X}）"
        hdr = mkrp_header(self.style_split, payload, pcid, self.orient)
        rows, rb = sub_shape(self.orient, self.style_split)
        return (hdr + payload,
                f"[{ts}] 设备(style={style}, fw={fw}, orient={self.orient}) → {pick.name}："
                f"{'分割' if self.style_split else '全屏'} {rows}×{rb}B {len(payload)}B "
                f"id {pcid:016X}")


APP = App()


class PullHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):           # 静默默认访问日志（自记一条更有用的）
        pass

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        if u.path != "/moink/pull":
            self.send_error(404, "not moink pull")
            return
        qs = urllib.parse.parse_qs(u.query)
        with APP.lock:
            body, log = APP.handle_pull(qs)
        try:
            with open(LOG_PATH, "a", encoding="utf-8") as f:
                f.write(log + "\n")
        except Exception:
            pass
        if APP.ui:
            APP.ui.log(log)              # 线程安全：入队，主线程 after 泵刷控件
        if body is None:
            self.send_error(503, "no content")
            return
        if body == 304:
            self.send_response(304)
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


# ================= GUI =================

def guard(fn):
    """Tk 回调统一兜底（R2.1.1）：异常不再被 pythonw 静默吞掉，弹窗告知。"""
    def wrap(*a, **k):
        try:
            return fn(*a, **k)
        except Exception as e:
            try:
                messagebox.showerror("墨印远端", f"操作失败：{e}")
            except Exception:
                pass
    return wrap


class UI:
    def __init__(self, root):
        self.root = root
        root.title("墨印远端 · MoInK Remote（配套固件 R2.2.1+）")
        root.geometry("1120x800")
        root.minsize(1000, 680)
        self.sel = -1
        self.preview_img = None
        self.logq = queue.Queue()         # 任意线程投递日志，主线程泵刷（线程安全）
        self.uiq = queue.Queue()          # HTTP 线程请求的 UI 动作（如方向切换刷新）
        self._core_out = None             # 色彩强度数值 label（编辑器内）
        self._core_after = None           # 滑杆拖动防抖
        self._editor_building = False     # 编辑器构建期标志（Scale 初始化回声防护）
        self._adv_win = None              # 高级调色窗口（Toplevel，仅图片项）
        self._build()
        self.refresh_list()
        self.refresh_style()
        self.root.after(300, self._auto_save_loop)
        self.root.after(150, self._log_pump)
        self.root.after(160, self._uiq_pump)

    # ---- 布局 ----
    def _build(self):
        top = ttk.Frame(self.root, padding=8)
        top.pack(fill="x")
        ttk.Label(top, text="显示样式").pack(side="left")
        self.style_var = tk.StringVar(value="分割式（顶部信息框+下方远端）")
        cb = ttk.Combobox(top, textvariable=self.style_var, state="readonly", width=26, values=[
            "分割式（顶部信息框+下方远端）", "信息框关闭（全屏远端）"])
        cb.pack(side="left", padx=(4, 12))
        cb.bind("<<ComboboxSelected>>", lambda e: guard(self.on_style)())
        ttk.Label(top, text="轮播").pack(side="left")
        self.rot_var = tk.StringVar(value="顺序轮播")
        rb = ttk.Combobox(top, textvariable=self.rot_var, state="readonly", width=10, values=[
            "顺序轮播", "随机轮播", "仅最新"])
        rb.pack(side="left", padx=(4, 12))
        rb.bind("<<ComboboxSelected>>", lambda e: guard(self.on_rot)())
        # R2.2.1：屏幕方向（排线基准）+ 跟随设备上报
        ttk.Label(top, text="方向").pack(side="left")
        self.orient_var = tk.StringVar(value=ORIENT_NAMES[APP.orient])
        ob = ttk.Combobox(top, textvariable=self.orient_var, state="readonly", width=20,
                          values=ORIENT_NAMES)
        ob.pack(side="left", padx=(4, 4))
        ob.bind("<<ComboboxSelected>>", lambda e: guard(self.on_orient)())
        self.follow_var = tk.BooleanVar(value=APP.follow_orient)
        fb = ttk.Checkbutton(top, text="跟随设备上报", variable=self.follow_var,
                             command=guard(self.on_follow))
        fb.pack(side="left", padx=(4, 12))
        ttk.Label(top, text="端口").pack(side="left")
        self.port_var = tk.StringVar(value=str(APP.port))
        pe = ttk.Entry(top, textvariable=self.port_var, width=6)
        pe.pack(side="left", padx=(4, 12))
        self.srv_btn = ttk.Button(top, text="启动服务", command=guard(self.toggle_server))
        self.srv_btn.pack(side="left")
        self.srv_state = ttk.Label(top, text="（未启动）", foreground="#888")
        self.srv_state.pack(side="left", padx=(8, 4))

        main = ttk.Frame(self.root, padding=(8, 0, 8, 8))
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=0, minsize=250)
        main.columnconfigure(1, weight=1)
        main.rowconfigure(0, weight=1)

        # 左：内容列表
        left = ttk.Frame(main)
        left.grid(row=0, column=0, sticky="nswe", padx=(0, 8))
        lf = ttk.LabelFrame(left, text="内容列表（勾选参与轮播）", padding=6)
        lf.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(lf, columns=("en", "kind", "id"), show="tree headings",
                                 height=14)
        self.tree.heading("#0", text="名称")
        self.tree.heading("en", text="启用")
        self.tree.heading("kind", text="类型")
        self.tree.heading("id", text="内容 id")
        self.tree.column("#0", width=120)
        self.tree.column("en", width=44, anchor="center")
        self.tree.column("kind", width=52, anchor="center")
        self.tree.column("id", width=90)
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", lambda e: guard(self.on_select)())
        btns = ttk.Frame(lf)
        btns.pack(fill="x", pady=(6, 0))
        ttk.Button(btns, text="＋图片", width=8, command=guard(self.add_image)).pack(side="left")
        ttk.Button(btns, text="＋文字", width=8, command=guard(self.add_text)).pack(side="left", padx=4)
        ttk.Button(btns, text="删除", width=6, command=guard(self.del_item)).pack(side="left")
        ttk.Button(btns, text="上移", width=6, command=lambda: guard(self.move)(-1)).pack(side="left", padx=4)
        ttk.Button(btns, text="下移", width=6, command=lambda: guard(self.move)(1)).pack(side="left")

        # 右：编辑 + 预览
        right = ttk.Frame(main)
        right.grid(row=0, column=1, sticky="nswe")
        right.rowconfigure(2, weight=1)
        right.columnconfigure(0, weight=1)

        edit = ttk.LabelFrame(right, text="内容编辑（图片项已完整复刻设备端配置页：裁切/旋转/抖动/调色）", padding=8)
        edit.grid(row=0, column=0, sticky="we")
        self.edit_host = ttk.Frame(edit)
        self.edit_host.pack(fill="both")

        ttk.Label(right, text="屏幕预览（设备实际显示的四色效果，同配置页）",
                  padding=(0, 6, 0, 0)).grid(row=1, column=0, sticky="w")
        pv = ttk.Frame(right, relief="groove", borderwidth=1)
        pv.grid(row=2, column=0, sticky="nswe", pady=4)
        self.canvas = tk.Canvas(pv, bg="#d8d2c2", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda e: self.draw_preview())

        self.status = ttk.Label(self.root, text="就绪", anchor="w", relief="sunken", padding=4)
        self.status.pack(fill="x", side="bottom")
        self.logvar = tk.StringVar(value="日志：")
        ttk.Label(self.root, textvariable=self.logvar, anchor="w", relief="sunken",
                  padding=4, foreground="#555").pack(fill="x", side="bottom")

    # ---- 列表 / 选中 ----
    def _id_text(self, it):
        """懒构建：已渲染显示缓存 id；未渲染显示 …（拉取/选中时才构建）。"""
        if it._payload and it._cache_key == (APP.style_split, APP.orient):
            return "%08X%s" % (it._cid, "!" if it._bad else "")
        return "…"

    def refresh_list(self, keep=True):
        selname = None
        if keep and 0 <= self.sel < len(APP.items):
            selname = APP.items[self.sel].name
        rows = [(self._id_text(it), it) for it in APP.items]
        self.tree.delete(*self.tree.get_children())
        for i, (cid_txt, it) in enumerate(rows):
            self.tree.insert("", "end", iid=str(i), text=it.name,
                             values=("✓" if it.enabled else "—",
                                     "图片" if it.kind == "image" else "文字",
                                     cid_txt))
        if selname:
            for i, (_, it) in enumerate(rows):
                if it.name == selname:
                    self.sel = i
                    self.tree.selection_set(str(i))
                    break
        self.build_editor()
        self.draw_preview()

    def on_select(self):
        s = self.tree.selection()
        self.sel = int(s[0]) if s else -1
        self.build_editor()
        self.draw_preview()

    def cur(self):
        return APP.items[self.sel] if 0 <= self.sel < len(APP.items) else None

    # ---- 编辑器 ----
    def clear_editor(self):
        for w in self.edit_host.winfo_children():
            w.destroy()
        self._cancel_slide_after()
        self._core_after = None
        self._core_out = None
        if self._adv_win is not None:
            try:
                self._adv_win.destroy()
            except Exception:
                pass
            self._adv_win = None

    def _cancel_slide_after(self):
        if self._core_after:
            try:
                self.root.after_cancel(self._core_after)
            except Exception:
                pass
            self._core_after = None

    def build_editor(self):
        self.clear_editor()
        self._editor_building = True          # ttk.Scale 创建期 .set() 会触发 command，需忽略
        try:
            self._build_editor_inner()
        finally:
            self._editor_building = False

    def _row(self, host):
        r = ttk.Frame(host)
        r.pack(fill="x", pady=2)
        return r

    def _build_editor_inner(self):
        it = self.cur()
        if not it:
            ttk.Label(self.edit_host, text="← 添加或选择一条内容",
                      foreground="#999").pack(pady=18)
            return
        if it._bad:
            ttk.Label(self.edit_host, foreground="#c00",
                      text=f"⚠ {it._bad}（重选图片可修复）").pack(anchor="w")
        h = self.edit_host
        if it.kind == "image":
            row = self._row(h)
            ttk.Label(row, text="图片：").pack(side="left")
            ttk.Label(row, text=os.path.basename(it.path) or "（未选）",
                      foreground="#0a6").pack(side="left")
            ttk.Button(row, text="选择图片…", command=guard(self.pick_image)).pack(side="left", padx=6)

            # ---- 裁切（适配 + 裁切位置 + 留白 + 底色）：同配置页裁剪卡 ----
            row = self._row(h)
            ttk.Label(row, text="裁切：").pack(side="left")
            fitv = tk.StringVar(value="铺满裁切" if it.fit == "cover" else "完整留边")

            def on_fit(*_):
                it.fit = "cover" if fitv.get() == "铺满裁切" else "contain"
                self.item_changed()
            fc = ttk.Combobox(row, textvariable=fitv, state="readonly", width=10,
                              values=["铺满裁切", "完整留边"])
            fc.pack(side="left"); fc.bind("<<ComboboxSelected>>", on_fit)
            ttk.Label(row, text="留边底色：").pack(side="left", padx=(10, 0))
            bgv = tk.StringVar(value=["黑", "白", "黄", "红"][it.bg & 3])

            def on_bg(*_):
                it.bg = ["黑", "白", "黄", "红"].index(bgv.get())
                self.item_changed()
            bc = ttk.Combobox(row, textvariable=bgv, state="readonly", width=4,
                              values=["黑", "白", "黄", "红"])
            bc.pack(side="left"); bc.bind("<<ComboboxSelected>>", on_bg)
            row = self._row(h)
            ttk.Label(row, text="裁切位置（铺满时）：").pack(side="left")
            self._mk_mini_scale(row, it, "offx", "横向", -100, 100, 1)
            ttk.Label(row, text=" ").pack(side="left")
            self._mk_mini_scale(row, it, "offy", "纵向", -100, 100, 1)
            row = self._row(h)
            padv = tk.BooleanVar(value=bool(it.pad_on))

            def on_pad(*_):
                it.pad_on = 1 if padv.get() else 0
                self.item_changed()
            ttk.Checkbutton(row, text="留白（px）", variable=padv,
                            command=guard(on_pad)).pack(side="left")
            for key, lab, dflt in (("pad_t", "上", 200), ("pad_b", "下", 200),
                                   ("pad_l", "左", 100), ("pad_r", "右", 100)):
                sv = tk.StringVar(value=str(getattr(it, key) or dflt))

                def on_pad_v(*_, k=key, s=sv, d=dflt):
                    setattr(it, k, _clamp_int(s.get(), d, 0, 300))
                    self.item_changed()
                ttk.Label(row, text=lab).pack(side="left", padx=(6, 0))
                e = ttk.Entry(row, textvariable=sv, width=4)
                e.pack(side="left"); e.bind("<FocusOut>", on_pad_v)

            # ---- 旋转：90° 步进 + 角度微调（同配置页旋转卡） ----
            row = self._row(h)
            ttk.Label(row, text="旋转：").pack(side="left")

            def rot(d):
                it.rot90 = (it.rot90 + d) & 3
                self.item_changed()
            ttk.Button(row, text="↺ 90°", width=6,
                       command=lambda: guard(rot)(1)).pack(side="left")
            ttk.Button(row, text="↻ 90°", width=6,
                       command=lambda: guard(rot)(-1)).pack(side="left", padx=4)
            self._mk_mini_scale(row, it, "rotfine", "微调", -180, 180, 1, unit="°")

            # ---- 调色：算法（R2.3.0 四档出图算法） + 风格 + 色彩强度 + 抖动 + 色域 + 自动色阶 + 高级窗口 ----
            row = self._row(h)
            ttk.Label(row, text="算法：").pack(side="left")
            algv = tk.StringVar(value=("标准（风格管线）" if it.alg == "std"
                                       else MS.REINK_NAMES[it.alg]))

            def on_alg(*_):
                name = algv.get()
                it.alg = "std" if name.startswith("标准") else \
                    next(k for k, v in MS.REINK_NAMES.items() if v == name)
                self.item_changed()          # 重渲染预览（alg 走 pipeline_cfg 分发）
                self.build_editor()          # 面板重建：四档下标准调色控件整体置灰

            acb = ttk.Combobox(row, textvariable=algv, state="readonly", width=13,
                               values=["标准（风格管线）"] +
                                      [MS.REINK_NAMES[k] for k in MS.REINK_MODES])
            acb.pack(side="left"); acb.bind("<<ComboboxSelected>>", guard(on_alg))
            ttk.Label(row, text="　调色：").pack(side="left")
            stv = tk.StringVar(value=STYLE_META[it.style][1])

            def on_style_sel(*_):
                it.style = STYLE_BY_NAME[stv.get()]
                it.core = STYLE_META[it.style][2]      # 切风格回默认强度（同配置页）
                self.item_changed()
            scb = ttk.Combobox(row, textvariable=stv, state="readonly", width=10,
                               values=STYLE_NAMES)
            scb.pack(side="left"); scb.bind("<<ComboboxSelected>>", on_style_sel)
            core_lab = ttk.Label(row, text="　色彩强度：")
            core_lab.pack(side="left")
            self._core_out = ttk.Label(row, text=str(round(it.core * 100)), width=3)
            scl = ttk.Scale(row, from_=0, to=100,
                            command=lambda v: self._on_core_slide(it, v))
            scl.set(round(it.core * 100))          # 不绑 variable：避免拖动反馈回路
            scl.pack(side="left", padx=4)
            self._core_out.pack(side="left")
            if it.style in ("gray", "naive"):
                scl.state(["disabled"]); core_lab.config(foreground="#999")
            ttk.Label(h, foreground="#777",
                      text=("　" + MS.REINK_HINTS[it.alg] + "（风格/抖动/色域/高级参数不参与）"
                            if it.alg != "std" else "　" + STYLE_META[it.style][3])
                      ).pack(anchor="w")
            row = self._row(h)
            ttk.Label(row, text="抖动：").pack(side="left")
            dv = tk.StringVar(value=dict(DITHERS)[it.dither])

            def on_dither(*_):
                it.dither = DITHER_BY_NAME[dv.get()]
                self.item_changed()
            dcb = ttk.Combobox(row, textvariable=dv, state="readonly", width=14,
                               values=DITHER_NAMES)
            dcb.pack(side="left"); dcb.bind("<<ComboboxSelected>>", on_dither)
            ttk.Label(row, text="色域：").pack(side="left", padx=(10, 0))
            spv = tk.StringVar(value=dict(SPACES)[it.space])

            def on_space(*_):
                it.space = SPACE_BY_NAME[spv.get()]
                self.item_changed()
            spb = ttk.Combobox(row, textvariable=spv, state="readonly", width=8,
                               values=SPACE_NAMES)
            spb.pack(side="left"); spb.bind("<<ComboboxSelected>>", on_space)
            alv = tk.BooleanVar(value=bool(it.autolv))

            def on_al(*_):
                it.autolv = 1 if alv.get() else 0
                self.item_changed()
            alcb = ttk.Checkbutton(row, text="自动色阶", variable=alv,
                                   command=guard(on_al))
            alcb.pack(side="left", padx=(10, 0))
            adv_btn = ttk.Button(row, text="高级调色…（亮度/对比度/Gamma/饱和度/暖色/锐化/抖动强度）",
                                 command=guard(self.open_adv))
            adv_btn.pack(anchor="w", pady=(4, 0))
            if it.alg != "std":
                # R2.3.0：四档算法自带预变换与抖动 —— 标准调色/抖动/色域/自动色阶整体置灰
                for wgt in (scb, scl, dcb, spb, alcb, adv_btn):
                    try:
                        wgt.state(["disabled"])
                    except Exception:
                        pass
        else:
            row = self._row(h)
            ttk.Label(row, text="名称：").pack(side="left")
            nv = tk.StringVar(value=it.name)

            def on_name(*_):
                it.name = nv.get() or it.name
                self.item_changed(list_only=True)
            ne = ttk.Entry(row, textvariable=nv, width=24)
            ne.pack(side="left", padx=4); ne.bind("<FocusOut>", on_name)
            row = self._row(h)
            ttk.Label(row, text="文字（自动换行，居中排版）").pack(side="left")
            txt = tk.Text(h, height=4, wrap="char")
            txt.pack(fill="x", pady=2)
            txt.insert("1.0", it.text)
            txt.bind("<KeyRelease>", lambda e: self.on_text(it, txt))
            row = self._row(h)
            ttk.Label(row, text="字体：").pack(side="left")
            fv = tk.StringVar(value=APP.fonts[min(it.font_idx, len(APP.fonts) - 1)][0])

            def on_font(*_):
                names = [f[0] for f in APP.fonts]
                it.font_idx = names.index(fv.get()) if fv.get() in names else 0
                self.item_changed()
            fcb = ttk.Combobox(row, textvariable=fv, state="readonly", width=10,
                               values=[f[0] for f in APP.fonts])
            fcb.pack(side="left"); fcb.bind("<<ComboboxSelected>>", on_font)
            ttk.Label(row, text="字号：").pack(side="left", padx=(10, 0))
            sv = tk.StringVar(value=str(it.font_size))

            def on_size(*_):
                try:
                    it.font_size = max(12, min(240, int(sv.get())))
                except ValueError:
                    pass                      # 数值非法：保持原值
                self.item_changed()
            se = ttk.Entry(row, textvariable=sv, width=5)
            se.pack(side="left"); se.bind("<FocusOut>", on_size)
            ttk.Label(row, text="颜色：").pack(side="left", padx=(10, 0))
            cvv = tk.StringVar(value=["黑", "白", "黄", "红"][it.color & 3])

            def on_color(*_):
                it.color = ["黑", "白", "黄", "红"].index(cvv.get())
                self.item_changed()
            ccb = ttk.Combobox(row, textvariable=cvv, state="readonly", width=4,
                               values=["黑", "白", "黄", "红"])
            ccb.pack(side="left"); ccb.bind("<<ComboboxSelected>>", on_color)
            ttk.Label(row, text="底色：").pack(side="left", padx=(10, 0))
            bv = tk.StringVar(value=["黑", "白", "黄", "红"][it.text_bg & 3])

            def on_tbg(*_):
                it.text_bg = ["黑", "白", "黄", "红"].index(bv.get())
                self.item_changed()
            bcb = ttk.Combobox(row, textvariable=bv, state="readonly", width=4,
                               values=["黑", "白", "黄", "红"])
            bcb.pack(side="left"); bcb.bind("<<ComboboxSelected>>", on_tbg)
        ttk.Label(h, text="（预览实时更新；内容 id 自动生成，设备据此判断新旧）",
                  foreground="#999").pack(anchor="w", pady=(4, 0))

    # ---- 小型滑杆（裁切位置/旋转微调；防抖 0.35s 同色彩强度） ----
    def _mk_mini_scale(self, row, it, key, label, lo, hi, res=1, unit=""):
        ttk.Label(row, text=label).pack(side="left", padx=(6, 0))
        out = ttk.Label(row, text=str(getattr(it, key)), width=5)

        def on_slide(v):
            if self._editor_building:
                return
            val = int(float(v))
            out.config(text=str(val))
            self._queue_debounce(lambda: self._mini_commit(it, key, val))

        sc = ttk.Scale(row, from_=lo, to=hi, command=on_slide)
        sc.set(getattr(it, key))
        sc.pack(side="left", padx=3)
        out.pack(side="left")
        return sc

    def _queue_debounce(self, fn):
        self._cancel_slide_after()
        self._core_after = self.root.after(350, lambda: guard(fn)())

    def _mini_commit(self, it, key, val):
        self._core_after = None
        if not (0 <= self.sel < len(APP.items)) or APP.items[self.sel] is not it:
            return
        if getattr(it, key) == val:
            return
        setattr(it, key, val)
        self.item_changed(keep_editor=True)

    # ---- 高级调色窗口（13 滑杆，同配置页高级图像设置） ----
    def open_adv(self):
        it = self.cur()
        if not it or it.kind != "image":
            return
        if self._adv_win is not None:
            try:
                self._adv_win.destroy()
            except Exception:
                pass
        win = tk.Toplevel(self.root)
        self._adv_win = win
        win.title("高级调色（同设备端配置页「高级图像设置」）")
        win.geometry("460x520")
        win.transient(self.root)
        frm = ttk.Frame(win, padding=10)
        frm.pack(fill="both", expand=True)
        self._adv_building = True
        outs = {}

        def mk(key, label, lo, hi, sc):
            r = ttk.Frame(frm)
            r.pack(fill="x", pady=1)
            ttk.Label(r, text=label, width=12, anchor="e").pack(side="left")
            out = ttk.Label(r, width=6)
            val = it.adv[key]

            def on_slide(v):
                if self._adv_building:
                    return
                out.config(text=fmt(v))
                self._queue_debounce(lambda: self._adv_commit(it, key, float(v) / sc))

            def fmt(v):
                f = float(v) / sc
                return ("%.2f" % f) if sc != 1.0 else str(int(float(v)))
            s = ttk.Scale(r, from_=lo, to=hi, command=on_slide)
            s.set(val * sc)
            s.pack(side="left", fill="x", expand=True, padx=4)
            out.config(text=fmt(val * sc))
            out.pack(side="left")
            outs[key] = out

        for key, label, lo, hi, sc in ADV_SLIDERS:
            mk(key, label, lo, hi, sc)
        self._adv_building = False

        def reset_defaults():
            it.adv.update(ADV_DEFAULT)
            self._adv_win.destroy()
            self._adv_win = None
            self.item_changed()
            self.log("已恢复默认调色参数")
        btns = ttk.Frame(frm)
        btns.pack(fill="x", pady=(8, 0))
        ttk.Button(btns, text="恢复默认参数", command=guard(reset_defaults)).pack(side="left")
        ttk.Button(btns, text="完成", command=lambda: (self._adv_win.destroy(),
                                                       setattr(self, "_adv_win", None))).pack(side="left", padx=6)

    def _adv_commit(self, it, key, val):
        self._core_after = None
        if not (0 <= self.sel < len(APP.items)) or APP.items[self.sel] is not it:
            return
        if abs(it.adv[key] - val) < 1e-9:
            return
        it.adv[key] = val
        self.item_changed(keep_editor=True)

    # ---- 色彩强度拖动（防抖 0.35s，同配置页 schedulePreview 思路） ----
    def _on_core_slide(self, it, val):
        if self._editor_building:
            return
        v = int(float(val))
        if self._core_out is not None:
            try:
                self._core_out.config(text=str(v))
            except Exception:
                pass
        self._queue_debounce(lambda: self._core_commit(it, v))

    def _core_commit(self, it, v):
        self._core_after = None
        if not (0 <= self.sel < len(APP.items)) or APP.items[self.sel] is not it:
            return
        new_core = max(0.0, min(1.0, v / 100.0))
        if abs(it.core - new_core) < 1e-9:
            return                          # 值未变（初始化回声）：不重渲染
        it.core = new_core
        self.item_changed(keep_editor=True)  # 滑杆已在新位置：不重建编辑器

    def on_text(self, it, widget):
        """打字时保持文本框焦点：只重算 payload/预览，不重建编辑器。"""
        try:
            it.text = widget.get("1.0", "end").rstrip("\n")
        except Exception:
            return
        self.item_changed(keep_editor=True)

    def pick_image(self):
        it = self.cur()
        if not it:
            return
        p = filedialog.askopenfilename(title="选择图片", filetypes=[
            ("图片", "*.jpg *.jpeg *.png *.bmp *.webp *.gif"), ("所有文件", "*.*")])
        if not p:
            return                          # 取消：保持原图不变
        try:
            dst = _copy_to_assets(p)
        except Exception as e:
            messagebox.showerror("导入失败", str(e))
            return
        it.path = dst
        it.name = os.path.splitext(os.path.basename(p))[0][:20] or it.name
        self.item_changed()
        self.log(f"图片已更换：{it.name}")

    # ---- 项操作 ----
    def add_image(self):
        """先选文件、成功导入才建条目（旧版先建空路径条目必炸回调）。"""
        p = filedialog.askopenfilename(title="选择图片", filetypes=[
            ("图片", "*.jpg *.jpeg *.png *.bmp *.webp *.gif"), ("所有文件", "*.*")])
        if not p:
            return
        try:
            dst = _copy_to_assets(p)
        except Exception as e:
            messagebox.showerror("导入失败", str(e))
            return
        it = Item("image", os.path.splitext(os.path.basename(p))[0][:20])
        it.path = dst
        APP.items.append(it)
        self.sel = len(APP.items) - 1
        self.refresh_list(keep=False)
        self.tree.selection_set(str(self.sel))
        APP.save_project()
        self.log(f"已添加图片：{it.name}")

    def add_text(self):
        it = Item("text", f"文字{len(APP.items) + 1}")
        it.text = "墨印 · 远端内容"
        APP.items.append(it)
        self.sel = len(APP.items) - 1
        self.refresh_list(keep=False)
        self.tree.selection_set(str(self.sel))
        APP.save_project()

    def del_item(self):
        if not (0 <= self.sel < len(APP.items)):
            return
        if not messagebox.askyesno("删除", f"确定删除「{APP.items[self.sel].name}」？"):
            return
        APP.items.pop(self.sel)
        self.sel = -1
        self.refresh_list(keep=False)
        APP.save_project()

    def move(self, d):
        i = self.sel
        j = i + d
        if not (0 <= i < len(APP.items)) or not (0 <= j < len(APP.items)):
            return
        APP.items[i], APP.items[j] = APP.items[j], APP.items[i]
        self.sel = j
        self.refresh_list(keep=False)
        self.tree.selection_set(str(j))
        APP.save_project()

    def item_changed(self, list_only=False, keep_editor=False):
        it = self.cur()
        if not it:
            return
        if not list_only:
            self.status.config(text="正在渲染四色预览（约 1~4 秒）…")
            self.root.update_idletasks()
            try:
                with APP.lock:
                    it.build(APP.style_split, APP.orient, APP.fonts, force=True)
            except Exception as e:
                self.log(f"内容更新失败：{e}")
                return
        if keep_editor:
            try:
                self.tree.set(str(self.sel), "id",
                              "%08X%s" % (it._cid, "!" if it._bad else ""))
            except Exception:
                pass
            self.draw_preview()
        else:
            self.refresh_list()
        APP.save_project()

    # ---- 样式 / 轮播 / 方向 ----
    def on_style(self):
        APP.style_split = self.style_var.get().startswith("分割")
        # 画布高度变了，全部缓存失效；只重建当前项（懒构建），其余项等被选中
        # 或被设备拉取到时再按需渲染。
        with APP.lock:
            for it in APP.items:
                it._cache_key = None
            cur = self.cur()
            if cur is not None:
                try:
                    cur.build(APP.style_split, APP.orient, APP.fonts, force=True)
                except Exception as e:
                    self.log(f"样式切换部分失败：{e}")
        self.refresh_list()
        APP.save_project()
        w, h = orient_user_dims(APP.orient)
        self.log(f"样式切换 → {'分割式（画布 %d×%d，内容高 %d）' % (w, h, h - BOX_H) if APP.style_split else '信息框关闭（画布 %d×%d）' % (w, h)}"
                 f"；正在服务的拉取将从下次开始按新画布尺寸应答")

    def on_rot(self):
        r = self.rot_var.get()
        APP.rotation = {"顺序轮播": "seq", "随机轮播": "rand", "仅最新": "latest"}.get(r, "seq")
        APP.seq_cursor = 0
        APP.save_project()
        self.log(f"轮播方式 → {r}")

    def on_orient(self):
        """用户手动改方向 → 以用户设置优先（设备上报只提示）。"""
        idx = ORIENT_NAMES.index(self.orient_var.get())
        if APP.set_orient(idx, by_user=True):
            w, h = orient_user_dims(APP.orient)
            self.refresh_list()
            self.log(f"屏幕方向 → {ORIENT_NAMES[APP.orient]}（用户设置，优先于设备上报）；"
                     f"已渲染缓存全部失效，正在服务的拉取将从下次开始按新方向打包")
        self.refresh_style()

    def on_follow(self):
        APP.follow_orient = bool(self.follow_var.get())
        APP.save_project()
        if APP.follow_orient and APP.device_orient is not None and APP.device_orient != APP.orient:
            o = APP.device_orient
            if APP.set_orient(o, by_user=False):
                self.refresh_list()
                self.log(f"跟随设备上报 → 已切换到 {ORIENT_NAMES[o]}")
        else:
            self.log("跟随设备上报：" + ("开（设备上报方向即默认画布方向）" if APP.follow_orient
                                     else "关（以手动设置优先，设备上报仅提示）"))

    def apply_orient_ui(self, orient, note=None):
        """HTTP 线程经 uiq 请求的方向刷新（不重建编辑器，只刷控件与预览）。"""
        self.uiq.put((orient, note))

    def _uiq_pump(self):
        try:
            while True:
                orient, note = self.uiq.get_nowait()
                self.orient_var.set(ORIENT_NAMES[orient])
                self.follow_var.set(APP.follow_orient)
                self.refresh_list(keep=True)
                if note:
                    self.status.config(text=note[:120])
        except queue.Empty:
            pass
        self.root.after(160, self._uiq_pump)

    def refresh_style(self):
        self.style_var.set("分割式（顶部信息框+下方远端）" if APP.style_split
                           else "信息框关闭（全屏远端）")
        self.rot_var.set({"seq": "顺序轮播", "rand": "随机轮播",
                          "latest": "仅最新"}.get(APP.rotation, "顺序轮播"))
        self.orient_var.set(ORIENT_NAMES[APP.orient])
        self.follow_var.set(APP.follow_orient)
        self.port_var.set(str(APP.port))

    # ---- 服务 ----
    def toggle_server(self):
        if APP.server:
            self.stop_server()
        else:
            self.start_server()

    def start_server(self):
        try:
            APP.port = max(1, min(65535, int(self.port_var.get())))
        except ValueError:
            messagebox.showerror("端口", "端口必须是 1..65535 的数字")
            return
        try:
            APP.server = ThreadingHTTPServer(("0.0.0.0", APP.port), PullHandler)
        except OSError as e:
            APP.server = None
            messagebox.showerror("启动失败",
                                 f"端口 {APP.port} 起不来：{e}\n\n"
                                 "常见原因：上一次程序没退干净（任务管理器结束 pythonw.exe），\n"
                                 "或防火墙/别的软件占了这个端口。")
            return
        APP.server_thread = threading.Thread(target=APP.server.serve_forever, daemon=True)
        APP.server_thread.start()
        APP.save_project()
        ips = self.lan_ips()
        self.srv_btn.config(text="停止服务")
        self.srv_state.config(text=f"● 运行中 :{APP.port}", foreground="#0a0")
        self.log(f"服务已启动：{ips}（设备端填其中之一，或域名）")

    def stop_server(self):
        try:
            if APP.server:
                APP.server.shutdown()
                APP.server.server_close()
            APP.server = None
        except Exception as e:
            self.log(f"停服务时出现小问题（不影响退出）：{e}")
            APP.server = None
        self.srv_btn.config(text="启动服务")
        self.srv_state.config(text="（未启动）", foreground="#888")
        self.log("服务已停止")

    @staticmethod
    def lan_ips():
        ips = []
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ips.append(s.getsockname()[0])
            s.close()
        except Exception:
            pass
        return " / ".join(ips) if ips else "127.0.0.1（取不到局域网 IP，检查网络）"

    # ---- 预览 ----
    def draw_preview(self):
        try:
            self._draw_preview()
        except Exception as e:
            try:
                self.log(f"预览刷新失败：{e}")
            except Exception:
                pass

    def _draw_preview(self):
        """整屏预览（对齐设备端配置页，画布随屏幕方向）。

        · 画布 = 设备整屏（方向决定 竖屏 552×768 / 横屏 768×552）；
        · 分割式 = 顶部 160px 信息框区（纯白 + 标注，设备端本地绘制时间/温湿度）
          + 下方远端内容；信息框关闭 = 全屏均为远端内容；
        · PIL.ImageTk.PhotoImage 承载 PIL 图（tk.PhotoImage 不接受 PIL 对象）。
        """
        it = self.cur()
        cw = max(80, self.canvas.winfo_width())
        ch = max(80, self.canvas.winfo_height())
        self.canvas.delete("all")
        W, H = orient_user_dims(APP.orient)
        if not it:
            self.canvas.create_text(cw // 2, ch // 2, text="选择左侧内容查看预览",
                                    fill="#888")
            return
        if not (it._payload and it._cache_key == (APP.style_split, APP.orient)):
            self.status.config(text="正在渲染四色预览（约 1~4 秒）…")
            self.root.update_idletasks()
        with APP.lock:
            payload, cid = it.build(APP.style_split, APP.orient, APP.fonts)
            codes = it._codes
        # 更新列表 id 列（懒构建下这里才拿到 id）
        try:
            self.tree.set(str(self.sel), "id", "%08X%s" % (cid, "!" if it._bad else ""))
        except Exception:
            pass
        flat, w_, h_ = codes
        # 合成整屏码表：分割式补顶部 160 行白色（信息框区）
        if APP.style_split:
            full = bytes([1]) * (W * BOX_H) + bytes(flat)
            fw, fh = W, H
        else:
            full = bytes(flat)
            fw, fh = w_, h_
        palimg = Image.frombytes("P", (fw, fh), full)
        palimg.putpalette(_PALETTE_PAD)
        s = min(cw / fw, (ch - 26) / fh)
        disp = palimg.resize((max(1, int(fw * s)), max(1, int(fh * s))), Image.NEAREST)
        self._disp_img = disp                    # 保存合成结果（测试/排障用）
        self._tkimg = ImageTk.PhotoImage(disp)   # ★ PIL 图必须用 ImageTk 承载
        ox = (cw - disp.width) // 2
        oy = max(2, (ch - 26 - disp.height) // 2)
        self.canvas.create_image(ox, oy, anchor="nw", image=self._tkimg)
        if APP.style_split:
            by = oy + int(disp.height * BOX_H / fh)      # 信息框分隔线（缩放后）
            self.canvas.create_line(ox, by, ox + disp.width, by,
                                    fill="#8a8577", dash=(4, 3))
            self.canvas.create_text(ox + disp.width // 2, oy + int(disp.height * BOX_H / fh / 2),
                                    text="信息框区域（分割式 · 纯白）", fill="#8a8577")
        rows, rb = sub_shape(APP.orient, APP.style_split)
        label = ("分割式：设备拼「本地信息框 + 此内容（%d×%d）」" % (W, H - BOX_H)
                 if APP.style_split else "信息框关闭：全屏均为此内容（%d×%d）" % (W, H))
        label += "　方向：%s　子帧 %d×%dB" % (ORIENT_SHORT[APP.orient], rows, rb)
        if it._bad:
            label += "　⚠ " + it._bad
        self.canvas.create_text(ox, oy + disp.height + 12, anchor="nw",
                                fill="#443f33",
                                text=f"{label}　id {cid:016X}")
        self.status.config(text=f"拉取 {APP.pull_count} 次 · 最近：{APP.last_pull}"
                                if APP.pull_count else "就绪")

    # ---- 日志 / 自存 ----
    def log(self, msg):
        """线程安全：HTTP 线程只入队；控件更新全部在主线程 _log_pump 里做。"""
        self.logq.put(msg)

    def _log_pump(self):
        try:
            while True:
                m = self.logq.get_nowait()
                self.logvar.set("日志：" + m[-220:])
                self.status.config(text=f"拉取 {APP.pull_count} 次 · 最近：{APP.last_pull}")
        except queue.Empty:
            pass
        self.root.after(150, self._log_pump)

    def _auto_save_loop(self):
        APP.save_project()
        self.root.after(10000, self._auto_save_loop)


def _copy_to_assets(src_path):
    """把用户选的图片复制进 assets/（项目自包含，源图移动/删除不影响）。"""
    os.makedirs(ASSET_DIR, exist_ok=True)
    ext = os.path.splitext(src_path)[1].lower() or ".png"
    dst = os.path.join(ASSET_DIR, f"img_{int(time.time() * 1000)}{ext}")
    with open(src_path, "rb") as fsrc, open(dst, "wb") as fdst:
        while True:
            chunk = fsrc.read(1 << 20)
            if not chunk:
                break
            fdst.write(chunk)
    return dst


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except Exception:
        pass
    ui = UI(root)
    APP.ui = ui
    if APP.healed:
        try:
            messagebox.showinfo(
                "项目自检",
                "启动时自动清理了无法使用的条目：\n\n· " + "\n· ".join(APP.healed) +
                "\n\n（多为旧版 bug 遗留，或图片文件被移动/删除。其余条目不受影响。）")
        except Exception:
            pass

    def _on_close():
        try:
            ui.stop_server()
        except Exception:
            pass
        try:
            APP.save_project()
        except Exception:
            pass
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", _on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
