@echo off
start "" pythonw moink_remote.pyw
