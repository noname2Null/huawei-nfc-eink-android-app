@echo off
chcp 65001 >nul
echo [MoInK] 安装依赖（Pillow 必需 + numpy 加速）...
python -m pip install "pillow>=9.5"
if errorlevel 1 goto :fail
python -m pip install numpy || echo [MoInK] numpy 未装成：不影响使用，仅预览速度稍慢
echo.
echo 完成。双击 moink_remote.pyw 即可启动。
pause
exit /b 0
:fail
echo.
echo 安装失败：请确认已安装 Python 3.8+ 并勾选 "Add to PATH"。
pause
