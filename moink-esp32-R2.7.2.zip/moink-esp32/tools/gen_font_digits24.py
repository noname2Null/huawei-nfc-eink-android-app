#!/usr/bin/env python3
"""生成 MoInk 功能验证固件 24px 等宽数字点阵（R2.3.4）。

字体源：DejaVu Sans Bold（/usr/share/fonts/truetype/dejavu/）。
- 验证固件（verifyfw.c）局刷演示用：字号 24 的三位随机数字。
- 等宽单元（CELL_W）：取 0-9 的最大渲染宽度 + 1px 侧距，各位数字
  水平居中入格 —— 任意三位数整体宽度恒定，居中位置稳定不跳。
- 垂直：墨迹居中放入 24px 高的 em 格（DejaVu Bold 数字同为 lining
  高度，居中即等价于基线对齐）。

输出：main/font_digits24.h —— const uint32_t DIGITS24[10][24]，
  每行一个 uint32_t 位图：bit31 = 最左像素（与 font_cjk32.h 的 bit31=左
  同款），行序自上而下。CELL_W ≤ 32 由本脚本断言保证。

用法：python3 tools/gen_font_digits24.py [字体.ttf] [输出.h]
（参数省略时用沙箱默认路径；头文件已入库，本工具仅再生成时需要。）
"""
import os
import sys

from PIL import Image, ImageDraw, ImageFont

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
OUT_PATH = os.path.join(REPO, "main", "font_digits24.h")

SIZE = 24          # 字号（em 像素）
SIDE_PAD = 1       # 每侧至少 1px 侧距（防相邻位粘连）


def render_digit(font, ch):
    """渲染单个数字，返回 (ink_w, ink_h, bits[y][x] 0/1)。"""
    img = Image.new("L", (SIZE * 3, SIZE * 3), 0)
    d = ImageDraw.Draw(img)
    # anchor="ls"：以基线左下为锚，留足上空间
    d.text((SIZE, SIZE * 2), ch, font=font, fill=255, anchor="ls")
    bbox = img.getbbox()
    if not bbox:
        raise SystemExit(f"字形为空: {ch!r}（字体缺字？）")
    x0, y0, x1, y1 = bbox
    w, h = x1 - x0, y1 - y0
    bits = [[1 if img.getpixel((x0 + x, y0 + y)) >= 128 else 0
             for x in range(w)] for y in range(h)]
    return w, h, bits


def main():
    font_path = sys.argv[1] if len(sys.argv) > 1 else FONT_PATH
    out_path = sys.argv[2] if len(sys.argv) > 2 else OUT_PATH
    font = ImageFont.truetype(font_path, SIZE)

    digits = []
    for ch in "0123456789":
        w, h, bits = render_digit(font, ch)
        digits.append((w, h, bits))

    cell_w = max(w for w, _, _ in digits) + 2 * SIDE_PAD
    if cell_w > 32:
        raise SystemExit(f"CELL_W={cell_w} > 32：字号/字体选择异常")
    if any(h > SIZE for _, h, _ in digits):
        raise SystemExit("字形高度超过 24px em 格（字体异常）")

    lines = []
    lines.append("/* 由 tools/gen_font_digits24.py 生成 —— 勿手改（重跑工具即再生）。")
    lines.append(" * R2.3.4 功能验证固件局刷演示：字号 24 等宽数字（DejaVu Sans Bold）。")
    lines.append(" * 每字 24 行 × CELL_W 位，bit31 = 最左像素，行序自上而下；")
    lines.append(" * 墨迹水平/垂直居中入格（DejaVu 数字等高，居中即基线对齐）。 */")
    lines.append("#ifndef MOINK_FONT_DIGITS24_H")
    lines.append("#define MOINK_FONT_DIGITS24_H")
    lines.append("")
    lines.append(f"#define DIGITS24_CELL_W {cell_w}")
    lines.append(f"#define DIGITS24_H      {SIZE}")
    lines.append("")
    lines.append("static const uint32_t DIGITS24[10][DIGITS24_H] = {")
    for d, (w, h, bits) in enumerate(digits):
        rows = []
        for gy in range(SIZE):
            v = 0
            # 垂直居中：墨迹行 range(SIZE) 内偏移
            iy = gy - (SIZE - h) // 2
            if 0 <= iy < h:
                for gx in range(w):
                    if bits[iy][gx]:
                        v |= 1 << (31 - (SIDE_PAD + gx))
            rows.append(f"0x{v:08X}")
        rows_txt = ", ".join(rows)
        lines.append(f"    /* '{d}' ink {w}x{h} */ {{ {rows_txt} }},")
    lines.append("};")
    lines.append("")
    lines.append("#endif /* MOINK_FONT_DIGITS24_H */")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    # 控制台 ASCII 预览（快速人检）
    print(f"CELL_W={cell_w}（数字墨宽 "
          f"{min(w for w, _, _ in digits)}..{max(w for w, _, _ in digits)}，"
          f"墨高 {digits[0][1]}）")
    for d, (w, h, bits) in enumerate(digits):
        print(f"--- {d} ---")
        for gy in range(SIZE):
            iy = gy - (SIZE - h) // 2
            row = ""
            if 0 <= iy < h:
                row = ("".join("#" if bits[iy][gx] else "." for gx in range(w))
                       .rjust(SIDE_PAD + w).ljust(cell_w))
            print("    " + row)
    print(f"已写入 {out_path}")


if __name__ == "__main__":
    main()
