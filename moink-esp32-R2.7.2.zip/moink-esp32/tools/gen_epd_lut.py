#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_epd_lut.py —— R2.3.0 生成 JD79665 快刷 R20 波形表（main/epd_lut_fast.h）。

移植自 jd79665aa-driver/host/lut_codec.py 的 wire 编码 + docs/06 的 P3/N3
最简短波形（该仓库在 SE0398NZ07A1 真机验证的配方）：

  2048B 表 = 逻辑零底板（wire 0xFF），仅填：
    头部字节 6 = 逻辑 1（启用 H1 首槽计数，docs/04 §7）
    H0（VCOM）   ：A 相 3 扫描 @ 电平 00（基线档）→ 终止
    H1（码 00 黑）：A 相 3 扫描 @ 电平 01（L01/Mode0 强正 = 黑化）→ 终止
    H2（码 01 白）：A 相 3 扫描 @ 电平 10（L10/负 = 推浅）→ 终止
    H3（码 10 黄）：A 相 3 扫描 @ 电平 10（浅色目标）→ 终止
    H4（码 11 红）：A 相 3 扫描 @ 电平 10（浅色目标）→ 终止
    H5（source 供电）：A 相 3 扫描 @ 电平 00（Mode0）→ 终止

  本项目保持色码语义不变（0黑/1白/2黄/3红，区别于参考仓库视频播放器的
  动作码重映射），黄/红像素按「浅色目标」处理（信息框区域基本只有黑字
  与白底；叠加式密度<100 时透出的黄/红照片像素被推向浅色，15 次局刷后
  的全刷会复位）。

  3 扫描 @ 120Hz PLL ≈ 25~40ms/次（参考仓库实测 3 扫描档 ~26.5fps 提交率）。
  wire 编码：wire = 0xFF XOR permute(logical)，逻辑 bit 0..7 → 线上 bit 4,7,6,1,0,3,2,5。
"""
import os

WIRE_BITS = (4, 7, 6, 1, 0, 3, 2, 5)


def encode_byte(logical):
    return 0xFF ^ sum(((logical >> bit) & 1) << wire
                      for bit, wire in enumerate(WIRE_BITS))


def pack_state(outer, levels, frames, repeats):
    """levels: 6 个 2bit 电平码【数值 0..3】（A..F）；frames: 6 个扫描数；repeats: (RA, RB)。"""
    if any(not 0 <= v <= 3 for v in levels):
        raise ValueError("levels must be 0..3 (2bit 电平码数值)")
    abc = sum(levels[i] << (6 - 2 * i) for i in range(3))
    deff = sum(levels[i + 3] << (6 - 2 * i) for i in range(3))
    logical = (outer, abc, deff, frames[0], frames[1], frames[2] & 0x7F,
               repeats[0], frames[3], frames[4], frames[5] & 0x7F, repeats[1])
    return bytes(encode_byte(v) for v in logical)


def build_table():
    t = bytearray([0xFF] * 2048)          # 逻辑零底板
    t[6] = encode_byte(1)                 # 头部字节 6 = 逻辑 1
    # 每路（H0..H5）首状态偏移 = 7 + 88*H（docs/04 §3）；电平码取 2bit 数值：
    #   00=0（L00/基线） 01=1（L01 强正·黑化） 10=2（L10 负·推浅）
    lanes = [
        (0, 0, "H0 VCOM 基线 00"),
        (1, 1, "H1 码00 黑 -> L01 黑化"),
        (2, 2, "H2 码01 白 -> L10 推浅"),
        (3, 2, "H3 码10 黄 -> L10 推浅"),
        (4, 2, "H4 码11 红 -> L10 推浅"),
        (5, 0, "H5 source 供电 Mode0"),
    ]
    for lane, level, desc in lanes:
        state = pack_state(1, [level, 0, 0, 0, 0, 0], [3, 0, 0, 0, 0, 0], [0, 0])
        off = 7 + 88 * lane
        t[off:off + 11] = state
    return bytes(t)


def self_test(table):
    # 自检：wire 编码可逆 + 关键偏移回读
    assert encode_byte(0) == 0xFF and encode_byte(1) == 0xEF
    for lane, level, _ in [
        (0, 0, None), (1, 1, None), (2, 2, None),
        (3, 2, None), (4, 2, None), (5, 0, None),
    ]:
        off = 7 + 88 * lane
        abc = table[off + 1]      # ABC_levels 在状态内偏移 1
        logical_abc = 0
        for bit, wire in enumerate(WIRE_BITS):
            logical_abc |= (((abc ^ 0xFF) >> wire) & 1) << bit
        assert (logical_abc >> 6) == level, (lane, hex(logical_abc))
    assert table[6] == 0xEF
    # 未用区域保持逻辑零底板
    assert table[600] == 0xFF and table[2047] == 0xFF


def main():
    table = build_table()
    self_test(table)
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "..", "main", "epd_lut_fast.h")
    out = os.path.normpath(out)
    with open(out, "w", encoding="utf-8") as f:
        f.write("/* 由 tools/gen_epd_lut.py 生成 —— 勿手改（重跑工具即再生）。\n")
        f.write(" * R2.3.0 JD79665 快刷 R20 波形表（P3/N3 最简短波形，2048B wire 编码）。\n")
        f.write(" * 配方与编码移植自 jd79665aa-driver（SE0398NZ07A1 真机验证），\n")
        f.write(" * 详见 tools/gen_epd_lut.py 文档注释与该仓库 docs/04、docs/06。 */\n")
        f.write("#ifndef MOINK_EPD_LUT_FAST_H\n#define MOINK_EPD_LUT_FAST_H\n\n")
        f.write("static const uint8_t EPD_LUT_FAST[2048] = {\n")
        for i in range(0, 2048, 12):
            f.write("    " + ", ".join("0x%02X" % b for b in table[i:i + 12]) + ",\n")
        f.write("};\n\n#endif /* MOINK_EPD_LUT_FAST_H */\n")
    print("wrote", out, "(%d bytes table)" % len(table))


if __name__ == "__main__":
    main()
