@echo off
rem 墨印视频快刷测试 PC 端 · 安装依赖（首次使用运行一次）
cd /d "%~dp0"
python -m pip install -r requirements.txt
echo.
echo 依赖安装完成。双击 run.bat 启动。
pause
