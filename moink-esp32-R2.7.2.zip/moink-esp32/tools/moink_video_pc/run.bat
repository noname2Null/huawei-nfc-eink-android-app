@echo off
rem 墨印视频快刷测试 PC 端 · 启动（双击即可）
cd /d "%~dp0"
python moink_video_pc.py
if errorlevel 1 pause
