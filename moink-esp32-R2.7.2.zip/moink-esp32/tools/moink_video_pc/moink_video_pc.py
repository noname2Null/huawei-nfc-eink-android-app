#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
墨印 MoInk · 视频快刷测试 PC 端（Windows / 跨平台）MV2
======================================================

配套「墨印视频快刷测试固件」（moink-esp32/video_fw，VIDEO-R3）：
把视频转换成黑白（灰度→抖动二值）、按设备协商的播放窗口裁剪、按抽帧规格
（默认 24 fps）生成屏数据，**只传与上一帧差异的写行**，本地起 **TCP** 端口
供设备拉取（一条连接一个会话，请求-响应，无每帧连接开销）。

VIDEO-R3 新增**会话预取**：hello 后即启动预取线程（深度 3），抽帧+缩放+
抖动+差分打包先行完成，'N' 到来即弹帧——R2 实测设备「取」247ms 的大头
正是本端按请求同步转码；协议字节流与 MV2 完全一致，旧固件可对播。

── 拉流协议 MV2（与 video_fw/main/video_main.c 同源，两端一起改） ──────────
[发现] 本程序每 0.8s 向 UDP 255.255.255.255:8899 广播 "MOINKVID2 <ip> <port>\\n"
       （设备 NVS 键 vurl 手动指定服务器时优先直连，跳过发现）
[TCP]  默认端口 8094；**一条连接一个会话**（断开即作废，重连 hello 重置 →
       首帧必为全帧，设备画布自愈）。两端 TCP_NODELAY。
       设备连接后发一行文本握手（\\n 结束）：
         "H orient=<0..3> col0=<c0> col1=<c1> row0=<r0> row1=<r1> xmirror=<0|1>\\n"
       本程序回 16B：'M''V''2' | rows u16le | row_bytes u16le | frames u32le
         | fps u8 | flags u8 | pad[3]
       rows = r1-r0+1（窗口写行数）、row_bytes = (c1-c0+1)/4（窗口行字节）；
       frames=0xFFFFFFFF=无限（测试图案）；flags bit0：0=重复动作码
       （自清残影），1=安静差异码（最安静）。
[帧]   设备发 "N\\n" 请求一帧；本程序回：
         frame_id u32le | row_count u16le | [row_no u16le + row_bytes B]×N
         | crc16 u16le
       row_no 为窗口内相对行（0..rows-1）；crc16=CRC16-CCITT-FALSE（初值
       0xFFFF，多项式 0x1021）覆盖其前全部字节；frame_id 循环点回 0；
       frame_id==0 必为全帧；row_count==0 = 无变化帧。
[复位] 设备发 "R\\n" → 会话游标清零（设备 CRC/序错后自救）。
[帧字节] 窗口画布行（窗宽 (c1-c0+1)/4 字节）；像素码 c 位于字节 b[c>>2] 的
       6-2*(c&3) 两位（MSB 优先 2bit 组）。寄存器 LUT 动作码：
       01=黑目标(0x55)、10=白/浅色目标(0xAA)、00=保持(0x00)。
       本程序按设备上报的 orient 完成用户视角→逻辑画布映射，再裁剪窗口，
       设备零换算；xmirror 由设备端 0x83 编码处理，本程序仅接收不使用。

用法（GUI）：
    python moink_video_pc.py
用法（无界面 / 自动化）：
    python moink_video_pc.py --nogui --source test:gradient --fps 24
    python moink_video_pc.py --nogui --source 视频文件.mp4 --dither bayer8

依赖：numpy、Pillow、opencv-python（测试图案模式不需要 opencv）。
"""

import argparse
import socket
import struct
import sys
import threading
import time
from collections import deque

import numpy as np
from PIL import Image

# ============================================================ 协议常量（与固件同源）

ROWS, RB, COLS = 552, 192, 768          # 逻辑画布：552 写行 × 768 缓冲列
UDP_PORT = 8899
TCP_PORT_DEF = 8094
MAGIC = b"MV2"
HDR_LEN = 6                               # frame_id u32 + row_count u16
FRAMES_INF = 0xFFFFFFFF

# VIDEO-R3：会话预取深度。预取线程把「抽帧+缩放+抖动+差分打包」提前做完，
# 设备 'N' 到来即弹帧——R2 实测设备「取」247ms 的大头是本端按请求同步转码
# （hello 后即开始预取，设备工厂清屏 15s 里队列已填满）。
PREFETCH_DEPTH = 3

CODE_BLACK = 0x01                         # 码 01 = 黑目标动作（字节 0x55）
CODE_WHITE = 0x02                         # 码 10 = 白/浅色目标动作（字节 0xAA）
CODE_HOLD = 0x00                          # 码 00 = 保持（字节 0x00）

DITHERS = ("bayer8", "bayer4", "fs", "none")
TEST_PATTERNS = ("gradient", "bars", "checker", "noise", "ball")


def crc16_ccitt(data: bytes) -> int:
    """CRC16-CCITT-FALSE：初值 0xFFFF、多项式 0x1021（与固件 crc16_update 一致）。"""
    crc = 0xFFFF
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if (crc & 0x8000) else (crc << 1)
            crc &= 0xFFFF
    return crc


# ============================================================ 抖动与像素打包

def _bayer_matrix(n: int) -> np.ndarray:
    """标准 Bayer 阈值矩阵（0..n²-1 递推生成），归一化到 (0,1) 开区间。"""
    m = np.array([[0]], dtype=np.uint32)
    for _ in range(n.bit_length() - 1):
        k = m.shape[0]
        m = np.block([[4 * m, 4 * m + 2], [4 * m + 3, 4 * m + 1]])
    return (m + 0.5) / (m.size)          # (0,1) 开区间，避免端点整行同判


_BAYER4 = _bayer_matrix(4)
_BAYER8 = _bayer_matrix(8)


def dither_to_bw(gray: np.ndarray, method: str) -> np.ndarray:
    """灰度 uint8 (H,W) → 黑白 bool (H,W)（True=黑）。"""
    if method == "none":
        return gray < 128
    if method == "fs":
        img = Image.fromarray(gray, mode="L")
        bw = img.convert("1", dither=Image.Dither.FLOYDSTEINBERG)
        return np.asarray(bw, dtype=np.uint8) == 0     # PIL: 0=黑
    mat = _BAYER4 if method == "bayer4" else _BAYER8
    h, w = gray.shape
    th = np.tile(mat, (h // mat.shape[0] + 1, w // mat.shape[1] + 1))[:h, :w]
    return (gray / 255.0) < th


def pack_codes(code: np.ndarray) -> np.ndarray:
    """2bit 像素码 (H,W) → 打包行 (H, W//4) uint8。
    每字节 4 像素、MSB 优先（像素 c 在组 6-2*(c&3)）。"""
    h, w = code.shape
    u = code.astype(np.uint8).reshape(h, w // 4, 4)
    shifts = np.array([6, 4, 2, 0], dtype=np.uint8)
    return (u << shifts).sum(axis=2, dtype=np.uint8)


def orient_map(bw_user: np.ndarray, orient: int) -> np.ndarray:
    """用户视角黑白图 → 逻辑画布 (ROWS,COLS)。
    与固件 u2p 同源：o0 j=ux,c=uy；o1 j=uy,c=767-ux；o2 j=551-ux,c=767-uy；o3 j=551-uy,c=767-ux。
    用户图尺寸：o0/o2 竖屏 768×552、o1/o3 横屏 552×768（均为 (uy,ux) 序）。"""
    if orient == 0:
        return np.ascontiguousarray(bw_user.T)                       # (552,768)
    if orient == 1:
        return np.ascontiguousarray(bw_user[:, ::-1])                # 横屏水平翻转
    if orient == 2:
        return np.ascontiguousarray(bw_user[::-1, ::-1].T)
    return np.ascontiguousarray(bw_user[::-1, ::-1])


# ============================================================ 帧源

class TestPatternSource:
    """内置测试图案（无限帧；不需要 opencv）——快速验证链路与快刷观感。"""

    kind = "test"
    infinite = True

    def __init__(self, pattern: str, fps: int):
        self.pattern = pattern
        self.fps = fps
        self._k = 0
        self._rng = np.random.default_rng(20261101)
        # 弹跳球状态（全屏画布坐标：始终按用户视角全屏渲染，窗口只取局部）
        self._bx, self._by = 276.0, 384.0
        self._vx, self._vy = 90.0, 70.0

    def frame_gray_user(self, shape_hw) -> np.ndarray:
        """返回用户视角灰度 uint8（shape_hw 随 orient：竖 768×552 / 横 552×768）。"""
        h, w = shape_hw
        k = self._k
        self._k += 1
        if self.pattern == "gradient":
            # 竖直渐变按帧滚动：灰度细腻度 + 抖动观感
            off = (k * 6) % 256
            g = (np.arange(h, dtype=np.int32)[:, None] + off) % 256
            return np.tile(g, (1, w)).astype(np.uint8)
        if self.pattern == "bars":
            # 移动黑白竖条：极限对比闪烁感测试
            x = np.arange(w, dtype=np.int32) + (k * 24)
            bar = ((x // 48) % 2 == 0)
            line = np.where(bar, 0, 255).astype(np.uint8)
            return np.repeat(line[None, :], h, axis=0)
        if self.pattern == "checker":
            # 棋盘整屏翻转：最坏情况（每帧全屏变化 = 差分/带宽极限）
            yy, xx = np.indices((h, w))
            c = ((xx // 64 + yy // 64 + k) % 2 == 0)
            return np.where(c, 0, 255).astype(np.uint8)
        if self.pattern == "noise":
            return self._rng.integers(0, 256, size=(h, w), dtype=np.uint8)
        if self.pattern == "ball":
            # 弹跳小球（局部小区域变化 = 局刷最小开销路径）
            dt = 1.0 / self.fps
            self._bx += self._vx * dt
            self._by += self._vy * dt
            if self._bx < 40 or self._bx > w - 40:
                self._vx = -self._vx
                self._bx = min(max(self._bx, 40), w - 40)
            if self._by < 40 or self._by > h - 40:
                self._vy = -self._vy
                self._by = min(max(self._by, 40), h - 40)
            yy, xx = np.indices((h, w))
            ball = (xx - self._bx) ** 2 + (yy - self._by) ** 2 < 32 ** 2
            return np.where(ball, 0, 230).astype(np.uint8)
        raise ValueError(f"未知测试图案 {self.pattern}")

    def restart(self):
        self._k = 0


class VideoFileSource:
    """视频文件源：按目标 fps 抽帧（24fps 规格数据；设备按快刷极限播放）。"""

    kind = "video"
    infinite = True                        # 循环播放（到尾重开）

    def __init__(self, path: str, fps: int):
        import cv2                          # 延迟导入：测试图案模式无需 opencv
        self.cv2 = cv2
        self.path = path
        self.fps = fps
        self._cap = cv2.VideoCapture(path)
        if not self._cap.isOpened():
            raise RuntimeError(f"无法打开视频：{path}")
        self.src_fps = self._cap.get(cv2.CAP_PROP_FPS) or 25.0
        if not (1.0 <= self.src_fps <= 240.0):
            self.src_fps = 25.0
        self._t = 0.0                       # 虚拟时间轴（跨循环单调递增）
        self._pos = 0.0                     # cap 当前所在源时间轴位置
        self._last = None                   # 最近读出的源帧（低帧率源复用）
        # 循环时长：优先 FRAME_COUNT 估计；不可靠（返回 0）则首次读尽时实测
        n = self._cap.get(cv2.CAP_PROP_FRAME_COUNT)
        self._duration = (n / self.src_fps) if (n and n > 0) else 0.0

    def _rewind(self):
        """回卷到第 0 帧并读出它：先试 seek，后端不可靠则重开 capture。"""
        cv2 = self.cv2
        self._cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        ok, f = self._cap.read()
        if ok and f is not None:
            return f
        self._cap.release()
        self._cap = cv2.VideoCapture(self.path)
        if not self._cap.isOpened():
            raise RuntimeError(f"视频重开失败：{self.path}")
        ok, f = self._cap.read()
        if not ok or f is None:
            raise RuntimeError(f"视频无法重读：{self.path}")
        return f

    def frame_gray_user(self, shape_hw) -> np.ndarray:
        """按目标 fps 抽帧：虚拟时钟对循环时长取模（跨循环循环播放），
        顺序读 + 帧内复用；目标在过去则回卷，读尽/空帧则回卷续读。"""
        cv2 = self.cv2
        tt = self._t % self._duration if self._duration > 0 else self._t
        self._t += 1.0 / self.fps

        # 目标时间在已读位置之前（新循环）→ 回卷（_rewind 已消费第 0 帧）
        if self._last is None or tt < self._pos - 1.0 / self.src_fps - 1e-9:
            self._last = self._rewind()
            self._pos = 1.0 / self.src_fps

        while self._pos <= tt + 1e-9:
            ok, frame = self._cap.read()
            if not ok or frame is None:
                if self._duration <= 0:
                    # FRAME_COUNT 不可靠：以读尽时刻的 pos 实测循环时长
                    self._duration = max(self._pos, 1.0 / self.src_fps)
                    tt = tt % self._duration
                frame = self._rewind()
                self._pos = 0.0
            self._last = frame
            self._pos += 1.0 / self.src_fps
        h, w = shape_hw
        return _fit_image(cv2.cvtColor(self._last, cv2.COLOR_BGR2GRAY), w, h)

    def restart(self):
        """外部重置（会话 reset 时全清：虚拟时钟 + 解码器都回起点）。"""
        self._cap.set(self.cv2.CAP_PROP_POS_FRAMES, 0)
        self._pos = 0.0
        self._t = 0.0
        self._last = None


def _fit_image(gray: np.ndarray, w: int, h: int) -> np.ndarray:
    """短边裁切居中 + 缩放到 (h,w)（用户视角画布尺寸随 orient）。"""
    import cv2
    ih, iw = gray.shape
    scale = max(w / iw, h / ih)             # 铺满裁切：按放大比例裁短边
    nw, nh = max(1, int(round(iw * scale))), max(1, int(round(ih * scale)))
    x0 = max(0, (nw - w) // 2)
    y0 = max(0, (nh - h) // 2)
    resized = cv2.resize(gray, (nw, nh), interpolation=cv2.INTER_AREA)
    return resized[y0:y0 + h, x0:x0 + w]


# ============================================================ 会话与服务器（MV2 TCP）

class Session:
    """一条 TCP 连接一个会话：窗口 + 方向 + 独立游标与基准画布。
    VIDEO-R3 新增会话预取：producer 线程先行渲染深度 PREFETCH_DEPTH 帧，
    need_reset 把会话复位路由进渲染路径（渲染状态单写者）。"""

    def __init__(self, orient: int, c0: int, c1: int, r0: int, r1: int):
        self.orient = orient
        self.c0, self.c1, self.r0, self.r1 = c0, c1, r0, r1
        self.win_rows = r1 - r0 + 1
        self.win_rb = (c1 - c0 + 1) // 4
        self.frame_id = 0
        self.prev_bw = None                 # 上一帧窗口黑白（安静模式用）
        self.prev_rows = None               # 上一帧打包行（差分基准）
        self.frames_sent = 0
        self.bytes_sent = 0
        # ---- VIDEO-R3 预取 ----
        self.cond = threading.Condition()
        self.q = []                         # 预取队列（已渲染帧）
        self.need_reset = False             # 复位请求：下次渲染从帧 0 全帧重来
        self.closed = False                 # 连接关闭：预取线程退出
        self.prod_ok = True                 # 预取线程健康（False=同步兑底）
        self.producer = None                # 预取线程（hello 后启动）


def parse_hello(line: str):
    """'H orient=0 col0=256 col1=511 row0=212 row1=339 xmirror=0' → dict（int 值）。
    校验窗口合法（列 4 对齐、范围、行范围、orient 0..3）。失败抛 ValueError。"""
    kv = {}
    for tok in line.split()[1:]:
        if "=" not in tok:
            continue
        k, v = tok.split("=", 1)
        kv[k] = v
    try:
        orient = int(kv.get("orient", "0")) & 3
        c0 = int(kv["col0"]); c1 = int(kv["col1"])
        r0 = int(kv["row0"]); r1 = int(kv["row1"])
    except KeyError as e:
        raise ValueError(f"hello 缺参数 {e}")
    if not (0 <= c0 < c1 < COLS and (c1 - c0 + 1) % 4 == 0):
        raise ValueError(f"列窗口非法 {c0}..{c1}（需 0<=c0<c1<{COLS} 且 4 对齐）")
    if not (0 <= r0 < r1 < ROWS):
        raise ValueError(f"行窗口非法 {r0}..{r1}（需 0<=r0<r1<{ROWS}）")
    return orient, c0, c1, r0, r1


class VideoServer:
    def __init__(self, source, cfg):
        self.source = source
        self.cfg = cfg                      # dict: dither/mode/fps/port
        self.running = False
        self.lsock = None
        self.accept_thread = None
        self.beacon_thread = None
        self.lock = threading.Lock()        # 帧渲染 + 源推进互斥（多设备交错拉取）
        self.stats_lock = threading.Lock()
        self.total_frames = 0
        self.total_bytes = 0
        self.last_peer = None
        self.sessions = {}                  # 连接对象 → Session（断开即删）
        self.log_lines = deque(maxlen=200)
        self.on_log = None                  # GUI 回调（无 GUI 时为 None）

    # ---------- 日志 ----------
    def log(self, msg: str):
        line = time.strftime("%H:%M:%S ") + msg
        self.log_lines.append(line)
        print(line, flush=True)
        if self.on_log:
            try:
                self.on_log(line)
            except Exception:
                pass

    # ---------- 帧生成 ----------
    @staticmethod
    def user_canvas_hw(orient: int):
        return (768, 552) if orient in (0, 2) else (552, 768)

    def render_frame(self, sess: Session):
        """生成下一帧的窗口打包行 + 窗口内相对差分行号；更新会话状态。"""
        hw = self.user_canvas_hw(sess.orient)
        gray = self.source.frame_gray_user(hw)
        if gray.shape != hw:
            raise RuntimeError(f"源帧尺寸 {gray.shape} ≠ 画布 {hw}")
        bw_user = dither_to_bw(gray, self.cfg["dither"])
        full = orient_map(bw_user, sess.orient)                 # (ROWS,COLS) 逻辑画布
        win = np.ascontiguousarray(
            full[sess.r0:sess.r1 + 1, sess.c0:sess.c1 + 1])     # (win_rows, win_cols)

        if self.cfg["mode"] == 1:
            prev = sess.prev_bw if sess.prev_bw is not None else ~win
            code = np.where(win == prev, CODE_HOLD,
                            np.where(win, CODE_BLACK, CODE_WHITE))
        else:
            code = np.where(win, CODE_BLACK, CODE_WHITE)
        rows = pack_codes(code)                                 # (win_rows, win_rb)

        if sess.prev_rows is None:
            changed = list(range(sess.win_rows))                # 首帧=全帧
        else:
            diff = np.any(rows != sess.prev_rows, axis=1)
            changed = np.nonzero(diff)[0].tolist()

        sess.prev_bw = win
        sess.prev_rows = rows.copy()
        return rows, changed

    def _render_pack(self, sess: Session) -> bytes:
        """渲染 + 打包下一帧（含 fid 分配）。会话渲染状态（frame_id/
        prev_*/source 游标）只在本函数的 self.lock 段内变更——预取线程与
        同步兑底共用同一入口，单写者语义；need_reset 在此内联完成复位。"""
        with self.lock:
            if sess.need_reset:
                sess.frame_id = 0
                sess.prev_bw = None
                sess.prev_rows = None
                self.source.restart()
                sess.need_reset = False
            rows, changed = self.render_frame(sess)
            fid = sess.frame_id
            sess.frame_id += 1
            if sess.frame_id >= (1 << 32):
                sess.frame_id = 0

        payload = bytearray()
        payload += struct.pack("<IH", fid & 0xFFFFFFFF, len(changed))
        for r in changed:
            payload += struct.pack("<H", r)
            payload += rows[r].tobytes()
        payload += struct.pack("<H", crc16_ccitt(bytes(payload)))
        return bytes(payload)

    def build_next(self, sess: Session) -> bytes:
        """'N' 请求：优先弹预取队列（转码已在线程里完成，设备侧「取」
        不再包含渲染耗时）；预取不可用/未就绪时同步兑底（R2 行为）。"""
        payload = None
        if sess.producer is not None and sess.prod_ok:
            with sess.cond:
                deadline = time.time() + 10.0
                while not sess.q and sess.prod_ok:
                    remain = deadline - time.time()
                    if remain <= 0:
                        break
                    sess.cond.wait(remain)
                if sess.q:
                    payload = sess.q.pop(0)
                    sess.cond.notify_all()
            if payload is None:
                self.log("[会话] 预取未就绪——本帧同步渲染（偶发正常）")
        if payload is None:
            payload = self._render_pack(sess)

        sess.frames_sent += 1
        sess.bytes_sent += len(payload)
        with self.stats_lock:
            self.total_frames += 1
            self.total_bytes += len(payload)
            self.last_peer = f"{sess.c1 - sess.c0 + 1}x{sess.win_rows}窗"
        return payload

    def _producer_loop(self, sess: Session):
        """会话预取线程（VIDEO-R3）：先行渲染 PREFETCH_DEPTH 帧，'N' 到来
        即弹。渲染在 self.lock 下与其它会话串行（多设备交错拉取语义与
        R2 一致）；复位/断开期间渲染的帧在入队前作废重渲染。"""
        try:
            while True:
                with sess.cond:
                    while (not sess.closed) and (not sess.need_reset) \
                            and len(sess.q) >= PREFETCH_DEPTH:
                        sess.cond.wait()
                    if sess.closed:
                        return
                try:
                    payload = self._render_pack(sess)
                except Exception as e:                     # noqa: BLE001
                    with sess.cond:
                        sess.prod_ok = False
                        sess.cond.notify_all()
                    self.log(f"[预取] 渲染异常 {e!r}——该会话回退同步渲染")
                    return
                with sess.cond:
                    if sess.closed or sess.need_reset:
                        continue                # 复位/断开后到达：作废重渲染
                    sess.q.append(payload)
                    sess.cond.notify_all()
        finally:
            with sess.cond:
                sess.prod_ok = False
                sess.cond.notify_all()

    def build_hello(self, sess: Session) -> bytes:
        frames = FRAMES_INF if getattr(self.source, "infinite", True) else 0
        flags = int(self.cfg.get("mode", 0)) & 1
        return MAGIC + struct.pack("<HHIBB", sess.win_rows, sess.win_rb, frames,
                                   int(self.cfg.get("fps", 24)), flags) + b"\0" * 3

    def reset_session(self, sess: Session):
        """会话复位：清预取队列 + 置 need_reset；基准/游标/source 的清零
        由下一次 _render_pack 在 self.lock 内完成（渲染状态单写者，
        预取线程在途的帧会在入队前被作废重渲染）。"""
        with sess.cond:
            sess.q.clear()
            sess.need_reset = True
            sess.cond.notify_all()

    # ---------- TCP ----------
    def start(self):
        if self.running:
            return
        port = int(self.cfg.get("port", TCP_PORT_DEF))
        self.lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.lsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.lsock.bind(("0.0.0.0", port))
        self.lsock.listen(4)
        self.running = True
        self.accept_thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.accept_thread.start()
        self.beacon_thread = threading.Thread(target=self._beacon, daemon=True)
        self.beacon_thread.start()
        self.log(f"[服务] TCP 端口 {port}（MV2 长连接）；UDP 广播 {UDP_PORT} 每 0.8s")
        self.log(f"[服务] 源={type(self.source).__name__} 抖动={self.cfg['dither']} "
                 f"模式={'安静差异' if self.cfg.get('mode') == 1 else '重复动作'} fps={self.cfg.get('fps')}")

    def stop(self):
        self.running = False
        if self.lsock:
            try:
                self.lsock.close()
            except Exception:
                pass
            self.lsock = None
        self.sessions.clear()
        self.log("[服务] 已停止")

    def _accept_loop(self):
        while self.running:
            try:
                conn, addr = self.lsock.accept()
            except OSError:
                break                        # lsock 关闭（stop）
            t = threading.Thread(target=self._handle_conn,
                                 args=(conn, addr), daemon=True)
            t.start()

    def _handle_conn(self, conn: socket.socket, addr):
        """一条连接 = 一个会话：H 握手 → N 帧 / R 复位 循环。"""
        peer = f"{addr[0]}:{addr[1]}"
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        conn.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 256 * 1024)
        sess = None
        try:
            conn.settimeout(60.0)            # 空闲保活上限（60s 无指令断开）
            rfile = conn.makefile("rb")
            while self.running:
                line = rfile.readline()
                if not line:
                    break
                text = line.decode("utf-8", "replace").strip()
                if not text:
                    continue
                cmd = text.split()[0].upper()
                if cmd == "H":
                    orient, c0, c1, r0, r1 = parse_hello(text)
                    sess = Session(orient, c0, c1, r0, r1)
                    with self.lock:
                        self.sessions[conn] = sess
                    self.log(f"[会话] {peer} hello：orient={orient} "
                             f"窗口 {c1 - c0 + 1}×{r1 - r0 + 1} @({c0},{r0})")
                    conn.sendall(self.build_hello(sess))
                    # VIDEO-R3：启动会话预取（设备工厂清屏 15s 里队列即填满，
                    # 首帧到手即免等转码）
                    sess.producer = threading.Thread(
                        target=self._producer_loop, args=(sess,),
                        name=f"prefetch-{peer}", daemon=True)
                    sess.producer.start()
                elif cmd == "N":
                    if sess is None:
                        conn.sendall(b"ERR no hello\n")
                        continue
                    conn.sendall(self.build_next(sess))
                elif cmd == "R":
                    if sess is not None:
                        self.reset_session(sess)
                        self.log(f"[会话] {peer} reset（下一帧全帧）")
                else:
                    self.log(f"[会话] {peer} 未知指令 {text!r}，忽略")
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass
        except Exception as e:
            self.log(f"[会话] {peer} 异常 {e!r}")
        finally:
            if sess is not None:
                with sess.cond:
                    sess.closed = True
                    sess.cond.notify_all()
            with self.lock:
                self.sessions.pop(conn, None)
            try:
                conn.close()
            except Exception:
                pass
            if sess is not None:
                self.log(f"[会话] {peer} 断开（已发 {sess.frames_sent} 帧 / "
                         f"{sess.bytes_sent / 1024:.0f} KB）")

    def _beacon(self):
        """UDP 广播发现信标。"""
        ip = _local_ip()
        msg = f"MOINKVID2 {ip} {self.cfg.get('port', TCP_PORT_DEF)}\n".encode()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        try:
            while self.running:
                try:
                    s.sendto(msg, ("255.255.255.255", UDP_PORT))
                except OSError:
                    pass                     # 个别网卡不支持广播：忽略
                time.sleep(0.8)
        finally:
            s.close()

    # ---------- 统计 ----------
    def stats_text(self):
        with self.stats_lock:
            tf, tb, peer = self.total_frames, self.total_bytes, self.last_peer
        if tf:
            avg = tb / tf
            return (f"已发 {tf} 帧｜均 {avg / 1024:.1f} KB/帧｜窗口 {peer or '—'}"
                    f"｜连接数 {len(self.sessions)}")
        return "等待设备拉取…（设备菜单直接回车即开始播放）"


def _local_ip() -> str:
    """取本机出口 IP（UDP connect 不发包）。"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


# ============================================================ GUI

def run_gui(cfg):
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title("墨印视频快刷测试 · PC 端（MoInk Video MV2）")
    root.geometry("780x640")
    root.minsize(720, 560)

    state = {"server": None, "source": None}

    frm = ttk.Frame(root, padding=10)
    frm.pack(fill="both", expand=True)

    # ---- 源 ----
    box_src = ttk.LabelFrame(frm, text=" 内容源 ", padding=8)
    box_src.pack(fill="x")
    src_var = tk.StringVar(value="测试图案")
    pat_var = tk.StringVar(value=TEST_PATTERNS[0])
    vid_var = tk.StringVar(value="")

    def kind_changed(*_):
        kind = src_var.get()
        box_pat.configure(state="readonly" if kind == "测试图案" else "disabled")
        btn_pick.configure(state="normal" if kind == "视频文件" else "disabled")
    src_var.trace_add("write", kind_changed)

    ttk.Radiobutton(box_src, text="测试图案（无需视频/opencv）", variable=src_var,
                    value="测试图案").grid(row=0, column=0, sticky="w")
    ttk.Label(box_src, text="图案：").grid(row=0, column=1, sticky="e")
    box_pat = ttk.Combobox(box_src, textvariable=pat_var, values=list(TEST_PATTERNS),
                           state="readonly", width=10)
    box_pat.grid(row=0, column=2, sticky="w", padx=(0, 16))
    ttk.Radiobutton(box_src, text="视频文件", variable=src_var,
                    value="视频文件").grid(row=1, column=0, sticky="w")
    vid_entry = ttk.Entry(box_src, textvariable=vid_var, width=52)
    vid_entry.grid(row=1, column=1, columnspan=2, sticky="we", padx=(4, 4))
    btn_pick = ttk.Button(box_src, text="浏览…", command=lambda: on_pick())
    btn_pick.grid(row=1, column=3)

    def on_pick():
        p = filedialog.askopenfilename(title="选择视频",
                                       filetypes=[("视频", "*.mp4 *.avi *.mkv *.mov *.flv *.webm"),
                                                  ("所有文件", "*.*")])
        if p:
            vid_var.set(p)

    box_src.columnconfigure(2, weight=1)

    # ---- 参数 ----
    box_par = ttk.LabelFrame(frm, text=" 转换参数（对后续新拉取生效） ", padding=8)
    box_par.pack(fill="x", pady=(8, 0))
    fps_var = tk.IntVar(value=24)
    dit_var = tk.StringVar(value="bayer8")
    mode_var = tk.IntVar(value=0)

    ttk.Label(box_par, text="抽帧规格：").grid(row=0, column=0, sticky="w")
    ttk.Spinbox(box_par, from_=1, to=30, textvariable=fps_var, width=5).grid(row=0, column=1)
    ttk.Label(box_par, text="fps（数据规格；设备按快刷极限播放）").grid(row=0, column=2, sticky="w")
    ttk.Label(box_par, text="抖动：").grid(row=1, column=0, sticky="w")
    ttk.Combobox(box_par, textvariable=dit_var, values=list(DITHERS),
                 state="readonly", width=8).grid(row=1, column=1)
    ttk.Label(box_par, text="（Bayer8 细腻 / Bayer4 快 / FS 误差扩散 / none 硬阈值）").grid(row=1, column=2, sticky="w")
    ttk.Label(box_par, text="动作模式：").grid(row=2, column=0, sticky="w")
    ttk.Radiobutton(box_par, text="重复动作码（每帧全屏驱动，自清残影）", variable=mode_var,
                    value=0).grid(row=2, column=1, columnspan=2, sticky="w")
    ttk.Radiobutton(box_par, text="安静差异码（只推变化像素，最安静）", variable=mode_var,
                    value=1).grid(row=3, column=1, columnspan=2, sticky="w")

    ttk.Label(box_par, text="端口：").grid(row=0, column=3, sticky="e")
    port_var = tk.IntVar(value=TCP_PORT_DEF)
    ttk.Spinbox(box_par, from_=1024, to=65535, textvariable=port_var, width=7).grid(row=0, column=4)
    ttk.Label(box_par, text="方向/窗口：").grid(row=1, column=3, sticky="e")
    ttk.Label(box_par, text="跟随设备（菜单 o/v 上报）").grid(row=1, column=4, sticky="w")

    # ---- 控制 ----
    box_ctl = ttk.Frame(frm)
    box_ctl.pack(fill="x", pady=10)

    status_var = tk.StringVar(value="服务未开始")
    btn_toggle = ttk.Button(box_ctl, text="开始服务")
    btn_toggle.pack(side="left")
    ttk.Label(frm, textvariable=status_var).pack(side="left", padx=12)

    # ---- 日志 ----
    box_log = ttk.LabelFrame(frm, text=" 运行日志 ", padding=4)
    box_log.pack(fill="both", expand=True)
    log_txt = tk.Text(box_log, height=14, state="disabled", font=("Consolas", 9))
    log_txt.pack(fill="both", expand=True)

    def gui_log(line):
        def _append():
            log_txt.configure(state="normal")
            log_txt.insert("end", line + "\n")
            log_txt.see("end")
            log_txt.configure(state="disabled")
        root.after(0, _append)

    def make_source():
        if src_var.get() == "测试图案":
            return TestPatternSource(pat_var.get(), int(fps_var.get()))
        p = vid_var.get().strip()
        if not p:
            raise RuntimeError("请先选择视频文件")
        return VideoFileSource(p, int(fps_var.get()))

    def toggle():
        if state["server"] is None:
            try:
                src = make_source()
                cfg2 = dict(cfg)
                cfg2.update(dither=dit_var.get(),
                            mode=int(mode_var.get()),
                            fps=int(fps_var.get()),
                            port=int(port_var.get()))
                srv = VideoServer(src, cfg2)
                srv.on_log = gui_log
                srv.start()
            except Exception as e:
                messagebox.showerror("墨印视频", f"启动失败：\n{e}")
                return
            state["server"] = srv
            state["source"] = src
            btn_toggle.configure(text="停止服务")
        else:
            state["server"].stop()
            state["server"] = None
            btn_toggle.configure(text="开始服务")

    btn_toggle.configure(command=toggle)

    def poll():
        srv = state["server"]
        status_var.set(srv.stats_text() if srv else "服务未开始")
        root.after(500, poll)
    root.after(500, poll)

    def on_close():
        if state["server"]:
            state["server"].stop()
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)
    kind_changed()
    root.mainloop()


# ============================================================ CLI

def run_nogui(cfg, source, port, dither, mode, fps):
    srv = VideoServer(source, dict(cfg, dither=dither, mode=mode, fps=fps, port=port))
    srv.start()
    print(f"\n[就绪] 设备（配好网、与本机同网段）菜单直接回车即自动发现并播放。")
    print("[就绪] Ctrl+C 退出。\n")
    try:
        while True:
            time.sleep(5)
            print(srv.stats_text(), flush=True)
    except KeyboardInterrupt:
        print()
        srv.stop()


def main():
    ap = argparse.ArgumentParser(description="墨印视频快刷测试 PC 端（MV2）")
    ap.add_argument("--nogui", action="store_true", help="无界面运行（自动化/测试）")
    ap.add_argument("--source", default="test:gradient",
                    help="视频文件路径，或 test:<图案>（gradient/bars/checker/noise/ball）")
    ap.add_argument("--fps", type=int, default=24, help="抽帧规格（默认 24）")
    ap.add_argument("--dither", default="bayer8", choices=list(DITHERS))
    ap.add_argument("--mode", type=int, default=0, choices=[0, 1],
                    help="0=重复动作码（默认） 1=安静差异码")
    ap.add_argument("--port", type=int, default=TCP_PORT_DEF)
    args = ap.parse_args()

    cfg = {"dither": args.dither, "mode": args.mode, "fps": args.fps, "port": args.port}

    if args.nogui:
        if args.source.startswith("test:"):
            src = TestPatternSource(args.source.split(":", 1)[1], args.fps)
        else:
            src = VideoFileSource(args.source, args.fps)
        run_nogui(cfg, src, args.port, args.dither, args.mode, args.fps)
    else:
        run_gui(cfg)


if __name__ == "__main__":
    main()
