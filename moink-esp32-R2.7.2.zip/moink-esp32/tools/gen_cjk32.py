#!/usr/bin/env python3
"""生成 MoInk 信息框 32x32 中文点阵字库（R2.0.4）。

字体源：Noto Serif SC Bold（思源宋体粗体，/usr/share/fonts/truetype/noto-serif-sc/）。
- 用户反馈「中文字体目前看不清」→ 弃用旧版手绘 12x12 点阵，
  改用真宋体渲染的 32x32 位图（scale=1 即 32px，scale=2 即 64px）。
- 粗体（Bold）：墨水屏低分辨率下宋体细横易断笔画。

输出：main/font_cjk32.h —— uint32_t CJK32[N][32]，bit31 = 最左像素。
字符序（与 overlay.c 的 cjk_idx_t 一一对应，改序必须两边同步）：
  一二三四五六日周中重置密码新℃%
"""
from PIL import Image, ImageDraw, ImageFont

FONT_PATH = "/usr/share/fonts/truetype/noto-serif-sc/NotoSerifSC-Bold.ttf"
OUT = "/home/z/my-project/download/moink-esp32/main/font_cjk32.h"
CELL = 32
MARGIN = 1          # 每边至少留 1px（描边膨胀 + 防相邻字粘连）
CHARS = "一二三四五六日周中重置密码新℃%"


def render(ch):
    """返回 32x32 的 bits[y][x]（0/1），bbox 居中；超格自动降字号。"""
    for size in range(CELL - 2 * MARGIN, 8, -1):
        font = ImageFont.truetype(FONT_PATH, size)
        img = Image.new("L", (CELL * 4, CELL * 4), 0)
        ImageDraw.Draw(img).text((CELL * 2, CELL * 2), ch,
                                 font=font, fill=255, anchor="mm")
        bbox = img.getbbox()
        if not bbox:
            raise SystemExit(f"字形为空: {ch!r}（字体缺字？）")
        x0, y0, x1, y1 = bbox
        w, h = x1 - x0, y1 - y0
        if w <= CELL - 2 * MARGIN and h <= CELL - 2 * MARGIN:
            cell = Image.new("L", (CELL, CELL), 0)
            cell.paste(img.crop(bbox), ((CELL - w) // 2, (CELL - h) // 2))
            return [[1 if cell.getpixel((x, y)) >= 128 else 0
                     for x in range(CELL)] for y in range(CELL)], size
    raise SystemExit(f"字形无法适配 {CELL}px cell: {ch!r}")


glyphs = []
for ch in CHARS:
    bits, size = render(ch)
    ink = sum(sum(r) for r in bits)
    if ink < 12 or ink > CELL * CELL * 62 // 100:
        raise SystemExit(f"字形覆盖率异常: {ch!r} ink={ink}")
    glyphs.append((ch, bits, ink, size))

with open(OUT, "w", encoding="utf-8") as f:
    f.write("/* 自动生成：tools/gen_cjk32.py（R2.0.4）— 勿手改，改字符集请改脚本后重生成。\n"
            " *\n"
            " * 32x32 中文点阵字库，字体源 Noto Serif SC Bold（思源宋体·粗）。\n"
            " * 行主序 uint32_t，bit31 = 最左像素。字形按 bbox 居中进 32x32 cell。\n"
            " * 粗体原因：墨水屏 2bpp 低分辨率下宋体细横易断笔画。\n"
            " * 字符序与 overlay.c 的 cjk_idx_t 一一对应（改序两边同步）：\n"
            " *   ")
    f.write(" ".join(CHARS))
    f.write("\n */\n"
            "#ifndef MOINK_FONT_CJK32_H\n"
            "#define MOINK_FONT_CJK32_H\n\n"
            "#include <stdint.h>\n\n"
            "#define CJK32_CELL 32\n\n"
            "static const uint32_t CJK32[][" + str(CELL) + "] = {\n")
    for ch, bits, ink, size in glyphs:
        f.write("    /* " + ch + f" (size {size}, ink {ink}) */ {{\n")
        for y in range(CELL):
            v = 0
            for x in range(CELL):
                if bits[y][x]:
                    v |= 1 << (CELL - 1 - x)
            f.write("        0x%08XU,\n" % v)
        f.write("    },\n")
    f.write("};\n\n#endif /* MOINK_FONT_CJK32_H */\n")

print("OK ->", OUT)
for ch, bits, ink, size in glyphs:
    print(f"  {ch}: size={size} ink={ink}")
