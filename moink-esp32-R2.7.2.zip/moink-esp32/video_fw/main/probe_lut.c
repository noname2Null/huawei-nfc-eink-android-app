/*
 * 墨印视频测试固件 —— 寄存器 LUT 探针实现（自 verify_fw/verify_main.c
 * 逐行提取，行为完全一致；画布经参数传入，去全局依赖）。
 */
#include "probe_lut.h"

#include <string.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "epd_vdrv.h"
#include "lut_r20.h"

/* 探针用画布（probe_register_lut 参数注入；fill 回调经此取行数据） */
static uint8_t *s_canvas;
static uint8_t  s_lut[LUT_R20_BYTES];

static void probe_fill_row(int j, uint8_t *row)
{
    memcpy(row, s_canvas + (size_t)j * VD_RB, VD_RB);
}

/* BUSY 确认窗：ms 内必须保持高电平（A1 假释放会在数百 ms 内再落下） */
static bool busy_confirm_high(int ms)
{
    for (int t = 0; t < ms; t += 5) {
        if (vd_busy_level() == 0) return false;
        vTaskDelay(pdMS_TO_TICKS(5));
    }
    return true;
}

probe_result_t probe_register_lut(uint8_t *canvas)
{
    static const uint8_t try_psr[2] = { 0xF9, 0xE9 };
    probe_result_t pr = { false, 0 };

    s_canvas = canvas;

    for (int t = 0; t < 2; t++) {
        printf("── 探测尝试 %d/2：PSR = 4B %02X（R20 空表 + 全 01 RAM）\n", t + 1, try_psr[t]);

        if (vd_full_reinit() != 0) {
            printf("   初始化失败，换下一档\n");
            continue;
        }
        vd_custom_overlay(0x00, 0x50);
        lut_build_empty(s_lut);
        if (vd_lut_write(s_lut) != 0) { printf("   R20 写入失败\n"); continue; }
        vd_set_psr_register(try_psr[t]);

        memset(s_canvas, 0x55, (size_t)VD_ROWS * VD_RB);   /* 全 01 码 RAM（工厂视角白）*/
        if (vd_write_full(probe_fill_row) != 0) { printf("   RAM 写入失败\n"); continue; }
        vd_window_full();

        {
            vd_drf_result_t r1 = vd_drf(180000u, false);
            printf("   探针 DRF#1：%lld ms，忙脉冲=%d\n",
                   (long long)r1.elapsed_ms, (int)r1.saw_low);
            if (r1.timeout || !r1.saw_low || r1.elapsed_ms >= 100) {
                printf("   → 未达接受判据（时长或忙脉冲），判定未接受\n");
                continue;
            }
            if (!busy_confirm_high(2000)) {
                printf("   → BUSY 在确认窗内再次变低（假释放），判定未接受\n");
                continue;
            }
        }
        {
            vd_drf_result_t r2 = vd_drf(180000u, false);
            printf("   探针 DRF#2：%lld ms，忙脉冲=%d\n",
                   (long long)r2.elapsed_ms, (int)r2.saw_low);
            if (r2.timeout || !r2.saw_low || r2.elapsed_ms >= 100) {
                printf("   → 复测未达标，判定未接受\n");
                continue;
            }
            printf("   ★ 寄存器 LUT 被接受（PSR 4B %02X）——快速局刷/剂量路径可用\n",
                   try_psr[t]);
            pr.ok = true;
            pr.psr2 = try_psr[t];
            return pr;
        }
    }
    printf("── 两档 PSR 均未被接受：本屏在 %s 画像下不支持（或未开放）寄存器 LUT。\n",
           vd_panel_name());
    return pr;
}
