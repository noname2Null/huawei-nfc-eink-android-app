/*
 * 墨印视频测试固件 —— 增强灰度色带实现。
 *
 * 布局（写行 j 0..551，条带均为整行横带；与 verify_fw 的 6+6 带版相比
 * 档位加密并新增黄弱正场对照组）：
 *
 *   j4           顶边框细黑线
 *   j10..33      黑参考带（工厂基色）
 *   j38..        B1..B6   Mode0 强正场 P，扫描 1/2/3/5/8/12（深灰档加密）
 *   j134..       B7..B12  Mode1 弱正场（VSP_1=0x2D），扫描 2/4/6/9/14/20（中间调）
 *   j240..263    黄参考带（工厂基色）
 *   j268..       Y1..Y7   负场 N（lut_build_yellow），扫描 8..96（剂量加倍）
 *   j380..       Y8..Y14  弱正场 VSPL（lut_build_yellow_pos），扫描 8..96
 *                （正场假说：黄颗粒带负电，正场拉其上浮——与负场组对照）
 *   j535         底边框细黑线
 *
 * 剂量执行方式与 verify_fw 相同：写动作码 → N 次 DRF（每次 1 扫描）
 * → 回保持。黄最大 96 次 DRF × 约 12 ms ≈ 1.2 s/带。
 */
#include "gray_bands.h"

#include <string.h>
#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "epd_vdrv.h"
#include "lut_r20.h"
#include "probe_lut.h"

/* 像素码（寄存器 LUT 动作码；工厂码） */
#define PACK_BLACK      0x00    /* 工厂黑 */
#define PACK_WHITE      0x55    /* 工厂白 */
#define PACK_YELLOW     0xAA    /* 工厂黄 */
#define PACK_HOLD       0x00    /* 寄存器 LUT：保持 */
#define PACK_ACT_BLACK  0x55    /* 寄存器 LUT：码 01 = H2 黑目标动作 */
#define PACK_ACT_WHITE  0xAA    /* 寄存器 LUT：码 10 = H3 白/浅色目标动作 */

typedef struct { int j0, j1; } band_t;

#define BAND_H  14      /* 剂量带高 */
#define BAND_S  16      /* 带间距（高 + 2 行间隔） */

static uint8_t *s_canvas;
static uint8_t  s_lut[LUT_R20_BYTES];

static void fill_row(int j, uint8_t *row)
{
    memcpy(row, s_canvas + (size_t)j * VD_RB, VD_RB);
}

static void canvas_all(uint8_t packed)
{
    memset(s_canvas, packed, (size_t)VD_ROWS * VD_RB);
}

static void canvas_rows(int j0, int j1, uint8_t packed)
{
    if (j0 < 0) j0 = 0;
    if (j1 > VD_ROWS - 1) j1 = VD_ROWS - 1;
    memset(s_canvas + (size_t)j0 * VD_RB, packed, (size_t)(j1 - j0 + 1) * VD_RB);
}

/* 工厂底图行：参考带 + 边框（其余白） */
static void base_fill_row(int j, uint8_t *row)
{
    uint8_t code;
    if (j >= 10 && j <= 33)        code = PACK_BLACK;    /* 黑参考带 */
    else if (j >= 240 && j <= 263) code = PACK_YELLOW;   /* 黄参考带 */
    else if (j == 4 || j == 535)   code = PACK_BLACK;    /* 上下边框线 */
    else                           code = PACK_WHITE;
    memset(row, code, VD_RB);
}

/* 一条带的剂量：写动作码 → n 次 DRF → 回保持 */
static void dose_band(const band_t *b, uint8_t act_packed, int n, const char *label)
{
    int timeouts = 0;
    canvas_rows(b->j0, b->j1, act_packed);
    vd_write_rows(b->j0, b->j1, fill_row);
    for (int i = 0; i < n; i++) {
        vd_window_full();
        vd_drf_result_t r = vd_drf(10000u, false);
        if (r.timeout || !r.saw_low) {
            timeouts++;
            printf("     ⚠ DRF#%d 异常：%lld ms，忙脉冲=%d\n",
                   i + 1, (long long)r.elapsed_ms, (int)r.saw_low);
        }
    }
    canvas_rows(b->j0, b->j1, PACK_HOLD);
    vd_write_rows(b->j0, b->j1, fill_row);
    printf("     %s（写行 %d..%d）：%d 次 DRF 完成%s\n", label, b->j0, b->j1, n,
           timeouts ? "（含异常，见上）" : "");
}

static int band_j0(int start, int i) { return start + i * BAND_S; }
static int band_j1(int start, int i) { return start + i * BAND_S + BAND_H - 1; }

int gray_bands_run(uint8_t *canvas)
{
    static const int B_M0[6]  = { 1, 2, 3, 5, 8, 12 };        /* 黑 · Mode0 强正场 */
    static const int B_M1[6]  = { 2, 4, 6, 9, 14, 20 };       /* 黑 · Mode1 弱正场 */
    static const int Y_NEG[7] = { 8, 16, 24, 32, 48, 64, 96 };/* 黄 · 负场加倍剂量 */
    static const int Y_POS[7] = { 8, 16, 24, 32, 48, 64, 96 };/* 黄 · 弱正场对照 */
    int64_t t_paint;

    s_canvas = canvas;

    printf("\n══════ 增强灰度色带（黑 12 档 + 黄 14 档两亚组对照） ══════\n");
    printf("上组 黑→白：参考带 j10..33；B1..B6 强正场 P 扫描 1/2/3/5/8/12；\n");
    printf("            B7..B12 弱正场（VSP_1=0x2D）扫描 2/4/6/9/14/20。\n");
    printf("下组 黄→白：参考带 j240..263；Y1..Y7 负场 N 扫描 8/16/24/32/48/64/96；\n");
    printf("            Y8..Y14 弱正场 VSPL 扫描 8/16/24/32/48/64/96（假说对照）。\n");
    printf("拍照请连同本串口日志（行号对号入座）。\n\n");

    printf("[G1] 探测寄存器 LUT...\n");
    probe_result_t pr = probe_register_lut(canvas);
    printf("\n");
    if (!pr.ok) {
        printf("[G1] 寄存器 LUT 未接受——剂量灰度不可用（判定过程见上）。\n");
        return -1;
    }

    printf("[G2] 工厂底图（白底 + 黑/黄参考带 + 边框；一次工厂全刷约 15 秒）...\n");
    if (vd_factory_frame(base_fill_row, &t_paint) != 0) {
        printf("[G2] 工厂底图失败\n");
        return -1;
    }
    printf("[G2] 工厂底图完成，DRF %lld ms\n\n", (long long)t_paint);

    /* 剂量阶段全部走寄存器 LUT */
    if (vd_full_reinit() != 0) return -1;

    /* 阶段 1：黑 · Mode0 强正场（B1..B6） */
    printf("[G3] 黑 · 强正场 P（Mode0），剂量 1/2/3/5/8/12 扫描：\n");
    vd_custom_overlay(0x00, 0x50);
    lut_build_gray_m0(s_lut);
    vd_lut_write(s_lut);
    vd_set_psr_register(pr.psr2);
    canvas_all(PACK_HOLD);
    vd_write_full(fill_row);
    for (int i = 0; i < 6; i++) {
        band_t b = { band_j0(38, i), band_j1(38, i) };
        char label[32];
        snprintf(label, sizeof(label), "B%d（%d 扫描）", i + 1, B_M0[i]);
        dose_band(&b, PACK_ACT_BLACK, B_M0[i], label);
    }

    /* 阶段 2：黑 · Mode1 弱正场（B7..B12）——中间调假说 */
    printf("\n[G4] 黑 · 弱正场（Mode1，VSP_1=0x2D），剂量 2/4/6/9/14/20 扫描：\n");
    vd_custom_overlay(0x2D, 0x50);
    lut_build_gray_m1(s_lut);
    vd_lut_write(s_lut);
    for (int i = 0; i < 6; i++) {
        band_t b = { band_j0(134, i), band_j1(134, i) };
        char label[32];
        snprintf(label, sizeof(label), "B%d（%d 扫描）", i + 7, B_M1[i]);
        dose_band(&b, PACK_ACT_BLACK, B_M1[i], label);
    }

    /* 阶段 3：黄 · 负场加倍剂量（Y1..Y7） */
    printf("\n[G5] 黄 · 负场 N（Mode0），剂量 8/16/24/32/48/64/96 扫描（加倍）：\n");
    vd_custom_overlay(0x00, 0x50);
    lut_build_yellow(s_lut);
    vd_lut_write(s_lut);
    for (int i = 0; i < 7; i++) {
        band_t b = { band_j0(268, i), band_j1(268, i) };
        char label[32];
        snprintf(label, sizeof(label), "Y%d（%d 扫描）", i + 1, Y_NEG[i]);
        dose_band(&b, PACK_ACT_WHITE, Y_NEG[i], label);
    }

    /* 阶段 4：黄 · 弱正场对照（Y8..Y14）——正场假说 */
    printf("\n[G6] 黄 · 弱正场 VSPL（Mode0），剂量 8/16/24/32/48/64/96 扫描（对照）：\n");
    lut_build_yellow_pos(s_lut);
    vd_lut_write(s_lut);
    for (int i = 0; i < 7; i++) {
        band_t b = { band_j0(380, i), band_j1(380, i) };
        char label[32];
        snprintf(label, sizeof(label), "Y%d（%d 扫描）", i + 8, Y_POS[i]);
        dose_band(&b, PACK_ACT_WHITE, Y_POS[i], label);
    }

    printf("\n[G7] 剂量阶段完成。判定指引：\n");
    printf("  · 黑组：B1..B12 应呈 24 档内的连续阶梯；中间调出现在 B7..B12 观察\n");
    printf("    「弱正场是否比强场更细腻」；\n");
    printf("  · 黄组：Y1..Y7 加倍剂量后是否出现黄调（verify 版 3..24 扫描全不显色）；\n");
    printf("    Y8..Y14 弱正场是否比负场更容易出黄调——两组对照拍照反馈即可。\n");

    vd_power_off();
    return 0;
}
