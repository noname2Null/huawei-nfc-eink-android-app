#ifndef MOINK_PROBE_LUT_H
#define MOINK_PROBE_LUT_H

/*
 * 墨印视频测试固件 —— 寄存器 LUT 探针（自 verify_fw/verify_main.c 提取）。
 *
 * 探测「PSR 寄存器 LUT 模式 + R20」是否被本屏接受：基线 = 复位 + 工厂
 * 初始化 + PON → 实验配置 overlay（AA/R01/PLL）→ R20 全 FF 空表 →
 * PSR 4B F9（再试 E9）→ 全 01 RAM → DRF。
 * 判接受：忙脉冲出现 + 时长 < 100 ms + 随后 2 s BUSY 保持高 + 复测一次。
 *
 * gray_bands（剂量灰度）与 video_main（快刷播放）都要先过这一关。
 */
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    bool    ok;         /* 寄存器 LUT 被接受 */
    uint8_t psr2;       /* 接受档：0xF9 或 0xE9 */
} probe_result_t;

/* 调用前置条件：vd_init 已成功。canvas 为 VD_ROWS*VD_RB 的画布缓冲
 * （探针过程会写入；返回后整幅为 01 码，调用方必须先全帧重写再 DRF）。 */
probe_result_t probe_register_lut(uint8_t *canvas);

#endif /* MOINK_PROBE_LUT_H */
