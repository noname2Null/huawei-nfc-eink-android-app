/*
 * 墨印功能验证固件 —— JD7966x 屏驱动实现。
 *
 * 电气序列来源（均为真机验证过的 1:1 移植，勿随意改顺序/时长）：
 *   A0 初始化 + 隔行写 + 行镜像    ← 主固件 main/epd_drv.c（非 linear 路径）
 *   A1 初始化块 + 顺序直写 + 假释放 ← 主固件 main/epd_drv.c（A1 路径，
 *                                     原始出处 InkSight EPD_PANEL_38）
 *   BUSY 观测策略（低脉冲采样 + 进度打印）
 *                                 ← ref/jd79665aa-driver driver/src/epd.c
 *   R20 / PSR 寄存器 LUT / 窗口语义 ← ref/jd79665aa-driver docs/02/03/04
 */
#include "epd_vdrv.h"
#include "lut_r20.h"

#include <string.h>

#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "epd";

#define SPI_HZ_DEFAULT         16000000  /* ref docs/06 短波形族：请求 16M、实测 15.625M */
#define SPI_HZ_CMD_MAX          8000000   /* 命令/寄存器通道上限。R2 真机实测：24M 档
                                             （实落约 20M）仅工厂清屏成功、动图一直
                                             白屏——工厂清屏走 OTP 波形不碰 R20/PSR
                                             寄存器长写，动图路径的 LUT/PSR 在高位宽
                                             下疑似被打坏。寄存器恒走 ≤8M 保守档。 */
#define BUSY_TIMEOUT_INIT_A0_MS  10000
#define BUSY_TIMEOUT_REFRESH_A0_MS 45000
#define BUSY_TIMEOUT_LONG_MS     180000   /* A1 全程（这块屏很慢 + 假释放） */

static vd_pins_t s_pins;
static vd_panel_t s_panel = VD_PANEL_A0;
static spi_device_handle_t s_spi_cmd;     /* 命令/寄存器通道（含 R20 LUT 长写，恒 ≤8M） */
static spi_device_handle_t s_spi_data;    /* RAM 数据突发通道（行写，随档位 4/8/16/24M） */
static bool s_inited = false;
static bool s_aa_sent = false;      /* 0xAA 解锁只发一次（重发效果未知，避免污染实验） */
static uint32_t s_spi_hz = SPI_HZ_DEFAULT;      /* 数据通道时钟（vd_set_spi_hz 可调） */
static uint32_t s_spi_cmd_hz = SPI_HZ_CMD_MAX;  /* 命令通道时钟 = min(数据档, 8M) */

static uint32_t clamp_cmd_hz(uint32_t hz)
{
    return hz < SPI_HZ_CMD_MAX ? hz : SPI_HZ_CMD_MAX;
}

void vd_set_spi_hz(uint32_t hz)
{
    /* 四档吸附：4M（保守已证）/ 8M / 16M（ref 快刷档，默认）/ 24M（实落约 20M，试探档）。
     * 仅改档位变量——已初始化的总线要 vd_apply_spi_hz() 重建设备才生效。 */
    if (hz < 6000000u)        s_spi_hz = 4000000u;
    else if (hz < 12000000u)  s_spi_hz = 8000000u;
    else if (hz < 20000000u)  s_spi_hz = 16000000u;
    else                      s_spi_hz = 24000000u;
    s_spi_cmd_hz = clamp_cmd_hz(s_spi_hz);
}

uint32_t vd_spi_hz(void)      { return s_spi_hz; }
uint32_t vd_spi_cmd_hz(void)  { return s_spi_cmd_hz; }

/* BUSY 观测：低电平 = 忙（两画像同极性）。 */
static int64_t now_ms(void) { return esp_timer_get_time() / 1000; }

/* ---- SPI / GPIO ---- */

/* 指定通道发送（命令通道 vs 数据通道时钟不同） */
static esp_err_t spi_tx_on(spi_device_handle_t dev, const uint8_t *data, size_t len)
{
    spi_transaction_t t = {
        .length = len * 8,
        .tx_buffer = data,
    };
    return spi_device_polling_transmit(dev, &t);
}

/* RAM 数据突发（行写专用：数据通道，可用最高档） */
static esp_err_t spi_tx_data(const uint8_t *data, size_t len)
{
    return spi_tx_on(s_spi_data, data, len);
}

/* 命令（DC 低）+ 可选参数（DC 高），CS 手动包络；恒走命令通道（≤8M）。
 * 命令字节与参数分两次传输是必须的：DC 要在两者之间翻转，单个 SPI
 * 事务中途不能动 GPIO。 */
static esp_err_t epd_cmd(uint8_t cmd, const uint8_t *data, size_t len)
{
    esp_err_t err;
    gpio_set_level(s_pins.dc, 0);
    gpio_set_level(s_pins.cs, 0);
    err = spi_tx_on(s_spi_cmd, &cmd, 1);
    if (err == ESP_OK && len > 0) {
        gpio_set_level(s_pins.dc, 1);
        err = spi_tx_on(s_spi_cmd, data, len);
    }
    gpio_set_level(s_pins.cs, 1);
    return err;
}

#define EPD_C1(c, a)        do { uint8_t d_[1]  = { (a) };          epd_cmd((c), d_, 1); } while (0)
#define EPD_C2(c, a, b)     do { uint8_t d_[2]  = { (a), (b) };     epd_cmd((c), d_, 2); } while (0)
#define EPD_C4(c, a, b, e, f) do { uint8_t d_[4] = { (a), (b), (e), (f) }; epd_cmd((c), d_, 4); } while (0)
#define EPD_C6(c, a, b, e, f, g, i) \
    do { uint8_t d_[6] = { (a), (b), (e), (f), (g), (i) }; epd_cmd((c), d_, 6); } while (0)

static void epd_reset(void)
{
    vTaskDelay(pdMS_TO_TICKS(20));
    gpio_set_level(s_pins.rst, 0);
    vTaskDelay(pdMS_TO_TICKS(40));
    gpio_set_level(s_pins.rst, 1);
    vTaskDelay(pdMS_TO_TICKS(50));
}

/*
 * BUSY 等待：BUSY 高 = 就绪，但至少观测 10 ms 才能认定（防止命令未被接受
 * 时「一直高」被当成完成——ref docs/02 §5）。返回是否就绪；*saw_low 记录
 * 期间是否真的出现过低电平忙脉冲。
 * ★ 让出策略（R3 修复）：首 1ms 内纯快轮询（短快刷 ~27ms 需要细粒度），
 * 之后每 1ms 至少睡 1 拍。IDF 默认 tick=100Hz 时 pdMS_TO_TICKS(1)=0，
 * vTaskDelay(0) 只让出不阻塞——同核 IDLE0 饿死 → 工厂 DRF 15s 期间
 * 看门狗风暴（R2 真机日志实源）。至少 1 拍后 100Hz 下粒度 10ms、
 * 1000Hz（sdkconfig.defaults 新档）下 1ms。
 */
static bool epd_wait_ready(uint32_t timeout_ms, bool *saw_low, int64_t *elapsed_ms)
{
    int64_t t0 = now_ms();
    bool low_seen = false;
    int64_t next_progress = 5000;
    int64_t last_yield_us = esp_timer_get_time();
    TickType_t yield_tick = pdMS_TO_TICKS(1);
    if (yield_tick == 0) yield_tick = 1;    /* 100Hz 档：0 拍 = 只让出，强制 ≥1 拍 */

    if (saw_low) *saw_low = false;
    for (;;) {
        int64_t el = now_ms() - t0;
        int lvl = gpio_get_level(s_pins.busy);
        if (lvl == 0) low_seen = true;
        if (lvl == 1 && el >= 10) {
            if (saw_low) *saw_low = low_seen;
            if (elapsed_ms) *elapsed_ms = el;
            if (!low_seen) {
                ESP_LOGW(TAG, "BUSY 全程高电平（未见忙脉冲）——命令可能未被接受");
            }
            return true;
        }
        if (el > (int64_t)timeout_ms) {
            if (saw_low) *saw_low = low_seen;
            if (elapsed_ms) *elapsed_ms = el;
            ESP_LOGE(TAG, "BUSY 超时 %lu ms（level=%d）",
                     (unsigned long)timeout_ms, gpio_get_level(s_pins.busy));
            return false;
        }
        if (el >= next_progress) {
            ESP_LOGI(TAG, "  ...BUSY 等待中 level=%d 已 %lld ms",
                     gpio_get_level(s_pins.busy), (long long)el);
            next_progress += 5000;
        }
        if (esp_timer_get_time() - last_yield_us >= 1000) {
            vTaskDelay(yield_tick);
            last_yield_us = esp_timer_get_time();
        }
    }
}

/* ---- 窗口（0x83） ---- */

/* 通用矩形窗：逻辑列 x0..x1（可镜像编码）+ 栅极 ys..ye。
 * R2 前所有窗口都全宽（x0=0,x1=767），X 坐标是否镜像无从分辨；
 * ref/jd79665aa-driver epd.c 的 visible_window() 在 SHL=0 时需要
 * encoded_x = 800 - physical_x - w（A1 画像已证），A0 未知——由调用方
 * 传 x_mirror 在真机上分辨（窗口内容左右错位时切换）。 */
static void epd_set_window_rect(int x_mirror, int x0, int x1, int ys, int ye)
{
    if (x_mirror) {
        int enc0 = VD_COLS - 1 - x1;      /* = 768 - physical_x - w 形式 */
        int enc1 = VD_COLS - 1 - x0;
        x0 = enc0;
        x1 = enc1;
    }
    uint8_t d[9] = {
        (uint8_t)((x0 >> 8) & 0xFF), (uint8_t)(x0 & 0xFF),
        (uint8_t)((x1 >> 8) & 0xFF), (uint8_t)(x1 & 0xFF),
        (uint8_t)((ys >> 8) & 0xFF), (uint8_t)(ys & 0xFF),
        (uint8_t)((ye >> 8) & 0xFF), (uint8_t)(ye & 0xFF),
        0x01,
    };
    epd_cmd(0x83, d, sizeof(d));
}

/* 全宽窗（旧接口：所有既有调用走这里，X 镜像与否对全宽无差别） */
static void epd_set_window_gate(int ys, int ye)
{
    epd_set_window_rect(0, 0, VD_COLS - 1, ys, ye);
}

/* A0 隔行映射：写行 j → 栅极。上半（j<276）偶数栅极 2j；下半奇数栅极
   自 551 递减（2*(552-j)-1）。 */
static int a0_gate_of(int j)
{
    return (j < VD_ROWS / 2) ? (j * 2) : (2 * (VD_ROWS - j) - 1);
}

/* 覆盖写行区间 j0..j1 的栅极范围（A0 隔行 → 三段情形） */
static void a0_gate_span(int j0, int j1, int *g0, int *g1)
{
    if (j1 < VD_ROWS / 2) {
        *g0 = a0_gate_of(j0);
        *g1 = a0_gate_of(j1);
    } else if (j0 >= VD_ROWS / 2) {
        *g0 = a0_gate_of(j1);
        *g1 = a0_gate_of(j0);
    } else {
        /* 跨中点：上半到栅 550，下半从栅 551 往下扫 */
        int lo = 2 * (VD_ROWS - j1) - 1;
        *g0 = (lo < 2 * j0) ? lo : (2 * j0);
        *g1 = 551;
    }
}

void vd_window_full(void)
{
    if (s_panel == VD_PANEL_A1) {
        epd_set_window_gate(0, VD_A1_GATES - 1);
    } else {
        epd_set_window_gate(0, VD_ROWS - 1);
    }
}

void vd_window_rows(int j0, int j1)
{
    if (j0 < 0) j0 = 0;
    if (j1 > VD_ROWS - 1) j1 = VD_ROWS - 1;
    if (s_panel == VD_PANEL_A1) {
        epd_set_window_gate(j0, j1);
    } else {
        int g0, g1;
        a0_gate_span(j0, j1, &g0, &g1);
        epd_set_window_gate(g0, g1);
    }
}

/* ---- 行镜像（字节倒序 + 2bit 组倒序；与主固件同式） ---- */

static void row_mirror(uint8_t *dst, const uint8_t *src, int row_bytes)
{
    for (int i = 0; i < row_bytes; i++) {
        uint8_t s = src[row_bytes - 1 - i];
        dst[i] = (uint8_t)(((s & 0x03) << 6) | ((s & 0x0C) << 2) |
                           ((s & 0x30) >> 2) | ((s & 0xC0) >> 6));
    }
}

/* ---- 初始化（工厂寄存器） ---- */

static int epd_panel_init_a1(void)
{
    int h_gates = VD_A1_GATES;

    epd_reset();
    if (!epd_wait_ready(BUSY_TIMEOUT_LONG_MS, NULL, NULL)) return -1;
    vTaskDelay(pdMS_TO_TICKS(30));

    /* 与主固件 A1 初始化 1:1（顺序不可乱：AA 解锁 → 基础寄存器 →
       TRES → 级联 → 0x83 布防 → PON） */
    EPD_C6(0xAA, 0x49, 0x55, 0x20, 0x08, 0x09, 0x18);
    s_aa_sent = true;                   /* A1 初始化块自带解锁 */
    EPD_C1(0x01, 0x3F);                 /* 驱动输出控制 */
    EPD_C2(0x00, 0x4B, 0x69);           /* PSR：工厂 LUT */
    EPD_C4(0x05, 0x40, 0x1F, 0x1F, 0x2C);
    EPD_C4(0x08, 0x6F, 0x1F, 0x1F, 0x22);
    EPD_C4(0x06, 0x6F, 0x1F, 0x14, 0x14);
    EPD_C4(0x03, 0x00, 0x54, 0x00, 0x44);
    EPD_C2(0x60, 0x02, 0x00);           /* TCON */
    EPD_C1(0x30, 0x08);                 /* PLL */
    EPD_C1(0x50, 0x3F);                 /* VCOM */
    {
        uint8_t tres[4] = {
            (uint8_t)(VD_COLS >> 8), (uint8_t)(VD_COLS & 0xFF),
            (uint8_t)(h_gates >> 8), (uint8_t)(h_gates & 0xFF),
        };
        epd_cmd(0x61, tres, 4);
    }
    EPD_C4(0x65, 0x10, 0x00, 0x20, 0x00);
    EPD_C1(0xE3, 0x2F);
    EPD_C1(0x84, 0x01);                 /* 级联配置 */
    epd_set_window_gate(0, h_gates - 1);
    return 0;
}

static int epd_panel_init_a0(void)
{
    uint8_t psr[1] = { 0x0B };
    uint8_t tres[4] = {
        (uint8_t)(VD_COLS >> 8), (uint8_t)(VD_COLS & 0xFF),
        (uint8_t)(VD_ROWS >> 8), (uint8_t)(VD_ROWS & 0xFF),
    };

    epd_reset();
    if (!epd_wait_ready(BUSY_TIMEOUT_INIT_A0_MS, NULL, NULL)) return -1;
    vTaskDelay(pdMS_TO_TICKS(30));

    epd_cmd(0x00, psr, 1);              /* PSR（单字节，JD79668 式） */
    epd_cmd(0x61, tres, 4);             /* TRES 768x552 */
    return 0;
}

static int vd_pwr_on(void)
{
    uint8_t z = 0x00;
    epd_cmd(0x04, &z, 0);
    return epd_wait_ready(s_panel == VD_PANEL_A1 ? BUSY_TIMEOUT_LONG_MS
                                                 : BUSY_TIMEOUT_REFRESH_A0_MS,
                          NULL, NULL) ? 0 : -1;
}

int vd_full_reinit(void)
{
    if (!s_inited) return -1;
    s_aa_sent = false;                   /* 复位可能重新上锁：解锁标记随复位清零 */
    if (s_panel == VD_PANEL_A1) {
        if (epd_panel_init_a1() != 0) return -1;
    } else {
        if (epd_panel_init_a0() != 0) return -1;
    }
    return vd_pwr_on();
}

/* ---- 行写 ---- */

int vd_write_rows(int j0, int j1, vd_row_fill_t fill)
{
    static uint8_t row[VD_RB];
    static uint8_t mir[VD_RB];

    if (!s_inited || !fill) return -1;
    if (j0 < 0) j0 = 0;
    if (j1 > VD_ROWS - 1) j1 = VD_ROWS - 1;
    if (j0 > j1) return -1;

    if (s_panel == VD_PANEL_A1) {
        /* 单窗（写行=栅极，顺序直写）+ 一次 0x10 连发 */
        epd_set_window_gate(j0, j1);
        epd_cmd(0x10, NULL, 0);
        gpio_set_level(s_pins.dc, 1);
        gpio_set_level(s_pins.cs, 0);
        esp_err_t err = ESP_OK;
        for (int j = j0; j <= j1 && err == ESP_OK; j++) {
            fill(j, row);
            row_mirror(mir, row, VD_RB);
            err = spi_tx_data(mir, VD_RB);
        }
        gpio_set_level(s_pins.cs, 1);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "SPI tx failed: %s", esp_err_to_name(err));
            return -1;
        }
        return 0;
    }

    /* A0：逐行单栅极窗（已证路径），每行自带 0x10 */
    uint8_t z = 0x00;
    for (int j = j0; j <= j1; j++) {
        int g = a0_gate_of(j);
        epd_set_window_gate(g, g);
        epd_cmd(0x10, &z, 0);
        fill(j, row);
        row_mirror(mir, row, VD_RB);
        gpio_set_level(s_pins.dc, 1);
        gpio_set_level(s_pins.cs, 0);
        esp_err_t err = spi_tx_data(mir, VD_RB);
        gpio_set_level(s_pins.cs, 1);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "SPI tx failed: %s", esp_err_to_name(err));
            return -1;
        }
    }
    return 0;
}

int vd_write_full(vd_row_fill_t fill)
{
    return vd_write_rows(0, VD_ROWS - 1, fill);
}

/* ---- 二维窗口行写（视频路径） ---- */

int vd_write_win_rows(int x_mirror, int c0, int c1,
                      int j0, int j1, vd_row_fill_t fill)
{
    static uint8_t win[VD_RB];               /* 窗宽最大 192B（全宽） */
    static uint8_t mir[VD_RB];

    if (!s_inited || !fill) return -1;
    if (j0 < 0) j0 = 0;
    if (j1 > VD_ROWS - 1) j1 = VD_ROWS - 1;
    if (c0 < 0) c0 = 0;
    if (c1 > VD_COLS - 1) c1 = VD_COLS - 1;
    if (j0 > j1 || c0 > c1) return -1;
    if ((c0 & 3) || ((c1 + 1) & 3)) return -1;    /* 4 像素对齐 */

    int wb = (c1 - c0 + 1) / 4;              /* 窗宽字节 */

    if (s_panel == VD_PANEL_A1) {
        /* 单窗（写行=栅极，顺序连写窗口行）+ 一次 0x10 连发 */
        epd_set_window_rect(x_mirror, c0, c1, j0, j1);
        epd_cmd(0x10, NULL, 0);
        gpio_set_level(s_pins.dc, 1);
        gpio_set_level(s_pins.cs, 0);
        esp_err_t err = ESP_OK;
        for (int j = j0; j <= j1 && err == ESP_OK; j++) {
            fill(j, win);
            row_mirror(mir, win, wb);
            err = spi_tx_data(mir, wb);
        }
        gpio_set_level(s_pins.cs, 1);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "SPI tx failed: %s", esp_err_to_name(err));
            return -1;
        }
        return 0;
    }

    /* A0：逐行单栅极窗（已证路径推广到窗口列区间），每行自带 0x10 */
    uint8_t z = 0x00;
    for (int j = j0; j <= j1; j++) {
        int g = a0_gate_of(j);
        epd_set_window_rect(x_mirror, c0, c1, g, g);
        epd_cmd(0x10, &z, 0);
        fill(j, win);
        row_mirror(mir, win, wb);
        gpio_set_level(s_pins.dc, 1);
        gpio_set_level(s_pins.cs, 0);
        esp_err_t err = spi_tx_data(mir, wb);
        gpio_set_level(s_pins.cs, 1);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "SPI tx failed: %s", esp_err_to_name(err));
            return -1;
        }
    }
    return 0;
}

/* ---- DRF ---- */

vd_drf_result_t vd_drf(uint32_t timeout_ms, bool a1_false_release)
{
    vd_drf_result_t r = { 0, false, false };
    uint8_t z = 0x00;
    int64_t t0;

    epd_cmd(0x12, &z, 1);
    t0 = now_ms();
    if (!epd_wait_ready(timeout_ms, &r.saw_low, &r.elapsed_ms)) {
        r.timeout = true;
        return r;
    }
    /* ★ elapsed_ms 用等待内部实测值（探针判据依赖它：空表 DRF 约 2 ms，
       不能把稳定余量算进去）。 */
    if (a1_false_release && r.elapsed_ms < 250) {
        /* A1 已知会在 0x12 后几百 ms 内假释 BUSY：退回固定 14 s 等待
           （主固件同款处理） */
        ESP_LOGW(TAG, "BUSY 仅 %lld ms 即释放，按 A1 假释放补 14 s",
                 (long long)r.elapsed_ms);
        vTaskDelay(pdMS_TO_TICKS(14000));
        r.elapsed_ms = now_ms() - t0;
    } else {
        vTaskDelay(pdMS_TO_TICKS(100));   /* 稳定余量（不计入时长） */
    }
    return r;
}

vd_drf_result_t vd_drf_video(uint32_t timeout_ms, bool a1_false_release)
{
    /* 与 vd_drf 同序列，仅去掉 DRF 后 100 ms 稳定余量（视频路径不需要；
       该余量在 R1 上把每帧刷路径从实测 ~18 ms 拖到 ~118 ms 且不体现在
       统计里——连续帧率的隐形杀手）。BUSY 等待内部自带 ≥10 ms 观测下限，
       对 ~18 ms 的三扫描快刷无额外拖尾。 */
    vd_drf_result_t r = { 0, false, false };
    uint8_t z = 0x00;
    int64_t t0;

    epd_cmd(0x12, &z, 1);
    t0 = now_ms();
    if (!epd_wait_ready(timeout_ms, &r.saw_low, &r.elapsed_ms)) {
        r.timeout = true;
        return r;
    }
    if (a1_false_release && r.elapsed_ms < 250) {
        ESP_LOGW(TAG, "BUSY 仅 %lld ms 即释放，按 A1 假释放补 14 s",
                 (long long)r.elapsed_ms);
        vTaskDelay(pdMS_TO_TICKS(14000));
        r.elapsed_ms = now_ms() - t0;
    }
    return r;
}

int vd_power_off(void)
{
    uint8_t z = 0x00;
    epd_cmd(0x02, &z, 1);
    return epd_wait_ready(s_panel == VD_PANEL_A1 ? BUSY_TIMEOUT_LONG_MS
                                                 : BUSY_TIMEOUT_REFRESH_A0_MS,
                          NULL, NULL) ? 0 : -1;
}

void vd_panel_sleep(void)
{
    uint8_t z = 0xA5;
    if (!s_inited) return;      /* 初始化失败路径：深睡前不得碰未初始化的 SPI */
    epd_cmd(0x07, &z, 1);
    vTaskDelay(pdMS_TO_TICKS(200));
}

/* ---- 寄存器 LUT 实验路径 ---- */

int vd_custom_overlay(uint8_t vsp1, uint8_t vsn1)
{
    if (!s_inited) return -1;
    if (s_panel == VD_PANEL_A0 && !s_aa_sent) {
        /* A0 极简初始化不含解锁块：补 JD79665 式 0xAA（若被忽略只影响
           后续扩展寄存器是否可写——探测结果会体现）。只发一次。 */
        EPD_C6(0xAA, 0x49, 0x55, 0x20, 0x08, 0x09, 0x18);
        s_aa_sent = true;
    }
    /* R01 = 3F 00 14 <VSP_1> <VSN_1> 14：Mode0 固定档 + Mode1 可配档
       （ref docs/06 短波形族共同配置；灰度 Mode1 档的 VSP_1 在此给定） */
    EPD_C6(0x01, 0x3F, 0x00, 0x14, vsp1, vsn1, 0x14);
    EPD_C1(0x30, 0x07);                 /* PLL：标称 120 Hz */
    return 0;
}

int vd_lut_write(const uint8_t *tbl)
{
    if (!s_inited || !tbl) return -1;
    return epd_cmd(0x20, tbl, LUT_R20_BYTES) == ESP_OK ? 0 : -1;
}

int vd_set_psr_register(uint8_t psr2)
{
    if (!s_inited) return -1;
    {
        uint8_t psr[2] = { 0x4B, psr2 };
        return epd_cmd(0x00, psr, 2) == ESP_OK ? 0 : -1;
    }
}

/* ---- 工厂完整周期 ---- */

int vd_factory_frame(vd_row_fill_t fill, int64_t *drf_ms)
{
    int attempt;
    if (!s_inited) return -1;

    for (attempt = 0; attempt < 3; attempt++) {
        ESP_LOGI(TAG, "工厂显示周期 %d/3（BUSY=%d）",
                 attempt + 1, gpio_get_level(s_pins.busy));
        if (vd_full_reinit() != 0) continue;

        if (vd_write_full(fill) != 0) continue;
        vd_window_full();

        {
            vd_drf_result_t r = vd_drf(s_panel == VD_PANEL_A1 ? BUSY_TIMEOUT_LONG_MS
                                                              : BUSY_TIMEOUT_REFRESH_A0_MS,
                                       s_panel == VD_PANEL_A1);
            ESP_LOGI(TAG, "工厂 DRF：%lld ms%s", (long long)r.elapsed_ms,
                     r.saw_low ? "" : "（未见忙脉冲！）");
            if (drf_ms) *drf_ms = r.elapsed_ms;
            if (r.timeout) continue;
        }
        vd_power_off();
        return 0;
    }
    ESP_LOGE(TAG, "工厂显示周期 3 次尝试均失败");
    return -1;
}

/* ---- init ---- */

int vd_init(const vd_pins_t *pins, vd_panel_t panel)
{
    esp_err_t err;
    if (!pins) return -1;
    s_pins = *pins;
    s_panel = panel;

    gpio_config_t out = {
        .pin_bit_mask = (1ULL << s_pins.cs) | (1ULL << s_pins.dc) |
                        (1ULL << s_pins.rst),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&out));
    gpio_set_level(s_pins.rst, 1);
    gpio_set_level(s_pins.cs, 1);
    gpio_set_level(s_pins.dc, 0);

    gpio_config_t in = {
        .pin_bit_mask = (1ULL << s_pins.busy),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&in));

    {
        spi_bus_config_t bus = {
            .mosi_io_num = s_pins.mosi,
            .miso_io_num = -1,
            .sclk_io_num = s_pins.sck,
            .quadwp_io_num = -1,
            .quadhd_io_num = -1,
            .max_transfer_sz = 4096,
        };
        err = spi_bus_initialize(SPI2_HOST, &bus, SPI_DMA_CH_AUTO);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "spi_bus_initialize: %s", esp_err_to_name(err));
            return -1;
        }
    }
    {
        spi_device_interface_config_t cdev = {
            .clock_speed_hz = (int)s_spi_cmd_hz,
            .mode = 0,
            .spics_io_num = -1,
            .queue_size = 1,
        };
        spi_device_interface_config_t ddev = {
            .clock_speed_hz = (int)s_spi_hz,
            .mode = 0,
            .spics_io_num = -1,
            .queue_size = 1,
        };
        err = spi_bus_add_device(SPI2_HOST, &cdev, &s_spi_cmd);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "spi_bus_add_device(命令通道): %s", esp_err_to_name(err));
            return -1;
        }
        err = spi_bus_add_device(SPI2_HOST, &ddev, &s_spi_data);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "spi_bus_add_device(数据通道): %s", esp_err_to_name(err));
            spi_bus_remove_device(s_spi_cmd);
            s_spi_cmd = NULL;
            return -1;
        }
    }

    s_inited = true;
    ESP_LOGI(TAG, "EPD 就绪：画像 %s，SPI2 命令/寄存器 %lu Hz + 数据 %lu Hz，SCK=%d MOSI=%d CS=%d DC=%d RST=%d BUSY=%d",
             vd_panel_name(), (unsigned long)s_spi_cmd_hz, (unsigned long)s_spi_hz,
             s_pins.sck, s_pins.mosi, s_pins.cs, s_pins.dc, s_pins.rst, s_pins.busy);
    return 0;
}

/* 运行时换档（R3 新增）：按当前 vd_set_spi_hz 档位删除并重建两路 SPI 设备，
 * 免去「改档要复位才生效」（R2 真机实测：未复位调档所有档位同速——档位
 * 变量只在 vd_init 的 add_device 时被读一次）。
 * 调用约束：必须处于无在途 SPI 事务的上下文（菜单/播放停止后；polling
 * 传输同步完成，正常流程不会在途）。失败返回 -1（建议复位）。 */
int vd_apply_spi_hz(void)
{
    if (!s_inited) return -1;

    spi_device_handle_t nc = NULL, nd = NULL;
    spi_device_interface_config_t cdev = {
        .clock_speed_hz = (int)s_spi_cmd_hz,
        .mode = 0,
        .spics_io_num = -1,
        .queue_size = 1,
    };
    spi_device_interface_config_t ddev = {
        .clock_speed_hz = (int)s_spi_hz,
        .mode = 0,
        .spics_io_num = -1,
        .queue_size = 1,
    };

    /* 先加新再删旧：任一新增失败时旧配置完好，总线无中间态 */
    if (spi_bus_add_device(SPI2_HOST, &cdev, &nc) != ESP_OK) return -1;
    if (spi_bus_add_device(SPI2_HOST, &ddev, &nd) != ESP_OK) {
        spi_bus_remove_device(nc);
        return -1;
    }
    spi_bus_remove_device(s_spi_cmd);
    spi_bus_remove_device(s_spi_data);
    s_spi_cmd = nc;
    s_spi_data = nd;

    ESP_LOGI(TAG, "SPI 换档生效：命令/寄存器 %lu Hz + 数据 %lu Hz",
             (unsigned long)s_spi_cmd_hz, (unsigned long)s_spi_hz);
    return 0;
}

const char *vd_panel_name(void)
{
    return s_panel == VD_PANEL_A1 ? "A1" : "A0";
}

vd_panel_t vd_panel(void)
{
    return s_panel;
}

int vd_busy_level(void)
{
    return gpio_get_level(s_pins.busy);
}
