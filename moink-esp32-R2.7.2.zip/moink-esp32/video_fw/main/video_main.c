/*
 * 墨印 MoInk · 视频快刷测试固件（VIDEO-R3）
 *
 * 配套 PC 端 tools/moink_video_pc（Windows，MV2）：把视频转成黑白抖动
 * 帧、按设备协商的播放窗口裁剪、只传与上一帧差异的写行；本固件 TCP
 * 长连接拉取，以寄存器 LUT 快刷连续播放，「取帧」与「刷屏」双任务流水
 * 线重叠，逐帧打印取/写/刷/节拍与有效帧率。
 *
 * ── 为什么是 MV2：VIDEO-R1 实测仅 ~1 fps 的四个根因 ────────────────────
 *   ① vd_drf 后隐藏的 100 ms「稳定余量」（未计入统计：串口显示刷=18 ms
 *     实际阻塞 118 ms）→ R2 视频路径改走 vd_drf_video（无余量）；
 *   ② 每帧 HTTP 都新建 TCP 连接（握手+慢启动+延迟 ACK，单请求往返
 *     100~300 ms）→ R2 改一条 TCP 长连接 + 'N' 请求-响应 + TCP_NODELAY；
 *   ③ SPI 默认 4 MHz（ref/jd79665aa-driver 短波形族用 16 MHz）→ R2 档位
 *     扩为 4/8/16/24 MHz 且默认 16 MHz；
 *   ④ 全屏 768×552 更新（ref 的 24 fps 实验是 256×128 小窗 = 1/13 屏）
 *     → R2 新增播放窗口档（菜单 v），行写/传输只碰窗口，窗外像素恒为
 *     「保持」码不动作（DRF 仍全窗——三扫描时长由 LUT 决定与窗口无关）。
 *   另：ref 的 24 fps = P3/N3 三扫描表 + 小窗 + 16 MHz SPI + 主机直连，
 *   本固件已具备同款三扫描表（lut_build_num），叠加流水线后小窗目标
 *   即 24 fps+（帧率预算表见 README_VIDEO_FW.md）。
 *
 * ── VIDEO-R3：R2 真机 2fps 的三个残余瓶颈（实测 取247/写126/刷27ms） ──
 *   ① 取 247ms 大头在 PC 端「按请求同步转码」（cv2 抽帧+缩放+抖动+差分
 *     打包在 'N' 到来才开始）→ moink_video_pc 增加会话预取线程（深度 3，
 *     渲染与发送解耦），设备取帧时帧早已渲染好；设备侧配套：接收缓冲
 *     SO_RCVBUF 32KB + staging 整帧大块收（替代逐 162B 小 recv）。
 *   ② 调 SPI 档「不重启无效」（档位只在 vd_init 读一次）且 24M 档寄存器
 *     写入不可靠（仅工厂清屏成功、动图白屏）→ epd_vdrv 拆双通道：
 *     命令/寄存器恒 ≤8M、RAM 行写走档位全额；菜单 s 即时换档（删设备重建）。
 *   ③ 流水线只重叠「刷」27ms（rx_sem 写完才放行）→ 帧中转 staging：
 *     fetch 整帧收进中转缓冲（不碰画布），play 应用后立刻放行 fetch，
 *     「写+刷」全程与网络重叠。分配失败自动回落 R2 乒乓模式。
 *   残影对策（菜单 c）：周期清理帧——同一画布不动 RAM，换六扫描清理表
 *   （ref §5「P3 → Mode1 N3」，白端黄度 R−B 18.2→0）多刷一次再换回。
 *   TWDT 根因修复：IDF 默认 tick=100Hz 时 pdMS_TO_TICKS(1)=0，忙等循环
 *   vTaskDelay(0) 只让出不阻塞 → 同核 IDLE0 饿死 → 工厂 DRF 15s 期间
 *   看门狗风暴（R2 真机日志实证）；等待改 ≥1 拍 + 1ms 快轮询，sdkconfig
 *   提到 1000Hz（需 fullclean 生效）。
 *
 * ── 拉流协议 MV2（与 moink_video_pc.py 同源，两端一起改） ─────────────
 * [发现] PC 每 0.8s 向 UDP 255.255.255.255:8899 广播文本行
 *        "MOINKVID2 <ip> <port>\n"；设备 NVS 键 vurl="ip:port" 优先直连。
 * [TCP]  默认端口 8094（即发现端口）；一条连接一个会话（断开即作废，
 *        重连后 hello 重置 → 首帧必为全帧自愈画布）。两端 TCP_NODELAY。
 *   连接后设备发一行文本握手（UTF-8，\n 结束）：
 *     "H orient=<0..3> col0=<c0> col1=<c1> row0=<r0> row1=<r1> xmirror=<0|1>\n"
 *   PC 回 16B：'M''V''2' | rows u16le | row_bytes u16le | frames u32le
 *     | fps u8 | flags u8 | pad[3]
 *   rows = r1-r0+1（窗口写行数）、row_bytes = (c1-c0+1)/4（窗口行字节），
 *   设备校验与本机窗口一致；frames=0xFFFFFFFF=无限（测试图案）；
 *   flags bit0：0=重复动作码（自清残影），1=安静差异码（最安静）。
 * [帧]   设备发 "N\n" 请求一帧；PC 回：
 *     frame_id u32le | row_count u16le
 *     | [row_no u16le + row_bytes B]×N | crc16 u16le
 *   row_no 为窗口内相对行（0..rows-1）；crc16=CRC16-CCITT-FALSE（初值
 *   0xFFFF，多项式 0x1021）覆盖其前全部字节；frame_id 循环点回 0；
 *   frame_id==0 必为全帧；row_count==0 = 无变化帧。
 * [复位] 设备发 "R\n" → 会话游标清零（CRC/序错后自救，下一帧全帧）。
 * [帧字节] 窗口画布行（窗宽 (c1-c0+1)/4 字节）；像素码 c 位于字节 b[c>>2]
 *   的 6-2*(c&3) 两位（MSB 优先）。寄存器 LUT 动作码：01=黑目标(0x55)、
 *   10=白/浅色目标(0xAA)、00=保持(0x00)。PC 端已按设备上报 orient 完成
 *   用户视角→逻辑画布映射，设备零换算。
 *
 * ── 流水线（R3：帧中转，取与「写+刷」全程重叠） ──────────────────────
 *   fetch 任务：take(rx_sem) → 发 "N" → 整帧收进 g_stage（staging 模式；
 *               回落模式逐行直写画布，R2 行为）→ 填帧元数据 →
 *               give(frame_sem)。staging 模式全程不碰画布。
 *   play 循环：take(frame_sem) → staging：把 g_stage 应用进画布+touched
 *               （亚毫秒级）→ give(rx_sem)（fetch 立即预取下一帧）→
 *               分段写 SPI（fetch 并行收）→ DRF（fetch 并行收）→
 *               [周期清理帧：换表多刷一次] → 循环。
 *   节拍 ≈ max(取, 应用+写+刷)：R2 只重叠 27ms 的「刷」，R3 全重叠。
 *   回落模式（g_stage 分配失败，如全屏 106KB）：R2 乒乓语义不变。
 *
 * 使用：上位机先启动 moink_video_pc 并开始服务 → 设备（配好网后）菜单
 * 直接回车进入播放；串口逐帧打印「取/写/刷/拍」与行数、字节数，每 60
 * 帧汇总有效 fps。播放中发送 s 停止回菜单。
 * 菜单：b=增强灰度色带、w=串口配网（NVS 同主固件 sta_ssid/sta_pass）、
 *   u=手动服务器、p=画像 A0↔A1、o=方向、v=播放窗口档（全屏…256×128）、
 *   m=窗口 X 镜像编码、s=SPI 档 4/8/16/24 MHz（即时生效）、
 *   c=周期清理帧档（关/64/128/300/600，默认 64）。
 *
 * 常开交互式测试台：不进深睡，结束后回菜单循环（发热问题已在
 * verify_fw 验证与 SoC 无关）。
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "esp_random.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "esp_sleep.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_partition.h"
#include "esp_heap_caps.h"

#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "lwip/sockets.h"

#include "epd_vdrv.h"
#include "lut_r20.h"
#include "probe_lut.h"
#include "gray_bands.h"

#define VIDEO_FW_VER   "VIDEO-R3（MV2 + 双钟SPI + 帧中转全重叠 + 周期清理表）"

/* ================= 协议常量（与 moink_video_pc.py 同源） ================= */

#define MV_UDP_PORT        8899       /* UDP 广播发现端口 */
#define MV_TCP_PORT_DEF    8094       /* PC 端 TCP 默认端口 */
#define MV_HDR_LEN         6          /* 帧头：frame_id u32 + row_count u16 */
#define MV_HELLO_LEN       16
#define MV_FRAMES_INF      0xFFFFFFFFu
#define MV_TCP_TIMEOUT_MS  15000      /* 单次 recv 超时（超时算网络错重连） */

/* ================= 配置（NVS 命名空间 moink，与主固件同池） ================= */

#define NVS_NS              "moink"
#define SSID_MAX            33
#define PASS_MAX            65
#define URL_MAX             24        /* "255.255.255.255:65535" 足够 */

/* SPI 档位表（vd_set_spi_hz 四档吸附）：默认档下标 2 = 16 MHz（ref 快刷配置） */
static const uint32_t SPI_STEPS[4] = { 4000000u, 8000000u, 16000000u, 24000000u };
#define SPI_DEFAULT_SEL     2

/* 播放窗口档（逻辑画布列 c0..c1 × 写行 r0..r1，均 4 像素对齐、居中）：
 * 档 4 = 256×128，正是 ref/jd79665aa-driver docs/06 的 24fps 实验窗。 */
typedef struct { int c0, c1, r0, r1; } win_rect_t;
static const win_rect_t WIN_STEPS[5] = {
    {   0, 767,   0, 551 },           /* 0: 全屏 768×552 */
    {  64, 703,  84, 467 },           /* 1: 中央 640×384 */
    { 128, 639, 132, 419 },           /* 2: 中央 512×288 */
    { 192, 575, 180, 371 },           /* 3: 中央 384×192 */
    { 256, 511, 212, 339 },           /* 4: 中央 256×128（ref 实验窗） */
};
#define WIN_DEFAULT_IDX     4         /* 默认：24fps 复现档 */

/* 引脚预设表（与主固件 settings.c 一致；[0] = 本移植版实际接线） */
static const uint8_t PIN_PRESETS[3][6] = {
    /* sck, mosi, cs, dc, rst, busy */
    { 18, 23,  5, 16, 17, 27 },
    { 14, 13, 15, 22, 21, 27 },
    { 18, 23,  5, 19,  4, 33 },
};

static nvs_handle_t s_nvs;
static bool s_nvs_ok = false;

static vd_panel_t s_panel_sel = VD_PANEL_A0;
static int  s_orient = 0;                 /* 屏幕方向（同主固件 0..3） */
static vd_pins_t  s_pins;
static const char *s_pin_src = "默认预设";
static int  s_spi_sel = SPI_DEFAULT_SEL; /* 0=4M 1=8M 2=16M 3=24M */
static int  s_win_idx = WIN_DEFAULT_IDX; /* 播放窗口档（菜单 v） */
static int  s_xmirror = 0;               /* 窗口 X 镜像编码（菜单 m） */
static bool s_wifi_inited = false;
static bool s_wifi_got_ip = false;
static char s_sta_ssid[SSID_MAX] = "";
static char s_sta_pass[PASS_MAX] = "";
static char s_srv_url[URL_MAX] = "";      /* NVS vurl：手动服务器（空=自动发现） */
static char s_srv_ip[16] = "";
static int  s_srv_port = MV_TCP_PORT_DEF;

static uint8_t *g_canvas;                 /* VD_ROWS × VD_RB，堆分配 */
static uint8_t  g_lut[LUT_R20_BYTES];
static uint8_t  g_touched[VD_ROWS];       /* 被更新的写行位图（绝对行号） */

/* ★ VIDEO-R3：帧中转缓冲（staging）——fetch 整帧收进这里（不碰画布），
 *   play 取走后应用到画布；从此「写+刷」全程与网络接收重叠。
 *   分配失败（大窗口内存不够）自动回落 R2 乒乓模式。 */
static uint8_t *g_stage = NULL;
static int      g_stage_cap = 0;
static bool     s_stage_mode = false;

/* ★ VIDEO-R3：周期残影清理帧（菜单 c）——同一画布不动 RAM，换六扫描
 *   清理表（lut_build_num_clean）多刷一次 DRF 再换回。0=关。 */
static uint8_t  g_lut_clean[LUT_R20_BYTES];
static const int CLEAN_STEPS[5] = { 0, 64, 128, 300, 600 };
static int       s_clean_step_idx = 1;    /* 默认每 64 帧（R2 实测残影累积快） */

static int clean_period(void)
{
    return CLEAN_STEPS[s_clean_step_idx];
}

static const char *clean_name(void)
{
    static const char *names[5] = {
        "关闭", "每 64 帧", "每 128 帧", "每 300 帧（ref 档）", "每 600 帧",
    };
    return names[s_clean_step_idx];
}

/* 播放窗口派生量（进播放时由 WIN_STEPS[s_win_idx] 求出） */
static int win_c0, win_c1, win_r0, win_r1;
static int win_rb;                        /* 窗口行字节 = (c1-c0+1)/4 */
static int win_rows;                      /* 窗口写行数 = r1-r0+1 */
static int win_cb0;                       /* 窗口在画布行内的字节偏移 = c0/4 */

static EventGroupHandle_t s_wifi_ev;
#define WIFI_CONNECTED_BIT  BIT0

/* ================= 基础小工具 ================= */

static int64_t now_ms(void) { return esp_timer_get_time() / 1000; }

/* 非阻塞读串口一个键；timeout_ms 内无输入返回 -1 */
static int uart_getkey(int timeout_ms)
{
    uint8_t ch;
    int waited = 0;
    while (waited <= timeout_ms) {
        int n = uart_read_bytes(UART_NUM_0, &ch, 1, 0);
        if (n > 0) return ch;
        if (timeout_ms == 0) return -1;   /* 纯非阻塞 */
        vTaskDelay(pdMS_TO_TICKS(20));
        waited += 20;
    }
    return -1;
}

/* 读一行（回车结束；支持退格；超时返回 false）。用于配网/服务器输入。 */
static bool uart_readline(char *buf, int buflen, int timeout_ms)
{
    int len = 0;
    int waited = 0;
    for (;;) {
        uint8_t ch;
        int n = uart_read_bytes(UART_NUM_0, &ch, 1, 0);
        if (n > 0) {
            if (ch == '\r' || ch == '\n') {
                if (timeout_ms <= 0) { /* 非阻塞模式回车确认 */ }
                buf[len] = '\0';
                return true;
            }
            if (ch == 0x08 || ch == 0x7F) {       /* 退格 */
                if (len > 0) { len--; printf("\b \b"); }
                continue;
            }
            if (len < buflen - 1 && ch >= 0x20 && ch < 0x7F) {
                buf[len++] = (char)ch;
                putchar('*');                      /* 密码不回显 */
            }
            fflush(stdout);
            continue;
        }
        if (timeout_ms > 0) {
            vTaskDelay(pdMS_TO_TICKS(20));
            waited += 20;
            if (waited > timeout_ms) { buf[len] = '\0'; return len > 0; }
        } else {
            vTaskDelay(pdMS_TO_TICKS(10));
        }
    }
}

/* ================= NVS ================= */

static bool cfg_get_u8(const char *key, uint8_t *out)
{
    return s_nvs_ok && nvs_get_u8(s_nvs, key, out) == ESP_OK;
}

static void cfg_put_u8(const char *key, uint8_t v)
{
    if (s_nvs_ok) (void)nvs_set_u8(s_nvs, key, v);
}

static void cfg_get_str(const char *key, char *buf, int buflen)
{
    size_t len = (size_t)buflen;
    buf[0] = '\0';
    if (s_nvs_ok) (void)nvs_get_str(s_nvs, key, buf, &len);
}

static void cfg_put_str(const char *key, const char *v)
{
    if (s_nvs_ok) (void)nvs_set_str(s_nvs, key, v);
}

static void nvs_commit_safe(void)
{
    if (s_nvs_ok) (void)nvs_commit(s_nvs);
}

static bool pin_basic_ok(const uint8_t *p)
{
    for (int i = 0; i < 6; i++) {
        if (p[i] > 33 || (p[i] >= 6 && p[i] <= 11)) return false;
        for (int k = i + 1; k < 6; k++) {
            if (p[i] == p[k]) return false;
        }
    }
    return true;
}

static void pins_from_array(const uint8_t *a)
{
    s_pins.sck  = a[0];
    s_pins.mosi = a[1];
    s_pins.cs   = a[2];
    s_pins.dc   = a[3];
    s_pins.rst  = a[4];
    s_pins.busy = a[5];
}

static void load_config(void)
{
    uint8_t v;

    if (cfg_get_u8("panel", &v) && v <= 1) s_panel_sel = (vd_panel_t)v;
    if (cfg_get_u8("orient", &v) && v <= 3) s_orient = v;
    if (cfg_get_u8("vspi", &v) && v <= 3) s_spi_sel = v;          /* R2: 0..3 */
    if (cfg_get_u8("vwin", &v) && v <= 4) s_win_idx = v;          /* R2 新增 */
    if (cfg_get_u8("vxm", &v) && v <= 1) s_xmirror = v;           /* R2 新增 */
    if (cfg_get_u8("vclean", &v) && v <= 4) s_clean_step_idx = (int)v;  /* R3 新增 */

    /* WiFi 凭据（与主固件 settings.c 同键：sta_ssid / sta_pass） */
    cfg_get_str("sta_ssid", s_sta_ssid, sizeof(s_sta_ssid));
    cfg_get_str("sta_pass", s_sta_pass, sizeof(s_sta_pass));

    /* 手动服务器（空 = UDP 自动发现） */
    cfg_get_str("vurl", s_srv_url, sizeof(s_srv_url));

    /* 引脚（与 verify_fw 同策略） */
    {
        uint8_t preset = 0;
        const char *keys[6] = { "p_sck", "p_mosi", "p_cs", "p_dc", "p_rst", "p_busy" };
        uint8_t custom[6];
        bool have_all = true;
        bool have_preset = cfg_get_u8("gpio_preset", &preset);

        if (!have_preset) preset = 0;
        if (preset > 3) preset = 0;

        for (int i = 0; i < 6; i++) {
            if (!cfg_get_u8(keys[i], &custom[i])) have_all = false;
        }

        if (preset <= 2) {
            pins_from_array(PIN_PRESETS[preset]);
            s_pin_src = have_preset ? "NVS 预设档（主固件配置）"
                                    : "默认预设[0]（NVS 无记录，编译内建）";
        } else if (have_all && pin_basic_ok(custom)) {
            pins_from_array(custom);
            s_pin_src = "NVS 自定义档（主固件配置）";
        } else {
            pins_from_array(PIN_PRESETS[0]);
            s_pin_src = "默认预设[0]（自定义档无效，回落）";
        }
    }
}

static void invalidate_otadata(void)
{
    const esp_partition_t *ot =
        esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_OTA, NULL);
    if (ot) {
        esp_err_t err = esp_partition_erase_range(ot, 0,
                          ot->size > 0x2000 ? 0x2000 : ot->size);
        printf("[启动] otadata 清除（%s）\n", err == ESP_OK ? "成功" : esp_err_to_name(err));
    }
}

/* ================= 画布 ================= */

static void canvas_fill_row(int j, uint8_t *row)
{
    memcpy(row, g_canvas + (size_t)j * VD_RB, VD_RB);
}

/* 窗口行填充：写行 j（绝对行号）的窗宽字节（vd_write_win_rows 回调） */
static void win_fill_row(int j, uint8_t *row)
{
    memcpy(row, g_canvas + (size_t)j * VD_RB + win_cb0, win_rb);
}

/* ================= WiFi（STA；凭据继承主固件） ================= */

static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        s_wifi_got_ip = false;
        if (s_wifi_ev) xEventGroupClearBits(s_wifi_ev, WIFI_CONNECTED_BIT);
        esp_wifi_connect();               /* 自动重连 */
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *ev = (ip_event_got_ip_t *)data;
        printf("[WiFi] 已连接 %s，IP " IPSTR "\n", s_sta_ssid, IP2STR(&ev->ip_info.ip));
        s_wifi_got_ip = true;
        if (s_wifi_ev) xEventGroupSetBits(s_wifi_ev, WIFI_CONNECTED_BIT);
    }
}

static void wifi_start_sta(void)
{
    if (s_wifi_inited) return;
    if (!s_sta_ssid[0]) {
        printf("[WiFi] 无配网记录（NVS 键 sta_ssid 空）——菜单发送 w 串口配网\n");
        return;
    }

    esp_netif_init();
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_t *netif = esp_netif_create_default_wifi_sta();
    (void)netif;

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    s_wifi_ev = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_event_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_event_handler, NULL));

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    wifi_config_t wc = { 0 };
    strlcpy((char *)wc.sta.ssid, s_sta_ssid, sizeof(wc.sta.ssid));
    strlcpy((char *)wc.sta.password, s_sta_pass, sizeof(wc.sta.password));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wc));
    /* 拉流延迟敏感：关省电（功耗换吞吐稳定；测试台常供电） */
    esp_wifi_set_ps(WIFI_PS_NONE);
    ESP_ERROR_CHECK(esp_wifi_start());

    s_wifi_inited = true;
    printf("[WiFi] STA 启动中（SSID %s，省电已关）...\n", s_sta_ssid);
}

static bool wifi_wait_ip(int timeout_s)
{
    if (!s_wifi_inited) return false;
    if (s_wifi_got_ip) return true;
    if (!s_wifi_ev) return false;
    return xEventGroupWaitBits(s_wifi_ev, WIFI_CONNECTED_BIT,
                               pdFALSE, pdTRUE,
                               pdMS_TO_TICKS(timeout_s * 1000)) & WIFI_CONNECTED_BIT;
}

/* ================= UDP 自动发现 ================= */

static bool udp_discover(int timeout_ms)
{
    int fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) return false;

    struct timeval tv = { .tv_sec = timeout_ms / 1000, .tv_usec = (timeout_ms % 1000) * 1000 };
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    struct sockaddr_in local = {
        .sin_family = AF_INET,
        .sin_port = htons(MV_UDP_PORT),
        .sin_addr.s_addr = htonl(INADDR_ANY),
    };
    if (bind(fd, (struct sockaddr *)&local, sizeof(local)) < 0) {
        close(fd);
        return false;
    }

    printf("[发现] 监听 UDP %d，等待 PC 广播（%d ms）...\n", MV_UDP_PORT, timeout_ms);
    char buf[64];
    int64_t t0 = now_ms();
    bool found = false;
    while (now_ms() - t0 < (int64_t)timeout_ms) {
        int n = recvfrom(fd, buf, sizeof(buf) - 1, 0, NULL, NULL);
        if (n <= 0) continue;
        buf[n] = '\0';
        char ip[16];
        int port = 0;
        if (sscanf(buf, "MOINKVID2 %15s %d", ip, &port) == 2 && port > 0 && port < 65536) {
            strlcpy(s_srv_ip, ip, sizeof(s_srv_ip));
            s_srv_port = port;
            printf("[发现] 收到 PC 广播：%s:%d\n", s_srv_ip, s_srv_port);
            found = true;
            break;
        }
    }
    close(fd);
    return found;
}

/* ================= MV2 TCP 拉流（长连接 + 请求-响应） ================= */

/* CRC16-CCITT-FALSE（初值 0xFFFF，多项式 0x1021）—— 与 PC 端一致。
 * 增量式：边收边算，无需整帧缓存。 */
static uint16_t crc16_update(uint16_t crc, const uint8_t *p, int len)
{
    for (int i = 0; i < len; i++) {
        crc ^= (uint16_t)p[i] << 8;
        for (int k = 0; k < 8; k++) {
            crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

static int g_fd = -1;

static int tcp_connect_srv(void)
{
    struct sockaddr_in dst = {
        .sin_family = AF_INET,
        .sin_port = htons((uint16_t)s_srv_port),
        .sin_addr.s_addr = inet_addr(s_srv_ip),
    };
    int fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (fd < 0) return -1;

    struct timeval tv = { .tv_sec = MV_TCP_TIMEOUT_MS / 1000,
                          .tv_usec = (MV_TCP_TIMEOUT_MS % 1000) * 1000 };
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    int one = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));  /* 'N' 小包禁 Nagle */
    {
        /* R3：加大接收缓冲 → lwIP 通告窗口跟随变大，PC 可突发整帧；
         * 设备侧按 8KB 级大块收（staging 模式 recv 直接收满整帧 body） */
        int rcb = 32768;
        setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcb, sizeof(rcb));
    }

    if (connect(fd, (struct sockaddr *)&dst, sizeof(dst)) != 0) {
        close(fd);
        return -1;
    }
    g_fd = fd;
    return 0;
}

/* 循环补齐读：凑满 len 返回 0；EOF/错误返回 -1 */
static int read_full_fd(uint8_t *buf, int len)
{
    int got = 0;
    while (got < len) {
        int n = recv(g_fd, buf + got, len - got, 0);
        if (n <= 0) return -1;
        got += n;
    }
    return 0;
}

static int send_all(const uint8_t *buf, int len)
{
    int sent = 0;
    while (sent < len) {
        int n = send(g_fd, buf + sent, len - sent, 0);
        if (n <= 0) return -1;
        sent += n;
    }
    return 0;
}

/* 握手：发 H 行 → 收 16B 头 → 尺寸校验。返回 0 成功。
 * ★ MV2 语义：一条连接一个会话——hello 即重置，首帧必为全帧。 */
static int tcp_hello(void)
{
    char line[96];
    snprintf(line, sizeof(line),
             "H orient=%d col0=%d col1=%d row0=%d row1=%d xmirror=%d\n",
             s_orient, win_c0, win_c1, win_r0, win_r1, s_xmirror);
    if (send_all((const uint8_t *)line, (int)strlen(line)) != 0) return -1;

    uint8_t hdr[MV_HELLO_LEN];
    if (read_full_fd(hdr, sizeof(hdr)) != 0) return -1;

    if (hdr[0] != 'M' || hdr[1] != 'V' || hdr[2] != '2') {
        printf("[TCP] hello 魔数不符（非 MV2 的 moink_video_pc？两端版本要配对）\n");
        return -1;
    }
    uint16_t rows   = (uint16_t)(hdr[3] | (hdr[4] << 8));
    uint16_t rb     = (uint16_t)(hdr[5] | (hdr[6] << 8));
    uint32_t frames = (uint32_t)hdr[7] | ((uint32_t)hdr[8] << 8) |
                      ((uint32_t)hdr[9] << 16) | ((uint32_t)hdr[10] << 24);
    uint8_t  fps    = hdr[11];
    uint8_t  flags  = hdr[12];

    if (rows != win_rows || rb != win_rb) {
        printf("[TCP] 窗口尺寸不符：服务器 %d×%dB，本机 %d×%dB（两端版本错配）\n",
               rows, rb, win_rows, win_rb);
        return -1;
    }
    printf("[TCP] hello 通过：%s，源帧率 %d fps，动作模式=%s\n",
           frames == MV_FRAMES_INF ? "无限（测试图案）" : "有限帧数",
           fps, (flags & 1) ? "安静差异码" : "重复动作码");
    return 0;
}

static int tcp_reset_session(void)
{
    if (send_all((const uint8_t *)"R\n", 2) != 0) return -1;
    printf("[TCP] 会话已 reset（下一帧为全帧）\n");
    return 0;
}

/* ---- fetch 任务与 play 的同步（严格乒乓，零帧缓冲） ----
 * rx_sem   : play → fetch「可以发下一个 'N' 请求并写画布了」
 * frame_sem: fetch → play「一帧已收好（画布/touched 已更新）」
 * 元数据单写者（fetch）单读者（play），rx_sem 保证写读不重叠。 */

typedef struct {
    uint32_t fid;
    int      rows;          /* 本帧行数（0=无变化帧） */
    int      bytes;
    int64_t  fetch_ms;
    int      err;           /* 0=ok；-1=网络错；-2=协议/CRC 错（会话已 reset） */
} frame_meta_t;

static frame_meta_t s_meta;
static SemaphoreHandle_t s_rx_sem;
static SemaphoreHandle_t s_frame_sem;
static volatile bool s_fetch_run = false;
static volatile int  s_net_gen = 0;       /* 连接代次：play 换连接时 ++ */
static TaskHandle_t s_fetch_task;

static void meta_give(int err, uint32_t fid, int rows, int bytes, int64_t ms)
{
    s_meta.err = err;
    s_meta.fid = fid;
    s_meta.rows = rows;
    s_meta.bytes = bytes;
    s_meta.fetch_ms = ms;
    xSemaphoreGive(s_frame_sem);
}

/* fetch 任务：拉一帧 → staging 模式整帧收进中转缓冲（不碰画布，交 play
 * 应用）；回落模式（分配失败）逐行直写画布（R2 行为）。
 * 出错时填 err 并通知；协议/CRC 错自动向 PC 发 R 复位会话。 */
static void fetch_task(void *arg)
{
    int gen = s_net_gen;
    uint8_t rec[2 + VD_RB];               /* row_no + 窗口行字节（≤192B；回落模式专用） */

    while (s_fetch_run && gen == s_net_gen) {
        if (xSemaphoreTake(s_rx_sem, pdMS_TO_TICKS(5000)) != pdTRUE) continue;
        if (!s_fetch_run || gen != s_net_gen) break;

        int64_t t0 = now_ms();
        if (send_all((const uint8_t *)"N\n", 2) != 0) {
            meta_give(-1, 0, 0, 0, now_ms() - t0);
            continue;
        }

        uint8_t hdr[MV_HDR_LEN];
        if (read_full_fd(hdr, sizeof(hdr)) != 0) {
            meta_give(-1, 0, 0, 0, now_ms() - t0);
            continue;
        }
        uint32_t fid = (uint32_t)hdr[0] | ((uint32_t)hdr[1] << 8) |
                       ((uint32_t)hdr[2] << 16) | ((uint32_t)hdr[3] << 24);
        uint16_t nrows = (uint16_t)(hdr[4] | (hdr[5] << 8));
        if (nrows > (uint16_t)win_rows) {
            (void)tcp_reset_session();
            meta_give(-2, fid, nrows, 0, now_ms() - t0);
            continue;
        }
        /* staging 模式下 touched 由 play 在应用时逐行置位，这里不清 */
        if (!s_stage_mode && fid == 0) memset(g_touched, 0, sizeof(g_touched));

        int reclen = 2 + win_rb;
        int bytes = MV_HDR_LEN + 2 + nrows * reclen;

        if (s_stage_mode) {
            /* ★ R3 staging：帧体（行记录 + CRC）一次 read_full 收齐——
             * recv 按内核可用数据成块返回，等效大块接收，替代 R2 每行
             * 162B 的小 recv（每帧 ~380 次 syscall/lwip 拷贝）。收齐后
             * 一次性 CRC + 行号校验，交给 play 应用，全程不碰画布。 */
            int body = nrows * reclen + 2;
            int bad = 0;
            memcpy(g_stage, hdr, MV_HDR_LEN);
            if (read_full_fd(g_stage + MV_HDR_LEN, body) != 0) bad = -1;
            if (!bad) {
                int dat = MV_HDR_LEN + nrows * reclen;
                uint16_t crc = crc16_update(0xFFFF, g_stage, dat);
                uint16_t want = (uint16_t)(g_stage[dat] | (g_stage[dat + 1] << 8));
                if (want != crc) {
                    bad = -2;
                } else {
                    for (int i = 0; i < nrows; i++) {
                        const uint8_t *p = g_stage + MV_HDR_LEN + i * reclen;
                        int rel = p[0] | (p[1] << 8);
                        if (rel >= win_rows) { bad = -2; break; }
                    }
                }
            }
            if (bad == -2) (void)tcp_reset_session();
            if (bad) {
                meta_give(bad, fid, nrows, 0, now_ms() - t0);
                continue;
            }
            meta_give(0, fid, nrows, bytes, now_ms() - t0);
            continue;
        }

        /* 回落模式（R2 行为）：逐行接收即写画布 + touched */
        uint16_t crc = crc16_update(0xFFFF, hdr, MV_HDR_LEN);
        int bad = 0;

        for (int i = 0; i < nrows; i++) {
            if (read_full_fd(rec, reclen) != 0) { bad = -1; break; }
            crc = crc16_update(crc, rec, reclen);
            int rel = rec[0] | (rec[1] << 8);
            if (rel >= win_rows) { bad = -2; break; }
            memcpy(g_canvas + (size_t)(win_r0 + rel) * VD_RB + win_cb0, rec + 2, win_rb);
            g_touched[win_r0 + rel] = 1;
        }
        if (!bad) {
            uint8_t crcbuf[2];
            if (read_full_fd(crcbuf, 2) != 0) {
                bad = -1;
            } else {
                uint16_t want = (uint16_t)(crcbuf[0] | (crcbuf[1] << 8));
                if (want != crc) bad = -2;
            }
        }
        if (bad == -2) (void)tcp_reset_session();
        if (bad) {
            meta_give(bad, fid, nrows, 0, now_ms() - t0);
            continue;
        }

        meta_give(0, fid, nrows, bytes, now_ms() - t0);
    }
    s_fetch_task = NULL;
    vTaskDelete(NULL);
}

/* 关闭当前连接与 fetch 任务（play 上下文调用；停止/重连前走这里） */
static void net_teardown(void)
{
    if (s_fetch_task) {
        s_fetch_run = false;
        s_net_gen++;
        if (g_fd >= 0) shutdown(g_fd, SHUT_RDWR);   /* 唤醒阻塞的 recv */
        if (s_rx_sem) xSemaphoreGive(s_rx_sem);     /* 唤醒阻塞的 take */
        for (int i = 0; i < 10 && s_fetch_task; i++) vTaskDelay(pdMS_TO_TICKS(20));
        if (s_fetch_task) {                          /* 兜底：强删（不应发生） */
            vTaskDelete(s_fetch_task);
            s_fetch_task = NULL;
        }
    }
    if (g_fd >= 0) { close(g_fd); g_fd = -1; }
    /* 清残留信号量计数，保证下次播放从干净状态开始 */
    if (s_rx_sem) while (xSemaphoreTake(s_rx_sem, 0) == pdTRUE) {}
    if (s_frame_sem) while (xSemaphoreTake(s_frame_sem, 0) == pdTRUE) {}
}

/* 建立连接 + hello + 启动 fetch。返回 0 成功。 */
static int net_setup(void)
{
    net_teardown();
    if (tcp_connect_srv() != 0) {
        printf("[TCP] 连接失败 %s:%d（PC 端未开始服务？）\n", s_srv_ip, s_srv_port);
        return -1;
    }
    printf("[TCP] 已连接 %s:%d\n", s_srv_ip, s_srv_port);
    if (tcp_hello() != 0) {
        close(g_fd); g_fd = -1;
        return -1;
    }
    memset(g_touched, 0, sizeof(g_touched));        /* 首帧全帧前保持干净 */
    s_fetch_run = true;
    if (xTaskCreate(fetch_task, "fetch", 4096, NULL, 3, &s_fetch_task) != pdPASS) {
        s_fetch_run = false;
        close(g_fd); g_fd = -1;
        printf("[TCP] fetch 任务创建失败（内存）\n");
        return -1;
    }
    return 0;
}

/* ================= 视频播放（play 主循环 + fetch 流水线） ================= */

static const char *win_name(int idx)
{
    static const char *names[5] = {
        "全屏 768×552", "中央 640×384", "中央 512×288",
        "中央 384×192", "中央 256×128（ref 24fps 实验窗）",
    };
    return names[idx];
}

/* 由窗口档下标求派生量（列区间/行区间/行字节/字节偏移） */
static void win_apply(int idx)
{
    const win_rect_t *w = &WIN_STEPS[idx];
    win_c0 = w->c0; win_c1 = w->c1; win_r0 = w->r0; win_r1 = w->r1;
    win_rb = (w->c1 - w->c0 + 1) / 4;
    win_rows = w->r1 - w->r0 + 1;
    win_cb0 = w->c0 / 4;
}

typedef struct {
    int      frames;
    int64_t  fetch_ms, write_ms, drf_ms, tick_ms;
    int64_t  bytes;
} play_stat_t;

static void stat_show(const play_stat_t *st, const frame_meta_t *m,
                      int64_t write, int64_t drf, bool detail)
{
    if (detail) {
        printf("帧 %-4d id=%-4u 行=%-3d %5dB 取=%4lld 写=%4lld 刷=%4lld 拍=%4lld\n",
               st->frames, (unsigned)m->fid, m->rows, m->bytes,
               (long long)m->fetch_ms, (long long)write, (long long)drf,
               (long long)st->tick_ms);
    } else {
        int n = st->frames > 0 ? st->frames : 1;
        int full = win_rows * (2 + win_rb) + MV_HDR_LEN + 2;
        printf("[统计] %d 帧：均 %lld B（全帧 %d B，省 %lld%%）｜取 %lld 写 %lld 刷 %lld 拍 %lld ms/帧｜有效 %lld fps｜last id=%u 行=%d\n",
               st->frames,
               (long long)(st->bytes / n), full,
               (long long)(100 - (st->bytes / n) * 100 / full),
               (long long)(st->fetch_ms / n), (long long)(st->write_ms / n),
               (long long)(st->drf_ms / n), (long long)(st->tick_ms / n),
               (long long)(st->tick_ms > 0 ? 1000 / (st->tick_ms / n) : 0),
               (unsigned)m->fid, m->rows);
    }
}

static void play_stream(void)
{
    win_apply(s_win_idx);                  /* 防御：窗口派生量与本档一致 */

    if (!s_wifi_inited) {
        printf("\n[播放] 未配网——菜单发送 w 先配网\n");
        return;
    }
    printf("\n══════ 视频拉流播放（窗口 %dx%d @(%d,%d)，X镜像 %d）═════\n",
           win_c1 - win_c0 + 1, win_r1 - win_r0 + 1, win_c0, win_r0, s_xmirror);
    if (!wifi_wait_ip(20)) {
        printf("[播放] 20 秒内未拿到 IP（路由器离线/信号差）——回菜单\n");
        return;
    }

    /* 服务器地址：vurl 手动优先，否则 UDP 自动发现 */
    if (s_srv_url[0]) {
        char ip[16];
        int port = 0;
        if (sscanf(s_srv_url, "%15[^:]:%d", ip, &port) == 2 && port > 0) {
            strlcpy(s_srv_ip, ip, sizeof(s_srv_ip));
            s_srv_port = port;
        }
        printf("[播放] 使用手动服务器 %s:%d\n", s_srv_ip, s_srv_port);
    } else if (!udp_discover(10000)) {
        printf("[播放] 未发现 PC 广播——请确认 moink_video_pc 已开始服务且与设备同网段；\n"
               "       或菜单 u 手动输入 ip:port\n");
        return;
    }

    if (net_setup() != 0) return;

    /* 工厂白屏清底（剂量基准） */
    printf("[播放] 工厂全刷白屏清底（约 15 秒）...\n");
    memset(g_canvas, 0x55, (size_t)VD_ROWS * VD_RB);   /* 工厂白码 */
    {
        int64_t t;
        if (vd_factory_frame(canvas_fill_row, &t) != 0) {
            printf("[播放] 工厂清屏失败\n");
            net_teardown();
            return;
        }
        printf("[播放] 白屏完成，DRF %lld ms\n\n", (long long)t);
    }
    /* 注意：工厂清底会复位控制器，网络连接不受影响，但 LUT/PSR 要重布 */

    /* 寄存器 LUT 探针 → 数字局刷表（黑/白动作各 3 扫描） */
    probe_result_t pr = probe_register_lut(g_canvas);
    if (!pr.ok) {
        printf("[播放] 寄存器 LUT 未接受——快刷播放不可用（回退判定见探针日志）\n");
        net_teardown();
        return;
    }
    if (vd_full_reinit() != 0) { net_teardown(); return; }
    vd_custom_overlay(0x00, 0x50);
    lut_build_num(g_lut);
    lut_build_num_clean(g_lut_clean);      /* R3：周期清理表（六扫描） */
    vd_lut_write(g_lut);
    vd_set_psr_register(pr.psr2);
    memset(g_canvas, 0x00, (size_t)VD_ROWS * VD_RB);   /* 全帧保持 */
    memset(g_touched, 0, sizeof(g_touched));
    vd_write_full(canvas_fill_row);
    printf("[播放] 快刷表就绪（01=黑动作 / 10=白动作 / 00=保持），周期清理 %s。\n\n",
           clean_name());

    /* ★ R3 帧中转缓冲（staging）：fetch 整帧收进它，play 应用后放行 fetch
     * ——「写+刷」全程与网络接收重叠。分配失败自动回落 R2 乒乓模式。 */
    g_stage_cap = MV_HDR_LEN + win_rows * (2 + win_rb) + 2;
    g_stage = heap_caps_malloc((size_t)g_stage_cap, MALLOC_CAP_8BIT);
    s_stage_mode = (g_stage != NULL);
    printf("[播放] 帧中转 %s（%d B）\n\n",
           s_stage_mode ? "已启用：fetch 与写+刷全程重叠"
                        : "分配失败：回落 R2 乒乓（取仅与刷重叠），建议降窗口档",
           g_stage_cap);

    play_stat_t st = { 0, 0, 0, 0, 0, 0 };
    int err_net = 0, err_proto = 0, reconnects = 0;
    int clean_cnt = 0, cleans = 0;
    int64_t clean_ms_sum = 0;
    int64_t frame_t0 = now_ms();
    bool stop = false;

    xSemaphoreGive(s_rx_sem);              /* 允许 fetch 预取第一帧 */

    while (!stop) {
        /* 播放中按 s 停止 */
        int key = uart_getkey(0);
        if (key == 's' || key == 'S') {
            printf("\n[播放] 收到停止键\n");
            break;
        }

        if (xSemaphoreTake(s_frame_sem, pdMS_TO_TICKS(30000)) != pdTRUE) {
            printf("[播放] 30 秒无帧（fetch 卡死/网络黑洞）——重连\n");
            err_net++;
        } else if (s_meta.err == -1) {
            err_net++;
            printf("[播放] 网络错（连续 %d 次）\n", err_net);
        } else if (s_meta.err == -2) {
            err_proto++;
            printf("[播放] 协议/CRC 错（连续 %d 次，会话已 reset）\n", err_proto);
            if (err_proto >= 3) {
                printf("[播放] 协议错误持续——重连\n");
                err_net = 1;               /* 走重连路径 */
            } else {
                xSemaphoreGive(s_rx_sem);  /* 会话已复位，直接续播 */
                continue;
            }
        } else {
            err_net = 0;
            err_proto = 0;

            if (s_meta.rows == 0) {
                /* 无变化帧（静帧）：不写不刷，直接取下一帧 */
                st.frames++;
                st.tick_ms += now_ms() - frame_t0;
                frame_t0 = now_ms();
                xSemaphoreGive(s_rx_sem);
                continue;
            }

            /* ★ R3 staging：先把中转帧应用进画布（fetch 静默，亚毫秒级），
             * 立即放行 fetch 预取下一帧——此后「写+刷」全程与网络重叠。
             * 回落模式跳过（fetch 收帧时已直写画布）。 */
            int64_t t_apply = 0;
            if (s_stage_mode) {
                int64_t t_ap0 = now_ms();
                int reclen = 2 + win_rb;
                const uint8_t *p = g_stage + MV_HDR_LEN;
                for (int i = 0; i < s_meta.rows; i++) {
                    int rel = p[0] | (p[1] << 8);
                    memcpy(g_canvas + (size_t)(win_r0 + rel) * VD_RB + win_cb0,
                           p + 2, win_rb);
                    g_touched[win_r0 + rel] = 1;
                    p += reclen;
                }
                t_apply = now_ms() - t_ap0;
                xSemaphoreGive(s_rx_sem);
            }

            /* 分段写：touched 扫描窗口行区间的连续段（staging 已放行 fetch，
             * 与本段 SPI 写并行；回落模式 fetch 仍静默） */
            int64_t t_write0 = now_ms();
            int j = win_r0;
            while (j <= win_r1) {
                if (!g_touched[j]) { j++; continue; }
                int k = j;
                while (k + 1 <= win_r1 && g_touched[k + 1]) k++;
                if (vd_write_win_rows(s_xmirror, win_c0, win_c1, j, k, win_fill_row) != 0) {
                    printf("[播放] 行写失败（SPI）——回菜单\n");
                    stop = true;
                    break;
                }
                j = k + 1;
            }
            int64_t t_write = now_ms() - t_write0 + t_apply;   /* 写 = 应用 + SPI */
            memset(g_touched, 0, sizeof(g_touched));
            if (stop) break;

            if (!s_stage_mode) {
                /* 回落：写完再放行 fetch（R2 语义，取仅与刷重叠） */
                xSemaphoreGive(s_rx_sem);
            }
            vd_window_full();
            vd_drf_result_t r = vd_drf_video(30000u, false);
            if (r.timeout) {
                printf("[播放] DRF 超时——回菜单\n");
                break;
            }

            st.frames++;
            st.bytes += s_meta.bytes;
            st.fetch_ms += s_meta.fetch_ms;
            st.write_ms += t_write;
            st.drf_ms += r.elapsed_ms;
            st.tick_ms += now_ms() - frame_t0;
            frame_t0 = now_ms();

            if (st.frames <= 10) {
                stat_show(&st, &s_meta, t_write, r.elapsed_ms, true);
            } else if (st.frames % 60 == 0) {
                stat_show(&st, &s_meta, t_write, r.elapsed_ms, false);
            }

            /* ★ R3 周期清理帧：同一画布不动 RAM，换六扫描清理表多刷一次
             * 再换回——白端获得 P3 预脉冲 + Mode1 N3 拉白（ref §5 实测
             * 白端黄度 R−B 18.2→0），代价 ≈ 50ms DRF + 2×2ms 换表。 */
            if (clean_period() > 0 && ++clean_cnt >= clean_period()) {
                clean_cnt = 0;
                vd_lut_write(g_lut_clean);
                vd_window_full();
                vd_drf_result_t rc = vd_drf_video(30000u, false);
                vd_lut_write(g_lut);
                if (rc.timeout) {
                    printf("[清理] DRF 超时——回菜单\n");
                    stop = true;
                    break;
                }
                cleans++;
                clean_ms_sum += rc.elapsed_ms;
                printf("[清理] #%d（六扫描 DRF %lld ms）\n",
                       cleans, (long long)rc.elapsed_ms);
            }
            continue;
        }

        /* 走到这里 = 需要重连（网络错/无帧/协议错持续） */
        if (err_net >= 10) {
            printf("[播放] 连续失败过多——放弃，回菜单\n");
            break;
        }
        if (err_net > 0) {
            reconnects++;
            vTaskDelay(pdMS_TO_TICKS(500));
            if (net_setup() == 0) {
                err_net = 0;
                xSemaphoreGive(s_rx_sem);
                frame_t0 = now_ms();
            } else if (reconnects >= 5) {
                printf("[播放] 重连 %d 次均失败——放弃，回菜单\n", reconnects);
                break;
            }
        }
    }

    printf("\n[播放] 结束汇总：%d 帧，平均 %lld B/帧，取 %lld / 写 %lld / 刷 %lld / 拍 %lld ms/帧，有效 %lld fps\n",
           st.frames,
           st.frames ? (long long)(st.bytes / st.frames) : 0,
           st.frames ? (long long)(st.fetch_ms / st.frames) : 0,
           st.frames ? (long long)(st.write_ms / st.frames) : 0,
           st.frames ? (long long)(st.drf_ms / st.frames) : 0,
           st.frames ? (long long)(st.tick_ms / st.frames) : 0,
           (st.frames && st.tick_ms) ? (long long)(1000 / (st.tick_ms / st.frames)) : 0);
    printf("[播放] 观察：闪烁感 / 残影（泛黄）随帧数累积 / 黑白对比衰减——把结论连同串口日志反馈。\n");
    if (cleans > 0) {
        printf("[播放] 残影清理帧本次共 %d 次，DRF 均 %lld ms（菜单 c 可调周期/关闭）。\n",
               cleans, (long long)(clean_ms_sum / cleans));
    }
    net_teardown();
    vd_power_off();
    if (g_stage) {
        heap_caps_free(g_stage);            /* 回菜单后释放（画布留给灰度带/探针） */
        g_stage = NULL;
        g_stage_cap = 0;
        s_stage_mode = false;
    }
}

/* ================= 菜单与输入 ================= */

static void print_banner(void)
{
    printf("\n");
    printf("╔══════════════════════════════════════════════════════════════╗\n");
    printf("║  墨印 MoInk · 视频快刷测试固件                                  ║\n");
    printf("╠═ VIDEO-R3：双钟 SPI / 帧中转全重叠 / 周期清理帧 ═╣\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    printf("版本：%s\n", VIDEO_FW_VER);
    printf("配套：tools/moink_video_pc（Windows，先启动并开始服务；需 MV2 版）\n");
}

static void print_config(void)
{
    win_apply(s_win_idx);
    printf("\n[配置] 画像 %s，方向 orient = %d，SPI = 数据 %lu MHz + 命令/寄存器 %lu MHz（档 %d/3）\n",
           vd_panel_name(), s_orient,
           (unsigned long)(vd_spi_hz() / 1000000u),
           (unsigned long)(vd_spi_cmd_hz() / 1000000u), s_spi_sel);
    printf("[配置] 播放窗口 = %s（行字节 %d，全帧 %d B）\n",
           win_name(s_win_idx), win_rb, win_rows * (2 + win_rb) + 8);
    printf("[配置] 窗口 X 镜像编码 = %d（窗口内容左右错位时菜单 m 切换）\n", s_xmirror);
    printf("[配置] 周期残影清理帧 = %s（菜单 c 调整；六扫描表，约 50ms/次）\n",
           clean_name());
    printf("[配置] 引脚来源 = %s\n", s_pin_src);
    printf("[配置] 生效引脚 SCK=%d MOSI=%d CS=%d DC=%d RST=%d BUSY=%d\n",
           s_pins.sck, s_pins.mosi, s_pins.cs, s_pins.dc, s_pins.rst, s_pins.busy);
    printf("[配置] WiFi STA：%s\n", s_sta_ssid[0] ? s_sta_ssid : "未配网（菜单 w）");
    printf("[配置] 服务器：%s\n",
           s_srv_url[0] ? s_srv_url : "自动发现（UDP 广播；菜单 u 手动指定）");
}

static void menu_wifi_creds(void)
{
    char ssid[SSID_MAX] = "";
    char pass[PASS_MAX] = "";

    printf("[配网] 输入 WiFi 名称（SSID）后回车：\n");
    fflush(stdout);
    if (!uart_readline(ssid, sizeof(ssid), 60000) || !ssid[0]) {
        printf("\n[配网] 未输入，取消\n");
        return;
    }
    printf("\n[配网] 输入 WiFi 密码后回车（开放网络直接回车）：\n");
    fflush(stdout);
    (void)uart_readline(pass, sizeof(pass), 60000);
    printf("\n[配网] 保存中...\n");

    cfg_put_str("sta_ssid", ssid);
    cfg_put_str("sta_pass", pass);
    nvs_commit_safe();
    printf("[配网] 已写入 NVS（键 sta_ssid/sta_pass，与主固件同池）。\n");
    printf("       新凭据将在重新上电后生效（本会话沿用旧连接）；或现在按 EN 复位。\n");
}

static void menu_srv_url(void)
{
    char url[URL_MAX] = "";

    printf("[服务器] 输入 ip:port（如 192.168.1.100:8094），直接回车=清除改回自动发现：\n");
    fflush(stdout);
    if (!uart_readline(url, sizeof(url), 30000)) {
        printf("\n[服务器] 未输入，取消\n");
        return;
    }
    url[URL_MAX - 1] = '\0';
    cfg_put_str("vurl", url);
    nvs_commit_safe();
    strlcpy(s_srv_url, url, sizeof(s_srv_url));
    printf("\n[服务器] 已保存：%s\n", url[0] ? url : "（空）→ 自动发现");
}

static void menu_and_run(void)
{
    for (;;) {
        printf("\n[菜单] 3 秒内可发送：\n");
        printf("       回车/g = 视频拉流播放（默认，超时自动开始）\n");
        printf("       b = 增强灰度色带（黑 12 档 + 黄 14 档对照）\n");
        printf("       w = WiFi 配网；u = 服务器地址 ip:port\n");
        printf("       p = 画像 A0↔A1；o = 方向 orient 0..3\n");
        printf("       v = 播放窗口档（%s）；m = 窗口 X 镜像编码\n", win_name(s_win_idx));
        printf("       s = SPI 档 4/8/16/24 MHz（当前数据 %lu/命令 %lu M，即时生效）\n",
               (unsigned long)(vd_spi_hz() / 1000000u),
               (unsigned long)(vd_spi_cmd_hz() / 1000000u));
        printf("       c = 周期残影清理帧 %s\n", clean_name());
        fflush(stdout);

        int key = uart_getkey(3000);
        switch (key) {
        case 'b': case 'B':
            gray_bands_run(g_canvas);
            continue;
        case 'w': case 'W':
            menu_wifi_creds();
            continue;
        case 'u': case 'U':
            menu_srv_url();
            continue;
        case 'p': case 'P':
            s_panel_sel = (s_panel_sel == VD_PANEL_A0) ? VD_PANEL_A1 : VD_PANEL_A0;
            cfg_put_u8("panel", (uint8_t)s_panel_sel);
            nvs_commit_safe();
            printf("[菜单] 画像 → %s\n", vd_panel_name());
            continue;
        case 'o': case 'O':
            s_orient = (s_orient + 1) & 3;
            cfg_put_u8("orient", (uint8_t)s_orient);
            nvs_commit_safe();
            printf("[菜单] orient → %d\n", s_orient);
            continue;
        case 'v': case 'V':
            s_win_idx = (s_win_idx + 1) % 5;
            cfg_put_u8("vwin", (uint8_t)s_win_idx);
            nvs_commit_safe();
            win_apply(s_win_idx);
            printf("[菜单] 播放窗口 → %s\n", win_name(s_win_idx));
            continue;
        case 'm': case 'M':
            s_xmirror ^= 1;
            cfg_put_u8("vxm", (uint8_t)s_xmirror);
            nvs_commit_safe();
            printf("[菜单] 窗口 X 镜像编码 → %d\n", s_xmirror);
            continue;
        case 's': case 'S':
            s_spi_sel = (s_spi_sel + 1) % 4;
            cfg_put_u8("vspi", (uint8_t)s_spi_sel);
            nvs_commit_safe();
            vd_set_spi_hz(SPI_STEPS[s_spi_sel]);
            if (vd_apply_spi_hz() == 0) {
                printf("[菜单] SPI 档 → 数据 %lu MHz / 命令寄存器 %lu MHz（已即时生效，免重启）\n",
                       (unsigned long)(vd_spi_hz() / 1000000u),
                       (unsigned long)(vd_spi_cmd_hz() / 1000000u));
            } else {
                printf("[菜单] SPI 档 → %lu MHz，但重配失败——请 EN 复位后生效\n",
                       (unsigned long)(SPI_STEPS[s_spi_sel] / 1000000u));
            }
            continue;
        case 'c': case 'C':
            s_clean_step_idx = (s_clean_step_idx + 1) % 5;
            cfg_put_u8("vclean", (uint8_t)s_clean_step_idx);
            nvs_commit_safe();
            printf("[菜单] 周期残影清理帧 → %s\n", clean_name());
            continue;
        default:
            /* 回车 / g / 超时 → 播放 */
            play_stream();
            continue;
        }
    }
}

/* ================= app_main ================= */

void app_main(void)
{
    esp_err_t err;

    print_banner();

    if (!lut_self_check()) {
        printf("[自检] ★ R20 波形编码器自检失败——固件有 bug，停止\n");
        return;
    }
    printf("[自检] R20 波形编码器自检通过\n");

    invalidate_otadata();

    err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        (void)nvs_flash_erase();
        err = nvs_flash_init();
    }
    if (err != ESP_OK) {
        printf("[NVS] 初始化失败：%s——配置继承不可用，默认值运行\n", esp_err_to_name(err));
    } else if (nvs_open(NVS_NS, NVS_READWRITE, &s_nvs) == ESP_OK) {
        s_nvs_ok = true;
    }
    printf("[NVS] %s\n", s_nvs_ok ? "已打开命名空间 moink（与主固件同池）"
                                  : "不可用（默认配置运行）");

    g_canvas = heap_caps_malloc((size_t)VD_ROWS * VD_RB, MALLOC_CAP_8BIT);
    if (!g_canvas) {
        printf("[错误] 画布分配失败（%d B）\n", VD_ROWS * VD_RB);
        return;
    }

    s_rx_sem = xSemaphoreCreateBinary();
    s_frame_sem = xSemaphoreCreateBinary();
    if (!s_rx_sem || !s_frame_sem) {
        printf("[错误] 流水线信号量创建失败\n");
        return;
    }

    if (uart_driver_install(UART_NUM_0, 512, 0, 0, NULL, 0) != ESP_OK) {
        printf("[警告] UART0 RX 驱动安装失败——菜单不可用\n");
    }

    load_config();
    print_config();

    /* 驱动（SPI 档位先于 init 设置；默认 16M = ref 快刷配置档） */
    vd_set_spi_hz(SPI_STEPS[s_spi_sel]);
    if (vd_init(&s_pins, s_panel_sel) != 0) {
        printf("[错误] 屏驱动初始化失败（SPI/引脚）——请核对引脚配置\n");
        return;
    }

    /* WiFi 在菜单期间就开始连接（凭据已继承/已配） */
    wifi_start_sta();

    menu_and_run();
}
