#ifndef MOINK_GRAY_BANDS_H
#define MOINK_GRAY_BANDS_H

/*
 * 墨印视频测试固件 —— 增强灰度色带（VERIFY-R1.1 实测反馈的调参版）。
 *
 * 实测反馈：黑→白剂量带有阶梯但不理想（档位粗、中间调缺）；黄→白
 * 剂量带 3..24 扫描全部未显色。本模块把档位加密到 12 档（黑）并给黄
 * 两亚组对照配方（负场加倍剂量 + 弱正场假说验证），全部打印到串口。
 */
#include <stdint.h>

/* 调用前置条件：vd_init 已成功；canvas 为 VD_ROWS*VD_RB 画布缓冲。
 * 返回 0 = 全程完成；非 0 = 中途失败（串口已打印原因）。 */
int gray_bands_run(uint8_t *canvas);

#endif /* MOINK_GRAY_BANDS_H */
