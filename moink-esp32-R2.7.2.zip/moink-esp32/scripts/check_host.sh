#!/bin/sh
# 沙盒宿主闸门（R2.4.1 思路复刻，R2.6.0 重建）：
#   1) 全部 main/*.c 用宿主 gcc -c -O2 -Wall -Wextra -Werror 编译（IDF 桩头）；
#   2) 纯 C 模块（pwr_sched / zone_core / lut_r20）主机单测全部跑过。
# 真机构建（idf.py build）仍是最终验证 —— 本闸门只拦「编译期」错误。
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(dirname "$HERE")
CC=${CC:-gcc}
CFLAGS="-c -O2 -Wall -Wextra -Werror -Wno-error=unused-parameter -I$HERE/idf_stubs -I$ROOT/main"

echo "== [1/3] 桩头在位检查 =="
if [ ! -f "$HERE/idf_stubs/esp_err.h" ]; then
    python3 "$HERE/make_idf_stubs.py"
fi

echo "== [2/3] 全量源 -c 编译（$CC） =="
mkdir -p "$HERE/build_host"
rc=0
for src in "$ROOT"/main/*.c; do
    out="$HERE/build_host/$(basename "$src" .c).o"
    if ! $CC $CFLAGS "$src" -o "$out" 2> "$HERE/build_host/$(basename "$src" .c).err"; then
        echo "FAIL: $src"
        cat "$HERE/build_host/$(basename "$src" .c).err"
        rc=1
    else
        if [ -s "$HERE/build_host/$(basename "$src" .c).err" ]; then
            echo "warn: $src"
            cat "$HERE/build_host/$(basename "$src" .c).err"
        fi
    fi
done
[ $rc -eq 0 ] && echo "all main/*.c compiled clean"

echo "== [3/3] 纯 C 单测 =="
for t in test_pwr_sched_v270 test_shift_geom test_lut_ghost; do
    $CC -O2 -Wall -Wextra -Werror -I"$HERE/idf_stubs" -I"$ROOT/main" \
        "$HERE/$t.c" "$ROOT/main/pwr_sched.c" "$ROOT/main/zone_core.c" \
        "$ROOT/main/lut_r20.c" -lm -o "$HERE/build_host/$t" 2> "$HERE/build_host/$t.err" \
        || { echo "FAIL(build): $t"; cat "$HERE/build_host/$t.err"; rc=1; continue; }
    if "$HERE/build_host/$t"; then
        echo "PASS: $t"
    else
        echo "FAIL(run): $t"
        rc=1
    fi
done

exit $rc
