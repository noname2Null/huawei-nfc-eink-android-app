#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 scripts/idf_stubs/ 下的最小 IDF 桩头（沙盒 gcc 闸门用，R2.4.1 同思路）。

桩头只保证「全部 main/*.c 能用宿主 gcc -c -O2 -Wall -Wextra -Werror 编过」：
  - 类型 / 枚举 / 原型按各源文件的实际调用面最小化；
  - 不提供实现（-c 只编译不链接）；
  - ESP_LOGx 带 printf 格式属性（格式串错配在沙盒就能抓住）。

改了固件源码后跑 scripts/check_host.sh 全量回归。删掉 idf_stubs 目录后
重跑本脚本可完整重建。
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "idf_stubs")

FILES = {}

FILES["esp_err.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int esp_err_t;
#define ESP_OK          0
#define ESP_FAIL        -1
#define ESP_ERR_NO_MEM          0x101
#define ESP_ERR_INVALID_STATE   0x103
#define ESP_ERR_INVALID_ARG     0x102
#define ESP_ERR_INVALID_SIZE    0x104
#define ESP_ERR_NOT_FOUND       0x105
#define ESP_ERR_NOT_SUPPORTED   0x106
#define ESP_ERR_TIMEOUT         0x107
#define ESP_ERR_INVALID_RESPONSE 0x108
#define ESP_ERR_INVALID_CRC     0x109
#define ESP_ERR_NVS_NO_FREE_PAGES 0x1102
#define ESP_ERR_NVS_NEW_VERSION_FOUND 0x1103
#define ESP_ERR_NVS_NOT_FOUND   0x1104
#define ESP_ERR_NVS_INVALID_NAME 0x1105
const char *esp_err_to_name(esp_err_t code);
#define ESP_ERROR_CHECK(x) do { (void)(x); } while (0)
"""

FILES["esp_log.h"] = r"""
#pragma once
#include <stdio.h>
void esp_log_stub(const char *tag, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
#define ESP_LOGE(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGW(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGI(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGD(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGV(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
"""

FILES["esp_attr.h"] = r"""
#pragma once
#define RTC_NOINIT_ATTR
#define IRAM_ATTR
"""

FILES["esp_timer.h"] = r"""
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
typedef struct esp_timer *esp_timer_handle_t;
typedef void (*esp_timer_cb_t)(void *arg);
typedef enum { ESP_TIMER_TASK, ESP_TIMER_ISR } esp_timer_dispatch_t;
typedef struct {
    esp_timer_cb_t callback;
    void *arg;
    esp_timer_dispatch_t dispatch_method;
    const char *name;
    bool skip_unhandled_events;
} esp_timer_create_args_t;
int64_t esp_timer_get_time(void);
esp_err_t esp_timer_create(const esp_timer_create_args_t *args, esp_timer_handle_t *out);
esp_err_t esp_timer_start_once(esp_timer_handle_t t, uint64_t us);
esp_err_t esp_timer_start_periodic(esp_timer_handle_t t, uint64_t us);
esp_err_t esp_timer_stop(esp_timer_handle_t t);
"""

FILES["freertos/FreeRTOS.h"] = r"""
#pragma once
#include <stdint.h>
typedef uint32_t TickType_t;
typedef int BaseType_t;
typedef unsigned UBaseType_t;
#define pdTRUE  1
#define pdFALSE 0
#define pdPASS  1
#define pdFAIL  0
#define portMAX_DELAY ((TickType_t)0xffffffffU)
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))
#define portTICK_PERIOD_MS 1
#define tskIDLE_PRIORITY 0
"""

FILES["freertos/task.h"] = r"""
#pragma once
#include "freertos/FreeRTOS.h"
typedef void *TaskHandle_t;
void vTaskDelay(TickType_t ticks);
void vTaskDelete(TaskHandle_t t);
BaseType_t xTaskCreate(void (*fn)(void *), const char *name, uint32_t stack,
                       void *arg, UBaseType_t prio, TaskHandle_t *out);
TickType_t xTaskGetTickCount(void);
"""

FILES["freertos/queue.h"] = r"""
#pragma once
#include "freertos/FreeRTOS.h"
typedef void *QueueHandle_t;
QueueHandle_t xQueueCreate(UBaseType_t len, UBaseType_t sz);
BaseType_t xQueueSend(QueueHandle_t q, const void *item, TickType_t wait);
BaseType_t xQueueReceive(QueueHandle_t q, void *out, TickType_t wait);
"""

FILES["freertos/semphr.h"] = r"""
#pragma once
#include "freertos/FreeRTOS.h"
typedef void *SemaphoreHandle_t;
SemaphoreHandle_t xSemaphoreCreateMutex(void);
SemaphoreHandle_t xSemaphoreCreateBinary(void);
SemaphoreHandle_t xSemaphoreCreateCounting(UBaseType_t max, UBaseType_t init);
BaseType_t xSemaphoreTake(SemaphoreHandle_t s, TickType_t wait);
BaseType_t xSemaphoreGive(SemaphoreHandle_t s);
"""

FILES["driver/gpio.h"] = r"""
#pragma once
#include <stdint.h>
#include "esp_err.h"
typedef int gpio_num_t;
typedef enum { GPIO_MODE_DISABLE = 0, GPIO_MODE_INPUT, GPIO_MODE_OUTPUT,
               GPIO_MODE_OUTPUT_OD, GPIO_MODE_INPUT_OUTPUT } gpio_mode_t;
typedef enum { GPIO_PULLUP_DISABLE = 0, GPIO_PULLUP_ENABLE } gpio_pullup_t;
typedef enum { GPIO_PULLDOWN_DISABLE = 0, GPIO_PULLDOWN_ENABLE } gpio_pulldown_t;
typedef enum { GPIO_INTR_DISABLE = 0, GPIO_INTR_POSEDGE, GPIO_INTR_NEGEDGE,
               GPIO_INTR_ANYEDGE, GPIO_INTR_LOW_LEVEL, GPIO_INTR_HIGH_LEVEL } gpio_int_type_t;
typedef struct {
    uint64_t pin_bit_mask;
    gpio_mode_t mode;
    gpio_pullup_t pull_up_en;
    gpio_pulldown_t pull_down_en;
    gpio_int_type_t intr_type;
} gpio_config_t;
esp_err_t gpio_config(const gpio_config_t *cfg);
esp_err_t gpio_set_level(gpio_num_t gpio, uint32_t level);
int gpio_get_level(gpio_num_t gpio);
esp_err_t gpio_set_direction(gpio_num_t gpio, gpio_mode_t mode);
esp_err_t gpio_pullup_en(gpio_num_t gpio);
esp_err_t gpio_pulldown_dis(gpio_num_t gpio);
"""

FILES["driver/spi_master.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
typedef int spi_host_device_t;
#define SPI2_HOST 1
#define SPI_DMA_CH_AUTO 3
typedef struct {
    int mosi_io_num, miso_io_num, sclk_io_num, quadwp_io_num, quadhd_io_num;
    int max_transfer_sz;
    uint32_t flags;
    int intr_flags;
} spi_bus_config_t;
typedef struct {
    uint8_t command_bits, address_bits, dummy_bits;
    uint8_t mode;
    uint16_t duty_cycle_pos;
    uint16_t cs_ena_pretrans, cs_ena_posttrans;
    int clock_speed_hz;
    int input_delay_ns;
    int spics_io_num;
    uint32_t flags;
    int queue_size;
} spi_device_interface_config_t;
typedef struct spi_device_t *spi_device_handle_t;
typedef struct {
    size_t length;
    size_t rxlength;
    const void *tx_buffer;
    void *rx_buffer;
    void *user;
    uint32_t flags;
    uint64_t cmd;
    uint64_t addr;
} spi_transaction_t;
esp_err_t spi_bus_initialize(spi_host_device_t host, const spi_bus_config_t *bus, int dma);
esp_err_t spi_bus_add_device(spi_host_device_t host, const spi_device_interface_config_t *dev,
                             spi_device_handle_t *out);
esp_err_t spi_device_polling_transmit(spi_device_handle_t h, spi_transaction_t *t);
"""

FILES["esp_adc/adc_oneshot.h"] = r"""
#pragma once
#include "esp_err.h"
typedef int adc_unit_t;
typedef int adc_channel_t;
typedef int adc_atten_t;
typedef int adc_bitwidth_t;
#define ADC_UNIT_1 0
#define ADC_CHANNEL_0 0
#define ADC_CHANNEL_3 3
#define ADC_CHANNEL_4 4
#define ADC_CHANNEL_5 5
#define ADC_CHANNEL_6 6
#define ADC_CHANNEL_7 7
#define ADC_ATTEN_DB_12 3
#define ADC_BITWIDTH_12 3
typedef enum { ADC_ULP_MODE_DISABLE = 0 } adc_ulp_mode_t;
typedef struct { adc_unit_t unit_id; adc_ulp_mode_t ulp_mode; } adc_oneshot_unit_init_cfg_t;
typedef struct { adc_atten_t atten; adc_bitwidth_t bitwidth; } adc_oneshot_chan_cfg_t;
typedef struct adc_oneshot_unit_t *adc_oneshot_unit_handle_t;
esp_err_t adc_oneshot_new_unit(const adc_oneshot_unit_init_cfg_t *u,
                               adc_oneshot_unit_handle_t *out);
esp_err_t adc_oneshot_config_channel(adc_oneshot_unit_handle_t h, adc_channel_t ch,
                                     const adc_oneshot_chan_cfg_t *cfg);
esp_err_t adc_oneshot_read(adc_oneshot_unit_handle_t h, adc_channel_t ch, int *raw);
"""

FILES["esp_sleep.h"] = r"""
#pragma once
#include <stdint.h>
#include "esp_err.h"
typedef enum {
    ESP_SLEEP_WAKEUP_UNDEFINED = 0,
    ESP_SLEEP_WAKEUP_ALL = 1,
    ESP_SLEEP_WAKEUP_EXT0 = 2,
    ESP_SLEEP_WAKEUP_EXT1 = 3,
    ESP_SLEEP_WAKEUP_TIMER = 4,
    ESP_SLEEP_WAKEUP_TOUCHPAD = 5,
    ESP_SLEEP_WAKEUP_ULP = 6,
    ESP_SLEEP_WAKEUP_GPIO = 7,
    ESP_SLEEP_WAKEUP_UART = 8,
    ESP_SLEEP_WAKEUP_WIFI = 9,
    ESP_SLEEP_WAKEUP_BT = 10,
    ESP_SLEEP_WAKEUP_COCPU = 11,
    ESP_SLEEP_WAKEUP_COCPU_TRAP_TRIG = 12,
    ESP_SLEEP_WAKEUP_BT_HCI = 13,
} esp_sleep_source_t;
uint64_t esp_sleep_get_wakeup_causes(void);
esp_err_t esp_sleep_enable_ext0_wakeup(int gpio, int level);
esp_err_t esp_sleep_enable_timer_wakeup(uint64_t us);
esp_err_t esp_sleep_disable_wakeup_source(esp_sleep_source_t src);
void esp_deep_sleep_start(void) __attribute__((noreturn));
"""

FILES["esp_system.h"] = r"""
#pragma once
#include <stdint.h>
void esp_restart(void) __attribute__((noreturn));
int esp_reset_reason(void);
uint32_t esp_get_free_heap_size(void);
uint32_t esp_get_minimum_free_heap_size(void);
"""

FILES["esp_random.h"] = r"""
#pragma once
#include <stddef.h>
void esp_fill_random(void *buf, size_t len);
"""

FILES["esp_mac.h"] = r"""
#pragma once
#include <stdint.h>
#include "esp_err.h"
typedef int esp_mac_type_t;
#define ESP_MAC_WIFI_STA 0
#define MACSTR "%02x%02x%02x%02x%02x%02x"
#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
esp_err_t esp_read_mac(uint8_t *mac, esp_mac_type_t type);
"""

FILES["esp_wifi.h"] = r"""
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
typedef enum { WIFI_MODE_NULL = 0, WIFI_MODE_STA, WIFI_MODE_AP, WIFI_MODE_APSTA } wifi_mode_t;
typedef enum { WIFI_PS_MIN_MODEM = 1, WIFI_PS_MAX_MODEM, WIFI_PS_INVALID } wifi_ps_type_t;
typedef int wifi_interface_t;
#define WIFI_IF_STA 0
#define WIFI_IF_AP  1
/* 事件 id（esp_wifi_types / lwip ip 事件在真机由各自主头提供，桩合并到此） */
#define WIFI_EVENT_STA_START 0
#define WIFI_EVENT_STA_CONNECTED 1
#define WIFI_EVENT_STA_DISCONNECTED 2
#define WIFI_EVENT_AP_START 3
#define WIFI_EVENT_AP_STACONNECTED 4
#define WIFI_EVENT_AP_STADISCONNECTED 5
/* ★R2.7.2：驱动停机跟踪事件（wifi_mgr.c）—— 桩 id 仅需互异 */
#define WIFI_EVENT_STA_STOP 6
#define WIFI_EVENT_AP_STOP 7
typedef struct { uint8_t mac[6]; int aid; } wifi_event_ap_staconnected_t;
typedef struct { uint8_t mac[6]; int aid; bool reason_is_local; } wifi_event_ap_stadisconnected_t;
typedef struct {
    uint8_t ssid[33];
    uint8_t password[65];
    bool bssid_set;
    uint8_t bssid[6];
    struct { bool capable; bool required; } pmf_cfg;
} wifi_sta_config_t;
typedef struct {
    uint8_t ssid[33];
    uint8_t password[65];
    uint8_t max_connection;
    bool ssid_hidden;
    uint8_t ssid_len;
    uint8_t channel;
    int authmode;
} wifi_ap_config_t;
typedef enum { WIFI_AUTH_OPEN = 0, WIFI_AUTH_WPA2_PSK = 3 } wifi_auth_mode_t;
typedef struct { wifi_sta_config_t sta; wifi_ap_config_t ap; } wifi_config_t;
typedef struct { int dummy; } wifi_init_config_t;
#define WIFI_INIT_CONFIG_DEFAULT() ((wifi_init_config_t){ 0 })
typedef struct {
    uint8_t ssid[33];
    int8_t rssi;
    uint8_t bssid[6];
} wifi_ap_record_t;
esp_err_t esp_wifi_init(const wifi_init_config_t *cfg);
esp_err_t esp_wifi_set_mode(wifi_mode_t mode);
esp_err_t esp_wifi_get_mode(wifi_mode_t *mode);   /* ★R2.7.2：驱动停机恢复分支用 */
esp_err_t esp_wifi_start(void);
esp_err_t esp_wifi_stop(void);
esp_err_t esp_wifi_connect(void);
esp_err_t esp_wifi_set_config(wifi_interface_t iface, wifi_config_t *cfg);
esp_err_t esp_wifi_set_ps(wifi_ps_type_t ps);
esp_err_t esp_wifi_set_max_tx_power(int8_t power);
esp_err_t esp_wifi_get_max_tx_power(int8_t *power);
typedef struct { uint8_t mac[6]; int8_t rssi; } wifi_sta_info_t;
typedef struct { int num; wifi_sta_info_t sta[10]; } wifi_sta_list_t;
esp_err_t esp_wifi_ap_get_sta_list(wifi_sta_list_t *out);
esp_err_t esp_wifi_sta_get_ap_info(wifi_ap_record_t *ap);
"""

FILES["esp_event.h"] = r"""
#pragma once
#include <stdint.h>
#include "esp_err.h"
typedef void *esp_event_handler_t;
typedef void *esp_event_handler_instance_t;
typedef const char *esp_event_base_t;
extern esp_event_base_t WIFI_EVENT;
extern esp_event_base_t IP_EVENT;
#define ESP_EVENT_ANY_ID (-1)
esp_err_t esp_event_loop_create_default(void);
esp_err_t esp_event_handler_instance_register(esp_event_base_t base, int32_t id,
                                              esp_event_handler_t h, void *arg,
                                              esp_event_handler_instance_t *out);
"""

FILES["esp_netif.h"] = r"""
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
typedef struct esp_netif_obj *esp_netif_t;
typedef struct { uint32_t addr; } esp_ip4_addr_t;
typedef struct {
    esp_ip4_addr_t ip;
    union { esp_ip4_addr_t ip4; } u_addr;
    uint8_t type;
} esp_ip_addr_t;
typedef struct { esp_ip4_addr_t ip; esp_ip4_addr_t netmask; esp_ip4_addr_t gw; } esp_netif_ip_info_t;
typedef enum { ESP_NETIF_DNS_MAIN = 0, ESP_NETIF_DNS_BACKUP, ESP_NETIF_DNS_FALLBACK } esp_netif_dns_type_t;
typedef struct { esp_ip_addr_t ip; } esp_netif_dns_info_t;
#define ESP_ERR_ESP_NETIF_DHCP_ALREADY_STOPPED 0x1101
#define ESP_ERR_ESP_NETIF_DHCP_ALREADY_STARTED 0x1102
#define ESP_NETIF_OP_SET 3
#define ESP_NETIF_DOMAIN_NAME_SERVER 6
#define ESP_IPADDR_TYPE_V4 0
#define IP_EVENT_STA_GOT_IP 1          /* 真机在 lwip/esp_netif_ip 事件头，桩合并 */
esp_err_t esp_netif_init(void);
esp_netif_t *esp_netif_create_default_wifi_sta(void);
esp_netif_t *esp_netif_create_default_wifi_ap(void);
esp_err_t esp_netif_get_ip_info(esp_netif_t *nif, esp_netif_ip_info_t *out);
esp_err_t esp_netif_set_dns_info(esp_netif_t *nif, esp_netif_dns_type_t type,
                                 esp_netif_dns_info_t *dns);
esp_err_t esp_netif_dhcps_start(esp_netif_t *nif);
esp_err_t esp_netif_dhcps_stop(esp_netif_t *nif);
esp_err_t esp_netif_dhcps_option(esp_netif_t *nif, int opt_op, int opt_num, void *val, uint32_t len);
char *esp_ip4addr_ntoa(const esp_ip4_addr_t *addr, char *buf, size_t len);
uint32_t esp_ip4addr_aton(const char *str);
"""

FILES["esp_netif_sntp.h"] = r"""
#pragma once
#include "esp_err.h"
typedef struct { const char *server; void *cb; } esp_sntp_config_t;
#define ESP_NETIF_SNTP_DEFAULT_CONFIG(srv) ((esp_sntp_config_t){ (srv), 0 })
esp_err_t esp_netif_sntp_init(const esp_sntp_config_t *cfg);
"""

FILES["esp_sntp.h"] = r"""
#pragma once
#include <stdint.h>
#include <sys/time.h>
void esp_sntp_set_sync_interval(uint32_t ms);
void esp_sntp_restart(void);
typedef void (*sntp_sync_time_cb_t)(struct timeval *tv);
void sntp_set_time_sync_notification_cb(sntp_sync_time_cb_t cb);
"""

FILES["esp_http_server.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>
#include <stdbool.h>
#include "esp_err.h"
typedef struct httpd_req httpd_req_t;
typedef struct httpd_data *httpd_handle_t;
typedef esp_err_t (*httpd_uri_func_t)(httpd_req_t *r);
typedef enum { HTTP_GET = 0, HTTPD_GET = 0, HTTP_POST = 1, HTTPD_POST = 1,
               HTTP_OPTIONS = 3 } httpd_method_t;
#define httpd_uri_match_wildcard NULL
typedef struct {
    const char *uri;
    httpd_method_t method;
    httpd_uri_func_t handler;
    void *user_ctx;
} httpd_uri_t;
#define HTTPD_400_BAD_REQUEST 400
#define HTTPD_404_NOT_FOUND 404
#define HTTPD_500_INTERNAL_SERVER_ERROR 500
#define HTTP_POST 1
typedef struct {
    unsigned task_priority;
    size_t stack_size;
    int max_uri_handlers;
    int max_open_sockets;
    bool lru_purge_enable;
    int recv_wait_timeout;
    int send_wait_timeout;
    const void *uri_match_fn;
} httpd_config_t;
#define HTTPD_DEFAULT_CONFIG() \
    ((httpd_config_t){ .task_priority = 5, .stack_size = 4096, .max_uri_handlers = 8, \
                       .max_open_sockets = 7, .lru_purge_enable = false, \
                       .recv_wait_timeout = 5, .send_wait_timeout = 5, \
                       .uri_match_fn = NULL })
struct httpd_req {
    httpd_handle_t handle;
    const char *uri;
    httpd_method_t method;
    int content_len;
    void *sess_ctx;
    void *aux;
    void *user_ctx;
    bool ignore_sess_ctx_changes;
};
esp_err_t httpd_start(httpd_handle_t *out, const httpd_config_t *cfg);
esp_err_t httpd_stop(httpd_handle_t h);
esp_err_t httpd_register_uri_handler(httpd_handle_t h, const httpd_uri_t *uri);
esp_err_t httpd_resp_set_status(httpd_req_t *r, const char *s);
esp_err_t httpd_resp_set_type(httpd_req_t *r, const char *s);
esp_err_t httpd_resp_set_hdr(httpd_req_t *r, const char *field, const char *val);
esp_err_t httpd_resp_send(httpd_req_t *r, const char *buf, ssize_t len);
esp_err_t httpd_resp_send_chunk(httpd_req_t *r, const char *buf, ssize_t len);
esp_err_t httpd_resp_sendstr(httpd_req_t *r, const char *s);
esp_err_t httpd_resp_send_err(httpd_req_t *r, int code, const char *msg);
int httpd_req_recv(httpd_req_t *r, char *buf, size_t len);
ssize_t httpd_req_get_url_query_len(httpd_req_t *r);
esp_err_t httpd_req_get_url_query_str(httpd_req_t *r, char *buf, size_t len);
esp_err_t httpd_query_key_value(const char *qs, const char *key, char *val, size_t len);
ssize_t httpd_req_get_hdr_value_len(httpd_req_t *r, const char *field);
esp_err_t httpd_req_get_hdr_value_str(httpd_req_t *r, const char *field, char *buf, size_t len);
esp_err_t httpd_req_get_cookie_val(httpd_req_t *r, const char *name, char *val, size_t len);
"""

FILES["esp_http_client.h"] = r"""
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
typedef struct esp_http_client *esp_http_client_handle_t;
typedef struct {
    const char *url;
    int32_t timeout_ms;
    bool keep_alive_enable;
} esp_http_client_config_t;
esp_http_client_handle_t esp_http_client_init(const esp_http_client_config_t *cfg);
esp_err_t esp_http_client_open(esp_http_client_handle_t h, int write_len);
int esp_http_client_fetch_headers(esp_http_client_handle_t h);
int esp_http_client_read(esp_http_client_handle_t h, char *buf, int len);
int esp_http_client_get_status_code(esp_http_client_handle_t h);
esp_err_t esp_http_client_cleanup(esp_http_client_handle_t h);
"""

FILES["esp_partition.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "esp_err.h"
typedef enum { ESP_PARTITION_TYPE_APP = 0, ESP_PARTITION_TYPE_DATA = 1 } esp_partition_type_t;
#define ESP_PARTITION_SUBTYPE_ANY 0xff
#define ESP_PARTITION_SUBTYPE_DATA_SPIFFS 0x81
typedef struct {
    uint16_t magic;
    uint8_t type;
    uint8_t subtype;
    uint32_t offset;
    uint32_t size;
    uint32_t address;      /* 兼容字段（store.c 用 address；真机与 offset 同义） */
    char label[17];
    bool encrypted;
} esp_partition_t;
const esp_partition_t *esp_partition_find_first(esp_partition_type_t type,
                                                uint8_t subtype, const char *label);
esp_err_t esp_partition_read(const esp_partition_t *part, size_t src,
                             void *dst, size_t len);
esp_err_t esp_partition_write(const esp_partition_t *part, size_t dst,
                              const void *src, size_t len);
esp_err_t esp_partition_erase_range(const esp_partition_t *part, size_t dst, size_t len);
"""

FILES["esp_ota_ops.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
#include "esp_partition.h"
#include "esp_system.h"      /* esp_restart（noreturn）随真机传递包含 */
typedef uint32_t esp_ota_handle_t;
esp_err_t esp_ota_begin(const esp_partition_t *part, size_t offset, esp_ota_handle_t *out);
esp_err_t esp_ota_write(esp_ota_handle_t h, const void *data, size_t len);
esp_err_t esp_ota_end(esp_ota_handle_t h);
const esp_partition_t *esp_ota_get_running_partition(void);
const esp_partition_t *esp_ota_get_next_update_partition(const esp_partition_t *cur);
esp_err_t esp_ota_set_boot_partition(const esp_partition_t *part);
esp_err_t esp_ota_mark_app_valid_cancel_rollback(void);
"""

FILES["esp_pm.h"] = r"""
#pragma once
#include <stdbool.h>
#include "esp_err.h"
typedef struct { int max_freq_mhz; int min_freq_mhz; bool light_sleep_enable; } esp_pm_config_t;
esp_err_t esp_pm_configure(const esp_pm_config_t *cfg);
"""

FILES["nvs.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
typedef uint32_t nvs_handle_t;
typedef enum { NVS_READONLY, NVS_READWRITE } nvs_open_mode_t;
typedef enum { NVS_TYPE_U8 = 1, NVS_TYPE_U16, NVS_TYPE_U32, NVS_TYPE_I8,
               NVS_TYPE_I16, NVS_TYPE_I32, NVS_TYPE_STR } nvs_type_t;
esp_err_t nvs_open(const char *ns, nvs_open_mode_t mode, nvs_handle_t *out);
void nvs_close(nvs_handle_t h);
esp_err_t nvs_commit(nvs_handle_t h);
esp_err_t nvs_get_u8(nvs_handle_t h, const char *k, uint8_t *v);
esp_err_t nvs_get_u16(nvs_handle_t h, const char *k, uint16_t *v);
esp_err_t nvs_get_u32(nvs_handle_t h, const char *k, uint32_t *v);
esp_err_t nvs_get_str(nvs_handle_t h, const char *k, char *v, size_t *len);
esp_err_t nvs_set_u8(nvs_handle_t h, const char *k, uint8_t v);
esp_err_t nvs_set_u16(nvs_handle_t h, const char *k, uint16_t v);
esp_err_t nvs_set_u32(nvs_handle_t h, const char *k, uint32_t v);
esp_err_t nvs_set_str(nvs_handle_t h, const char *k, const char *v);
esp_err_t nvs_erase_key(nvs_handle_t h, const char *k);
esp_err_t nvs_erase_all(nvs_handle_t h);
esp_err_t nvs_get_stats(const char *ns, void *stats);
"""

FILES["nvs_flash.h"] = r"""
#pragma once
#include "esp_err.h"
esp_err_t nvs_flash_init(void);
esp_err_t nvs_flash_erase(void);
esp_err_t nvs_flash_erase_partition(const char *label);
"""

FILES["mdns.h"] = r"""
#pragma once
#include <stdint.h>
#include "esp_err.h"
esp_err_t mdns_init(void);
void mdns_free(void);
esp_err_t mdns_hostname_set(const char *host);
esp_err_t mdns_instance_name_set(const char *name);
/* 托管版 mdns（v5.2+/v6/espressif/mdns）签名含 TXT：
   mdns_service_add(instance, type, proto, port, txt[], num_items) */
esp_err_t mdns_service_add(const char *inst, const char *service, const char *proto,
                           uint16_t port, const char *txt[], int num);
"""

FILES["lwip/netdb.h"] = r"""
#pragma once
#include <stddef.h>
struct hostent { char *h_name; char **h_addr_list; int h_addrtype; };
struct hostent *gethostbyname(const char *name);
"""

FILES["lwip/sockets.h"] = r"""
#pragma once
/* captive.c 用标准 BSD socket 面：桩直接透传宿主真实现（只编译不链接）。 */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
"""

FILES["psa/crypto.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int psa_status_t;
#define PSA_SUCCESS ((psa_status_t)0)
#define PSA_ERROR_NOT_SUPPORTED ((psa_status_t)-134)
typedef uint16_t psa_key_type_t;
typedef uint32_t psa_key_usage_t;
typedef uint32_t psa_algorithm_t;
typedef int mbedtls_svc_key_id_t;      /* IDF v6 = mbedTLS 4.x：key id 已非裸 u32 */
typedef mbedtls_svc_key_id_t psa_key_id_t;
typedef struct { psa_key_type_t type; uint32_t bits; psa_algorithm_t alg;
                 psa_key_usage_t usage; } psa_key_attributes_t;
#define PSA_KEY_ATTRIBUTES_INIT ((psa_key_attributes_t){ 0, 0, 0, 0 })
#define PSA_KEY_TYPE_AES ((psa_key_type_t)0x2400)
#define PSA_ALG_CCM ((psa_algorithm_t)0x050051)
#define PSA_ALG_AEAD_WITH_AT_LEAST_THIS_LENGTH_TAG(alg, tag) (alg)
#define PSA_KEY_USAGE_ENCRYPT ((psa_key_usage_t)0x0100)
#define PSA_KEY_USAGE_DECRYPT ((psa_key_usage_t)0x0200)
psa_key_attributes_t psa_key_attributes_init(void);
void psa_set_key_type(psa_key_attributes_t *a, psa_key_type_t t);
void psa_set_key_bits(psa_key_attributes_t *a, uint32_t bits);
void psa_set_key_usage_flags(psa_key_attributes_t *a, psa_key_usage_t u);
void psa_set_key_algorithm(psa_key_attributes_t *a, psa_algorithm_t alg);
psa_status_t psa_crypto_init(void);
psa_status_t psa_import_key(const psa_key_attributes_t *a, const uint8_t *data, size_t len,
                            mbedtls_svc_key_id_t *out);
psa_status_t psa_destroy_key(mbedtls_svc_key_id_t key);
psa_status_t psa_aead_encrypt(mbedtls_svc_key_id_t key, psa_algorithm_t alg,
                              const uint8_t *nonce, size_t nonce_len,
                              const uint8_t *ad, size_t ad_len,
                              const uint8_t *in, size_t in_len,
                              uint8_t *out, size_t out_size, size_t *out_len);
psa_status_t psa_aead_decrypt(mbedtls_svc_key_id_t key, psa_algorithm_t alg,
                              const uint8_t *nonce, size_t nonce_len,
                              const uint8_t *ad, size_t ad_len,
                              const uint8_t *in, size_t in_len,
                              uint8_t *out, size_t out_size, size_t *out_len);
"""

FILES["nimble/nimble_port.h"] = r"""
#pragma once
int nimble_port_init(void);
int nimble_port_run(void);
void nimble_port_stop(void);
void nimble_port_deinit(void);
"""

FILES["nimble/nimble_port_freertos.h"] = r"""
#pragma once
void nimble_port_freertos_init(void (*fn)(void *param));
void nimble_port_freertos_deinit(void);
"""
FILES["host/ble_hs.h"] = r"""
#pragma once
#include <stdint.h>
#define BLE_HS_FOREVER ((int32_t)0x7fffffff)
struct ble_hs_cfg {
    void (*sync_cb)(void);
    void (*reset_cb)(int reason);
    void (*gap_event_cb)(void);
};
extern struct ble_hs_cfg ble_hs_cfg;
int ble_hs_util_ensure_addr(int prefer_random);
int ble_hs_id_infer_auto(int prefer_random, uint8_t *addr_type);
"""

FILES["host/ble_gap.h"] = r"""
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "host/ble_hs.h"
typedef struct { uint8_t type; uint8_t val[6]; } ble_addr_t;
#define BLE_GAP_EVENT_DISC 0
#define BLE_GAP_EVENT_DISC_COMPLETE 1
#define BLE_GAP_EVENT_CONNECT 2
#define BLE_GAP_EVENT_DISCONNECT 3
#define BLE_GAP_EVENT_SUBSCRIBE 4
#define BLE_GAP_EVENT_CONN_UPDATE 5
#define BLE_GAP_EVENT_MTU 6
#define BLE_GAP_EVENT_ADV_COMPLETE 7
#define BLE_GAP_EVENT_ENC_CHANGE 8
#define BLE_GAP_EVENT_PASSKEY_ACTION 9
#define BLE_GAP_EVENT_REPEAT_PAIRING 10
struct ble_gap_disc_desc {
    ble_addr_t addr;
    int8_t rssi;
    const uint8_t *data;
    size_t length_data;
};
struct ble_gap_event {
    int type;
    union {
        struct ble_gap_disc_desc disc;
        int dummy;
    } __attribute__((packed));
};
struct ble_gap_disc_params {
    uint16_t itvl;
    uint16_t window;
    uint8_t filter_policy;
    unsigned passive:1;
    unsigned limited:1;
};
typedef int (*ble_gap_event_fn)(struct ble_gap_event *event, void *arg);
int ble_gap_disc_cancel(void);
int ble_gap_disc(uint8_t own_addr_type, int32_t duration_ms,
                 const struct ble_gap_disc_params *disc_params,
                 ble_gap_event_fn cb, void *cb_arg);
typedef struct { int conn_handle; int bonded; } ble_gap_conn_desc_t;
int ble_gap_conn_find(int conn_handle, ble_gap_conn_desc_t *out);
"""

FILES["host/util/util.h"] = r"""
#pragma once
#include "host/ble_hs.h"
int ble_hs_util_ensure_addr_util_stub(void);
"""

def main():
    for sub in ("driver", "freertos", "esp_adc", "lwip", "nimble", "host/util", "psa"):
        os.makedirs(os.path.join(OUT, sub), exist_ok=True)
    for name, body in FILES.items():
        path = os.path.join(OUT, name)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write("/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */\n")
            f.write(body.lstrip("\n"))
        print("wrote", path)
    print("done: %d stub headers" % len(FILES))

if __name__ == "__main__":
    main()
