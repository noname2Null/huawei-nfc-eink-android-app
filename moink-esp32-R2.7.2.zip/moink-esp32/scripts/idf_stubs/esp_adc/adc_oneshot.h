/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include "esp_err.h"
typedef int adc_unit_t;
typedef int adc_channel_t;
typedef int adc_atten_t;
typedef int adc_bitwidth_t;
#define ADC_UNIT_1 0
#define ADC_CHANNEL_0 0
#define ADC_CHANNEL_3 3
#define ADC_CHANNEL_4 4
#define ADC_CHANNEL_5 5
#define ADC_CHANNEL_6 6
#define ADC_CHANNEL_7 7
#define ADC_ATTEN_DB_12 3
#define ADC_BITWIDTH_12 3
typedef enum { ADC_ULP_MODE_DISABLE = 0 } adc_ulp_mode_t;
typedef struct { adc_unit_t unit_id; adc_ulp_mode_t ulp_mode; } adc_oneshot_unit_init_cfg_t;
typedef struct { adc_atten_t atten; adc_bitwidth_t bitwidth; } adc_oneshot_chan_cfg_t;
typedef struct adc_oneshot_unit_t *adc_oneshot_unit_handle_t;
esp_err_t adc_oneshot_new_unit(const adc_oneshot_unit_init_cfg_t *u,
                               adc_oneshot_unit_handle_t *out);
esp_err_t adc_oneshot_config_channel(adc_oneshot_unit_handle_t h, adc_channel_t ch,
                                     const adc_oneshot_chan_cfg_t *cfg);
esp_err_t adc_oneshot_read(adc_oneshot_unit_handle_t h, adc_channel_t ch, int *raw);
