/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
typedef enum { WIFI_MODE_NULL = 0, WIFI_MODE_STA, WIFI_MODE_AP, WIFI_MODE_APSTA } wifi_mode_t;
typedef enum { WIFI_PS_MIN_MODEM = 1, WIFI_PS_MAX_MODEM, WIFI_PS_INVALID } wifi_ps_type_t;
typedef int wifi_interface_t;
#define WIFI_IF_STA 0
#define WIFI_IF_AP  1
/* 事件 id（esp_wifi_types / lwip ip 事件在真机由各自主头提供，桩合并到此） */
#define WIFI_EVENT_STA_START 0
#define WIFI_EVENT_STA_CONNECTED 1
#define WIFI_EVENT_STA_DISCONNECTED 2
#define WIFI_EVENT_AP_START 3
#define WIFI_EVENT_AP_STACONNECTED 4
#define WIFI_EVENT_AP_STADISCONNECTED 5
/* ★R2.7.2：驱动停机跟踪事件（wifi_mgr.c）—— 桩 id 仅需互异 */
#define WIFI_EVENT_STA_STOP 6
#define WIFI_EVENT_AP_STOP 7
typedef struct { uint8_t mac[6]; int aid; } wifi_event_ap_staconnected_t;
typedef struct { uint8_t mac[6]; int aid; bool reason_is_local; } wifi_event_ap_stadisconnected_t;
typedef struct {
    uint8_t ssid[33];
    uint8_t password[65];
    bool bssid_set;
    uint8_t bssid[6];
    struct { bool capable; bool required; } pmf_cfg;
} wifi_sta_config_t;
typedef struct {
    uint8_t ssid[33];
    uint8_t password[65];
    uint8_t max_connection;
    bool ssid_hidden;
    uint8_t ssid_len;
    uint8_t channel;
    int authmode;
} wifi_ap_config_t;
typedef enum { WIFI_AUTH_OPEN = 0, WIFI_AUTH_WPA2_PSK = 3 } wifi_auth_mode_t;
typedef struct { wifi_sta_config_t sta; wifi_ap_config_t ap; } wifi_config_t;
typedef struct { int dummy; } wifi_init_config_t;
#define WIFI_INIT_CONFIG_DEFAULT() ((wifi_init_config_t){ 0 })
typedef struct {
    uint8_t ssid[33];
    int8_t rssi;
    uint8_t bssid[6];
} wifi_ap_record_t;
esp_err_t esp_wifi_init(const wifi_init_config_t *cfg);
esp_err_t esp_wifi_set_mode(wifi_mode_t mode);
esp_err_t esp_wifi_get_mode(wifi_mode_t *mode);   /* ★R2.7.2：驱动停机恢复分支用 */
esp_err_t esp_wifi_start(void);
esp_err_t esp_wifi_stop(void);
esp_err_t esp_wifi_connect(void);
esp_err_t esp_wifi_set_config(wifi_interface_t iface, wifi_config_t *cfg);
esp_err_t esp_wifi_set_ps(wifi_ps_type_t ps);
esp_err_t esp_wifi_set_max_tx_power(int8_t power);
esp_err_t esp_wifi_get_max_tx_power(int8_t *power);
typedef struct { uint8_t mac[6]; int8_t rssi; } wifi_sta_info_t;
typedef struct { int num; wifi_sta_info_t sta[10]; } wifi_sta_list_t;
esp_err_t esp_wifi_ap_get_sta_list(wifi_sta_list_t *out);
esp_err_t esp_wifi_sta_get_ap_info(wifi_ap_record_t *ap);
