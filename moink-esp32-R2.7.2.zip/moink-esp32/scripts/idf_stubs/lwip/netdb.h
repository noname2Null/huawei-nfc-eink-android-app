/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stddef.h>
struct hostent { char *h_name; char **h_addr_list; int h_addrtype; };
struct hostent *gethostbyname(const char *name);
