/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include "freertos/FreeRTOS.h"
typedef void *TaskHandle_t;
void vTaskDelay(TickType_t ticks);
void vTaskDelete(TaskHandle_t t);
BaseType_t xTaskCreate(void (*fn)(void *), const char *name, uint32_t stack,
                       void *arg, UBaseType_t prio, TaskHandle_t *out);
TickType_t xTaskGetTickCount(void);
