/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
typedef struct esp_http_client *esp_http_client_handle_t;
typedef struct {
    const char *url;
    int32_t timeout_ms;
    bool keep_alive_enable;
} esp_http_client_config_t;
esp_http_client_handle_t esp_http_client_init(const esp_http_client_config_t *cfg);
esp_err_t esp_http_client_open(esp_http_client_handle_t h, int write_len);
int esp_http_client_fetch_headers(esp_http_client_handle_t h);
int esp_http_client_read(esp_http_client_handle_t h, char *buf, int len);
int esp_http_client_get_status_code(esp_http_client_handle_t h);
esp_err_t esp_http_client_cleanup(esp_http_client_handle_t h);
