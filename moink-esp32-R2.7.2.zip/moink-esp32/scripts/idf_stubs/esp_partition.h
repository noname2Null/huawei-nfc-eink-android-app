/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "esp_err.h"
typedef enum { ESP_PARTITION_TYPE_APP = 0, ESP_PARTITION_TYPE_DATA = 1 } esp_partition_type_t;
#define ESP_PARTITION_SUBTYPE_ANY 0xff
#define ESP_PARTITION_SUBTYPE_DATA_SPIFFS 0x81
typedef struct {
    uint16_t magic;
    uint8_t type;
    uint8_t subtype;
    uint32_t offset;
    uint32_t size;
    uint32_t address;      /* 兼容字段（store.c 用 address；真机与 offset 同义） */
    char label[17];
    bool encrypted;
} esp_partition_t;
const esp_partition_t *esp_partition_find_first(esp_partition_type_t type,
                                                uint8_t subtype, const char *label);
esp_err_t esp_partition_read(const esp_partition_t *part, size_t src,
                             void *dst, size_t len);
esp_err_t esp_partition_write(const esp_partition_t *part, size_t dst,
                              const void *src, size_t len);
esp_err_t esp_partition_erase_range(const esp_partition_t *part, size_t dst, size_t len);
