/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdio.h>
void esp_log_stub(const char *tag, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
#define ESP_LOGE(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGW(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGI(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGD(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
#define ESP_LOGV(tag, fmt, ...) esp_log_stub(tag, fmt, ##__VA_ARGS__)
