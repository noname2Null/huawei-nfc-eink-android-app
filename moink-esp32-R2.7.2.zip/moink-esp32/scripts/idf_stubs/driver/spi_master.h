/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
typedef int spi_host_device_t;
#define SPI2_HOST 1
#define SPI_DMA_CH_AUTO 3
typedef struct {
    int mosi_io_num, miso_io_num, sclk_io_num, quadwp_io_num, quadhd_io_num;
    int max_transfer_sz;
    uint32_t flags;
    int intr_flags;
} spi_bus_config_t;
typedef struct {
    uint8_t command_bits, address_bits, dummy_bits;
    uint8_t mode;
    uint16_t duty_cycle_pos;
    uint16_t cs_ena_pretrans, cs_ena_posttrans;
    int clock_speed_hz;
    int input_delay_ns;
    int spics_io_num;
    uint32_t flags;
    int queue_size;
} spi_device_interface_config_t;
typedef struct spi_device_t *spi_device_handle_t;
typedef struct {
    size_t length;
    size_t rxlength;
    const void *tx_buffer;
    void *rx_buffer;
    void *user;
    uint32_t flags;
    uint64_t cmd;
    uint64_t addr;
} spi_transaction_t;
esp_err_t spi_bus_initialize(spi_host_device_t host, const spi_bus_config_t *bus, int dma);
esp_err_t spi_bus_add_device(spi_host_device_t host, const spi_device_interface_config_t *dev,
                             spi_device_handle_t *out);
esp_err_t spi_device_polling_transmit(spi_device_handle_t h, spi_transaction_t *t);
