/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include "esp_err.h"
typedef int esp_mac_type_t;
#define ESP_MAC_WIFI_STA 0
#define MACSTR "%02x%02x%02x%02x%02x%02x"
#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
esp_err_t esp_read_mac(uint8_t *mac, esp_mac_type_t type);
