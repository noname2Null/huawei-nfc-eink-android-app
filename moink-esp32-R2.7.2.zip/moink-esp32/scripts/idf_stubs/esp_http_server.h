/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>
#include <stdbool.h>
#include "esp_err.h"
typedef struct httpd_req httpd_req_t;
typedef struct httpd_data *httpd_handle_t;
typedef esp_err_t (*httpd_uri_func_t)(httpd_req_t *r);
typedef enum { HTTP_GET = 0, HTTPD_GET = 0, HTTP_POST = 1, HTTPD_POST = 1,
               HTTP_OPTIONS = 3 } httpd_method_t;
#define httpd_uri_match_wildcard NULL
typedef struct {
    const char *uri;
    httpd_method_t method;
    httpd_uri_func_t handler;
    void *user_ctx;
} httpd_uri_t;
#define HTTPD_400_BAD_REQUEST 400
#define HTTPD_404_NOT_FOUND 404
#define HTTPD_500_INTERNAL_SERVER_ERROR 500
#define HTTP_POST 1
typedef struct {
    unsigned task_priority;
    size_t stack_size;
    int max_uri_handlers;
    int max_open_sockets;
    bool lru_purge_enable;
    int recv_wait_timeout;
    int send_wait_timeout;
    const void *uri_match_fn;
} httpd_config_t;
#define HTTPD_DEFAULT_CONFIG() \
    ((httpd_config_t){ .task_priority = 5, .stack_size = 4096, .max_uri_handlers = 8, \
                       .max_open_sockets = 7, .lru_purge_enable = false, \
                       .recv_wait_timeout = 5, .send_wait_timeout = 5, \
                       .uri_match_fn = NULL })
struct httpd_req {
    httpd_handle_t handle;
    const char *uri;
    httpd_method_t method;
    int content_len;
    void *sess_ctx;
    void *aux;
    void *user_ctx;
    bool ignore_sess_ctx_changes;
};
esp_err_t httpd_start(httpd_handle_t *out, const httpd_config_t *cfg);
esp_err_t httpd_stop(httpd_handle_t h);
esp_err_t httpd_register_uri_handler(httpd_handle_t h, const httpd_uri_t *uri);
esp_err_t httpd_resp_set_status(httpd_req_t *r, const char *s);
esp_err_t httpd_resp_set_type(httpd_req_t *r, const char *s);
esp_err_t httpd_resp_set_hdr(httpd_req_t *r, const char *field, const char *val);
esp_err_t httpd_resp_send(httpd_req_t *r, const char *buf, ssize_t len);
esp_err_t httpd_resp_send_chunk(httpd_req_t *r, const char *buf, ssize_t len);
esp_err_t httpd_resp_sendstr(httpd_req_t *r, const char *s);
esp_err_t httpd_resp_send_err(httpd_req_t *r, int code, const char *msg);
int httpd_req_recv(httpd_req_t *r, char *buf, size_t len);
ssize_t httpd_req_get_url_query_len(httpd_req_t *r);
esp_err_t httpd_req_get_url_query_str(httpd_req_t *r, char *buf, size_t len);
esp_err_t httpd_query_key_value(const char *qs, const char *key, char *val, size_t len);
ssize_t httpd_req_get_hdr_value_len(httpd_req_t *r, const char *field);
esp_err_t httpd_req_get_hdr_value_str(httpd_req_t *r, const char *field, char *buf, size_t len);
esp_err_t httpd_req_get_cookie_val(httpd_req_t *r, const char *name, char *val, size_t len);
