/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include "esp_err.h"
typedef enum {
    ESP_SLEEP_WAKEUP_UNDEFINED = 0,
    ESP_SLEEP_WAKEUP_ALL = 1,
    ESP_SLEEP_WAKEUP_EXT0 = 2,
    ESP_SLEEP_WAKEUP_EXT1 = 3,
    ESP_SLEEP_WAKEUP_TIMER = 4,
    ESP_SLEEP_WAKEUP_TOUCHPAD = 5,
    ESP_SLEEP_WAKEUP_ULP = 6,
    ESP_SLEEP_WAKEUP_GPIO = 7,
    ESP_SLEEP_WAKEUP_UART = 8,
    ESP_SLEEP_WAKEUP_WIFI = 9,
    ESP_SLEEP_WAKEUP_BT = 10,
    ESP_SLEEP_WAKEUP_COCPU = 11,
    ESP_SLEEP_WAKEUP_COCPU_TRAP_TRIG = 12,
    ESP_SLEEP_WAKEUP_BT_HCI = 13,
} esp_sleep_source_t;
uint64_t esp_sleep_get_wakeup_causes(void);
esp_err_t esp_sleep_enable_ext0_wakeup(int gpio, int level);
esp_err_t esp_sleep_enable_timer_wakeup(uint64_t us);
esp_err_t esp_sleep_disable_wakeup_source(esp_sleep_source_t src);
void esp_deep_sleep_start(void) __attribute__((noreturn));
