/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"
typedef struct esp_netif_obj *esp_netif_t;
typedef struct { uint32_t addr; } esp_ip4_addr_t;
typedef struct {
    esp_ip4_addr_t ip;
    union { esp_ip4_addr_t ip4; } u_addr;
    uint8_t type;
} esp_ip_addr_t;
typedef struct { esp_ip4_addr_t ip; esp_ip4_addr_t netmask; esp_ip4_addr_t gw; } esp_netif_ip_info_t;
typedef enum { ESP_NETIF_DNS_MAIN = 0, ESP_NETIF_DNS_BACKUP, ESP_NETIF_DNS_FALLBACK } esp_netif_dns_type_t;
typedef struct { esp_ip_addr_t ip; } esp_netif_dns_info_t;
#define ESP_ERR_ESP_NETIF_DHCP_ALREADY_STOPPED 0x1101
#define ESP_ERR_ESP_NETIF_DHCP_ALREADY_STARTED 0x1102
#define ESP_NETIF_OP_SET 3
#define ESP_NETIF_DOMAIN_NAME_SERVER 6
#define ESP_IPADDR_TYPE_V4 0
#define IP_EVENT_STA_GOT_IP 1          /* 真机在 lwip/esp_netif_ip 事件头，桩合并 */
esp_err_t esp_netif_init(void);
esp_netif_t *esp_netif_create_default_wifi_sta(void);
esp_netif_t *esp_netif_create_default_wifi_ap(void);
esp_err_t esp_netif_get_ip_info(esp_netif_t *nif, esp_netif_ip_info_t *out);
esp_err_t esp_netif_set_dns_info(esp_netif_t *nif, esp_netif_dns_type_t type,
                                 esp_netif_dns_info_t *dns);
esp_err_t esp_netif_dhcps_start(esp_netif_t *nif);
esp_err_t esp_netif_dhcps_stop(esp_netif_t *nif);
esp_err_t esp_netif_dhcps_option(esp_netif_t *nif, int opt_op, int opt_num, void *val, uint32_t len);
char *esp_ip4addr_ntoa(const esp_ip4_addr_t *addr, char *buf, size_t len);
uint32_t esp_ip4addr_aton(const char *str);
