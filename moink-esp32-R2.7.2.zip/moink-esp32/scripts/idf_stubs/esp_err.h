/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int esp_err_t;
#define ESP_OK          0
#define ESP_FAIL        -1
#define ESP_ERR_NO_MEM          0x101
#define ESP_ERR_INVALID_STATE   0x103
#define ESP_ERR_INVALID_ARG     0x102
#define ESP_ERR_INVALID_SIZE    0x104
#define ESP_ERR_NOT_FOUND       0x105
#define ESP_ERR_NOT_SUPPORTED   0x106
#define ESP_ERR_TIMEOUT         0x107
#define ESP_ERR_INVALID_RESPONSE 0x108
#define ESP_ERR_INVALID_CRC     0x109
#define ESP_ERR_NVS_NO_FREE_PAGES 0x1102
#define ESP_ERR_NVS_NEW_VERSION_FOUND 0x1103
#define ESP_ERR_NVS_NOT_FOUND   0x1104
#define ESP_ERR_NVS_INVALID_NAME 0x1105
const char *esp_err_to_name(esp_err_t code);
#define ESP_ERROR_CHECK(x) do { (void)(x); } while (0)
