/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "esp_err.h"
#include "esp_partition.h"
#include "esp_system.h"      /* esp_restart（noreturn）随真机传递包含 */
typedef uint32_t esp_ota_handle_t;
esp_err_t esp_ota_begin(const esp_partition_t *part, size_t offset, esp_ota_handle_t *out);
esp_err_t esp_ota_write(esp_ota_handle_t h, const void *data, size_t len);
esp_err_t esp_ota_end(esp_ota_handle_t h);
const esp_partition_t *esp_ota_get_running_partition(void);
const esp_partition_t *esp_ota_get_next_update_partition(const esp_partition_t *cur);
esp_err_t esp_ota_set_boot_partition(const esp_partition_t *part);
esp_err_t esp_ota_mark_app_valid_cancel_rollback(void);
