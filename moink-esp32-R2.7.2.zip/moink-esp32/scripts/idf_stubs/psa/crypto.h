/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stddef.h>
typedef int psa_status_t;
#define PSA_SUCCESS ((psa_status_t)0)
#define PSA_ERROR_NOT_SUPPORTED ((psa_status_t)-134)
typedef uint16_t psa_key_type_t;
typedef uint32_t psa_key_usage_t;
typedef uint32_t psa_algorithm_t;
typedef int mbedtls_svc_key_id_t;      /* IDF v6 = mbedTLS 4.x：key id 已非裸 u32 */
typedef mbedtls_svc_key_id_t psa_key_id_t;
typedef struct { psa_key_type_t type; uint32_t bits; psa_algorithm_t alg;
                 psa_key_usage_t usage; } psa_key_attributes_t;
#define PSA_KEY_ATTRIBUTES_INIT ((psa_key_attributes_t){ 0, 0, 0, 0 })
#define PSA_KEY_TYPE_AES ((psa_key_type_t)0x2400)
#define PSA_ALG_CCM ((psa_algorithm_t)0x050051)
#define PSA_ALG_AEAD_WITH_AT_LEAST_THIS_LENGTH_TAG(alg, tag) (alg)
#define PSA_KEY_USAGE_ENCRYPT ((psa_key_usage_t)0x0100)
#define PSA_KEY_USAGE_DECRYPT ((psa_key_usage_t)0x0200)
psa_key_attributes_t psa_key_attributes_init(void);
void psa_set_key_type(psa_key_attributes_t *a, psa_key_type_t t);
void psa_set_key_bits(psa_key_attributes_t *a, uint32_t bits);
void psa_set_key_usage_flags(psa_key_attributes_t *a, psa_key_usage_t u);
void psa_set_key_algorithm(psa_key_attributes_t *a, psa_algorithm_t alg);
psa_status_t psa_crypto_init(void);
psa_status_t psa_import_key(const psa_key_attributes_t *a, const uint8_t *data, size_t len,
                            mbedtls_svc_key_id_t *out);
psa_status_t psa_destroy_key(mbedtls_svc_key_id_t key);
psa_status_t psa_aead_encrypt(mbedtls_svc_key_id_t key, psa_algorithm_t alg,
                              const uint8_t *nonce, size_t nonce_len,
                              const uint8_t *ad, size_t ad_len,
                              const uint8_t *in, size_t in_len,
                              uint8_t *out, size_t out_size, size_t *out_len);
psa_status_t psa_aead_decrypt(mbedtls_svc_key_id_t key, psa_algorithm_t alg,
                              const uint8_t *nonce, size_t nonce_len,
                              const uint8_t *ad, size_t ad_len,
                              const uint8_t *in, size_t in_len,
                              uint8_t *out, size_t out_size, size_t *out_len);
