/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#define RTC_NOINIT_ATTR
#define IRAM_ATTR
