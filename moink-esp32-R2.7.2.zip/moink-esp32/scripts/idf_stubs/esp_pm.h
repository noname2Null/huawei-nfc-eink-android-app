/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdbool.h>
#include "esp_err.h"
typedef struct { int max_freq_mhz; int min_freq_mhz; bool light_sleep_enable; } esp_pm_config_t;
esp_err_t esp_pm_configure(const esp_pm_config_t *cfg);
