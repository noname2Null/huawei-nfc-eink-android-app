/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include <stddef.h>
#include "host/ble_hs.h"
typedef struct { uint8_t type; uint8_t val[6]; } ble_addr_t;
#define BLE_GAP_EVENT_DISC 0
#define BLE_GAP_EVENT_DISC_COMPLETE 1
#define BLE_GAP_EVENT_CONNECT 2
#define BLE_GAP_EVENT_DISCONNECT 3
#define BLE_GAP_EVENT_SUBSCRIBE 4
#define BLE_GAP_EVENT_CONN_UPDATE 5
#define BLE_GAP_EVENT_MTU 6
#define BLE_GAP_EVENT_ADV_COMPLETE 7
#define BLE_GAP_EVENT_ENC_CHANGE 8
#define BLE_GAP_EVENT_PASSKEY_ACTION 9
#define BLE_GAP_EVENT_REPEAT_PAIRING 10
struct ble_gap_disc_desc {
    ble_addr_t addr;
    int8_t rssi;
    const uint8_t *data;
    size_t length_data;
};
struct ble_gap_event {
    int type;
    union {
        struct ble_gap_disc_desc disc;
        int dummy;
    } __attribute__((packed));
};
struct ble_gap_disc_params {
    uint16_t itvl;
    uint16_t window;
    uint8_t filter_policy;
    unsigned passive:1;
    unsigned limited:1;
};
typedef int (*ble_gap_event_fn)(struct ble_gap_event *event, void *arg);
int ble_gap_disc_cancel(void);
int ble_gap_disc(uint8_t own_addr_type, int32_t duration_ms,
                 const struct ble_gap_disc_params *disc_params,
                 ble_gap_event_fn cb, void *cb_arg);
typedef struct { int conn_handle; int bonded; } ble_gap_conn_desc_t;
int ble_gap_conn_find(int conn_handle, ble_gap_conn_desc_t *out);
