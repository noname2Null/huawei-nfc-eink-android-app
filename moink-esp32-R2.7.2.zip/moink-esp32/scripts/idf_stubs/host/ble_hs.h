/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#define BLE_HS_FOREVER ((int32_t)0x7fffffff)
struct ble_hs_cfg {
    void (*sync_cb)(void);
    void (*reset_cb)(int reason);
    void (*gap_event_cb)(void);
};
extern struct ble_hs_cfg ble_hs_cfg;
int ble_hs_util_ensure_addr(int prefer_random);
int ble_hs_id_infer_auto(int prefer_random, uint8_t *addr_type);
