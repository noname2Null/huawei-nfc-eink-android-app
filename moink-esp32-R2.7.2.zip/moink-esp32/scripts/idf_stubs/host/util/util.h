/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include "host/ble_hs.h"
int ble_hs_util_ensure_addr_util_stub(void);
