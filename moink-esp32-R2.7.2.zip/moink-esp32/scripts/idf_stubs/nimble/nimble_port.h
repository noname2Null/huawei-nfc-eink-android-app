/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
int nimble_port_init(void);
int nimble_port_run(void);
void nimble_port_stop(void);
void nimble_port_deinit(void);
