/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
void nimble_port_freertos_init(void (*fn)(void *param));
void nimble_port_freertos_deinit(void);
