/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include <stdint.h>
#include "esp_err.h"
esp_err_t mdns_init(void);
void mdns_free(void);
esp_err_t mdns_hostname_set(const char *host);
esp_err_t mdns_instance_name_set(const char *name);
/* 托管版 mdns（v5.2+/v6/espressif/mdns）签名含 TXT：
   mdns_service_add(instance, type, proto, port, txt[], num_items) */
esp_err_t mdns_service_add(const char *inst, const char *service, const char *proto,
                           uint16_t port, const char *txt[], int num);
