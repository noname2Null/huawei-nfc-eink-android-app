/* 生成桩头（scripts/make_idf_stubs.py）—— 仅沙盒编译闸门用，勿在真机构建引用 */
#pragma once
#include "esp_err.h"
typedef struct { const char *server; void *cb; } esp_sntp_config_t;
#define ESP_NETIF_SNTP_DEFAULT_CONFIG(srv) ((esp_sntp_config_t){ (srv), 0 })
esp_err_t esp_netif_sntp_init(const esp_sntp_config_t *cfg);
