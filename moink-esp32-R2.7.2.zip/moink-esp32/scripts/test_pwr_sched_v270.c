/*
 * pwr_sched R2.7.0 主机单测：事件分档提前量 + 同边界抢断 + 补刷窗口。
 *
 * ★ R2.7.0 语义（pwr_sched.h 契约的直接翻译）：
 *   - BOX（轻唤醒，分钟局刷）：lead = LEAD_LIGHT_S（6s）—— 轻唤醒门控 ≈2~3s；
 *   - REMOTE / CAROUSEL / MOVE（全功能唤醒）：lead = LEAD_S（30s）—— 门控 5~32s；
 *   - 各档独立评估退档（LEAD_MIN_S）与贴边（MIN_S）；
 *   - at_epoch = 事件边界；wake_s 不对齐、无提前量；
 *   - ★同边界抢断：同一整分边界 BOX 与全功能事件都命中时，全功能必须赢
 *     （它的门控+补刷顺带覆盖该边界的分钟刷新；BOX 赢了会把拉取/换位
 *     挤掉整个间隔）。数学上全功能唤醒点（bnd-30）恒早于 BOX（bnd-6），
 *     平局只发生在双方同落贴边档（in_s == MIN_S）—— steal 从 BOX 手里
 *     抢下；全功能之间仍先到先得（BOX > REMOTE > CAROUSEL > MOVE）。
 *   - pwr_sched_missed = 边界已过且仍在同一对齐周期内（R2.6.1 右端+1 分钟）。
 */
#include <stdio.h>
#include <stdint.h>
#include "pwr_sched.h"

static int fails = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { fails++; \
        printf("FAIL %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } \
} while (0)

static int64_t mk_boundary(int iv_min, int64_t k)
{
    return (int64_t)iv_min * 60 * k;            /* 对齐边界 */
}

/* ---- BOX（轻唤醒）分档 ---- */

static void test_box_light_lead_fits(void)
{
    /* 距边界足够远（≥ LEAD_LIGHT+MIN = 16s）：提前 LEAD_LIGHT 唤醒 */
    for (int iv = 1; iv <= 60; iv += (iv < 10 ? 4 : 11)) {
        int64_t b = mk_boundary(iv, 7);
        for (int d = PWR_SCHED_LEAD_LIGHT_S + PWR_SCHED_MIN_S; d < iv * 60; d += 37) {
            int64_t now = b - d;
            pwr_sched_in_t in = {0};
            in.box_iv_min = (uint32_t)iv;
            pwr_sched_out_t o;
            pwr_sched_next(now, &in, &o);
            CHECK(o.in_s > 0, "iv=%d d=%d in_s=%u", iv, d, o.in_s);
            CHECK((int64_t)o.in_s >= PWR_SCHED_MIN_S, "iv=%d d=%d min-gap %u",
                  iv, d, o.in_s);
            CHECK((int64_t)o.in_s == d - PWR_SCHED_LEAD_LIGHT_S,
                  "iv=%d d=%d light lead lost: in_s=%u want %d",
                  iv, d, o.in_s, d - PWR_SCHED_LEAD_LIGHT_S);
            CHECK(o.at_epoch == b, "iv=%d d=%d at=%lld want %lld",
                  iv, d, (long long)o.at_epoch, (long long)b);
            CHECK(o.event == PWR_EVT_BOX, "iv=%d d=%d evt=%u", iv, d, o.event);
        }
    }
}

static void test_box_light_imminent(void)
{
    /* 距边界 < LEAD_LIGHT+MIN = 16s：轻档放不下（退档 LEAD_MIN=10 更放不下，
       16 < 20）→ 一律贴边唤醒（in_s = MIN_S，at = 眼前边界）。 */
    for (int d = 1; d < PWR_SCHED_LEAD_LIGHT_S + PWR_SCHED_MIN_S; d++) {
        int iv = 5;
        int64_t b = mk_boundary(iv, 3);
        int64_t now = b - d;
        pwr_sched_in_t in = {0};
        in.box_iv_min = (uint32_t)iv;
        pwr_sched_out_t o;
        pwr_sched_next(now, &in, &o);
        CHECK(o.at_epoch == b, "d=%d at=%lld want %lld (imminent boundary)",
              d, (long long)o.at_epoch, (long long)b);
        CHECK((int64_t)o.in_s == PWR_SCHED_MIN_S, "d=%d in_s=%u want MIN_S",
              d, o.in_s);
        {
            int64_t wake = now + (int64_t)o.in_s;
            int64_t off = (wake > b) ? (wake - b) : (b - wake);
            CHECK(off < PWR_SCHED_MIN_S, "d=%d wake off-boundary %lld", d,
                  (long long)off);
        }
        CHECK(o.event == PWR_EVT_BOX, "d=%d evt=%u", d, o.event);
    }
    /* d=0（now 正好在边界上）：当前边界归醒着的 minute_cb，目标下个周期 */
    {
        int64_t b = mk_boundary(5, 3);
        pwr_sched_in_t in = {0};
        in.box_iv_min = 5;
        pwr_sched_out_t o;
        pwr_sched_next(b, &in, &o);
        CHECK(o.at_epoch == b + 300, "d=0 at=%lld", (long long)o.at_epoch);
        CHECK((int64_t)o.in_s == 300 - PWR_SCHED_LEAD_LIGHT_S, "d=0 in_s=%u",
              o.in_s);
    }
}

/* ---- 全功能事件（REMOTE/CAROUSEL/MOVE）分档 —— R2.6.x 语义回归 ---- */

static void test_full_lead_fits(void)
{
    /* 距边界足够远（≥ LEAD+MIN = 40s）：提前 LEAD 唤醒 */
    for (int iv = 5; iv <= 60; iv += (iv < 10 ? 5 : 11)) {
        int64_t b = mk_boundary(iv, 7);
        for (int d = PWR_SCHED_LEAD_S + PWR_SCHED_MIN_S; d < iv * 60; d += 41) {
            int64_t now = b - d;
            pwr_sched_in_t in = {0};
            in.rmt_iv_min = (uint32_t)iv;
            pwr_sched_out_t o;
            pwr_sched_next(now, &in, &o);
            CHECK(o.in_s > 0, "iv=%d d=%d in_s=%u", iv, d, o.in_s);
            CHECK((int64_t)o.in_s == d - PWR_SCHED_LEAD_S,
                  "iv=%d d=%d lead lost: in_s=%u want %d",
                  iv, d, o.in_s, d - PWR_SCHED_LEAD_S);
            CHECK(o.at_epoch == b, "iv=%d d=%d at=%lld want %lld",
                  iv, d, (long long)o.at_epoch, (long long)b);
            CHECK(o.event == PWR_EVT_REMOTE, "iv=%d d=%d evt=%u", iv, d, o.event);
        }
    }
}

static void test_full_lead_degrades(void)
{
    /* 距边界 LEAD_MIN+MIN..LEAD+MIN 之间（20..40s）：退 LEAD_MIN */
    for (int d = PWR_SCHED_LEAD_MIN_S + PWR_SCHED_MIN_S;
         d < PWR_SCHED_LEAD_S + PWR_SCHED_MIN_S; d++) {
        int64_t b = mk_boundary(10, 3);
        int64_t now = b - d;
        pwr_sched_in_t in = {0};
        in.rmt_iv_min = 10;
        pwr_sched_out_t o;
        pwr_sched_next(now, &in, &o);
        CHECK((int64_t)o.in_s == d - PWR_SCHED_LEAD_MIN_S,
              "d=%d in_s=%u want %d", d, o.in_s, d - PWR_SCHED_LEAD_MIN_S);
        CHECK(o.at_epoch == b, "d=%d at=%lld", d, (long long)o.at_epoch);
        CHECK(o.event == PWR_EVT_REMOTE, "d=%d evt=%u", d, o.event);
    }
}

static void test_full_imminent(void)
{
    /* 距边界 < LEAD_MIN+MIN = 20s：贴边唤醒（R2.6.1 语义） */
    for (int d = 1; d < PWR_SCHED_LEAD_MIN_S + PWR_SCHED_MIN_S; d++) {
        int64_t b = mk_boundary(10, 3);
        int64_t now = b - d;
        pwr_sched_in_t in = {0};
        in.move_iv_min = 10;
        pwr_sched_out_t o;
        pwr_sched_next(now, &in, &o);
        CHECK(o.at_epoch == b, "d=%d at=%lld", d, (long long)o.at_epoch);
        CHECK((int64_t)o.in_s == PWR_SCHED_MIN_S, "d=%d in_s=%u want MIN_S",
              d, o.in_s);
        CHECK(o.event == PWR_EVT_MOVE, "d=%d evt=%u", d, o.event);
    }
}

/* ---- ★R2.7.0 同边界抢断 ---- */

static void test_full_steals_shared_boundary(void)
{
    /* 同一整分边界 BOX 与全功能事件都命中：全功能必须赢（唤醒点更早，
       门控+补刷顺带覆盖分钟刷新）。覆盖整段 d：放得下 / 退档 / 贴边。 */
    int iv = 10;
    int64_t b = mk_boundary(iv, 11);             /* 两者共用的边界 */
    for (int d = 1; d < iv * 60; d += 7) {
        int64_t now = b - d;
        pwr_sched_in_t in = {0};
        in.box_iv_min = (uint32_t)iv;
        in.rmt_iv_min = (uint32_t)iv;
        pwr_sched_out_t o;
        pwr_sched_next(now, &in, &o);
        CHECK(o.event == PWR_EVT_REMOTE,
              "d=%d shared boundary stolen by BOX: evt=%u", d, o.event);
        CHECK(o.at_epoch == b, "d=%d at=%lld want %lld",
              d, (long long)o.at_epoch, (long long)b);
    }
    /* CAROUSEL / MOVE 同样抢断 */
    {
        int64_t now = b - 300;
        pwr_sched_in_t in = {0};
        in.box_iv_min = (uint32_t)iv;
        in.caro_iv_min = (uint32_t)iv;
        pwr_sched_out_t o;
        pwr_sched_next(now, &in, &o);
        CHECK(o.event == PWR_EVT_CAROUSEL, "caro steal evt=%u", o.event);
        in.caro_iv_min = 0;
        in.move_iv_min = (uint32_t)iv;
        pwr_sched_next(now, &in, &o);
        CHECK(o.event == PWR_EVT_MOVE, "move steal evt=%u", o.event);
    }
    /* 全功能之间同边界平局：先到先得（REMOTE > CAROUSEL > MOVE） */
    {
        int64_t now = b - 300;
        pwr_sched_in_t in = {0};
        in.rmt_iv_min = (uint32_t)iv;
        in.caro_iv_min = (uint32_t)iv;
        in.move_iv_min = (uint32_t)iv;
        pwr_sched_out_t o;
        pwr_sched_next(now, &in, &o);
        CHECK(o.event == PWR_EVT_REMOTE, "full tie evt=%u (want REMOTE first)",
              o.event);
    }
}

static void test_event_selection(void)
{
    /* 最近【唤醒时刻】者胜：不同边界按各自分档的唤醒点比较 */
    int64_t now = 8450;                          /* 分钟 140 */
    int64_t caro_b = (now / 60 / 5 + 1) * 5 * 60;    /* 145min 边界 */
    int64_t box_b  = (now / 60 / 30 + 1) * 30 * 60;  /* 150min 边界 */
    if (caro_b == box_b) { printf("test bug: pick another now\n"); fails++; return; }
    CHECK(caro_b < box_b, "test setup");
    pwr_sched_in_t in = {0};
    in.box_iv_min = 30;
    in.rmt_iv_min = 30;
    in.caro_iv_min = 5;                          /* 5min 边界更近 */
    pwr_sched_out_t o;
    pwr_sched_next(now, &in, &o);
    CHECK(o.event == PWR_EVT_CAROUSEL, "evt=%u", o.event);
    CHECK(o.at_epoch == caro_b, "at=%lld want %lld",
          (long long)o.at_epoch, (long long)caro_b);

    /* BOX 独享的边界（两个全功能边界之间）：轻唤醒赢出 */
    in.caro_iv_min = 0;
    in.rmt_iv_min = 0;
    pwr_sched_next(now, &in, &o);
    CHECK(o.event == PWR_EVT_BOX, "box alone evt=%u", o.event);
    CHECK(o.at_epoch == box_b, "box at=%lld want %lld",
          (long long)o.at_epoch, (long long)box_b);
    CHECK((int64_t)o.in_s == box_b - PWR_SCHED_LEAD_LIGHT_S - now,
          "box in_s=%u", o.in_s);
}

/* ---- wake_s（不对齐闹钟）与空输入 ---- */

static void test_wake_s(void)
{
    int64_t now = mk_boundary(10, 5) - 12345;
    pwr_sched_in_t in = {0};
    in.wake_s = 3600;
    pwr_sched_out_t o;
    pwr_sched_next(now, &in, &o);
    CHECK(o.event == PWR_EVT_WAKE, "evt=%u", o.event);
    CHECK(o.in_s == 3600, "in_s=%u", o.in_s);
    CHECK(o.at_epoch == now + 3600, "at=%lld", (long long)o.at_epoch);

    in.wake_s = 3;                                /* 保底 MIN_S */
    pwr_sched_next(now, &in, &o);
    CHECK(o.in_s == PWR_SCHED_MIN_S, "floor in_s=%u", o.in_s);

    in.wake_s = 0;                                /* 无事件 */
    pwr_sched_next(now, &in, &o);
    CHECK(o.in_s == 0 && o.event == PWR_EVT_NONE && o.at_epoch == 0,
          "empty not zero: %u/%u/%lld", o.in_s, o.event, (long long)o.at_epoch);
}

/* ---- 补刷窗口（R2.6.1 语义回归） ---- */

static void test_missed(void)
{
    int64_t tgt = mk_boundary(10, 9);             /* 目标边界 */
    CHECK(!pwr_sched_missed(tgt - 1, tgt, 10), "before boundary");
    CHECK(pwr_sched_missed(tgt, tgt, 10), "at boundary");
    CHECK(pwr_sched_missed(tgt + 599, tgt, 10), "same slot tail");
    /* ★R2.6.1：窗口右端扩 1 分钟 —— 慢漂+慢门控下边界落后 60s+ 仍可补 */
    CHECK(pwr_sched_missed(tgt + 600, tgt, 10), "+1min now in window");
    CHECK(pwr_sched_missed(tgt + 659, tgt, 10), "+1min tail");
    CHECK(!pwr_sched_missed(tgt + 660, tgt, 10), "beyond +1min");
    CHECK(!pwr_sched_missed(tgt, tgt, 0), "iv=0");
    CHECK(!pwr_sched_missed(tgt, 0, 10), "no target");
    /* RTC 慢漂兜底：30min 档漂 3 分钟仍在窗口内 */
    CHECK(pwr_sched_missed(tgt + 180, tgt, 30), "slow drift 30min slot");
    /* 1 分钟档：门控把边界落后 60s+（漂移 + 慢路由 + 贴边唤醒叠加）
       仍在扩 1 分钟的窗口内 —— 「时钟偶尔不跳」的兜底 */
    CHECK(pwr_sched_missed(tgt + 60, tgt, 1), "iv=1 +60s still catches up");
    CHECK(pwr_sched_missed(tgt + 119, tgt, 1), "iv=1 +119s still catches up");
    CHECK(!pwr_sched_missed(tgt + 120, tgt, 1), "iv=1 +120s out");
}

int main(void)
{
    test_box_light_lead_fits();
    test_box_light_imminent();
    test_full_lead_fits();
    test_full_lead_degrades();
    test_full_imminent();
    test_full_steals_shared_boundary();
    test_event_selection();
    test_wake_s();
    test_missed();
    if (fails) { printf("%d FAIL(S)\n", fails); return 1; }
    printf("pwr_sched v2.7.0: all passed\n");
    return 0;
}
