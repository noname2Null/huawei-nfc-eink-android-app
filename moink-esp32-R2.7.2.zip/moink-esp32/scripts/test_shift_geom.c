/*
 * R2.6.0 换位让位几何主机单测：4 方向 × 框上/下 × 本地分割 / 远端分割 ×
 * 让位开/关 —— 逐像素对拍「provider 管线输出」vs「用户画布金样模型」。
 *
 * 金样（zone_core 已证明原语 zc_u2prov / zc_prov2u 推导）：
 *   display(ux,uy) = 区内 ? 区图案
 *                   : payload_user(ux, uy + 让位?160:0)
 *   （payload_user = u2prov(ux,uy') → provider 坐标 → 镜像逆映射到载荷字节/组）
 *
 * 管线仿真（复刻 frame.c frame_row_provider + overlay_strip_blend 的
 * 让位分支，调真实的 zc_shift_payload_row / zc_shift_row_bytes / zc_blend_row）：
 *   本地分割：载荷 552×192；让位时行号走 zc_shift_payload_row；
 *   远端分割：子帧存储按 MKRP 文档布局（o0/o2: 552×152B 段；o1/o3: 392×192B
 *   段 = 载荷行 0..391 / 160..551），让位时 o1/o3 段号 ±160 互换。
 *
 * 覆盖了用户反馈的呈现修复：框挪到「下」时照片整体上移 160 用户行，
 * 不再出现「顶部留白 + 照片底部被压」。
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "zone_core.h"

#define RROWS 552
#define RBYTES 192
#define HBAR 160            /* ZC_HBAR_H */
#define SEM 40              /* 160/4 载荷字节 */

static int fails = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { fails++; \
        printf("FAIL %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } \
} while (0)

static uint8_t payload[RROWS][RBYTES];     /* 分割帧载荷（本地路径的 flash） */
static uint8_t sub[RROWS * RBYTES];        /* 远端子帧存储（段序连续） */
static uint8_t rot[RBYTES];                /* provider 行（旋转视图） */

static uint32_t rnd_state = 0x1234abcdu;
static uint8_t rnd_byte(void)
{
    rnd_state = rnd_state * 1664525u + 1013904223u;
    return (uint8_t)(rnd_state >> 24);
}

/* epd_drv.row_mirror(flip=false) 复刻：字节倒序 + 字节内 2bit 组倒序 */
static void mirror_row(uint8_t *dst, const uint8_t *src, int n)
{
    for (int i = 0; i < n; i++) {
        uint8_t s = src[n - 1 - i];
        dst[i] = (uint8_t)(((s & 0x03) << 6) | ((s & 0x0C) << 2) |
                           ((s & 0x30) >> 2) | ((s & 0xC0) >> 6));
    }
}

/* 载荷用户像素（金样原语）：u2prov → provider 坐标 → 镜像逆映射 */
static int payload_user_px(int orient, int ux, int uy)
{
    int r, j, g;
    zc_u2prov(orient, ux, uy, &r, &j, &g);
    uint8_t b = payload[RROWS - 1 - r][RBYTES - 1 - j];
    return (b >> (6 - 2 * (3 - g))) & 3;
}

/* 把用户行 [0,HBAR)（分割白边）写白 —— 按 orient 换算载荷坐标 */
static void whiten_margin(int orient, int cw)
{
    for (int uy = 0; uy < HBAR; uy++)
        for (int ux = 0; ux < cw; ux++) {
            int r, j, g;
            zc_u2prov(orient, ux, uy, &r, &j, &g);
            uint8_t *b = &payload[RROWS - 1 - r][RBYTES - 1 - j];
            int sh = 6 - 2 * (3 - g);
            *b = (uint8_t)((*b & ~(3 << sh)) | (1 << sh));   /* 白 = 01 */
        }
}

/* 按方向把远端子帧从载荷摘出（与 PC 工具打包 / remote.h 文档一致） */
static void build_sub(int orient)
{
    for (int s = 0; s < RROWS; s++) {
        if (orient == 0) memcpy(sub + (size_t)s * 152, payload[s] + SEM, 152);
        else if (orient == 2) memcpy(sub + (size_t)s * 152, payload[s], 152);
    }
    if (orient == 1 || orient == 3) {
        int segs = RROWS - HBAR;                       /* 392 */
        for (int s = 0; s < segs; s++) {
            int prow = (orient == 1) ? s : (s + HBAR); /* o1: 行 0..391 / o3: 行 160..551 */
            memcpy(sub + (size_t)s * RBYTES, payload[prow], RBYTES);
        }
    }
}

static int zone_pattern(int ux, int uy) { return (ux * 3 + uy * 7) & 3; }

static void setup_zone(int orient, int pos, int cw, int ch, zc_rect_t *zone)
{
    if (pos == 0) *zone = (zc_rect_t){ 0, 0, (int16_t)cw, HBAR };
    else          *zone = (zc_rect_t){ 0, (int16_t)(ch - HBAR), (int16_t)cw, HBAR };
    zc_zone_set(orient, zone);
    for (int uy = zone->y; uy < zone->y + zone->h; uy++)
        for (int ux = zone->x; ux < zone->x + zone->w; ux++)
            zc_px_set(ux, uy, zone_pattern(ux, uy));
    zc_capture_done();                                  /* 区内容有效（图案） */
}

/* 金样：display(r,j,g) 应显示什么 */
static int golden(int orient, int shift, int r, int j, int g, const zc_rect_t *zone)
{
    int ux, uy;
    zc_prov2u(orient, r, j, g, &ux, &uy);
    if (ux >= zone->x && ux < zone->x + zone->w &&
        uy >= zone->y && uy < zone->y + zone->h)
        return zone_pattern(ux, uy);
    int uy2 = shift ? uy + HBAR : uy;
    if (uy2 >= 768) return 1;                           /* 白（防御，不应触发） */
    return payload_user_px(orient, ux, uy2);
}

/* 本地分割 provider 行（复刻 frame.c 分支 + overlay_strip_blend 让位） */
static void local_row(int orient, int r, bool shift)
{
    if (shift) {
        int pr = zc_shift_payload_row(orient, r);
        if (pr < 0) { memset(rot, 0x55, RBYTES); goto blend; }
        mirror_row(rot, payload[pr], RBYTES);
    } else {
        mirror_row(rot, payload[RROWS - 1 - r], RBYTES);
    }
blend:
    if (shift) zc_shift_row_bytes(orient, rot);
    zc_blend_row(rot, r);
}

/* 远端分割 provider 行（复刻 frame.c 分支 + 让位段号互换） */
static void remote_row(int orient, int r, bool shift)
{
    int pr = RROWS - 1 - r;
    if (orient == 0 || orient == 2) {
        uint8_t raw[152];
        memcpy(raw, sub + (size_t)pr * 152, 152);
        mirror_row(rot, raw, 152);
        if (orient == 0) memset(rot + 152, 0x55, SEM);
        else { memmove(rot + SEM, rot, 152); memset(rot, 0x55, SEM); }
    } else {
        int segs = RROWS - HBAR;
        int srow = (orient == 1) ? (shift ? (pr - HBAR) : pr)
                                 : (shift ? pr : (pr - HBAR));
        if (srow >= 0 && srow < segs) {
            uint8_t raw[RBYTES];
            memcpy(raw, sub + (size_t)srow * RBYTES, RBYTES);
            mirror_row(rot, raw, RBYTES);
        } else {
            memset(rot, 0x55, RBYTES);
        }
    }
    if (shift) zc_shift_row_bytes(orient, rot);
    zc_blend_row(rot, r);
}

static void run_case(int orient, int pos, int remote, int shift)
{
    int cw = (orient == 1 || orient == 3) ? 768 : 552;
    int ch = (orient == 1 || orient == 3) ? 552 : 768;

    /* 载荷：伪随机 + 顶部白边（分割契约） */
    rnd_state = 0x1234abcdu ^ (uint32_t)(orient * 7 + pos * 3 + remote * 11 + shift);
    for (int r = 0; r < RROWS; r++)
        for (int b = 0; b < RBYTES; b++) payload[r][b] = rnd_byte();
    whiten_margin(orient, cw);
    if (remote) build_sub(orient);

    zc_rect_t zone;
    setup_zone(orient, pos, cw, ch, &zone);

    long bad = 0;
    for (int r = 0; r < RROWS; r++) {
        if (remote) remote_row(orient, r, shift);
        else        local_row(orient, r, shift);
        for (int j = 0; j < RBYTES; j++)
            for (int g = 0; g < 4; g++) {
                int got = (rot[j] >> (6 - 2 * g)) & 3;
                int want = golden(orient, shift, r, j, g, &zone);
                if (got != want) {
                    if (bad < 6)
                        printf("  mismatch o%d pos%d %s shift%d r=%d j=%d g=%d "
                               "got=%d want=%d\n", orient, pos,
                               remote ? "remote" : "local", shift, r, j, g,
                               got, want);
                    bad++;
                }
            }
    }
    CHECK(bad == 0, "o%d pos%d %s shift%d: %ld mismatched pixels",
          orient, pos, remote ? "remote" : "local", shift, bad);
}

int main(void)
{
    int cases = 0;
    for (int orient = 0; orient < 4; orient++) {
        for (int pos = 0; pos < 2; pos++) {          /* 0=框上 1=框下 */
            for (int remote = 0; remote < 2; remote++) {
                run_case(orient, pos, remote, 0);    /* 未让位（回归：原行为） */
                if (pos == 1)                        /* 让位只在框「下」生效 */
                    run_case(orient, pos, remote, 1);
                cases++;
            }
        }
    }
    if (fails) { printf("%d FAIL(S) over %d cases\n", fails, cases); return 1; }
    printf("shift geom: all %d cases passed (4 orient x pos x local/remote x shift)\n",
           cases);
    return 0;
}
