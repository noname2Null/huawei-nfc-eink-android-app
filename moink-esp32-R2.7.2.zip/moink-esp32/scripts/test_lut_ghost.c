/*
 * R2.6.1 LUT 主机单测：lut_build_num_ghost 清理配方多轮化 + 既有表回归。
 *
 * 判据：
 *   - ghost 表 H2/H3/H5 三路的字段逐个解码对拍（G=rounds、Mode0 正场预脉冲
 *     P3 + Mode1 目标段 N3/L00 各 3 扫描、RA=RB=1、计划扫描数 = 6×rounds）；
 *   - rounds=1 与 lut_build_num_clean 逐字节同构（六扫描清理配方本尊，
 *     ref docs/06 §5 真机验证过的配方 = 多轮化的单轮基线）；
 *   - 轮数钳位（0→1、>6→6）；
 *   - lut_build_num / lut_build_num_clean 既有配方零回归（防误伤）；
 *   - lut_self_check 自检仍过。
 */
#include <stdio.h>
#include <string.h>
#include "lut_r20.h"

static int fails = 0;
#define CHECK(cond, ...) do { \
    if (!(cond)) { fails++; \
        printf("FAIL %d: ", __LINE__); printf(__VA_ARGS__); printf("\n"); } \
} while (0)

/* 解码某路首状态的 11 个逻辑字节（与 lut_table_set_state 写入序一致） */
static void decode_state(const uint8_t *tbl, int lane, int slot, uint8_t out[11])
{
    const uint8_t *p = tbl + 7 + 88 * lane + 11 * slot;
    for (int i = 0; i < 11; i++) out[i] = lut_wire_decode(p[i]);
}

static unsigned scans_of(const uint8_t *tbl, int lane)
{
    uint8_t d[11];
    decode_state(tbl, lane, 0, d);
    lut_state_t st = {
        .g = d[0],
        .level = { (uint8_t)((d[1] >> 6) & 3), (uint8_t)((d[1] >> 4) & 3),
                   (uint8_t)((d[1] >> 2) & 3), (uint8_t)((d[2] >> 6) & 3),
                   (uint8_t)((d[2] >> 4) & 3), (uint8_t)((d[2] >> 2) & 3) },
        .frames = { d[3], d[4], d[5], d[7], d[8], d[9] },
        .ra = d[6], .rb = d[10],
    };
    return lut_state_scans(&st);
}

static void check_ghost(unsigned rounds)
{
    uint8_t tbl[LUT_R20_BYTES];
    uint8_t d[11];
    lut_build_num_ghost(tbl, (uint8_t)rounds);

    /* H2（码01 黑目标）：G=rounds，A=L01(Mode0 正场)×3，D=L00×3，RA=RB=1
       —— 清理配方黑路：P3 驱动 + Mode1 段静默。 */
    decode_state(tbl, LANE_H2, 0, d);
    CHECK(d[0] == rounds, "H2 g=%u want %u", d[0], rounds);
    CHECK(d[1] == (uint8_t)(LVL_L01 << 6), "H2 abc=%02x", d[1]);
    CHECK(d[2] == (uint8_t)(LVL_L00 << 6), "H2 def=%02x", d[2]);
    CHECK(d[3] == 3 && d[4] == 0 && d[5] == 0, "H2 ABC=%u/%u/%u", d[3], d[4], d[5]);
    CHECK(d[7] == 3 && d[8] == 0 && d[9] == 0, "H2 DEF=%u/%u/%u", d[7], d[8], d[9]);
    CHECK(d[6] == 1 && d[10] == 1, "H2 ra=%u rb=%u", d[6], d[10]);

    /* H3（码10 白目标）：G=rounds，A=L01(Mode0 正场预脉冲)×3，D=L10(Mode1
       负场)×3 —— 正负交变：旧黑残影的正场回收 + 负场拉白（黑像素残影的
       针对性解法，R2.6.0 纯 L10 重复的替换）。 */
    decode_state(tbl, LANE_H3, 0, d);
    CHECK(d[0] == rounds, "H3 g=%u", d[0]);
    CHECK(d[1] == (uint8_t)(LVL_L01 << 6), "H3 abc=%02x (pre-pulse)", d[1]);
    CHECK(d[2] == (uint8_t)(LVL_L10 << 6), "H3 def=%02x (Mode1 pull)", d[2]);
    CHECK(d[3] == 3 && d[7] == 3 && d[6] == 1 && d[10] == 1,
          "H3 frames ra rb %u %u %u %u", d[3], d[7], d[6], d[10]);

    /* H5（source 供电）：Mode0×3 + Mode1×3 × rounds（第二段 Mode1 供出
       白路负场电压 VSN_1 = R01 第 5 参数）。 */
    decode_state(tbl, LANE_H5, 0, d);
    CHECK(d[0] == rounds, "H5 g=%u", d[0]);
    CHECK(d[1] == (uint8_t)(SUPPLY_MODE0 << 6), "H5 abc=%02x", d[1]);
    CHECK(d[2] == (uint8_t)(SUPPLY_MODE1 << 6), "H5 def=%02x", d[2]);
    CHECK(d[3] == 3 && d[7] == 3, "H5 frames %u %u", d[3], d[7]);

    /* 计划扫描数 = rounds × (3 + 3)：仅 H2/H3/H5（H4 备用路保持终止） */
    CHECK(scans_of(tbl, LANE_H2) == 6u * rounds,
          "H2 scans=%u want %u", scans_of(tbl, LANE_H2), 6u * rounds);
    CHECK(scans_of(tbl, LANE_H3) == 6u * rounds,
          "H3 scans=%u want %u", scans_of(tbl, LANE_H3), 6u * rounds);
    CHECK(scans_of(tbl, LANE_H5) == 6u * rounds,
          "H5 scans=%u want %u", scans_of(tbl, LANE_H5), 6u * rounds);
    CHECK(scans_of(tbl, LANE_H4) == 0, "H4 must stay terminated");

    /* H1（码00 保持）必须保持终止（全 FF 底板未动） */
    decode_state(tbl, LANE_H1, 0, d);
    CHECK(d[0] == 0, "H1 g=%u (keep lane must terminate)", d[0]);
}

static void check_rounds1_is_clean(void)
{
    /* ★R2.6.1 核心不变量：rounds=1 与 lut_build_num_clean 逐字节同构 ——
       多轮化 = 单轮验证配方的纯粹重复，不带任何未验证的波形改动。 */
    uint8_t a[LUT_R20_BYTES], b[LUT_R20_BYTES];
    lut_build_num_ghost(a, 1);
    lut_build_num_clean(b);
    CHECK(memcmp(a, b, LUT_R20_BYTES) == 0, "ghost(1) != num_clean (byte level)");
}

static void check_regress_num(void)
{
    uint8_t tbl[LUT_R20_BYTES];
    uint8_t d[11];
    lut_build_num(tbl);
    decode_state(tbl, LANE_H2, 0, d);
    CHECK(d[0] == 1 && d[1] == (uint8_t)(LVL_L01 << 6) &&
          d[3] == 3 && d[6] == 1 && d[7] == 0,
          "num H2 regressed: g=%u abc=%02x A=%u ra=%u D=%u",
          d[0], d[1], d[3], d[6], d[7]);
    CHECK(scans_of(tbl, LANE_H2) == 3 && scans_of(tbl, LANE_H3) == 3,
          "num scans regressed");
}

static void check_regress_clean(void)
{
    uint8_t tbl[LUT_R20_BYTES];
    uint8_t d[11];
    lut_build_num_clean(tbl);
    decode_state(tbl, LANE_H3, 0, d);
    CHECK(d[0] == 1 && d[1] == (uint8_t)(LVL_L01 << 6) &&
          d[2] == (uint8_t)(LVL_L10 << 6) && d[3] == 3 && d[7] == 3,
          "clean H3 regressed: g=%u abc=%02x def=%02x A=%u D=%u",
          d[0], d[1], d[2], d[3], d[7]);
    CHECK(scans_of(tbl, LANE_H3) == 6, "clean H3 scans=%u", scans_of(tbl, LANE_H3));
}

int main(void)
{
    CHECK(lut_self_check(), "self check");

    for (unsigned r = 1; r <= 6; r++) check_ghost(r);

    /* rounds=1 ≡ 清理配方（字节级不变量，先于钳位测试锁定） */
    check_rounds1_is_clean();

    /* 钳位：0 → 1；>6 → 6 */
    uint8_t tbl[LUT_R20_BYTES];
    lut_build_num_ghost(tbl, 0);
    CHECK(scans_of(tbl, LANE_H2) == 6, "clamp 0 -> 1");
    lut_build_num_ghost(tbl, 9);
    CHECK(scans_of(tbl, LANE_H2) == 36, "clamp 9 -> 6");

    /* 默认档（overlay OVL_FAST_DRIVE_ROUNDS=3）= 18 扫描 ≈ 150ms @120Hz */
    lut_build_num_ghost(tbl, 3);
    CHECK(scans_of(tbl, LANE_H2) == 18, "default rounds");

    check_regress_num();
    check_regress_clean();

    if (fails) { printf("%d FAIL(S)\n", fails); return 1; }
    printf("lut ghost: all passed (clean-recipe rounds 1..6 + regressions)\n");
    return 0;
}
