# 移植说明 — ESP32-C3 → ESP32（WROOM-32 / ESP32-D0WDQ6）

本文档记录从上游 [atunverse/moink](https://github.com/atunverse/moink)（R1.3.4，ESP32-C3 SUPERMINI）
移植到经典 ESP32 的**全部改动点**，供后续维护与排错参考。

硬件前提：
- 主控：ESP-WROOM-32 模组（芯片 ESP32-D0WDQ6，Xtensa LX6 双核，无 PSRAM，4MB Flash）
- 屏幕：SE0398NZ07-FNG-A0（华为 Nova 14 墨水屏手机壳拆机屏，3.98" 768×552 黑白黄红四色，JDY79668 协议）
  —— 正是上游项目默认支持的 **A0 画像**（隔行半屏 Y 映射），驱动逻辑零改动。
- 接线：DIN=GPIO23 / CLK=GPIO18 / CS=GPIO5 / DC=GPIO16 / RST=GPIO17 / BUSY=GPIO27
- 供电：USB 常开，无电池、无唤醒按键、无屏幕电源使能脚。

---

## 0. 为什么能移植：不变的部分

| 部分 | 原因 |
|------|------|
| **epd_drv.c/h 屏幕驱动** | SPI 协议 + GPIO 操作与芯片无关；A0 画像正是本屏；引脚 R1.2.2 起运行时从 NVS 读 |
| **frame.c/h 帧协议** | 纯 HTTP + 内存运算（CRC16 / 几何校验） |
| **captive.c/h DNS 劫持** | 纯 lwIP socket |
| **netif_ap.c/h SoftAP** | esp_wifi/esp_netif API 跨芯片一致 |
| **store.c/h 轮播图库** | 纯 esp_partition + NVS |
| **ota_web.c 大部分** | esp_ota/partition API 一致（仅芯片 ID 校验差异） |
| **index_html.h 控制页** | 768×552 四色页面与屏一致，纯浏览器端 |
| **partitions.csv 分区表** | 4MB 布局，WROOM-32（4MB）完全兼容 |

GPIO18/23 恰好是 ESP32 的 **VSPI 默认 SCK/MOSI** 脚位，SPI 信号矩阵直通，无需任何路由配置。

## 1. 构建系统：PlatformIO → 纯 ESP-IDF

- 删除 `platformio.ini` 与 `sdkconfig.moink`（C3 专用整包配置）。
- 目录从 PIO 的 `src/` 改为标准 ESP-IDF 的 `main/` 组件目录；顶层 `CMakeLists.txt` 的
  `project(moink)` → `project(moink_esp32)`。
- `sdkconfig.defaults`（重建）：
  - `CONFIG_ESP_CONSOLE_USB_SERIAL_JTAG=y` → **`CONFIG_ESP_CONSOLE_UART_DEFAULT=y`**
    （ESP32-D0WDQ6 没有 USB-Serial-JTAG 外设；开发板板载 USB 转串口芯片接 UART0 = GPIO1/3）
  - 日志 `ERROR` → **`INFO`**（排错友好；稳定后可改回）
  - 显式写入 `CONFIG_IDF_TARGET="esp32"`（双保险）
  - 保留：4MB/DIO/40M flash、自定义分区表、OTA 回滚、RTC 内部 RC 时钟、编译体积优化

## 2. settings.h/.c — 引脚系统整体改写

| 项 | C3 原版 | ESP32 移植版 |
|----|---------|-------------|
| PIN_PRESETS[0] 默认档 | ADC0/WAKE5/SCK4/MOSI6/CS7/DC1/RST3/BUSY10 | **ADC34/WAKE25/SCK18/MOSI23/CS5/DC16/RST17/BUSY27** |
| PIN_PRESETS[1] 排线 | C3 排线接法 | 备用 A（VSPI 经典脚位 SCK14/MOSI13/CS15/DC22/RST21/BUSY27） |
| PIN_PRESETS[2] 整合板 | C3 整合板接法 | 备用 B（同默认 SPI 脚，ADC36/WAKE32/DC19/RST4/BUSY33） |
| pin_io_allowed | io ≤ 10 且 ≠ 2 | 白名单 {4,5,13..19,21..23,25..27,32,33}（可输出脚） |
| pin_adc_allowed | io ≤ 4（GPIO0..4=ADC1_CH0..4 等值） | {32..36,39}（查表映射，37/38 WROOM 未引出） |
| pin_wake_allowed | io ≤ 5（RTC 域） | {4,5,13..15,25..27,32..36,39}（RTC 域） |
| PIN_SELF_LOCK（GPIO2 自锁） | 存在 | **删除** |

GPIO 排除理由（ESP32）：6..11 片内 flash；1/3 UART0（下载/日志）；0 BOOT strapping；
**2 strapping（保持低才能进 UART 下载模式，固件占用会让下次刷机失败）**；
12 strapping（flash 电压选择，拉高会砖）；34..39 仅输入；20/24/37/38 WROOM-32 未引出。

默认值变化：
- `sleep_s`：`SETT_SLEEP_3MIN` → **`SETT_SLEEP_OFF`**（USB 常开，不休眠）
- `wifi_pwr`：`LOW(8.5dBm)` → **`HIGH(18dBm)`**（C3 低功率是 supermini 板级天线补丁，
  ESP32 开发板天线正常，用满功率连接更稳；页面仍可改）

## 3. power.c/.h — ADC 与深睡

1. **ADC 通道映射**：C3 上 `GPIO0..4 = ADC1_CH0..4` 可以直接把引脚号当通道号；
   ESP32 上是乱序的，新增查表函数 `gpio_to_adc1_ch()`：
   GPIO36=CH0, GPIO39=CH3, GPIO32=CH4, GPIO33=CH5, GPIO34=CH6, GPIO35=CH7。
2. **深睡唤醒**：`esp_sleep_enable_gpio_wakeup_on_hp_periph_powerdown()`（C3/C5/C6 专用 API）
   → **`esp_sleep_enable_ext0_wakeup(pin, 0)`**（经典 ESP32 标准 GPIO 深睡唤醒，低电平有效）。
3. **删除自锁**：深睡前 `gpio_hold_en(GPIO2)` + `gpio_deep_sleep_hold_en()` 整块删除。
4. **power_self_lock_off()**：不再拉低 GPIO2（会影响下载模式），直接退回深睡。
5. `power_wakeup_causes()` 返回类型 `uint32_t` → `uint64_t`（与 `esp_sleep_get_wakeup_causes()` 一致）。

电池检测逻辑保留（分压 1M:1M、12 次采样中位数、极差判悬空）；无电池时 GPIO34 悬空，
自动返回 -1，页面显示「未连接」。

## 4. main.c

1. **删除 app_main() 开头的 GPIO2 自锁块**（上电拉高 GPIO2 会让下次复位无法进入
   UART 下载模式 = 刷不了机，绝对不能保留）。
2. **修正 wake_src_from_bits()**：原版 `bits & (1u << ESP_SLEEP_WAKEUP_GPIO)` 对
   `esp_sleep_source_t` 枚举做了**双重移位**（枚举值本身已是 `1ull<<n` 位掩码，
   再移位在 32 位上是未定义行为）。改为直接按位或枚举值比较，并补充 ESP32 按键
   深睡唤醒实际置位的 **EXT0/EXT1** 位（ESP32 按键唤醒走 ext0）。
3. `s_wake_bits` 类型 `uint32_t` → `uint64_t`；`/api/info` 打印 `%lu` → `%llu`。

其余（按键识别状态机、轮播事件队列、HTTP 路由、CORS、OTA 确认）零改动。

## 5. ota_web.c

- OTA 最小镜像校验的芯片 ID：`0x0005`（ESP32-C3）→ **`0x0000`（ESP32）**。
  作用：即使把 C3 固件通过页面「上传并升级」传到 ESP32，也会被此校验拒绝，
  不会变砖；反向同理。

## 6. version.h

- 追加「ESP32 移植版」变更记录；`MOINK_VERSION` 保持 `"R1.3.4"`、`MOINK_API_VERSION`
  保持 2（帧协议与页面版本零变动，避免页面「热更页落后于固件」误报）。
- 平台混淆风险由 OTA 芯片 ID 校验兜底。

## 7. 未改动文件的芯片相关性复核

- `epd_drv.c`：`SPI2_HOST` 在 ESP32 上即 HSPI；`spi_device_polling_transmit` 等 API 一致；
  `max_transfer_sz=4096`（VSPI 支持）；`SPI_HZ=4MHz` 保守值不变。
- `netif_ap.c`：信道 6 的选择（C3 晶振谐波规避）对 ESP32 无副作用，保留。
- `frame.c/captive.c/store.c`：仅用 esp_http_server / lwIP / esp_partition / NVS。

## 8. 已知行为差异（预期内）

| 现象 | 说明 |
|------|------|
| 电池显示「未连接」 | 未接电池分压，GPIO34 悬空，预期行为 |
| 深睡后按页面默认设置不会再发生 | 默认不休眠；要深睡需页面里把「超时」改为 1/3/5 分钟 |
| 「关机」超时动作效果=深睡 | 无 MOS 自锁电路，「关机」档退回深睡 |
| 日志走 USB 转串口（115200） | ESP32 无 USB-JTAG；插上 USB 线即可在 monitor 看到 |

## 9. 上游同步建议

上游更新后，按以下顺序合并：
1. 先比对 `epd_drv.c`（若协议变化）与 `page/index.html` → 重新生成 `index_html.h`
   （上游 tools/make_index_header.py）。
2. 再比对 `frame.c / store.c / captive.c / netif_ap.c`（芯片无关，直接同步）。
3. `settings.c / power.c / main.c / ota_web.c` 同步时**保留本文件的改动点**
   （引脚预设、白名单、ADC 映射、ext0、无自锁、芯片 ID 0x0000、wake bitmap 修正）。

## R2.0.0 增量改动（2026-10-29，功能扩展）

在 R1.3.4 ESP32 移植版基础上的新增/修改，帧格式（api=2）与 NVS 旧键不变；
★ R2.2.0 起分区表已变更（OTA 槽 1.5M×2 / web 256K / store 704K=5 槽，
见 partitions.csv 与 README 的 R2.2.0 节）：

1. **方向修复（frame.c）**：入图 CRC 校验通过后对帧做一次 180° 旋转（`frame_rotate_180()`），
   修正该屏批次安装方向与上游 180° 缓冲契约相反导致"必须手动旋转"的问题。
   驱动写入序列零改动（真机验证过的部分绝不碰）。旧固件存的图库照片仍是旧方向，重新上传即可。
2. **wifi_mgr.c（新）**：AP/STA 双模式。有 STA 凭据则 AP+STA 并开重试加入（10 次失败回落热点；
   连上切 WIFI_MODE_STA 关热点）；mDNS（moink.local）；SNTP（esp_netif_sntp，TZ=CST-8）；
   外网探测（gethostbyname("www.baidu.com")）。netif_ap.c 拆分为 setup/apply 从属模块，
   captive.c 增加 dns_stop 与 STA 模式退位（不再劫持跳转 192.168.4.1）。
3. **auth.c（新）**：Basic 认证（用户名任意、密码 6 位数字），所有业务路由挂闸；
   /api/pwdreset 免认证触发屏上重置（overlay 红字两阶段）。
4. **ble_sensor.c（新）**：NimBLE observer 连续被动扫描；MiBeacon v5 解密
   （AES-CCM：nonce=MAC(6,小端)+pid(2)+帧计数(1)+扩展计数(3)，AAD=0x11，MIC=4B，
   逐字段对照 ESPHome xiaomi_ble 实现）；只解析绑定 MAC；TLV 值类型
   0x100D/0x1004/0x1006/0x100A/0x4803/0x4C01/0x4C02/0x4C08。
5. **overlay.c（新）**：信息框渲染/分钟调度/密码重置屏。坐标推导（关键！）：
   页面 canvas 552x768(竖屏) --rotateCW--> 768x552 --packIdx--> 契约缓冲，
   叠加固件入图 180° 后映射为 **s_fb(row=dx, col=767-dy)**；顶部条带 = 每缓冲行末 40 字节。
   条带 RAM 备份（21KB）保证重置屏覆盖后可完整还原照片。
   字体：font8x8（公有领域）+ 手绘 12x12 中文点阵 14 字。
6. **settings.c**：新增 sta_ssid/sta_pass/web_pass/box_en/box_density/box_iv/ble_mac/ble_key。
7. **构建**：main/CMakeLists 增 bt mdns mbedtls esp_phy 组件；sdkconfig.defaults 启用
   NimBLE observer-only。mdns 自 IDF v6 起不再是内核组件，经组件管理器拉取
   （main/idf_component.yml，espressif/mdns ^1.14.1，仅 IDF>=6.0 生效，v5.x 自动跳过）。
   首次配置需联网；顶层 CMakeLists 显式 set(PROJECT_VER "R2.0.0")，非 git 环境不再警告。
8. **页面（page/index.html → index_html.h）**：三张新卡片（配网/密码/传感器信息框）、
   首次密码引导、cropRot 归零迁移（rotfix2）、取图预览信息框覆盖层。
