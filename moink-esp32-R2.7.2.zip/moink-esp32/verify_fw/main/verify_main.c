/*
 * 墨印 MoInk 功能验证固件（VERIFY-R1.1）
 *
 * 目的：把用户实测反馈的四个问题在最小固件里逐项隔离验证——
 *   ① 信息框「局部刷新」实际仍是全局刷新  → 数字局刷演示（两档：寄存器
 *      LUT 快速局刷 / 工厂 LUT 窗口局刷），串口逐次打印 DRF 时长；
 *   ② 黄黑色的灰度无测试点                → 灰度色带演示（黑→白剂量带 +
 *      黄→白剂量带，每条带的配方与剂量全部打印到串口）；
 *   ③ 串口日志从未见进入睡眠              → 演示结束显式进入深度睡眠并
 *      倒计时播报（无唤醒源，断电重上电 = 下一场）；
 *   ④ 发热                                → 本固件无 WiFi/BLE/HTTP，若仍
 *      发热则热源在供电/屏升压而非 SoC 负载。
 *
 * 上电行为（用户规格）：
 *   - 每次「断电再上电」在两场演示间切换：数字局刷 ↔ 灰度色带；
 *   - 切换状态存 NVS（命名空间 moink、键 vdemo）——掉电即失的 RAM 做不到
 *     跨断电记忆，闪存标志位是唯一途径；
 *   - 数字演示：字号 24（8x8 点阵整倍放大 3 倍）的三位随机数，黑字白底、
 *     屏幕正中央，上电只跑 10 个并在串口打印；
 *   - 灰度演示：黑色→白色的灰度色带 + 黄色→白色的灰度色带。
 *
 * 波形技术来源：ref/jd79665aa-driver（SE0398NZ07A1 四色屏 JD79665AA 逆向
 * 研究）。注意该研究基于 A1 画像控制器；本固件在用户的 A0（JD79668）画像
 * 上以「空表探针」先行验证寄存器 LUT 是否被接受，不接受则自动回退工厂
 * LUT 演示并把判定过程全部打印。
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_random.h"
#include "esp_sleep.h"
#include "esp_timer.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "nvs.h"
#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_partition.h"
#include "esp_heap_caps.h"

#include "epd_vdrv.h"
#include "lut_r20.h"
#include "font_dig8.h"

#define VERIFY_FW_VER   "VERIFY-R1.1（基于主固件 R2.2.2 驱动 + jd79665aa 波形研究）"

/* ================= 配置（NVS 命名空间 moink，与主固件同池不冲突） ================ */

#define NVS_NS              "moink"

/* 演示模式（掉电跨场记忆） */
#define DEMO_NUMBERS        0
#define DEMO_BANDS          1

/* 像素码（工厂 LUT 语义的字节填充值；2bit 码 × 4 像素/字节） */
#define PACK_BLACK          0x00    /* 00 00 00 00 = 黑 */
#define PACK_WHITE          0x55    /* 01 01 01 01 = 白 */
#define PACK_YELLOW         0xAA    /* 10 10 10 10 = 黄 */
#define PACK_RED            0xFF    /* 11 11 11 11 = 红 */

/* 寄存器 LUT 语义（本固件预设表的动作码，同上打包） */
#define PACK_HOLD           0x00    /* 码 00 = 保持（路径终止） */
#define PACK_ACT_BLACK      0x55    /* 码 01 = H2 黑目标动作（P 剂量） */
#define PACK_ACT_WHITE      0xAA    /* 码 10 = H3 白/浅色动作（N 剂量） */

/* 引脚预设表（与主固件 settings.c 一致；[0] = 本移植版实际接线） */
static const uint8_t PIN_PRESETS[3][6] = {
    /* sck, mosi, cs, dc, rst, busy */
    { 18, 23,  5, 16, 17, 27 },
    { 14, 13, 15, 22, 21, 27 },
    { 18, 23,  5, 19,  4, 33 },
};

static nvs_handle_t s_nvs;
static bool s_nvs_ok = false;

static int  s_demo = DEMO_NUMBERS;
static int  s_orient = 0;                 /* 屏幕方向（同主固件 0..3，仅影响数字绘制） */
static vd_panel_t s_panel_sel = VD_PANEL_A0;
static vd_pins_t  s_pins;                 /* 解析后的生效引脚 */
static const char *s_pin_src = "默认预设";

static uint32_t s_rng;

/* 画布与波形表 */
static uint8_t *g_canvas;                 /* VD_ROWS × VD_RB，堆分配 */
static uint8_t  g_lut[LUT_R20_BYTES];
static uint8_t  g_prev_mask[24][88];      /* 上一个数字的字形掩码（用户视角） */
static uint8_t  g_mask[24][88];

/* 数字区域（写行区间；c 方向在画行内） */
static int s_reg_j0, s_reg_j1;

/* ================= 基础小工具 ================= */

static uint32_t factory_drf_timeout(void)
{
    return vd_panel() == VD_PANEL_A1 ? 180000u : 45000u;
}

static bool a1_release_guard(void)
{
    return vd_panel() == VD_PANEL_A1;
}

/* 非阻塞读串口一个键；timeout_ms 内无输入返回 -1 */
static int uart_getkey(int timeout_ms)
{
    uint8_t ch;
    int waited = 0;
    while (waited <= timeout_ms) {
        int n = uart_read_bytes(UART_NUM_0, &ch, 1, 0);
        if (n > 0) return ch;
        vTaskDelay(pdMS_TO_TICKS(20));
        waited += 20;
    }
    return -1;
}

/* BUSY 确认窗：ms 内必须保持高电平（A1 假释放会在数百 ms 内再落下） */
static bool busy_confirm_high(int ms)
{
    for (int t = 0; t < ms; t += 5) {
        if (vd_busy_level() == 0) return false;
        vTaskDelay(pdMS_TO_TICKS(5));
    }
    return true;
}

/* ================= NVS ================= */

static bool cfg_get_u8(const char *key, uint8_t *out)
{
    return s_nvs_ok && nvs_get_u8(s_nvs, key, out) == ESP_OK;
}

static void cfg_put_u8(const char *key, uint8_t v)
{
    if (s_nvs_ok) (void)nvs_set_u8(s_nvs, key, v);
}

static void nvs_commit_safe(void)
{
    if (s_nvs_ok) (void)nvs_commit(s_nvs);
}

static bool pin_basic_ok(const uint8_t *p)
{
    /* 轻量校验：0..33、无重复、避开 flash 供电脚 6..11；
       完整白名单见主固件 settings.c 的 pin_io_allowed。 */
    for (int i = 0; i < 6; i++) {
        if (p[i] > 33 || (p[i] >= 6 && p[i] <= 11)) return false;
        for (int k = i + 1; k < 6; k++) {
            if (p[i] == p[k]) return false;
        }
    }
    return true;
}

static void pins_from_array(const uint8_t *a)
{
    s_pins.sck  = a[0];
    s_pins.mosi = a[1];
    s_pins.cs   = a[2];
    s_pins.dc   = a[3];
    s_pins.rst  = a[4];
    s_pins.busy = a[5];
}

static void load_config(void)
{
    uint8_t v;
    uint32_t vrng = 0;

    if (cfg_get_u8("vdemo", &v) && v <= 1) s_demo = v;
    if (cfg_get_u8("panel", &v) && v <= 1) s_panel_sel = (vd_panel_t)v;
    if (cfg_get_u8("orient", &v) && v <= 3) s_orient = v;

    /* 引脚：预设档直接用预设表；自定义档逐键读，校验失败回落默认
       （与主固件 settings.c 同策略——避免半套引脚把设备带进不可诊断态） */
    {
        uint8_t preset = 0;
        const char *keys[6] = { "p_sck", "p_mosi", "p_cs", "p_dc", "p_rst", "p_busy" };
        uint8_t custom[6];
        bool have_all = true;
        bool have_preset = cfg_get_u8("gpio_preset", &preset);

        if (!have_preset) preset = 0;
        if (preset > 3) preset = 0;

        for (int i = 0; i < 6; i++) {
            if (!cfg_get_u8(keys[i], &custom[i])) have_all = false;
        }

        if (preset <= 2) {
            pins_from_array(PIN_PRESETS[preset]);
            s_pin_src = have_preset ? "NVS 预设档（主固件配置）"
                                    : "默认预设[0]（NVS 无记录，编译内建）";
        } else if (have_all && pin_basic_ok(custom)) {
            pins_from_array(custom);
            s_pin_src = "NVS 自定义档（主固件配置）";
        } else {
            pins_from_array(PIN_PRESETS[0]);
            s_pin_src = "默认预设[0]（自定义档无效，回落）";
        }
    }

    /* 随机数种子掺入跨上电计数 */
    if (s_nvs_ok && nvs_get_u32(s_nvs, "vrng", &vrng) != ESP_OK) vrng = 0;
    s_rng = esp_random() ^ (uint32_t)esp_timer_get_time() ^ (vrng + 1u) * 0x9E3779B9u;
    if (!s_rng) s_rng = 0xACE1DADAu;
    if (s_nvs_ok) (void)nvs_set_u32(s_nvs, "vrng", vrng + 1);
    nvs_commit_safe();
}

static void invalidate_otadata(void)
{
    /* 保险：清掉 OTA 启动指针，确保本槽位下次复位仍被选中。
       正常流程（README 要求 erase-flash 后线刷）里 otadata 本就是空的。 */
    const esp_partition_t *ot =
        esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_OTA, NULL);
    if (ot) {
        esp_err_t err = esp_partition_erase_range(ot, 0,
                          ot->size > 0x2000 ? 0x2000 : ot->size);
        printf("[启动] otadata 清除（%s）\n", err == ESP_OK ? "成功" : esp_err_to_name(err));
    }
}

/* ================= 画布 ================= */

static void canvas_fill_row(int j, uint8_t *row)
{
    memcpy(row, g_canvas + (size_t)j * VD_RB, VD_RB);
}

static void canvas_all(uint8_t packed)
{
    memset(g_canvas, packed, (size_t)VD_ROWS * VD_RB);
}

static void canvas_rows(int j0, int j1, uint8_t packed)
{
    if (j0 < 0) j0 = 0;
    if (j1 > VD_ROWS - 1) j1 = VD_ROWS - 1;
    memset(g_canvas + (size_t)j0 * VD_RB, packed, (size_t)(j1 - j0 + 1) * VD_RB);
}

static void canvas_set(int j, int c, uint8_t code)
{
    uint8_t *b = g_canvas + (size_t)j * VD_RB + (c >> 2);
    int sh = 6 - 2 * (c & 3);
    *b = (uint8_t)((*b & ~(3u << sh)) | ((code & 3u) << sh));
}

/* 用户视角坐标 → 画布（写行 j，缓冲列 c）。映射与主固件 orient 0..3 同源
   （sim_box_geom_r230.py 的 user_to_payload 再经行镜像推导，四方向中心自洽）。 */
static void u2p(int ux, int uy, int *j, int *c)
{
    switch (s_orient) {
    case 1:  *j = uy;        *c = 767 - ux; break;
    case 2:  *j = 551 - ux;  *c = 767 - uy; break;
    case 3:  *j = 551 - uy;  *c = 767 - ux; break;
    default: *j = ux;        *c = uy;       break;
    }
}

static void user_center(int *ux, int *uy)
{
    if (s_orient & 1) { *ux = 384; *uy = 276; }   /* 横屏 768x552 */
    else              { *ux = 276; *uy = 384; }   /* 竖屏 552x768 */
}

/* ================= 数字字形（字号 24 = 8x8 × 3） ================= */

static void glyph_mask(int n)
{
    memset(g_mask, 0, sizeof(g_mask));
    for (int d = 0; d < 3; d++) {
        int dig = (d == 0) ? n / 100 : (d == 1) ? (n / 10) % 10 : n % 10;
        const unsigned char *g = DIG8[dig];
        for (int fy = 0; fy < 8; fy++) {
            for (int fx = 0; fx < 8; fx++) {
                if (g[fy] & (1u << fx)) {
                    for (int sy = 0; sy < 3; sy++) {
                        for (int sx = 0; sx < 3; sx++) {
                            g_mask[fy * 3 + sy][d * 32 + fx * 3 + sx] = 1;
                        }
                    }
                }
            }
        }
    }
}

/* 计算数字区域覆盖的写行区间（画布 c 方向在行内，不必求区间） */
static void glyph_region(void)
{
    int ucx, ucy, jmin = VD_ROWS, jmax = -1;
    user_center(&ucx, &ucy);
    int x0 = ucx - 44, y0 = ucy - 12;
    const int corners[4][2] = {
        { x0, y0 }, { x0 + 87, y0 }, { x0, y0 + 23 }, { x0 + 87, y0 + 23 },
    };
    for (int k = 0; k < 4; k++) {
        int j, c;
        u2p(corners[k][0], corners[k][1], &j, &c);
        if (j < jmin) jmin = j;
        if (j > jmax) jmax = j;
    }
    s_reg_j0 = jmin;
    s_reg_j1 = jmax;
}

/* 把当前字形码画进画布：new 字形 → black_code；仅旧字形残留 → white_code。
   调用前区域须已清为背景（hold 或白）。 */
static void draw_number(uint8_t black_code, uint8_t white_code)
{
    int ucx, ucy;
    user_center(&ucx, &ucy);
    for (int gy = 0; gy < 24; gy++) {
        for (int gx = 0; gx < 88; gx++) {
            if (!g_mask[gy][gx] && !g_prev_mask[gy][gx]) continue;
            int j, c;
            u2p(ucx - 44 + gx, ucy - 12 + gy, &j, &c);
            if (g_mask[gy][gx])        canvas_set(j, c, black_code & 3u);
            else if (white_code != 0xFFu) canvas_set(j, c, white_code & 3u);
        }
    }
}

/* ================= 寄存器 LUT 探针 ================= */

typedef struct {
    bool    ok;
    uint8_t psr2;
    int64_t t1, t2;
} probe_result_t;

/*
 * 探测「PSR 寄存器 LUT 模式 + R20」是否被本屏接受：
 *   基线 = 复位 + 工厂初始化 + PON（ref docs/06 §1：这也是清 R20 污染、
 *   恢复工厂时序的唯一组合）→ 实验配置 overlay（AA/R01/PLL）→ R20 全 FF
 *   空表 → PSR 4B F9（再试 E9）→ 全 01 RAM（工厂视角 = 白，即便 2 字节
 *   PSR 被误读也不会画出花屏——均匀数据对寻址错误免疫）→ DRF。
 * 判接受：忙脉冲出现 + 时长 < 100 ms + 随后 2 s BUSY 保持高（防 A1 假
 * 释放误判）+ 复测一次同样达标。
 */
static probe_result_t probe_register_lut(void)
{
    static const uint8_t try_psr[2] = { 0xF9, 0xE9 };
    probe_result_t pr = { false, 0, 0, 0 };

    for (int t = 0; t < 2; t++) {
        printf("── 探测尝试 %d/2：PSR = 4B %02X（R20 空表 + 全 01 RAM）\n", t + 1, try_psr[t]);

        if (vd_full_reinit() != 0) {
            printf("   初始化失败，换下一档\n");
            continue;
        }
        vd_custom_overlay(0x00, 0x50);
        lut_build_empty(g_lut);
        if (vd_lut_write(g_lut) != 0) { printf("   R20 写入失败\n"); continue; }
        vd_set_psr_register(try_psr[t]);

        canvas_all(PACK_WHITE);
        if (vd_write_full(canvas_fill_row) != 0) { printf("   RAM 写入失败\n"); continue; }
        vd_window_full();

        {
            vd_drf_result_t r1 = vd_drf(180000u, false);
            printf("   探针 DRF#1：%lld ms，忙脉冲=%d\n",
                   (long long)r1.elapsed_ms, (int)r1.saw_low);
            if (r1.timeout || !r1.saw_low || r1.elapsed_ms >= 100) {
                printf("   → 未达接受判据（时长或忙脉冲），判定未接受\n");
                continue;
            }
            if (!busy_confirm_high(2000)) {
                printf("   → BUSY 在确认窗内再次变低（假释放），判定未接受\n");
                continue;
            }
        }
        {
            vd_drf_result_t r2 = vd_drf(180000u, false);
            printf("   探针 DRF#2：%lld ms，忙脉冲=%d\n",
                   (long long)r2.elapsed_ms, (int)r2.saw_low);
            if (r2.timeout || !r2.saw_low || r2.elapsed_ms >= 100) {
                printf("   → 复测未达标，判定未接受\n");
                continue;
            }
            printf("   ★ 寄存器 LUT 被接受（PSR 4B %02X）——快速局刷/剂量路径可用\n",
                   try_psr[t]);
            pr.ok = true;
            pr.psr2 = try_psr[t];
            pr.t1 = pr.t2 = 0;
            return pr;
        }
    }
    printf("── 两档 PSR 均未被接受：本屏在 %s 画像下不支持（或未开放）寄存器 LUT。\n"
           "   自动回退工厂 LUT 演示（判定依据已全部打印，请连同照片一起反馈）。\n",
           vd_panel_name());
    return pr;
}

/* ================= 演示 A：数字局刷 ================= */

static int rnd_1000(void)
{
    s_rng ^= s_rng << 13;
    s_rng ^= s_rng >> 17;
    s_rng ^= s_rng << 5;
    return (int)(s_rng % 1000u);
}

static void demo_numbers(void)
{
    int nums[10];
    int64_t times[10];
    bool lows[10];
    int64_t t_clear;

    printf("\n══════ 演示 A：数字局刷验证（字号 24 · 三位随机数 · 屏幕正中央） ══════\n");
    printf("观察点：① 数字是否只更新数字区域；② 背景是否整屏闪黑闪白；\n");
    printf("        ③ 若走快速局刷：每次更新应只有轻微变化、无整屏闪烁；\n");
    printf("        ④ 数字周围是否随次数逐次泛黄（负向剂量残影特征）。\n\n");

    /* A1. 工厂白屏清屏（前一场演示的残影必须清掉；本底也是剂量基准） */
    printf("[A1] 工厂全刷白屏（约 15 秒，正常现象，请等待）...\n");
    canvas_all(PACK_WHITE);
    if (vd_factory_frame(canvas_fill_row, &t_clear) != 0) {
        printf("[A1] 工厂清屏失败——请检查接线/串口上方 BUSY 日志后断电重试\n");
        return;
    }
    printf("[A1] 白屏清屏完成，工厂 DRF 时长 %lld ms\n\n", (long long)t_clear);

    /* A2. 寄存器 LUT 探测 */
    printf("[A2] 探测寄存器 LUT（JD79665 式 R20 波形表 + PSR 寄存器模式）...\n");
    probe_result_t pr = probe_register_lut();
    printf("\n");

    /* A3. 快速局刷：10 个随机数 */
    if (pr.ok) {
        printf("[A3] 快速局刷模式：H2=P3(黑目标) / H3=N3(白目标) / H5=Mode0，\n");
        printf("     码 01=黑动作、10=白动作、00=保持。区域只写数字所在写行段。\n");

        lut_build_num(g_lut);
        vd_lut_write(g_lut);

        /* ★ 探针后整帧 RAM = 01（黑动作码！）——载入数字表后必须先把
           整帧重写为保持，否则第一次 DRF 会把整屏推向黑。 */
        canvas_all(PACK_HOLD);
        vd_write_full(canvas_fill_row);

        for (int k = 0; k < 10; k++) nums[k] = rnd_1000();
        printf("     本场 10 个随机数（串口留档）：");
        for (int k = 0; k < 10; k++) printf("%03d%s", nums[k], k == 9 ? "\n" : " ");
        printf("\n");

        for (int k = 0; k < 10; k++) {
            glyph_mask(nums[k]);
            glyph_region();
            /* 区域清保持 → 画新字形(黑动作) + 旧字形残留(白动作) */
            canvas_rows(s_reg_j0, s_reg_j1, PACK_HOLD);
            draw_number(PACK_ACT_BLACK, PACK_ACT_WHITE);
            vd_write_rows(s_reg_j0, s_reg_j1, canvas_fill_row);
            memcpy(g_prev_mask, g_mask, sizeof(g_mask));

            vd_window_full();
            vd_drf_result_t r = vd_drf(30000u, false);
            times[k] = r.elapsed_ms;
            lows[k] = r.saw_low;
            printf("     数字 %2d/10 = %03d —— DRF %lld ms%s\n",
                   k + 1, nums[k], (long long)r.elapsed_ms,
                   r.saw_low ? "" : "（未见忙脉冲！）");
            vTaskDelay(pdMS_TO_TICKS(700));
        }

        {
            int64_t tmin = times[0], tmax = times[0], tsum = 0;
            int n_ok = 0;
            for (int k = 0; k < 10; k++) {
                if (times[k] < tmin) tmin = times[k];
                if (times[k] > tmax) tmax = times[k];
                tsum += times[k];
                if (times[k] < 500 && lows[k]) n_ok++;
            }
            printf("\n[A3] 汇总：最快 %lld ms / 最慢 %lld ms / 平均 %lld ms；达标 %d/10\n",
                   (long long)tmin, (long long)tmax, (long long)(tsum / 10), n_ok);
            printf("[A3] 判定：%s\n", n_ok == 10
                   ? "★ 快速局部刷新时序成立——请核对屏幕：数字应瞬时变化、"
                     "背景不动、无整屏闪烁"
                   : "未全部达标——请把逐条时长与照片一并反馈");
        }
    } else {
        /* A4. 工厂 LUT 窗口局刷（回退）：验证 0x83 窗口能否约束工厂波形的
           驱动范围（ref 在 A1 上已证光学基本只动窗内；A0 未证，正是本验证点） */
        printf("[A4] 工厂 LUT 回退模式：每次更新用「区域窗口 + 工厂 DRF」。\n");
        printf("     每个 DRF 约 15 秒、伴随整屏闪烁（工厂波形本性）；\n");
        printf("     ★ 本模式的验证点：屏幕变化是否【只发生在数字区域】——\n");
        printf("       窗外若完全不动 = 窗口可约束工厂波形；若整屏闪变 = 不可约束。\n");
        printf("     整场约 2.5 分钟。第一个数字之后可发 s 跳过剩余。\n\n");

        if (vd_full_reinit() != 0) {
            printf("[A4] 初始化失败\n");
            return;
        }
        bool skip = false;
        for (int k = 0; k < 10 && !skip; k++) {
            nums[k] = rnd_1000();
            glyph_mask(nums[k]);
            glyph_region();
            canvas_all(PACK_WHITE);
            draw_number(PACK_BLACK, 0xFFu);
            memcpy(g_prev_mask, g_mask, sizeof(g_mask));

            if (k == 0) vd_write_full(canvas_fill_row);
            else        vd_write_rows(s_reg_j0, s_reg_j1, canvas_fill_row);

            vd_window_rows(s_reg_j0, s_reg_j1);
            vd_drf_result_t r = vd_drf(factory_drf_timeout(), a1_release_guard());
            times[k] = r.elapsed_ms;
            printf("     数字 %2d/10 = %03d —— 工厂 DRF %lld ms%s（观察窗外是否保持）\n",
                   k + 1, nums[k], (long long)r.elapsed_ms,
                   r.saw_low ? "" : "（未见忙脉冲！）");

            if (k == 0) {
                printf("     —— 30 秒内发送 s 可跳过剩余 9 个，或等待继续 ——\n");
                int key = uart_getkey(30000);
                if (key == 's' || key == 'S') {
                    printf("     已跳过剩余数字\n");
                    skip = true;
                }
            } else {
                vTaskDelay(pdMS_TO_TICKS(500));
            }
        }
        printf("\n[A4] 判定：请对照屏幕与串口——窗外保持 = 窗口有效（可做慢局刷）；\n"
               "     整屏闪变 = 工厂波形不可被窗口约束，只能走寄存器 LUT 路线。\n");
    }

    vd_power_off();
}

/* ================= 演示 B：灰度色带 ================= */

/* 色带布局（写行坐标，整行条带）。两组成组出现，每组 = 参考带 + 6 条剂量带 */
#define S1_REF_J0   45
#define S1_REF_J1   73
#define S1_EDGE_A0  43
#define S1_EDGE_A1  44
#define S1_EDGE_B0  266
#define S1_EDGE_B1  267
#define S2_REF_J0   286
#define S2_REF_J1   314
#define S2_EDGE_A0  284
#define S2_EDGE_A1  285
#define S2_EDGE_B0  508
#define S2_EDGE_B1  509

typedef struct { int j0, j1; } band_t;

static const band_t S1_BANDS[6] = {
    {  82, 105 }, { 114, 137 }, { 146, 169 }, { 178, 201 }, { 210, 233 }, { 242, 265 },
};
static const band_t S2_BANDS[6] = {
    { 323, 346 }, { 355, 378 }, { 387, 410 }, { 419, 442 }, { 451, 474 }, { 483, 506 },
};

/* 剂量配方（打印到串口，供照片对照） */
static const int S1_DOSE_M0[3] = { 3, 2, 1 };          /* Mode0 强正场 P 扫描数 */
static const int S1_DOSE_M1[3] = { 8, 6, 2 };          /* Mode1 弱正场（VSP_1=0x2D） */
static const int S2_DOSE_N[6]   = { 24, 16, 12, 8, 5, 3 };  /* Mode0 负场 N 扫描数 */

static void band_factory_fill(int j, uint8_t *row)
{
    uint8_t code;
    if ((j >= S1_REF_J0 && j <= S1_REF_J1)) {
        code = PACK_BLACK;
    } else if (j >= S2_REF_J0 && j <= S2_REF_J1) {
        code = PACK_YELLOW;
    } else if (j == S1_EDGE_A0 || j == S1_EDGE_A1 || j == S1_EDGE_B0 || j == S1_EDGE_B1 ||
               j == S2_EDGE_A0 || j == S2_EDGE_A1 || j == S2_EDGE_B0 || j == S2_EDGE_B1) {
        code = PACK_BLACK;
    } else {
        code = PACK_WHITE;
    }
    memset(row, code, VD_RB);
}

/* 一条带的剂量：写动作码 → n 次 DRF（每次 1 扫描）→ 回保持 */
static void dose_band(const band_t *b, uint8_t act_packed, int n, const char *label)
{
    int timeouts = 0;
    canvas_rows(b->j0, b->j1, act_packed);
    vd_write_rows(b->j0, b->j1, canvas_fill_row);
    for (int i = 0; i < n; i++) {
        vd_window_full();
        vd_drf_result_t r = vd_drf(10000u, false);
        if (r.timeout || !r.saw_low) {
            timeouts++;
            printf("     ⚠ DRF#%d 异常：%lld ms，忙脉冲=%d\n",
                   i + 1, (long long)r.elapsed_ms, (int)r.saw_low);
        }
    }
    canvas_rows(b->j0, b->j1, PACK_HOLD);
    vd_write_rows(b->j0, b->j1, canvas_fill_row);
    printf("     %s（写行 %d..%d）：%d 次 DRF 完成%s\n", label, b->j0, b->j1, n,
           timeouts ? "（含异常，见上）" : "");
}

static void demo_bands(void)
{
    int64_t t_paint;

    printf("\n══════ 演示 B：灰度色带验证（黑→白 / 黄→白 各 6 条剂量带 + 参考带） ══════\n");
    printf("布局（写行坐标，条带为整行横带）：\n");
    printf("  上组 黑→白：写行 %d..%d 黑参考带，下方 6 条白底剂量带逐级变浅；\n",
           S1_REF_J0, S1_REF_J1);
    printf("  下组 黄→白：写行 %d..%d 黄参考带，下方 6 条白底负向剂量带由深黄调渐白；\n",
           S2_REF_J0, S2_REF_J1);
    printf("  两端细黑线为组边框。所有配方/剂量都打印到串口，拍照请连同本串口日志。\n\n");

    printf("[B1] 探测寄存器 LUT...\n");
    probe_result_t pr = probe_register_lut();
    printf("\n");

    if (!pr.ok) {
        /* 回退：工厂四色对照 */
        printf("[B-回退] 寄存器 LUT 未接受——剂量灰度（自定义波形）在本画像下不可用。\n");
        printf("   改画工厂四色对照带（黑/黄/红 + 白底），供确认工厂基色正常：\n");
        if (vd_full_reinit() != 0) return;
        canvas_all(PACK_WHITE);
        canvas_rows(45, 115, PACK_BLACK);
        canvas_rows(165, 235, PACK_YELLOW);
        canvas_rows(285, 355, PACK_RED);
        if (vd_factory_frame(canvas_fill_row, &t_paint) != 0) return;
        printf("   工厂对照图完成（DRF %lld ms）。四色正常 = 屏与工厂波形健康；\n"
               "   剂量灰度需换画像（菜单 p 切 A1）或进一步逆向本控制器波形接口。\n",
               (long long)t_paint);
        vd_power_off();
        return;
    }

    /* B2. 工厂底图：白底 + 黑参考带 + 黄参考带 + 组边框（一次工厂全刷） */
    printf("[B2] 工厂底图（白底 + 黑/黄参考带 + 边框；一次工厂全刷约 15 秒）...\n");
    if (vd_factory_frame(band_factory_fill, &t_paint) != 0) {
        printf("[B2] 工厂底图失败\n");
        return;
    }
    printf("[B2] 工厂底图完成，DRF %lld ms\n\n", (long long)t_paint);

    /* B3. 剂量阶段（全部走寄存器 LUT，每 DRF 1 扫描 ≈ 8.3 ms + 开销） */
    printf("[B3] 剂量阶段开始（H2=正向 / H3=负向，每 DRF 1 扫描，次数即剂量）...\n");

    if (vd_full_reinit() != 0) return;
    vd_custom_overlay(0x00, 0x50);
    lut_build_gray_m0(g_lut);
    vd_lut_write(g_lut);
    vd_set_psr_register(pr.psr2);
    canvas_all(PACK_HOLD);
    vd_write_full(canvas_fill_row);       /* 全帧重写为保持——探针残留的整帧 01 必须清 */

    printf("  阶段 1/3 黑→白 · 深灰档（Mode0 强正场 P，剂量 %d/%d/%d 扫描）：\n",
           S1_DOSE_M0[0], S1_DOSE_M0[1], S1_DOSE_M0[2]);
    dose_band(&S1_BANDS[0], PACK_ACT_BLACK, S1_DOSE_M0[0], "带 1（最深）");
    dose_band(&S1_BANDS[1], PACK_ACT_BLACK, S1_DOSE_M0[1], "带 2");
    dose_band(&S1_BANDS[2], PACK_ACT_BLACK, S1_DOSE_M0[2], "带 3");

    printf("  阶段 2/3 黑→白 · 中浅灰档（Mode1 弱正场，VSP_1=0x2D，剂量 %d/%d/%d 扫描）：\n",
           S1_DOSE_M1[0], S1_DOSE_M1[1], S1_DOSE_M1[2]);
    vd_custom_overlay(0x2D, 0x50);
    lut_build_gray_m1(g_lut);
    vd_lut_write(g_lut);
    dose_band(&S1_BANDS[3], PACK_ACT_BLACK, S1_DOSE_M1[0], "带 4（中灰）");
    dose_band(&S1_BANDS[4], PACK_ACT_BLACK, S1_DOSE_M1[1], "带 5");
    dose_band(&S1_BANDS[5], PACK_ACT_BLACK, S1_DOSE_M1[2], "带 6（最浅）");

    printf("  阶段 3/3 黄→白 · 黄调档（Mode0 负场 N，剂量 %d/%d/%d/%d/%d/%d 扫描）：\n",
           S2_DOSE_N[0], S2_DOSE_N[1], S2_DOSE_N[2], S2_DOSE_N[3], S2_DOSE_N[4], S2_DOSE_N[5]);
    vd_custom_overlay(0x00, 0x50);
    lut_build_yellow(g_lut);
    vd_lut_write(g_lut);
    dose_band(&S2_BANDS[0], PACK_ACT_WHITE, S2_DOSE_N[0], "黄带 1（最浓黄调）");
    dose_band(&S2_BANDS[1], PACK_ACT_WHITE, S2_DOSE_N[1], "黄带 2");
    dose_band(&S2_BANDS[2], PACK_ACT_WHITE, S2_DOSE_N[2], "黄带 3");
    dose_band(&S2_BANDS[3], PACK_ACT_WHITE, S2_DOSE_N[3], "黄带 4");
    dose_band(&S2_BANDS[4], PACK_ACT_WHITE, S2_DOSE_N[4], "黄带 5");
    dose_band(&S2_BANDS[5], PACK_ACT_WHITE, S2_DOSE_N[5], "黄带 6（最淡）");

    printf("\n[B3] 剂量阶段完成。判定指引：\n");
    printf("  · 黑→白组：6 条带应呈「深→浅」阶梯（黑参考 → 带 6 → 白底）。\n");
    printf("    若深浅档全部接近黑或全部接近白 = 剂量曲线过陡/过平，下一版调参；\n");
    printf("  · 黄→白组：6 条带应呈「浓黄调 → 近白」阶梯（黄参考 → 带 6 → 白底）。\n");
    printf("    每条带的实际剂量已打印，照片按串口行号对号入座。\n");

    vd_power_off();
}

/* ================= 深度睡眠 ================= */

static void sleep_forever(void)
{
    const char *next = (s_demo == DEMO_NUMBERS) ? "灰度色带演示" : "数字局刷演示";

    printf("\n══════ 演示结束 → 深度睡眠 ══════\n");
    printf("[睡眠] 屏已发送面板深睡命令（0x07 A5）。\n");
    printf("[睡眠] 3 秒后 SoC 进入深度睡眠（无唤醒源）。\n");
    printf("[睡眠] 唤醒方式：拔掉 USB 重新上电，或按 EN/RST 复位键 ——\n");
    printf("       两者都会重启并切换到下一场：%s（模式标志已写入 NVS）。\n", next);
    printf("[发热] 深睡后 SoC 电流应降到 µA 级。若板面/屏仍持续发热，\n");
    printf("       热源在 USB 供电、3.3V 稳压或屏升压电路，而非 SoC 负载——\n");
    printf("       请在深睡 2 分钟后手摸排查并反馈。\n");
    printf("[串口] 深睡期间重开串口监视器会触发 DTR/RTS 复位 = 直接开始下一场。\n");

    vd_panel_sleep();
    for (int i = 3; i >= 1; i--) {
        printf("[睡眠] %d...\n", i);
        fflush(stdout);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
    fflush(stdout);
    uart_wait_tx_done(UART_NUM_0, pdMS_TO_TICKS(200));
    esp_deep_sleep_start();

    /* 不会到达 */
    for (;;) { vTaskDelay(pdMS_TO_TICKS(1000)); }
}

/* ================= 开机菜单 ================= */

static void print_banner(void)
{
    printf("\n");
    printf("╔══════════════════════════════════════════════════════════════╗\n");
    printf("║  墨印 MoInk · 功能验证固件                                     ║\n");
    printf("║  局部刷新 / 灰度色带 / 深度睡眠 / 发热 —— 四项隔离验证          ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝\n");
    printf("版本：%s\n", VERIFY_FW_VER);
    printf("波形依据：ref/jd79665aa-driver（JD79665AA 逆向；A0 画像先探针后启用）\n");
}

static void print_config(void)
{
    printf("\n[配置] 演示模式 = %s（本场）\n",
           s_demo == DEMO_NUMBERS ? "数字局刷" : "灰度色带");
    printf("[配置] 屏幕画像 = %s，方向 orient = %d\n", vd_panel_name(), s_orient);
    printf("[配置] 引脚来源 = %s\n", s_pin_src);
    printf("[配置] 生效引脚 SCK=%d MOSI=%d CS=%d DC=%d RST=%d BUSY=%d\n",
           s_pins.sck, s_pins.mosi, s_pins.cs, s_pins.dc, s_pins.rst, s_pins.busy);
    printf("[配置] 下电重上电自动切换两场演示（NVS 键 vdemo）\n");
}

static void menu_and_run(void)
{
    printf("\n[菜单] 3 秒内可发送：\n");
    printf("       回车/g = 立即开始本场；\n");
    printf("       m = 切到另一场演示（写入 NVS）并开始；\n");
    printf("       p = 切屏幕画像 A0↔A1（写入 NVS，主固件同键）并开始；\n");
    printf("       （超时自动开始本场）\n");
    fflush(stdout);

    for (;;) {
        int key = uart_getkey(3000);
        if (key == '\r' || key == '\n' || key == 'g' || key == 'G' || key < 0) break;
        if (key == 'm' || key == 'M') {
            s_demo = (s_demo == DEMO_NUMBERS) ? DEMO_BANDS : DEMO_NUMBERS;
            cfg_put_u8("vdemo", (uint8_t)s_demo);
            nvs_commit_safe();
            printf("[菜单] 已切换演示模式 → %s\n",
                   s_demo == DEMO_NUMBERS ? "数字局刷" : "灰度色带");
            break;
        }
        if (key == 'p' || key == 'P') {
            s_panel_sel = (s_panel_sel == VD_PANEL_A0) ? VD_PANEL_A1 : VD_PANEL_A0;
            cfg_put_u8("panel", (uint8_t)s_panel_sel);
            nvs_commit_safe();
            printf("[菜单] 已切换屏幕画像 → %s\n",
                   s_panel_sel == VD_PANEL_A0 ? "A0" : "A1");
            break;
        }
        printf("[菜单] 忽略按键 0x%02X（回车/g/m/p）\n", key);
        fflush(stdout);
    }

    /* 模式标志在本场开始时即翻转：中途断电/复位也算完成一次切换 */
    {
        uint8_t next = (s_demo == DEMO_NUMBERS) ? DEMO_BANDS : DEMO_NUMBERS;
        cfg_put_u8("vdemo", next);
        nvs_commit_safe();
    }

    if (vd_init(&s_pins, s_panel_sel) != 0) {
        printf("[错误] 屏驱动初始化失败（SPI/引脚）——请核对引脚配置\n");
        return;
    }

    if (s_demo == DEMO_NUMBERS) demo_numbers();
    else                        demo_bands();
}

/* ================= app_main ================= */

void app_main(void)
{
    esp_err_t err;

    print_banner();

    if (!lut_self_check()) {
        printf("[自检] ★ R20 波形编码器自检失败——固件有 bug，停止演示\n");
        return;
    }
    printf("[自检] R20 波形编码器自检通过（256 回环 + 9 已知向量 + 108 扫描算例）\n");

    invalidate_otadata();

    err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        (void)nvs_flash_erase();
        err = nvs_flash_init();
    }
    if (err != ESP_OK) {
        printf("[NVS] 初始化失败：%s——演示模式切换与引脚继承不可用，用默认值继续\n",
               esp_err_to_name(err));
    } else if (nvs_open(NVS_NS, NVS_READWRITE, &s_nvs) == ESP_OK) {
        s_nvs_ok = true;
    }
    printf("[NVS] %s\n", s_nvs_ok ? "已打开命名空间 moink（与主固件同池）"
                                  : "不可用（默认配置运行）");

    g_canvas = heap_caps_malloc((size_t)VD_ROWS * VD_RB, MALLOC_CAP_8BIT);
    if (!g_canvas) {
        printf("[错误] 画布分配失败（%d B）\n", VD_ROWS * VD_RB);
        return;
    }

    /* 串口 RX 驱动（菜单 + 交互跳过用；TX 走 ROM 控制台互不影响） */
    if (uart_driver_install(UART_NUM_0, 256, 0, 0, NULL, 0) != ESP_OK) {
        printf("[警告] UART0 RX 驱动安装失败——菜单不可用，3 秒后自动开始\n");
    }

    load_config();
    print_config();
    menu_and_run();

    sleep_forever();
}
