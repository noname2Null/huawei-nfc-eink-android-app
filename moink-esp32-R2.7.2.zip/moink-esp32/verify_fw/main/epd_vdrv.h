#ifndef MOINK_EPD_VDRV_H
#define MOINK_EPD_VDRV_H

/*
 * 墨印功能验证固件 —— JD7966x 屏驱动（A0 / A1 双画像）
 *
 * 从主固件 main/epd_drv.c 的两条已真机验证的电气路径精简而来，并按
 * ref/jd79665aa-driver 的研究结论扩展了验证固件需要的实验能力：
 *   - R20 运行时波形表写入（0x20 + 2048 B）与 PSR 寄存器 LUT 模式切换；
 *   - 行区写（只写指定写行区间的 RAM，不整帧）；
 *   - DRF 前的窗口控制（全窗 / 行区窗）—— 用于验证「窗口能否约束工厂波形
 *     的驱动范围」（ref docs/03：A1 上小窗 + 工厂波形仍约 15 s，但光学上
 *     基本只动窗内；A0 上未证，正是本固件的验证点之一）；
 *   - BUSY 观测强化：每次等待记录是否真的出现过低电平忙脉冲（只有高电平
 *     不能证明控制器收到了命令，ref docs/02 §5）。
 *
 * ★ 坐标契约（与主固件同一套已证映射，主程序按 orient 换算后喂行）：
 *   - 逻辑画布 768 列 × 552 行（写行 j = 0..551，行内 192 B、MSB 优先）；
 *   - provider 填写行 j 的 192 B：缓冲列 c（0..767）为该位置像素码；
 *   - 驱动对每行做「字节倒序 + 字节内 2bit 组倒序」镜像后发送（电气序列与
 *     主固件逐字节一致——两次镜像抵消的原始推导见主固件 overlay.c 头注）；
 *   - A0：每个写行 j 经 0x83 单行窗写往栅极 ys(j) = 2j（j<276）/ 1103-2j；
 *   - A1：单窗（0..767 × 栅极 0..551）+ 552 行线性连写。
 *
 * 像素码两套语义（同一组 bit，由 PSR 选的 LUT 决定解释）：
 *   工厂 LUT：00=黑 01=白 10=黄 11=红（字节填充 0x00/0x55/0xAA/0xFF）；
 *   寄存器 LUT（本固件预设表）：00=保持(终止) 01=H2 黑目标动作
 *                             10=H3 白/浅色目标动作 11=备用(终止)。
 */

#include <stdint.h>
#include <stdbool.h>

#define VD_COLS      768        /* 逻辑画布列数（= 行字节数 × 4） */
#define VD_ROWS      552        /* 逻辑画布行数（= 写行数 = 可见栅极） */
#define VD_RB        192        /* 每行字节数 */
#define VD_A1_GATES  600        /* A1 TRES 栅极数（可见 552 + 边框 48） */

typedef enum {
    VD_PANEL_A0 = 0,            /* JD79668 画像：极简初始化 + 隔行半屏映射 */
    VD_PANEL_A1 = 1,            /* JD79665 式画像：长初始化块 + 顺序直写 */
} vd_panel_t;

typedef struct {
    uint8_t sck, mosi, cs, dc, rst, busy;
} vd_pins_t;

/* 行填充回调：填写行 j 的 VD_RB 字节（缓冲列 c = 像素码） */
typedef void (*vd_row_fill_t)(int j, uint8_t *row);

/* DRF 结果 */
typedef struct {
    int64_t elapsed_ms;         /* 0x12 到 BUSY 释放（或超时时刻） */
    bool    saw_low;            /* 等待期间采样到 BUSY 低电平（真实忙脉冲） */
    bool    timeout;
} vd_drf_result_t;

/* ---- 初始化 ---- */
int  vd_init(const vd_pins_t *pins, vd_panel_t panel);
const char *vd_panel_name(void);
vd_panel_t vd_panel(void);
int  vd_busy_level(void);      /* BUSY 引脚当前电平（低=忙；确认窗用） */

/* ---- 工厂完整显示周期 ----
 * full_reinit（复位 + 工厂寄存器初始化 + PON）→ 整帧写 → 全窗 → DRF → POF。
 * 内部重试至多 3 次（同主固件）。*drf_ms 可为 NULL。返回 0 成功。
 * ★ 每次调用都走完整初始化：这也是 ref docs/06 §1 的结论——R20 污染只有
 *   「复位 + 正常初始化 + PON」才能恢复工厂时序。 */
int  vd_factory_frame(vd_row_fill_t fill, int64_t *drf_ms);

/* ---- 低层拼装（验证实验用） ---- */
int  vd_full_reinit(void);                    /* 复位 + 工厂初始化 + PON */
int  vd_write_rows(int j0, int j1, vd_row_fill_t fill);  /* 行区写（不刷新） */
int  vd_write_full(vd_row_fill_t fill);       /* 整帧写 = write_rows(0,551) */
void vd_window_full(void);                    /* DRF 前全窗 */
void vd_window_rows(int j0, int j1);          /* DRF 前行区窗（范围约束实验） */
vd_drf_result_t vd_drf(uint32_t timeout_ms, bool a1_false_release);
int  vd_power_off(void);                      /* 0x02 + 等 BUSY */
void vd_panel_sleep(void);                    /* 0x07 0xA5 */

/* ---- 寄存器 LUT（实验路径） ----
 * overlay：A0 追加 0xAA 解锁（A1 初始化已含）；两画像都写
 *   R01(0x01) = 3F 00 14 <vsp1> <vsn1> 14（供电：VSPL_0=14、VSP_1、VSN_1、VSPL_1=14）
 *   PLL(0x30) = 07（标称 120 Hz 扫描时钟，ref 实验配置）
 * 然后 R20 写表、PSR 切寄存器模式。顺序不可乱。 */
int vd_custom_overlay(uint8_t vsp1, uint8_t vsn1);
int vd_lut_write(const uint8_t *tbl);              /* 0x20 + 2048 B */
int vd_set_psr_register(uint8_t psr2);             /* 0x00 4B <E9|F9> */

#endif /* MOINK_EPD_VDRV_H */
