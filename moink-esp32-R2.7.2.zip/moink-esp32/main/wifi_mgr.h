#ifndef MOINK_WIFI_MGR_H
#define MOINK_WIFI_MGR_H

#include <stdbool.h>
#include <stdint.h>

/*
 * R2.0.0 网络模式管理（取代"纯 SoftAP"单一模式）；★R2.1.0 大改（需求 2/7/8/9/10/11）。
 *
 * 启动策略：
 *   - settings 里无 STA 凭据        -> 纯热点模式（原行为，含 captive portal）。
 *   - 有 STA 凭据                  -> AP+STA 同时开（热点兜底，配错了还能进页面改），
 *                                      逐次尝试加入路由器；连接成功（拿到 IP）后
 *                                      切 WIFI_MODE_STA（热点关闭，DNS 劫持停止）。
 *   - 连续 STA_CONNECT_MAX 次 加入失败 -> 停止快重试，保持「热点 + STA 待命」；
 *                                      ★R2.1.0 需求 11：无设备连热点（=配置页无人）
 *                                      时每 2 分钟再试加入局域网。
 *
 * 运行期（★R2.1.0 网络状态监测）：
 *   - 独立任务按用户设置的间隔（默认 30s）做外网探测（DNS 解析）；
 *   - 状态变化须【连续 3 次】探测一致才确认（需求 9：防路由器瞬断误报，
 *     刷新屏幕前强制三连确认）；
 *   - 探测确认后投递 NET_CHANGED 事件给 main 的 UI 队列 → 刷屏（需求 2/7）；
 *   - 确认【外网断、局域网在】→ ★需求 10：局域网 + 热点共存（WIFI_MODE_APSTA，
 *     ESP32 单芯片同频支持，已验证启动期即如此工作 —— 无需"退出局域网"的退路）；
 *   - 确认外网恢复 → 热点关闭，回纯 STA；
 *   - 页面发起的 BLE 扫描窗口期间跳过探测（把射频让给蓝牙 —— 需求 9 的让步条款；
 *     ESP32 WiFi/BT 硬件共存（CONFIG_ESP_COEX_SW_COEXIST_ENABLE）本身已时分复用）。
 *
 * 连上局域网后：
 *   - mDNS：moink.local 可直达配置页。
 *   - SNTP：对上时后把同步间隔拉长到 12 小时（需求 8：时间存 RTC 本地走时，
 *     减少网络请求；掉点也不重问，本地时钟漂移由每日两次的再同步吸收）。
 */

/* 连接尝试上限：连续失败达到此值后回落热点模式（用户规格：10 次）。 */
#define STA_CONNECT_MAX   10
/* 单次连接尝试的兜底超时（ms）：无任何事件时按此节奏推进重试。 */
#define STA_ATTEMPT_TIMEOUT_MS 8000
/* R2.1.0：外网探测三连确认的次数（需求 9）。 */
#define NET_CONFIRM_N     3
/* R2.1.0：热点待命时的再入网间隔（ms，需求 11：2 分钟）。 */
#define STA_SLOW_RETRY_MS (2 * 60 * 1000)

typedef enum {
    NETIF_MODE_AP = 0,      /* 自发热点（原行为；含"热点+STA 待命"） */
    NETIF_MODE_STA,         /* 已连入局域网（热点关闭；或外网断时的共存热点） */
} netif_mode_t;

/* 网络总装配：netif + 事件循环 + WiFi 驱动 + AP/STA netif + 模式决策 + 状态监测。
 * 取代原 main.c 里的 netif_ap_init() + captive_dns_start() 两个调用。
 * ★R2.7.0 入参 unattended = 本次开机是调度事件唤醒（非人触发）：
 *   路由器不在（连续 ≥ 3 个全功能唤醒都加入失败，RTC 连败计数）时
 *   本轮只试【一次】加入 —— 原每轮 10 次尝试 × ~1-3s 的射频搜寻是
 *   全功能唤醒的主要发热源；有人触发（上电/按键/配网保存）仍全力
 *   尝试并清零连败计数。 */
void wifi_mgr_init(bool unattended);

/* ★R2.7.0：网络栈是否已初始化（wifi_mgr_init 已跑）。轻唤醒（分钟局刷）
 * 不起射频 —— main 跳过 wifi_mgr_init，本函数恒 false：overlay 的远端
 * 拉取触发据此让路（拉取任务在无网络栈的开机上不启动）。 */
bool wifi_mgr_up(void);

/* R2.1.0：注入 UI 事件投递口（main 在创建 ui 队列后、wifi_mgr_init 前调用）。
 * 网络状态三连确认后投 OV_EV_NET_CHANGED（数值见 overlay.h）。 */
void wifi_mgr_set_ui_post(void (*post)(int ev));

/* 当前生效模式（STA 模式下热点可能仍开着 —— 共存态，见 wifi_mgr_ap_also）。 */
netif_mode_t wifi_mgr_mode(void);
const char *wifi_mgr_mode_name(void);

/* R2.1.0：网络状态是否已落定（上电门控用）：已入局域网 / 无凭据纯热点 /
 * 加入待命（10 次失败已回落）均算落定；正在快重试加入时为 false。 */
bool wifi_mgr_net_settled(void);

/* ★R2.6.1：正在快速尝试加入局域网（快重试中）—— remote 拉取在途判定用：
 * joining 中几秒内可能入网值得等；待命态（2 分钟慢重试）不必等。 */
bool wifi_mgr_joining(void);

/* R2.1.0：热点当前是否也在广播（外网断开时的共存热点 / 加入待命态）。 */
bool wifi_mgr_ap_also(void);

/* STA 状态 */
bool wifi_mgr_sta_connected(void);
const char *wifi_mgr_ip(void);        /* STA IP；未连接返回 "192.168.4.1" */
int  wifi_mgr_rssi(void);             /* 当前 RSSI dBm；未连接返回 0 */
bool wifi_mgr_internet(void);         /* 最近一次【三连确认】的外网探测结果 */
bool wifi_mgr_time_synced(void);      /* NTP 是否已对上时（年 > 2025 视为有效） */

/* 兼容口：R2.1.0 起探测由监测任务周期进行，这里只回缓存值（不再现场 DNS）。 */
void wifi_mgr_check_internet(void);

/* R2.1.0：改网络检测间隔（秒）。立刻生效（重启探测定时器）。 */
void wifi_mgr_set_netcheck_iv(uint32_t sec);

/* STA 尝试失败次数（页面展示用）。 */
int wifi_mgr_sta_fails(void);

/* 请求重启 STA 加入流程（配网保存后页面会引导重启，此函数兜底）。 */
void wifi_mgr_restart_join(void);

#endif /* MOINK_WIFI_MGR_H */
