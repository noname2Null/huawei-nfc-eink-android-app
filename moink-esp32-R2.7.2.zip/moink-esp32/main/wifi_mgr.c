#include "wifi_mgr.h"
#include "settings.h"
#include "netif_ap.h"
#include "captive.h"
#include "overlay.h"     /* R2.0.3：入网成功 → 重置信息框 IP 行显示周期 */
#include "ble_sensor.h"  /* R2.1.0：BLE 扫描窗口期间探测让路（需求 9）*/
#include "power.h"       /* ★R2.7.2【修复1b/3】：power_sleeping() 入睡短路判据 */

#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_netif_sntp.h"
#include "esp_sntp.h"    /* R2.1.0：同步间隔拉长（需求 8），lwip 兼容别名头 */
#include "esp_event.h"
#include "esp_mac.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_attr.h"    /* R2.7.0：RTC_NOINIT_ATTR（连败计数跨深睡存活） */
#include "mdns.h"
#include "lwip/netdb.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

#include <string.h>
#include <stdio.h>
#include <stdlib.h>          /* setenv/tzset；GCC14 隐式声明即错误，显式包含 */
#include <time.h>
#include <sys/time.h>        /* R2.6.1：struct timeval（SNTP 步进回调） */

static const char *TAG = "wifi_mgr";

#define HOSTNAME       "moink"
#define SNTP_CHECK_TAG "www.baidu.com"   /* 外网探测域名：解析成功即视为有外网 */
/* NTP 对时有效性阈值（2024-01-01 UTC 的 unix 秒）：超过即视为已对上时。 */
#define TIME_OK_TS     1704067200LL
/* R2.1.0：对上时后的再同步间隔（需求 8：本地 RTC 走时，12h 才再问一次网络）。 */
#define SNTP_RESYNC_MS (12ULL * 3600 * 1000)

static netif_mode_t s_mode = NETIF_MODE_AP;
static esp_netif_t *s_sta_if = NULL;
static bool s_joining = false;        /* 正在尝试加入局域网（快重试） */
static int  s_fails = 0;              /* 连续失败次数 */
static bool s_connected = false;
static char s_ip[16] = "192.168.4.1";
static int64_t s_last_attempt_ms = 0;  /* 上一次发起连接的时刻 */
static esp_timer_handle_t s_watchdog; /* 加入尝试看门狗（8s 无事件推进一次重试） */
static bool s_dns_running = false;
static bool s_up = false;               /* ★R2.7.0：网络栈已初始化（wifi_mgr_init 已跑） */

/* ★R2.7.0 路由器连败计数（RTC noinit）：连续 N 个全功能唤醒都「加入失败
 *   回落热点」时，无人attended 的后续全功能唤醒只试一次（射频搜寻是
 *   全功能唤醒的主要发热源）；有人触发（上电/按键/配网保存）或某次
 *   加入成功则清零。魔数校验，掉电/乱码按从未失败处理（保守全试）。 */
#define WIFI_RTC_JOIN_MAGIC 0x4A4F494Eu   /* "JOIN" */
#define WIFI_JOIN_STREAK_MAX 3            /* 连败 ≥ 此值 → 单次尝试档 */
static struct {
    uint32_t magic;
    uint32_t fail_streak;
} s_rtc_join RTC_NOINIT_ATTR;

static int s_attempt_cap = STA_CONNECT_MAX;  /* ★R2.7.0：本轮尝试上限（连败抑制档 = 1） */

/* ★R2.7.2【修复3】：WiFi 驱动停机跟踪 —— STA/AP 的 STOP 事件
 *   （esp_wifi_stop() 完成）置位，START 事件清除。两个用途：
 *   ① sta_attempt()/probe_once() 据此避免对停机驱动 connect/探测
 *     （R2.7.1 实测的 ESP_ERR_WIFI_STOP_STATE 报错链）；
 *   ② 入睡序列被二次校验中止后，slow_retry_cb 的恢复分支据此把
 *     驱动重新拉起（被 power_enter_deep_sleep 的 esp_wifi_stop 停掉，
 *     光 connect 救不回来 —— connect 要求驱动处于 start 态）。 */
static volatile bool s_drv_stopped = false;

/* ---------------- R2.1.0 新状态 ---------------- */
static bool s_slow_retry = false;     /* 加入待命：每 2 分钟再试（需求 11） */
static esp_timer_handle_t s_slow_timer;
static bool s_ap_also = false;        /* STA 模式下热点也在广播（外网断共存，需求 10） */

/* 外网探测（需求 9）：独立任务 + 周期定时器；连续 NET_CONFIRM_N 次一致才确认。 */
static esp_timer_handle_t s_probe_timer;
static SemaphoreHandle_t   s_probe_sem;
static TaskHandle_t        s_probe_task_h;
static volatile uint32_t s_netcheck_iv = 30;   /* 探测间隔（秒），页面可调 */
static bool  s_inet = false;           /* 已确认的外网状态 */
static int   s_inet_agree;             /* 与已确认状态不同的连续次数 */
static void (*s_ui_post)(int ev) = NULL;

/* ---------------- captive DNS 开关（AP 侧在播才劫持） ---------------- */

static void dns_guard(bool on)
{
    if (on && !s_dns_running) {
        captive_dns_start();
        s_dns_running = true;
    } else if (!on && s_dns_running) {
        captive_dns_stop();
        s_dns_running = false;
    }
}

/* ---------------- 热点共存开关（需求 10） ---------------- */

/* 开：局域网保持连接的同时发射热点（APSTA，ESP32 同频共存）。
   关：回纯 STA（连上局域网、外网正常时的默认态）。 */
static void hotspot_also(bool on)
{
    if (on == s_ap_also) return;
    if (on) {
        /* ★需求 10：外网断但局域网仍在 —— 加入局域网的同时发射热点，
           用户可连热点进配置页排障。ESP32 APSTA 同频共存可行（开机加入期
           一直就是这个形态），无需「退出局域网再发热点」的退路。 */
        esp_wifi_set_mode(WIFI_MODE_APSTA);
        netif_ap_apply();
        dns_guard(true);
        s_ap_also = true;
        ESP_LOGW(TAG, "internet down (LAN alive): hotspot ON alongside LAN");
    } else {
        esp_wifi_set_mode(WIFI_MODE_STA);
        dns_guard(false);
        s_ap_also = false;
        ESP_LOGI(TAG, "internet restored: hotspot OFF, pure STA");
    }
}

/* ---------------- 网络状态变化通知（需求 2/7） ---------------- */

static void net_changed(void)
{
    if (s_ui_post) s_ui_post(5 /* OV_EV_NET_CHANGED，与 overlay.h/main.c 对齐 */);
}

/* ---------------- SNTP（需求 8：对上时后本地 RTC 走时，12h 再同步） ---------------- */

/* ★R2.6.1：NTP 步进通知 —— 唤醒后系统钟带深睡累积的 RTC 慢漂（唤醒定时器
 * 与系统钟同源，漂移方向一致：唤醒与分钟边界一起漂，到点唤醒本身不迟到；
 * 但真钟整分时刻设备钟可能还差几十秒 —— 用户看到「整分不跳」，随后
 * SNTP 步进把钟拗回来又可能一次跳过一分钟）。SNTP 步进后投
 * OV_EV_TIME_STEP，display_task 里 overlay_time_realign 重排分钟定时器 +
 * 时钟显示立即局刷校正。回调跑在 SNTP 任务上下文 —— 只投队列，不刷屏。 */
static void sntp_synced_cb(struct timeval *tv)
{
    (void)tv;
    if (s_ui_post) s_ui_post(7 /* OV_EV_TIME_STEP，与 overlay.h/main.c 对齐 */);
    ESP_LOGI(TAG, "SNTP time stepped");
}

static void start_sntp(void)
{
    /* v6.1 的 esp_netif_sntp.h：结构体名是 esp_sntp_config_t（并没有
       esp_netif_sntp_config_t 这个类型），且字段相比 5.x 有增删——
       手写初始化极易踩坑，统一用官方默认宏最稳。单服务器即可，
       SNTP 内部会自动重试直到对上时。 */
    static bool s_started = false;      /* 断线重连后重复拿 IP，不重复 init */
    if (!s_started) {
        esp_sntp_config_t cfg = ESP_NETIF_SNTP_DEFAULT_CONFIG("ntp.aliyun.com");
        esp_netif_sntp_init(&cfg);
        /* ★R2.6.1：对时步进回调（注册一次，跨 SNTP restart 保持） */
        sntp_set_time_sync_notification_cb(sntp_synced_cb);
        s_started = true;
    }
    /* 时区固定 UTC+8（本项目面向国内；如需出国使用可改这里的 TZ 串）。 */
    setenv("TZ", "CST-8", 1);
    tzset();
    /* ★R2.1.0 需求 8：NTP 时间交给系统 RTC 本地走时，把再同步间隔拉到 12h
       （lwip 默认 1h 一问）。interval 最小 15s，此处远大于下限。 */
    esp_sntp_set_sync_interval((uint32_t)SNTP_RESYNC_MS);
    esp_sntp_restart();
    ESP_LOGI(TAG, "SNTP running (tz CST-8, resync every 12h)");
}

/* ---------------- 事件处理 ---------------- */

static void enter_sta_mode(void)
{
    /* ★R2.7.0：路由器在（拿到 IP）—— RTC 连败计数清零。 */
    s_rtc_join.magic = WIFI_RTC_JOIN_MAGIC;
    s_rtc_join.fail_streak = 0;
    /* ★ 用户规格：连上局域网后关闭自己的热点。
       切 WIFI_MODE_STA 会停掉 AP 侧（客户端全部被踢），DNS 劫持停止。
       R2.1.0：外网断开的共存热点（s_ap_also）也在这里一并关掉 ——
       重新拿到 IP 意味着链路刚重建，外网状态由探测任务重新确认。 */
    dns_guard(false);
    esp_wifi_set_mode(WIFI_MODE_STA);
    s_mode = NETIF_MODE_STA;
    s_connected = true;
    s_fails = 0;
    s_joining = false;
    s_slow_retry = false;
    if (s_watchdog) esp_timer_stop(s_watchdog);

    esp_netif_ip_info_t ip;
    if (s_sta_if && esp_netif_get_ip_info(s_sta_if, &ip) == ESP_OK) {
        esp_ip4addr_ntoa(&ip.ip, s_ip, sizeof(s_ip));
    }
    ESP_LOGI(TAG, "joined LAN: %s (RSSI %d) -- SoftAP off, hotspot portal disabled",
             s_ip, wifi_mgr_rssi());
    ESP_LOGI(TAG, "config page: http://%s/  or  http://%s.local/", s_ip, HOSTNAME);

    /* R2.1.0：链路重建 = 网络状态变化（信息框 IP/图标刷新）；外网判定重置，
       由探测任务 3 连确认后再定。 */
    s_inet = false;
    s_inet_agree = 0;
    s_ap_also = false;
    net_changed();

    start_sntp();

    /* R2.0.3：入网成功 → 信息框 IP 行显示周期重新计数（同组件模块间的轻量钩子）。 */
    overlay_ip_notify_joined();
}

static void fallback_to_ap(void)
{
    /* ★R2.7.0：本轮加入失败回落 —— RTC 连败计数 +1（无人attended 全功能
       唤醒连败 ≥ 3 次后改单次尝试档，见 wifi_mgr_init）。 */
    if (s_rtc_join.magic != WIFI_RTC_JOIN_MAGIC) {
        s_rtc_join.magic = WIFI_RTC_JOIN_MAGIC;
        s_rtc_join.fail_streak = 0;
    }
    s_rtc_join.fail_streak++;
    ESP_LOGW(TAG, "join failed %d times -> hotspot standby (retry every %ds when idle)",
             STA_CONNECT_MAX, (int)(STA_SLOW_RETRY_MS / 1000));
    s_joining = false;
    s_connected = false;
    s_fails = 0;
    s_slow_retry = true;              /* R2.1.0 需求 11：待命态，2 分钟后再试 */
    esp_wifi_set_mode(WIFI_MODE_APSTA);   /* 保持 STA 待命：热点开、随时可再连 */
    netif_ap_apply();                 /* 重新套用热点配置 */
    dns_guard(true);
    s_mode = NETIF_MODE_AP;
    if (s_watchdog) esp_timer_stop(s_watchdog);
    s_inet = false;                   /* 无局域网 = 无外网 */
    s_inet_agree = 0;
    net_changed();
}

static void sta_attempt(void)
{
    /* ★R2.7.2【修复3】：入睡序列中 / 驱动停机态不发 connect —— 对正在
       停机或已停机的驱动 connect 只会报错（ESP_ERR_WIFI_STATE /
       STOP_STATE）或触发无效掉线事件；R2.7.1 实测的报错链一环。 */
    if (power_sleeping() || s_drv_stopped) return;
    s_last_attempt_ms = esp_timer_get_time() / 1000;
    s_fails++;
    ESP_LOGW(TAG, "STA connect attempt %d/%d ...", s_fails, s_attempt_cap);
    if (s_fails >= s_attempt_cap) {   /* ★R2.7.0：连败抑制档下 cap=1 */
        fallback_to_ap();
        return;
    }
    esp_wifi_connect();
}

static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        s_drv_stopped = false;   /* ★R2.7.2【修复3】：驱动（重新）start → 解除停机标记 */
        /* WiFi 驱动就绪：发起第一次加入。 */
        if (s_joining) esp_wifi_connect();
    } else if (base == WIFI_EVENT &&
               (id == WIFI_EVENT_STA_STOP || id == WIFI_EVENT_AP_STOP)) {
        /* ★R2.7.2【修复3】：esp_wifi_stop() 完成（入睡序列 / 运行期切模式）
           —— 记入停机标记；入睡中止后 slow_retry 恢复分支拉起驱动。 */
        s_drv_stopped = true;
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        bool was_in_lan = (s_mode == NETIF_MODE_STA);
        s_connected = false;
        /* ★R2.7.2【修复1b/3】（睡死链闭合点）：入睡序列自己的
           esp_wifi_stop() 异步触发本事件 —— 旧代码在这里对正在停机的
           驱动 set_mode(APSTA) + netif_ap_apply(set_config → 实测
           ESP_ERR_WIFI_STOP_STATE) + esp_wifi_connect()，还投
           NET_CHANGED 触发 15s 全屏重画（随即被深睡拦腰斩断）。
           入睡窗口内一律短路：不重配、不重连、不重画、不拉 captive；
           只把状态退到「热点待命 + 慢重试」记账 —— 若入睡最终被
           power_enter_deep_sleep 的二次校验中止，驱动由
           slow_retry_cb 的恢复分支拉起（s_drv_stopped）。 */
        if (power_sleeping()) {
            ESP_LOGI(TAG, "sta disconnect during sleep entry: skip reconnect/redraw");
            if (was_in_lan) {
                s_mode = NETIF_MODE_AP;   /* 记账退到热点待命（驱动已停） */
                s_inet = false;
                s_inet_agree = 0;
            }
            s_ap_also = false;
            s_slow_retry = true;         /* 入睡中止后按 slow_retry 节拍恢复 */
            return;
        }
        if (was_in_lan) {
            /* 运行中掉线（路由器重启 / 信号抖动）：回 AP+STA 双开重试。 */
            ESP_LOGW(TAG, "lost LAN, reopening hotspot and retrying join");
            esp_wifi_set_mode(WIFI_MODE_APSTA);
            netif_ap_apply();
            dns_guard(true);
            s_ap_also = false;        /* 热点回到「主身份」而非共存态 */
            s_mode = NETIF_MODE_AP;
            s_joining = true;
            s_inet = false;           /* R2.1.0：局域网都没了 → 外网必然无 */
            s_inet_agree = 0;
            net_changed();            /* R2.1.0：掉线也是网络状态变化 */
            sta_attempt();
        } else if (s_joining) {
            sta_attempt();
        } else if (s_slow_retry) {
            /* 待命态试探失败：等下一个 2 分钟节拍，不快重试、不计失败。 */
            ESP_LOGI(TAG, "slow retry: not in range yet, wait next tick");
        }
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        enter_sta_mode();
    }
}

/* 加入尝试看门狗：无任何事件时按 STA_ATTEMPT_TIMEOUT_MS 推进一次重试
 *（个别路由器不回 DISCONNECT 事件，纯 esp_wifi_connect 会永远挂着）。 */
static void watchdog_cb(void *arg)
{
    (void)arg;
    if (!s_joining || s_mode == NETIF_MODE_STA) return;
    int64_t now = esp_timer_get_time() / 1000;
    if (now - s_last_attempt_ms >= STA_ATTEMPT_TIMEOUT_MS) {
        ESP_LOGW(TAG, "attempt watchdog fired (%lld ms since last attempt)",
                 (long long)(now - s_last_attempt_ms));
        sta_attempt();
    }
}

/* ---------------- R2.1.0：待命态慢速再入网（需求 11） ---------------- */

/* ★R2.7.2【修复1a 配套】：入睡中止后的驱动恢复 —— 入睡序列的
 * esp_wifi_stop() 把驱动停在 stop 态，光 esp_wifi_connect() 救不回来
 *（connect 要求驱动处于 start 态）。恢复序列与 wifi_mgr_restart_join
 * 同源：set_mode(APSTA) → 热点配置 → start；有 STA 凭据则置 joining，
 * STA_START 事件里自动 connect。无凭据的纯热点开机同样适用（只拉回
 * 热点，不动 STA）。 */
static void recover_driver_stopped(void)
{
    /* 已在局域网（s_mode 只在 GOT_IP 时置 STA）必然意味着驱动在跑 ——
       停机标记是竞态残影，清掉直接返回，避免把纯 STA 拖回 APSTA。 */
    if (s_mode == NETIF_MODE_STA) {
        s_drv_stopped = false;
        return;
    }
    wifi_mode_t m = WIFI_MODE_NULL;
    if (esp_wifi_get_mode(&m) != ESP_OK) {
        /* 驱动未初始化（异常路径，理论上不会发生）：无计可施，清标记
           等下一次全功能唤醒重走 wifi_mgr_init。 */
        ESP_LOGW(TAG, "recover: wifi driver unavailable, skip");
        s_drv_stopped = false;
        return;
    }
    ESP_LOGW(TAG, "slow retry: driver stopped by aborted sleep, restarting wifi");
    esp_wifi_set_mode(WIFI_MODE_APSTA);
    netif_ap_apply();
    if (settings_get()->sta_ssid[0] != '\0') {
        s_joining = true;               /* STA_START 事件里自动 connect */
        s_fails = 0;
        s_last_attempt_ms = esp_timer_get_time() / 1000;
    } else {
        s_joining = false;              /* 纯热点开机：只拉回热点 */
    }
    dns_guard(true);                    /* 热点在播 → captive 就绪 */
    if (esp_wifi_start() == ESP_OK) {
        s_drv_stopped = false;
    } else {
        ESP_LOGE(TAG, "recover: esp_wifi_start failed (retry next slow tick)");
    }
}

static void slow_retry_cb(void *arg)
{
    (void)arg;
    /* ★R2.7.2【修复1b】：入睡序列进行中不动作 —— 防对停机驱动 connect。 */
    if (power_sleeping()) return;
    /* ★R2.7.2【修复1a】：驱动停在 stop 态（入睡中止遗留）→ 先拉起驱动，
       连接交给 STA_START 事件；本周期不重复 connect。 */
    if (s_drv_stopped) {
        recover_driver_stopped();
        return;
    }
    if (!s_slow_retry || s_mode == NETIF_MODE_STA) return;
    /* 配置页无设备访问 = 热点无已连接客户端（连着热点的手机可能正在配置，
       此时切信道会把它踢掉 —— 需求 11 的保护条件）。 */
    int clients = netif_ap_client_count();
    if (clients > 0) {
        ESP_LOGI(TAG, "slow retry: %d client(s) on hotspot, skip join", clients);
        return;
    }
    const moink_settings_t *s = settings_get();
    if (s->sta_ssid[0] == '\0') return;
    ESP_LOGI(TAG, "slow retry: trying to join '%s' ...", s->sta_ssid);
    s_last_attempt_ms = esp_timer_get_time() / 1000;
    esp_wifi_connect();
}

/* ---------------- R2.1.0：外网探测任务（需求 2/9/10） ---------------- */

static void probe_once(void)
{
    /* ★R2.7.2【修复1b】：入睡序列中 / 驱动停机态不探测 —— DNS 解析白耗
       时且可能在入睡窗口内投 NET_CHANGED；停机驱动上探测结果无意义。 */
    if (power_sleeping() || s_drv_stopped) return;
    if (s_mode != NETIF_MODE_STA || !s_connected) {
        s_inet = false;
        s_inet_agree = 0;
        return;
    }
    /* 需求 9 让步条款：页面 BLE 扫描窗口期间跳过本轮探测（射频让给蓝牙；
       ESP32 共存仲裁本身已时分复用，这里是额外礼让）。 */
    if (ble_sensor_scan_active()) {
        ESP_LOGI(TAG, "probe: BLE scan window active, yield this round");
        return;
    }

    struct hostent *he = gethostbyname(SNTP_CHECK_TAG);
    bool ok = (he != NULL);

    if (ok == s_inet) {
        s_inet_agree = 0;              /* 与已确认状态一致：计数清零 */
        return;
    }
    if (++s_inet_agree < NET_CONFIRM_N) {
        ESP_LOGI(TAG, "probe: %s x%d/%d (not confirmed yet)",
                 ok ? "up" : "down", s_inet_agree, NET_CONFIRM_N);
        return;
    }

    /* 三连确认 → 状态生效（需求 9：刷新屏幕前强制连续确认三次）。 */
    s_inet = ok;
    s_inet_agree = 0;
    ESP_LOGI(TAG, "internet confirmed %s (dns %s, 3x)",
             ok ? "up" : "down", SNTP_CHECK_TAG);

    if (!ok && s_connected) {
        hotspot_also(true);            /* 需求 10：局域网在 + 热点共存 */
    } else if (ok) {
        hotspot_also(false);           /* 外网恢复：热点退位 */
    }
    net_changed();                     /* 需求 2/7：网络状态变化 → 刷屏 */
}

static void probe_task(void *arg)
{
    (void)arg;
    for (;;) {
        xSemaphoreTake(s_probe_sem, portMAX_DELAY);
        probe_once();
    }
}

static void probe_timer_cb(void *arg)
{
    (void)arg;
    if (s_probe_sem) xSemaphoreGive(s_probe_sem);
}

static void probe_start(void)
{
    if (!s_probe_timer) {
        const esp_timer_create_args_t t = {
            .callback = &probe_timer_cb,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "net_probe",
        };
        esp_timer_create(&t, &s_probe_timer);
    } else {
        esp_timer_stop(s_probe_timer);
    }
    esp_timer_start_periodic(s_probe_timer, (uint64_t)s_netcheck_iv * 1000000ULL);
}

/* ---------------- 公共 API ---------------- */

void wifi_mgr_set_ui_post(void (*post)(int ev))
{
    s_ui_post = post;
}

void wifi_mgr_init(bool unattended)
{
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    /* ★R2.7.0 连败抑制：无人attended 的全功能唤醒（调度事件：换位/轮播/
       校时保底/看护）且路由器已连败 ≥ 3 个唤醒周期 —— 本轮只试【一次】
       加入（射频搜寻 ~1-3s）。有人触发（上电/按键 —— unattended=false）
       或计数丢失：全力尝试并清零。 */
    s_attempt_cap = STA_CONNECT_MAX;
    if (unattended && s_rtc_join.magic == WIFI_RTC_JOIN_MAGIC &&
        s_rtc_join.fail_streak >= WIFI_JOIN_STREAK_MAX) {
        s_attempt_cap = 1;
        ESP_LOGW(TAG, "router missed %u full wake(s), single join attempt this cycle",
                 (unsigned)s_rtc_join.fail_streak);
    } else if (!unattended) {
        s_rtc_join.magic = WIFI_RTC_JOIN_MAGIC;
        s_rtc_join.fail_streak = 0;
    }

    /* 两个 netif 一次性建好，之后只靠 WiFi 模式切换控制谁在播。
       （default creator 只能各调用一次，动态启停用 set_mode 实现。） */
    netif_ap_setup();
    s_sta_if = esp_netif_create_default_wifi_sta();

    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        IP_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL));

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    /* STA + BLE 共存：最小省电档给蓝牙扫描留出时间片（默认即是，显式设定防漂移）。
       v6 起 wifi_ps_type_t 只保留 *MODEM 旧式 *MODE 名已删除。 */
    ESP_ERROR_CHECK(esp_wifi_set_ps(WIFI_PS_MIN_MODEM));

    /* R2.1.0：外网探测任务 + 定时器（先起任务再起定时器）。 */
    s_netcheck_iv = settings_get()->netcheck_iv;
    s_probe_sem = xSemaphoreCreateCounting(2, 0);
    if (s_probe_sem &&
        xTaskCreate(probe_task, "net_probe", 4096, NULL, 4, &s_probe_task_h) == pdPASS) {
        probe_start();
    } else {
        ESP_LOGW(TAG, "probe task create failed, net check disabled");
    }

    const moink_settings_t *s = settings_get();
    bool have_sta = (s->sta_ssid[0] != '\0');

    if (have_sta) {
        /* ★ FB-R2.0.1 修复：配网保存重启后开机循环崩溃（0x3005）的根因 —— 顺序错误。
           原代码先 set_config(WIFI_IF_STA) 再 set_mode(APSTA)：还没设过模式
           （NULL 模式）时 STA 接口不存在，esp_wifi_set_config 返回
           ESP_ERR_WIFI_MODE，ESP_ERROR_CHECK 直接 abort（首次启动无凭据不走
           本分支，所以只有配网后才会崩）。正确顺序：set_mode → set_config →
           start，这是 v6.x 的硬约束。 */
        /* AP+STA 双开：加入期间热点仍在（配错密码也能连热点改配置）。 */
        ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_APSTA));
        netif_ap_apply();   /* 内部 set_config(WIFI_IF_AP)：同样要求模式已含 AP */

        wifi_config_t sta = { 0 };
        strlcpy((char *)sta.sta.ssid, s->sta_ssid, sizeof(sta.sta.ssid));
        strlcpy((char *)sta.sta.password, s->sta_pass, sizeof(sta.sta.password));
        sta.sta.pmf_cfg.capable = true;
        sta.sta.pmf_cfg.required = false;
        ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &sta));

        /* 状态先置位再 start：STA_START 事件在事件任务里派发，若 start
           返回后才置位，事件先到就漏掉第一次 connect（虽有 8s 看门狗
           兜底，没必要赌调度）。 */
        s_joining = true;
        s_fails = 0;
        s_last_attempt_ms = esp_timer_get_time() / 1000;
        ESP_ERROR_CHECK(esp_wifi_start());

        ESP_LOGI(TAG, "joining '%s' (up to %d attempts, hotspot stays up)",
                 s->sta_ssid, STA_CONNECT_MAX);

        const esp_timer_create_args_t wargs = {
            .callback = &watchdog_cb,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "sta_watchdog",
        };
        esp_timer_create(&wargs, &s_watchdog);
        esp_timer_start_periodic(s_watchdog, STA_ATTEMPT_TIMEOUT_MS * 1000);
    } else {
        /* 无配网：原纯热点行为。 */
        ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
        netif_ap_apply();
        ESP_ERROR_CHECK(esp_wifi_start());
        s_joining = false;
    }

    dns_guard(true);       /* AP（或 APSTA 的热点侧）在播 → captive portal 就绪 */
    netif_ap_apply_tx_power();

    /* R2.1.0：待命态慢速再入网定时器（每 2 分钟看一眼，回调里自行判定）。 */
    {
        const esp_timer_create_args_t rargs = {
            .callback = &slow_retry_cb,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "sta_slow",
        };
        esp_timer_create(&rargs, &s_slow_timer);
        esp_timer_start_periodic(s_slow_timer, STA_SLOW_RETRY_MS * 1000ULL);
    }

    /* mDNS：moink.local（两种模式下都可用）。 */
    if (mdns_init() == ESP_OK) {
        mdns_hostname_set(HOSTNAME);
        mdns_instance_name_set("MoInK e-paper");
        /* 托管版 mdns（v5.2+ / v6 / espressif/mdns）签名多出 TXT 参数：
           mdns_service_add(instance, type, proto, port, txt[], num_items) */
        mdns_service_add(NULL, "_http", "_tcp", 80, NULL, 0);
        ESP_LOGI(TAG, "mDNS: http://%s.local/", HOSTNAME);
    } else {
        ESP_LOGW(TAG, "mDNS init failed (fine in AP mode)");
    }

    s_up = true;   /* ★R2.7.0：网络栈在位（远端拉取触发等的判据） */
}

netif_mode_t wifi_mgr_mode(void) { return s_mode; }

bool wifi_mgr_up(void) { return s_up; }

const char *wifi_mgr_mode_name(void)
{
    return (s_mode == NETIF_MODE_STA) ? "sta" : "ap";
}

bool wifi_mgr_ap_also(void) { return s_ap_also; }

bool wifi_mgr_net_settled(void)
{
    if (s_mode == NETIF_MODE_STA) return true;
    return !s_joining;      /* 无凭据纯热点 / 待命态（慢速重试）都算落定 */
}

/* ★R2.6.1：正在快速尝试加入局域网（remote 拉取在途判定用 ——
   joining 中 = 几秒内可能入网，值得等；待命态（2 分钟慢重试）不必等）。 */
bool wifi_mgr_joining(void) { return s_joining; }

bool wifi_mgr_sta_connected(void) { return s_connected; }

const char *wifi_mgr_ip(void) { return s_ip; }

int wifi_mgr_rssi(void)
{
    if (s_mode != NETIF_MODE_STA) return 0;
    wifi_ap_record_t ap;
    if (esp_wifi_sta_get_ap_info(&ap) != ESP_OK) return 0;
    return ap.rssi;
}

bool wifi_mgr_internet(void) { return s_inet; }

/* R2.1.0 兼容口：旧代码到点重画前现场探测；现在探测任务周期更新缓存，
   这里只回缓存（display_task 不再做阻塞 DNS）。 */
void wifi_mgr_check_internet(void)
{
    /* ★R2.7.1：无网络栈（轻唤醒未起射频）第一时间返回 —— 固化「本口
       永不触发 DNS/getaddrinfo 阻塞」契约，防未来实现回归卡死轻链路。 */
    if (!s_up) return;
}

bool wifi_mgr_time_synced(void)
{
    time_t t = time(NULL);
    return ((int64_t)t > TIME_OK_TS);
}

void wifi_mgr_set_netcheck_iv(uint32_t sec)
{
    if (sec < 10) sec = 10;
    if (sec > 600) sec = 600;
    s_netcheck_iv = sec;
    probe_start();
    ESP_LOGI(TAG, "net check interval -> %us", (unsigned)sec);
}

int wifi_mgr_sta_fails(void) { return s_fails; }

void wifi_mgr_restart_join(void)
{
    const moink_settings_t *s = settings_get();
    if (s->sta_ssid[0] == '\0') return;
    if (s_mode == NETIF_MODE_STA) return;

    /* ★ FB-R2.0.1：运行期应用（新）凭据必须走 stop → set_mode →
       set_config → start 完整序列。旧实现两个坑：① 运行中直接
       set_config(WIFI_IF_STA) 与开机路径同病（接口不在当前模式 →
       0x3005）；② 从未把凭据写进驱动，connect 会拿旧/空 SSID 去连。 */
    esp_wifi_stop();                  /* 运行中切模式的合法前提：先停 */
    esp_wifi_set_mode(WIFI_MODE_APSTA);
    netif_ap_apply();

    wifi_config_t sta = { 0 };
    strlcpy((char *)sta.sta.ssid, s->sta_ssid, sizeof(sta.sta.ssid));
    strlcpy((char *)sta.sta.password, s->sta_pass, sizeof(sta.sta.password));
    sta.sta.pmf_cfg.capable = true;
    sta.sta.pmf_cfg.required = false;
    esp_wifi_set_config(WIFI_IF_STA, &sta);

    s_slow_retry = false;             /* 回到快重试节奏 */
    s_joining = true;                 /* start 后 STA_START 事件里自动 connect */
    s_fails = 0;
    s_attempt_cap = STA_CONNECT_MAX;  /* ★R2.7.0：配网保存 = 有人在配置，全力尝试 */
    s_last_attempt_ms = esp_timer_get_time() / 1000;
    esp_wifi_start();
}
