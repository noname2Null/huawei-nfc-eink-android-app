#ifndef MOINK_PWR_SCHED_H
#define MOINK_PWR_SCHED_H

/*
 * 事件驱动休眠调度（R2.5.0，纯 C —— 不依赖任何 IDF 头，主机可测）。
 *
 * 背景：主控常开太烫。R2.5.0 起改「空闲入睡 + 事件唤醒」：
 *   入睡前把「下一次会刷屏的调度事件」折算成 RTC 定时器秒数；
 *   到点唤醒（等价一次重启）跑全部任务，干完活再睡。
 *
 * 本模块只做**分钟边界数学**：给定各事件间隔与当前时刻，求最近一次
 * 事件的秒距。判据与 overlay.c minute_cb 的触发器一一对应：
 *   BOX / REMOTE / CAROUSEL / MOVE 都是 `分钟数 % 间隔 == 0` 的整分对齐
 *   （★R2.7.1 起触发侧 minute_cb 同用 epoch 分钟 mnow —— 三处同一判据，
 *   原先触发侧用 tmv.tm_min，间隔档不整除时区偏移时会与唤醒点错位）。
 *
 * wake_s（用户「自动唤醒」）不是分钟对齐，而是自本次入睡起算的固定
 * 间隔 —— 单独一路参与取最小。
 *
 * ★ R2.6.0 唤醒提前量（LEAD）：唤醒时刻不再落在事件边界上，而是提前
 *   PWR_SCHED_LEAD_S 秒 —— 深睡唤醒是一次完整重启（boot + 网络落定 +
 *   NTP + 上电门控合计 5~26 s），踩点唤醒必然错过触发分钟（minute_cb 的
 *   整分判据错过一次就要再等整个间隔）。提前量不够放（距边界太近）时
 *   退化到 PWR_SCHED_LEAD_MIN_S，仍不够则顺延一个周期；错过由唤醒侧
 *   补刷兜底（overlay catch-up，见 overlay.c）。
 *
 * ★ R2.6.1 贴边唤醒：距边界不足 LEAD_MIN+MIN_S（上一事件的忙碌尾巴常
 *   把入睡决策推进这一窗）时不再顺延一个周期 —— 顺延等于无声跳过眼前
 *   的边界（无唤醒、无标记，时钟/拉取再 stale 一个间隔）。改为贴边唤醒
 *   （now+MIN_S，标记仍指向眼前边界），迟到交给唤醒侧补刷
 *   （pwr_sched_missed 窗口已扩 1 分钟）兜底。
 *
 * 距唤醒时刻不足 PWR_SCHED_MIN_S 的一律贴边唤醒（见上）：睡眠入口 +
 * 深睡掉电 + 重新启动要 1~3 s，太近的定时只会在门控期间错过触发分钟。
 *
 * ★ R2.7.0 事件分档提前量（两档功耗状态机）：
 *   BOX（分钟局刷）唤醒是【轻唤醒】—— 不起射频、不过 boot 门控等待，
 *   启动+门控 ≈ 2~3s，提前量只要 LEAD_LIGHT_S；其余事件（REMOTE/
 *   CAROUSEL/MOVE，全功能唤醒：联网/校时/拉取/蓝牙窗口）门控合计
 *   5~32s，维持 LEAD_S。退档/贴边判据同样按各自档位评估。
 *   PWR_EVT_SYNC 不参与本调度（它不是对齐事件，而是 power 侧的
 *   「轻链连续 ≥ PWR_SYNC_IV_MIN 强制升格全功能」保底，见 power.c）。
 */

#include <stdint.h>
#include <stdbool.h>

/* 调度事件种类（也用作日志名）。 */
enum {
    PWR_EVT_NONE = 0,   /* 无事件（不该出现在 in_s > 0 的结果里） */
    PWR_EVT_BOX,        /* 信息框到点重画（用户口中的「分钟刷新」） */
    PWR_EVT_REMOTE,     /* 远端图片拉取 */
    PWR_EVT_CAROUSEL,   /* 图库自动轮播 */
    PWR_EVT_MOVE,       /* 信息框防老化换位 */
    PWR_EVT_WAKE,       /* 用户定时唤醒（wake_s，等人的窗口） */
    PWR_EVT_SYNC,       /* ★R2.7.0 校时保底（不参与 pwr_sched_next：power 侧
                           轻链连续 ≥ PWR_SYNC_IV_MIN 时把下一个 BOX 轻唤醒
                           升格为全功能唤醒 —— 联网/SNTP 重锚/蓝牙窗口） */
};

typedef struct {
    uint32_t box_iv_min;   /* 信息框刷新间隔（分钟）；0 = 不参与 */
    uint32_t rmt_iv_min;   /* 远端拉取间隔（分钟）；0 = 不参与 */
    uint32_t caro_iv_min;  /* 图库轮播间隔（分钟）；0 = 不参与 */
    uint32_t move_iv_min;  /* 防老化换位间隔（分钟）；0 = 不参与 */
    uint32_t wake_s;       /* 用户自动唤醒间隔（秒）；0 = 不参与 */
} pwr_sched_in_t;

typedef struct {
    uint32_t in_s;         /* 距唤醒定时秒数（> 0）；0 = 无事件 */
    uint8_t  event;        /* PWR_EVT_*；in_s == 0 时为 PWR_EVT_NONE */
    int64_t  at_epoch;     /* ★R2.6.0：事件边界的 epoch 秒（整分对齐事件的
                              边界时刻；wake_s = now+in_s）。0 = 无事件。
                              power 侧随入睡标记写 RTC noinit，唤醒后
                              overlay catch-up 用它判断「边界是否被门控
                              吃掉」。（唤醒时刻 = at_epoch - 提前量） */
} pwr_sched_out_t;

/* 求最近一次调度事件。now_epoch = time(NULL)（未对时的假钟同样按 1 Hz
   走，数学不变 —— 对齐相位无意义但间隔正确）。 */
void pwr_sched_next(int64_t now_epoch, const pwr_sched_in_t *in,
                    pwr_sched_out_t *out);

/* ★R2.6.0：补刷窗口判定 —— 唤醒标记里的目标边界 tgt 是否已被本次开机的
   门控期吃掉（tgt ≤ 当前分钟 < tgt + iv_min + 1；★R2.6.1 右端扩 1 分钟）。
   真 = 该事件应立即补发（错过整分判据后 minute_cb 要再等整个间隔，
   时钟/拉取会 stale 一个周期）。补刷只在 boot_done 一处执行且先于任何
   minute_cb 触发，扩窗不会重复补发。wake_s / 无事件（iv=0）恒为 false。 */
bool pwr_sched_missed(int64_t now_epoch, int64_t tgt_epoch, uint32_t iv_min);

/* 事件短名（日志用）。 */
const char *pwr_sched_evt_name(uint8_t evt);

/* 唤醒提前量（秒）：目标边界前该时长唤醒，给 boot + 上电门控留出提前量。
 * ★R2.7.0 起仅用于【全功能事件】（REMOTE/CAROUSEL/MOVE）：boot 门控快速档
 * 合计 5~32s（net 12 + ntp 6 + ble 6 + rmt 8），30s 提前量吃得下。 */
#define PWR_SCHED_LEAD_S     30
/* ★R2.7.0 轻唤醒（BOX 分钟局刷）提前量（秒）：不起射频、门控捷径 ≈ 2~3s
 *（boot ~1s + 显示源恢复 + boot_done），6s 提前量足够踩点整分边界。 */
#define PWR_SCHED_LEAD_LIGHT_S 6
/* 提前量退化档（秒）：距边界不足以放满 LEAD 时至少提前这么多（仍保
   PWR_SCHED_MIN_S 的唤醒下限）；再放不下就贴边唤醒（★R2.6.1）。 */
#define PWR_SCHED_LEAD_MIN_S 10
/* 距唤醒时刻不足该秒数时贴边唤醒（防「醒-睡-醒」乒乓；迟到交给补刷）。 */
#define PWR_SCHED_MIN_S      10

#endif /* MOINK_PWR_SCHED_H */
