#include "remote.h"
#include "settings.h"
#include "wifi_mgr.h"
#include "frame.h"
#include "store.h"
#include "overlay.h"
#include "version.h"
#include "power.h"        /* R2.5.0：拉取完成计一次活动（事件唤醒窗口以此收尾） */

#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "esp_attr.h"      /* R2.6.0：RTC_NOINIT_ATTR（cid/槽位跨深睡存活） */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

#include <string.h>
#include <stdio.h>
#include <inttypes.h>

static const char *TAG = "remote";

/* ---- 协议常量（与 remote.h 头注释、tools/moink_remote_pc 三方一致） ---- */
#define RMT_HDR_LEN    32
#define RMT_ROWS       552                 /* 全帧行数（= 面板 552 行载荷） */
#define RMT_RB_FULL    192                 /* 信息框关闭：全屏 768px 宽行 */
#define RMT_RB_SPLIT   152                 /* 分割（竖屏方向）：每行 152 字节段 */
#define RMT_SUB_ROWS_L 392                 /* 分割（横屏方向）：段数 = 552-160 */
#define RMT_SUB_RB_L   192                 /* 分割（横屏方向）：整行 192 字节段 */

/* R2.2.1：当前方向应答分割子帧的（行数， 每行字节）。
 * 竖屏 0/2：552 x 152（载荷行内字节段）；横屏 1/3：392 x 192（整载荷行）。
 * 与 frame.c 子帧布局 / PC 工具打包三方一致（sim_orient_geom.py 证明）。 */
static void sub_shape(bool split, uint16_t *rows, uint16_t *rb)
{
    const uint8_t o = settings_get()->orient;
    if (!split) { *rows = RMT_ROWS; *rb = RMT_RB_FULL; return; }
    if (o == 1 || o == 3) { *rows = RMT_SUB_ROWS_L; *rb = RMT_SUB_RB_L; }
    else                  { *rows = RMT_ROWS;       *rb = RMT_RB_SPLIT; }
}
#define RMT_TIMEOUT_MS 12000
#define RMT_CHUNK      512
/* URL 缓冲：最坏 7(http://)+71(auth)+39(path)+18(/moink/pull?style=)+11(%d 最宽)
   +5(&cid=)+16(cid)+4(&fw=)+len(版本号)+1(NUL) ≈ 178B。R2.1.0 曾取 160，
   GCC -Wformat-truncation 判定最坏 168B 可截断（-Werror 直接编译失败），
   R2.1.1 放宽到 256 根除；build_url 内另有运行时兜底检查。 */
#define RMT_URL_MAX    256

typedef struct {
    bool     en;
    bool     active;      /* 当前屏幕显示的是远端内容 */
    bool     split;       /* 远端样式（true = 分割） */
    uint64_t cid;         /* 当前内容唯一 id */
    bool     last_ok;
    int      last_code;
    int64_t  last_ms;
    uint32_t pulls, fails, skips;
} rmt_state_t;

static rmt_state_t s = { 0 };
static SemaphoreHandle_t s_kick_sem;        /* 拉取信号（计数） */
static SemaphoreHandle_t s_first_sem;      /* 首次拉取出结果（boot gate 等） */
static volatile bool s_first_done = false;
static volatile bool s_revert_req = false; /* 配置关闭后的回落请求（任务内执行） */
static bool s_task_up = false;

/* ---------------- ★R2.6.0 远端显示状态 RTC 持久化 ----------------
 * R2.5.0 事件驱动休眠后，cid（RAM）随深睡丢失 —— 唤醒后首拉必带 cid=0，
 * 远端只能整发新内容，设备每个唤醒周期都对【同一画面】做一次整屏刷新
 * （15~25 s 闪屏 + 面板损耗）。cid/split/暂存槽其实就 24 字节，存 RTC
 * noinit 跨深睡存活：唤醒后恢复显示源（frame_remote_restore，不刷屏），
 * 同内容 304 跳过 —— 唤醒零刷新。
 * 一致性：提交成功/回落/被顶替时同步写；槽头校验不过（被上传复用）
 * 则放弃恢复（回落为「未激活」，首拉重新整刷，与 R2.5 行为一致）。 */
#define RMT_RTC_MAGIC 0x524D5436u   /* "RMT6" */

typedef struct {
    uint32_t magic;
    uint8_t  active;
    uint8_t  split;
    uint8_t  _rsv[2];
    int32_t  phys;                 /* 睡前远端暂存槽（显示源） */
    uint64_t cid;                  /* 睡前显示的内容 id */
} rmt_rtc_t;

static rmt_rtc_t s_rtc RTC_NOINIT_ATTR;

static void rtc_save(bool active, bool split, int32_t phys, uint64_t cid)
{
    s_rtc.magic  = RMT_RTC_MAGIC;
    s_rtc.active = active ? 1 : 0;
    s_rtc.split  = split ? 1 : 0;
    s_rtc._rsv[0] = s_rtc._rsv[1] = 0;
    s_rtc.phys   = phys;
    s_rtc.cid    = cid;
}

static void rtc_clear(void)
{
    s_rtc.magic  = 0;
    s_rtc.active = 0;
    s_rtc.split  = 0;
    s_rtc.phys   = -1;
    s_rtc.cid    = 0;
}

/* ---------------- 小工具 ---------------- */

/* CRC-16/CCITT-FALSE：poly 0x1021，init 0xFFFF，无反射、无终异或（与 frame.c 同）。 */
static uint16_t crc16_update(uint16_t crc, const uint8_t *d, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        crc ^= (uint16_t)d[i] << 8;
        for (int b = 0; b < 8; b++) {
            crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021)
                                 : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

static int64_t now_us(void) { return esp_timer_get_time(); }

static void pull_finish(int code)
{
    s.last_ok = (code >= 0);
    s.last_code = code;
    s.last_ms = now_us();
    if (code >= 0) {
        if (code == RMT_CODE_OK_SAME) s.skips++;
    } else {
        s.fails++;
    }
    if (!s_first_done) {
        s_first_done = true;
        if (s_first_sem) xSemaphoreGive(s_first_sem);
    }
}

static int fail_code(int code)
{
    pull_finish(code);
    return code;
}

/* 组装拉取 URL：http://<authority>[/前缀]/moink/pull?style=S&cid=C&fw=V */
static void build_url(char *out, size_t n)
{
    const moink_settings_t *st = settings_get();
    const char *host = st->remote_host;
    char auth[72] = "", path[40] = "";

    /* 容忍用户带 http(s):// 前缀（TLS 不支持，按明文端口试） */
    if (strncmp(host, "http://", 7) == 0)  host += 7;
    else if (strncmp(host, "https://", 8) == 0) host += 8;

    const char *slash = strchr(host, '/');
    if (slash) {
        size_t alen = (size_t)(slash - host);
        if (alen >= sizeof(auth)) alen = sizeof(auth) - 1;
        memcpy(auth, host, alen);
        auth[alen] = '\0';
        strlcpy(path, slash, sizeof(path));   /* 含开头的 '/' */
    } else {
        strlcpy(auth, host, sizeof(auth));
    }

    /* 需求 6：向远端发送设备当前呈现样式（0 关 / 1 叠加 / 2 分割）。 */
    int style;
    if (s.active) {
        style = s.split ? 2 : 0;
    } else if (st->box_en) {
        style = (st->box_style == SETT_BOX_STYLE_SPLIT) ? 2 : 1;
    } else {
        style = 0;
    }

    char cid[17];
    remote_cid_hex(cid, sizeof(cid));
    /* R2.2.1：上报屏幕方向（0..3，以排线为基准）—— 远端据此切换默认画布
     * （竖屏 552×768 / 横屏 768×552）并按方向打包；方向语义见 settings.h。 */
    uint8_t orient = settings_get()->orient;
    if (orient > 3) orient = 0;
    int k = snprintf(out, n, "http://%s%s/moink/pull?style=%d&cid=%s&fw=%s&orient=%u",
                     auth, path, style, cid, MOINK_VERSION, orient);
    if (k < 0 || (size_t)k >= n) {         /* R2.1.1：理论到不了，防未来字段加长 */
        out[0] = '\0';
        ESP_LOGE(TAG, "pull url truncated (%d >= %u)", k, (unsigned)n);
    }
}

/* 循环读满 n 字节（esp_http_client_read 单次可能短读）。
   返回实际读到的字节数（< n = 截断/出错）。 */
static int read_full(esp_http_client_handle_t h, uint8_t *buf, int n)
{
    int got = 0;
    while (got < n) {
        int k = esp_http_client_read(h, (char *)buf + got, n - got);
        if (k > 0) { got += k; continue; }
        if (k == 0) {                 /* 超时窗口内无数据：短暂让出后再试一次 */
            vTaskDelay(pdMS_TO_TICKS(50));
            k = esp_http_client_read(h, (char *)buf + got, n - got);
            if (k > 0) { got += k; continue; }
        }
        break;                        /* 连接关闭 / 出错 */
    }
    return got;
}

/* 远端内容暂存槽的哑帧头（16B，与上传帧同构；仅诊断用途 —— 显示源不走
   frame_display_slot，正常路径不读它）。hdr[15]：bit0=分割 bit1=远端源。 */
static void dummy_frame_hdr(uint8_t *h16, bool split, uint32_t len, uint16_t crc)
{
    memset(h16, 0, 16);
    h16[0] = 0xA5;  h16[1] = 0x5A;
    h16[2] = 1;                        /* fmt v1 */
    h16[3] = 0;                        /* A0 */
    h16[4] = (uint8_t)(768 >> 8);  h16[5] = (uint8_t)(768 & 0xFF);
    h16[6] = (uint8_t)(552 >> 8);  h16[7] = (uint8_t)(552 & 0xFF);
    h16[8]  = (uint8_t)(len >> 24); h16[9]  = (uint8_t)(len >> 16);
    h16[10] = (uint8_t)(len >> 8);  h16[11] = (uint8_t)(len & 0xFF);
    h16[12] = (uint8_t)(crc >> 8);  h16[13] = (uint8_t)(crc & 0xFF);
    h16[14] = 0xA5;
    h16[15] = (uint8_t)((split ? 0x01 : 0x00) | 0x02);
}

/* ---------------- 拉取主流程（remote_task 上下文） ---------------- */

static void do_revert(void)
{
    if (s.active) {
        frame_remote_revert();         /* 回落图库当前槽（空则白底）+ 刷屏 */
        s.active = false;
        s.split = false;
        s.cid = 0;
        rtc_clear();                   /* ★R2.6.0：显示状态不再有效 */
        ESP_LOGI(TAG, "remote off: reverted to gallery/white");
    }
}

static void do_pull(void)
{
    const moink_settings_t *st = settings_get();

    /* 配置关闭 → 回落并出结果（boot gate 也要能等到这个结果）。 */
    if (s_revert_req) {
        s_revert_req = false;
        do_revert();
        pull_finish(RMT_CODE_OK_SAME);
        return;
    }

    s.en = (st->remote_en && st->remote_host[0] != '\0');
    if (!s.en) {
        do_revert();                   /* 开关被关但还没回落的兜底 */
        pull_finish(RMT_E_NO_HOST);
        return;
    }
    if (wifi_mgr_mode() != NETIF_MODE_STA) {
        if (!wifi_mgr_joining()) {
            /* 纯热点 / 待命态（10 次失败已回落，2 分钟慢重试）：不必等 */
            ESP_LOGI(TAG, "pull skipped: not in LAN");
            fail_code(RMT_E_NO_LAN);
            return;
        }
        /* ★R2.6.1：正在加入（慢路由器在途）—— 门控 net_wait 兜不到的
           GOT_IP 落后 kick 几秒的窗，原实现直接判「not in LAN」=
           本周期空手（用户实测「远程拉取内容失败」根因之一）。 */
        ESP_LOGI(TAG, "pull: LAN join in flight, waiting link ...");
    }
    /* ★R2.6.1：等真实链路（mode STA 且已拿 IP，最多 ~10s）—— 慢路由器
       下 GOT_IP 常落在门控后 / 补刷 kick 与 minute_cb kick 在途时。 */
    {
        uint32_t w = 0;
        while (w < 10000 &&
               !(wifi_mgr_mode() == NETIF_MODE_STA && wifi_mgr_sta_connected())) {
            vTaskDelay(pdMS_TO_TICKS(250));
            w += 250;
            if (wifi_mgr_mode() != NETIF_MODE_STA && !wifi_mgr_joining()) break;
        }
        if (!(wifi_mgr_mode() == NETIF_MODE_STA && wifi_mgr_sta_connected())) {
            ESP_LOGI(TAG, "pull skipped: link not up after %ums", w);
            fail_code(RMT_E_NO_LAN);
            return;
        }
    }
    if (overlay_pwd_reset_active()) {  /* 密码重置独占屏幕，别抢 */
        fail_code(RMT_E_PWD);
        return;
    }
    if (!store_part()) {
        fail_code(RMT_E_NO_STORE);
        return;
    }

    char url[RMT_URL_MAX];
    build_url(url, sizeof(url));
    ESP_LOGI(TAG, "pull: %s", url);

    esp_http_client_config_t cfg = {
        .url = url,
        .timeout_ms = RMT_TIMEOUT_MS,
        .keep_alive_enable = false,   /* 每次独立连接，省得断线状态串台 */
    };
    esp_http_client_handle_t h = esp_http_client_init(&cfg);
    if (!h) { fail_code(RMT_E_HTTP); return; }

    int err = RMT_CODE_OK_NEW;
    int phys = -1;
    bool held_lock = false;           /* 原地复用暂存槽时流式写入期间持帧锁 */
    bool staged_inplace = false;      /* 已往原地复用槽写入（失败时须回落图库） */
    bool committed = false;

    do {
        if (esp_http_client_open(h, 0) != ESP_OK) { err = RMT_E_HTTP; break; }
        int cl = esp_http_client_fetch_headers(h);
        int status = esp_http_client_get_status_code(h);
        if (status == 304) {          /* 远端告知内容未变 */
            err = RMT_CODE_OK_SAME;
            break;
        }
        if (status != 200) {
            ESP_LOGW(TAG, "pull: HTTP %d (cl %d)", status, cl);
            err = RMT_E_HTTP;
            break;
        }

        /* ---- 32B 协议头 ---- */
        uint8_t hdr[RMT_HDR_LEN];
        if (read_full(h, hdr, sizeof(hdr)) != (int)sizeof(hdr)) {
            err = RMT_E_BAD_HDR;
            break;
        }
        if (memcmp(hdr, "MKRP", 4) != 0 || hdr[4] != 1) { err = RMT_E_BAD_HDR; break; }
        bool split = (hdr[5] == 1);
        uint16_t rows = (uint16_t)((hdr[6] << 8) | hdr[7]);
        uint16_t rb   = (uint16_t)((hdr[8] << 8) | hdr[9]);
        uint32_t len  = ((uint32_t)hdr[10] << 24) | ((uint32_t)hdr[11] << 16) |
                         ((uint32_t)hdr[12] << 8) | hdr[13];
        uint16_t crc_h = (uint16_t)((hdr[14] << 8) | hdr[15]);
        uint64_t cid = 0;
        for (int i = 16; i < 24; i++) cid = (cid << 8) | hdr[i];
        uint16_t want_rows = 0, want_rb = 0;
        sub_shape(split, &want_rows, &want_rb);
        if (rows != want_rows || rb != want_rb ||
            len != (uint32_t)rows * rb) {
            ESP_LOGW(TAG, "pull: bad header (style %u rows %u rb %u len %lu)",
                     hdr[5], rows, rb, (unsigned long)len);
            err = RMT_E_BAD_HDR;
            break;
        }
        if (cl >= 0 && (uint32_t)cl != RMT_HDR_LEN + len) {
            ESP_LOGW(TAG, "pull: content-length %d != %u", cl,
                     (unsigned)(RMT_HDR_LEN + len));
            err = RMT_E_BAD_HDR;
            break;
        }
        /* R2.2.1：记住本次子帧布局依据的方向；提交前复查 —— 流式收包期间
           方向被改会让 provider 按新方向读旧布局数据（整屏错位）。 */
        const uint8_t pull_orient = settings_get()->orient;

        /* 同内容：读完载荷（保连接干净）后保持画面不变。 */
        if (s.active && cid == s.cid && split == s.split) {
            uint8_t sink[RMT_CHUNK];
            uint32_t left = len;
            while (left) {
                int k = esp_http_client_read(h, (char *)sink,
                                             left > sizeof(sink) ? (int)sizeof(sink) : (int)left);
                if (k <= 0) break;
                left -= (uint32_t)k;
            }
            ESP_LOGI(TAG, "pull: same content (cid %016" PRIX64 "), keep screen", cid);
            err = RMT_CODE_OK_SAME;
            break;
        }

        /* ---- 暂存槽 ---- */
        phys = frame_remote_stage_begin();
        if (phys == STORE_ERR_FULL) {
            ESP_LOGW(TAG, "pull: no free staging slot (gallery full?)");
            err = RMT_E_NO_SLOT;
            break;
        }
        if (phys < 0) { err = RMT_E_STAGE; break; }
        held_lock = (phys == frame_src_phys());   /* 原地复用：写入期间持帧锁 */
        staged_inplace = held_lock;
        if (held_lock && !frame_lock(15000)) {
            frame_remote_stage_abort();
            phys = -1;
            held_lock = false;
            staged_inplace = false;
            err = RMT_E_STAGE;
            break;
        }

        /* ---- 流式收载荷（边收边写 flash，不占整帧 RAM） ---- */
        uint8_t buf[RMT_CHUNK];
        uint32_t got = 0;
        uint16_t crc = 0xFFFF;
        while (got < len) {
            int want = (len - got > sizeof(buf)) ? (int)sizeof(buf) : (int)(len - got);
            int k = esp_http_client_read(h, (char *)buf, want);
            if (k <= 0) { err = RMT_E_BODY; break; }
            crc = crc16_update(crc, buf, (size_t)k);
            if (frame_remote_stage_put(buf, (uint32_t)k) != 0) { err = RMT_E_STAGE; break; }
            got += (uint32_t)k;
        }
        if (err != RMT_CODE_OK_NEW) break;
        if (crc != crc_h) {
            ESP_LOGW(TAG, "pull: CRC mismatch (got %04X want %04X)", crc, crc_h);
            err = RMT_E_CRC;
            break;
        }

        /* ---- 提交为显示源并整屏刷新（帧锁内） ---- */
        if (settings_get()->orient != pull_orient) {
            ESP_LOGW(TAG, "pull: orient changed during transfer, drop frame");
            err = RMT_E_BAD_HDR;          /* 丢弃；GEOM 事件已触发新方向重拉 */
            break;
        }
        if (!held_lock && !frame_lock(15000)) { err = RMT_E_STAGE; break; }
        uint8_t h16[16];
        dummy_frame_hdr(h16, split, len, crc);
        int r = frame_remote_commit_locked(phys, split, h16);
        committed = (r == 0);
        if (!held_lock) frame_unlock();
        else            staged_inplace = false;   /* 已提交成功/或槽已交.finish，不再按原地写入处理 */
        int committed_phys = phys;     /* ★R2.6.0：提交槽位留样（下面 phys 归 -1） */
        phys = -1;                    /* 提交后槽归显示源，不再按暂存处理 */
        if (r != 0) { err = RMT_E_DISPLAY; break; }

        s.active = true;
        s.split = split;
        s.cid = cid;
        s.pulls++;
        rtc_save(true, split, committed_phys, cid);   /* ★R2.6.0：深睡前记忆显示状态 */
        ESP_LOGI(TAG, "pull ok: cid %016" PRIX64 ", %s (%lu bytes)",
                 cid, split ? "split + local box" : "fullscreen",
                 (unsigned long)len);
    } while (0);

    /* 失败清理：暂存作废；原地复用且未提交时显示源已被写坏 → 回落图库。 */
    if (err < 0) {
        if (phys >= 0) {
            frame_remote_stage_abort();
            phys = -1;
        }
        if (held_lock) {
            frame_unlock();
            held_lock = false;
        }
        if (staged_inplace && !committed) {
            do_revert();              /* 显示源槽刚被覆盖，必须回落 */
        }
        ESP_LOGW(TAG, "pull failed: code %d", err);
        fail_code(err);
    } else {
        if (held_lock) {
            frame_unlock();
            held_lock = false;
        }
        pull_finish(err);
    }

    esp_http_client_cleanup(h);
}

static void remote_task(void *arg)
{
    (void)arg;
    for (;;) {
        xSemaphoreTake(s_kick_sem, portMAX_DELAY);
        /* R2.5.0：拉取期间报忙（连接+流式收+整屏刷最坏 ~60s，忙期内
           idle_monitor 不入睡）；拉取是调度活，不重置空闲计时。
           ★R2.6.0：do_pull 返回即拉取/回落/刷屏都已结束 —— 忙期收口，
           不再白等 90s 尾巴（1 分钟档 + 远端会因此变成常开）。
           ★R2.6.1：传输层失败（拒连/超时，慢路由 + PC 端瞬时不在线
           常见）短延后重试一次 —— 原来「一次失败 = 本周期空手」，
           用户实测「远程拉取内容失败」的又一根因。 */
        power_busy_pulse(90);
        do_pull();
        if (s.last_code == RMT_E_HTTP) {
            vTaskDelay(pdMS_TO_TICKS(2000));
            ESP_LOGI(TAG, "pull transport failed, retry once");
            do_pull();
        }
        power_busy_cap(12);
    }
}

/* ---------------- 公共 API ---------------- */

void remote_init(void)
{
    if (s_task_up) return;

    const moink_settings_t *st = settings_get();
    store_set_reserve((st->remote_en && st->remote_host[0]) ? 1 : 0);

    /* ★R2.6.0：深睡唤醒恢复 —— cid/样式/暂存槽从 RTC noinit 读回，
       显示源经 frame_remote_restore 重建（不刷屏，面板本来就显示着它）。
       本函数在 app_main 里先于 httpd/display 任务运行，无并发。 */
    if (s_rtc.magic == RMT_RTC_MAGIC && s_rtc.active &&
        st->remote_en && st->remote_host[0] && store_part() &&
        frame_remote_restore(s_rtc.phys, s_rtc.split != 0) == 0) {
        s.active = true;
        s.split  = s_rtc.split != 0;
        s.cid    = s_rtc.cid;
        ESP_LOGI(TAG, "remote state restored from RTC (cid %016" PRIX64
                 ", phys %d, %s)", s.cid, s_rtc.phys,
                 s.split ? "split" : "fullscreen");
    } else {
        rtc_clear();                     /* 标记不合法/槽被复用/远端已关 */
    }

    s_kick_sem  = xSemaphoreCreateCounting(4, 0);
    s_first_sem = xSemaphoreCreateBinary();
    if (!s_kick_sem || !s_first_sem) {
        ESP_LOGE(TAG, "sem create failed");
        return;
    }
    if (xTaskCreate(remote_task, "remote", 6144, NULL, 4, NULL) != pdPASS) {
        ESP_LOGE(TAG, "task create failed");
        return;
    }
    s_task_up = true;
    ESP_LOGI(TAG, "remote pull task up (en=%u host='%s' iv=%umin%s)",
             st->remote_en, st->remote_host, st->remote_iv,
             s.active ? ", restored active" : "");
}

void remote_kick(void)
{
    if (!s_task_up || !s_kick_sem) return;
    xSemaphoreGive(s_kick_sem);
}

bool remote_wait_first(uint32_t timeout_ms)
{
    if (s_first_done) return true;
    if (!s_first_sem) return true;
    TickType_t t = (timeout_ms == (uint32_t)portMAX_DELAY)
                   ? portMAX_DELAY : pdMS_TO_TICKS(timeout_ms);
    return (xSemaphoreTake(s_first_sem, t) == pdTRUE) || s_first_done;
}

void remote_settings_changed(void)
{
    const moink_settings_t *st = settings_get();
    store_set_reserve((st->remote_en && st->remote_host[0]) ? 1 : 0);
    if (!st->remote_en) {
        s_revert_req = true;          /* 回落在拉取任务里做（httpd 任务不刷屏） */
    }
    remote_kick();
}

bool remote_active(void) { return s.active; }

void remote_notify_override(void)
{
    /* 手动上传 / 图库切图接管显示：标记失效（不清 s.cid —— 那是内容记忆，
       只需让「同 cid 跳过」判定失效，下一轮拉取重新上屏）。 */
    if (s.active) {
        s.active = false;
        rtc_clear();                     /* ★R2.6.0：面板已不是远端内容 */
        ESP_LOGI(TAG, "remote display overridden by manual upload/gallery");
    }
}

void remote_get_status(remote_status_t *out)
{
    if (!out) return;
    const moink_settings_t *st = settings_get();
    memset(out, 0, sizeof(*out));
    out->en   = (st->remote_en && st->remote_host[0]) ? 1 : 0;
    out->iv   = st->remote_iv;
    strlcpy(out->host, st->remote_host, sizeof(out->host));
    out->active   = s.active;
    out->split    = s.split;
    out->last_ok  = s.last_ok;
    out->last_code = s.last_code;
    out->last_ms  = s.last_ms;
    out->cid      = s.cid;
    out->pulls    = s.pulls;
    out->fails    = s.fails;
    out->skips    = s.skips;
}

void remote_cid_hex(char *buf, size_t n)
{
    if (!buf || n == 0) return;
    if (!s.active || !s.cid) {
        strlcpy(buf, "0", n);
        return;
    }
    snprintf(buf, n, "%016" PRIX64, s.cid);
}
