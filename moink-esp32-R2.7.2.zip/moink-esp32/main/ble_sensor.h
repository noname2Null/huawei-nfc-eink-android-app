#ifndef MOINK_BLE_SENSOR_H
#define MOINK_BLE_SENSOR_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

/*
 * R2.0.0 米家温湿度计（LYWSD03MMC / MHO-C401，官方固件）BLE 广播监听。
 *
 * 事实链（已对照 ESPHome xiaomi_ble 权威实现逐字段验证）：
 *   - 官方固件按 MiBeacon v5 广播（service data UUID 0xFE95），载荷加密：
 *     fctrl.LE16(0x5858) + pid.LE16 + 帧计数 u8 + MAC(6, 小端序) +
 *     密文 TLV + 扩展计数(3B) + MIC(4B)。
 *   - 解密 = AES-CCM：key=bind key(16B，米家云端提取)，
 *     nonce(12B) = MAC(6, 小端) + pid(2) + 帧计数(1) + 扩展计数(3)，
 *     AAD=0x11，MIC=4B。
 *   - 解出的明文 = TLV：[type u8][fixed u8(0x10/0x00/0x4C/0x48)][len u8][值]，
 *     值类型 0x100D=温+湿(各 int16LE x0.1)、0x1004=温、0x1006=湿、
 *     0x100A/0x4803=电量%、0x4C01=温(float32)、0x4C02=湿%、0x4C08=湿(float32)。
 *   - 只监听绑定 MAC 的一只（页面绑定，防串到邻居家）。
 */

typedef struct {
    float   temp_c;        /* 摄氏度；未收到过为 -1000 */
    float   hum_pct;       /* %；未收到过为 -1 */
    int     battery;       /* %；未收到过为 -1 */
    int     rssi;          /* 最近一帧 RSSI dBm */
    int64_t last_seen_ms;  /* esp_timer 微秒时间戳；0 = 从未收到 */
    uint8_t last_cnt;      /* 最近一帧的帧计数（去重） */
} ble_state_t;

/* 初始化 NimBLE 并启动扫描（绑定了传感器才解析；未绑定也可为页面扫描列表用）。 */
void ble_sensor_init(void);

/* ★R2.7.0：跨深睡恢复最后已知温湿度（RTC noinit → RAM 状态，无射频依赖）。
 * app_main 无条件调用（在 ble_sensor_init 之前）：轻唤醒（分钟局刷）不起
 * 射频、不扫描 —— 温湿控件显示最后已知值而不是 "--.-"。判龄 1 天。 */
void ble_sensor_restore(void);

/* 换绑 / 改 bind key 后重读设置（保存后不重启也能生效；扫描不中断）。 */
void ble_sensor_reload_binding(void);

/* 是否已绑定传感器。 */
bool ble_sensor_bound(void);

/* 取最新状态快照（线程安全，拷贝返回）。 */
ble_state_t ble_sensor_state(void);

/* 数据是否有效（有可显示值：本次开机收到过帧，或 ★R2.7.0 从 RTC 恢复了
 * 最后已知值 —— 轻唤醒期间温湿控件由此不空显 "--.-"）。 */
bool ble_sensor_valid(void);

/* ★R2.7.0：本次开机是否收到过【新】帧 —— boot 门控等最新数据用
 * （valid() 含恢复的旧值，不能拿来判「等最新」）。 */
bool ble_sensor_fresh(void);

/* R2.1.0：页面扫描窗口是否在进行（wifi_mgr 外网探测期间射频让路，需求 9）。 */
bool ble_sensor_scan_active(void);

/* ---- 页面扫描绑定支持 ----
 * 开一次 10 秒的收集窗口：期间所有 0xFE95 广播（米家系）都记录为候选。
 * 列表由 /api/ble/scan 读取（读取自动结束窗口）。 */
typedef struct {
    char mac[13];       /* 大写可打印 hex "AABBCCDDEEFF" */
    int  rssi;          /* 窗口内最强信号 */
    int  hits;          /* 收到的帧数（区分真实设备与偶发串扰） */
} ble_candidate_t;

void ble_sensor_scan_start(void);
/* 返回候选数；list 容量 *count_in_out，写满截断。窗口结束后数据保留到下次扫描。 */
int ble_sensor_scan_results(ble_candidate_t *out, int cap);

#endif /* MOINK_BLE_SENSOR_H */
