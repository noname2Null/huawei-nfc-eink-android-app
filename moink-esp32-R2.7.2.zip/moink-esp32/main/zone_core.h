#ifndef MOINK_ZONE_CORE_H
#define MOINK_ZONE_CORE_H
/*
 * 墨印主固件 R2.4.0 —— 信息框区域引擎（纯 C，无 ESP 依赖，原生可测）。
 *
 * 把 R2.2.1「固定顶部 160 行条带」推广为【任意用户坐标矩形区】：
 *   - 通用方向映射 user→provider：由已证明的方向链合成（见 .c 头注），
 *     与 R2.2.1 顶部条带公式逐字节对拍（scripts/test_zone_geom_r240.c）；
 *   - 区缓冲（2bpp）+ 暂存位图（1bpp）双渲染目标：正常渲染进区缓冲，
 *     快刷前把控件【旧值】重渲染进暂存，diff 出动作码行；
 *   - 控件矩形工具：自定义布局校验 + 横竖屏切换派生（比例缩放 + 中轴线
 *     贴边吸附 + 收屏）。
 * ESP 侧胶水（settings/渲染调度/快刷触发）在 overlay.c / epd_drv.c。
 */
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#define ZC_RROWS      552      /* provider/载荷行数（恒定，= PC 列数） */
#define ZC_RBYTES     192      /* provider 行字节数（768px × 2bpp） */
#define ZC_HBAR_H     160      /* 横向信息框高（沿用 R2.2.1 条带高） */
#define ZC_VBAR_W     200      /* 竖向信息框宽 */
#define ZC_BYTES_MAX  38400    /* 区缓冲上限 = 768 行 × 200/4（竖向条带） */
#define ZC_SCRATCH_MAX 15360   /* 暂存 1bpp 上限 = 768×160/8（最大控件并集） */

#define ZC_WG_COUNT   5        /* 控件数 */
enum { ZC_WG_TIME = 0, ZC_WG_DATE, ZC_WG_TH, ZC_WG_IP, ZC_WG_ICON };

typedef struct { int16_t x, y, w, h; } zc_rect_t;

/* ---- 方向映射（orient 0..3；对 4 个方向全矩形通用） ---- */
void zc_u2prov(int orient, int ux, int uy, int *r, int *j, int *grp);
void zc_prov2u(int orient, int r, int j, int grp, int *ux, int *uy);

/* ---- 区状态 ---- */
void zc_zone_set(int orient, const zc_rect_t *z);
const zc_rect_t *zc_zone(void);
uint8_t *zc_buf(void);                 /* 2bpp 区缓冲（ZC_BYTES_MAX） */

/* 区像素（用户坐标，区外忽略）。色码 0黑/1白/2黄/3红。 */
void zc_px_set(int ux, int uy, int c);
int  zc_px_get(int ux, int uy);        /* 区外返回 -1 */
void zc_fill_white(void);

/* ---- 合成 / 截取（frame.c 接口；行号 = 载荷行 0..551） ---- */
void zc_capture_range(int *r0, int *r1);              /* 区的载荷行足迹 */
void zc_capture_row(int row, const uint8_t *line192); /* 喂完整载荷行 */
void zc_capture_done(void);
void zc_blend_row(uint8_t *row_rot, int r);           /* provider 行合成 */
bool zc_valid(void);
void zc_invalidate(void);

/* ---- ★R2.6.0 防烧屏换位让位（照片跟随框上移） ----
 * 分割式载荷的照片自带顶部 ZC_HBAR_H 用户行白边；防老化换位把框挪到
 * 「下」时，照片需整体上移 ZC_HBAR_H 用户行（显示行 0..H-1 ← 载荷用户
 * 行 H..末尾），框区底下无照片（白）。本组函数只做坐标平移，生效条件
 * （分割源/框在下/标准横向条带）由 overlay.c 判定：
 *   zc_shift_payload_row  provider 行 r → 应读的载荷行号（-1 = 该行属框
 *                          区，整行白）。仅横屏方向（o1/o3）有行号平移；
 *                          竖屏（o0/o2）行号不变（平移在字节级）。
 *   zc_shift_row_bytes    竖屏方向对镜像后的 provider 行做 40 字节平移
 *                          （o0：向高字节端 / o2：向低字节端）；o1/o3 恒等。
 * 公式由 scripts/test_shift_geom.c 对拍（金样 = zc_u2prov/prov2u 已证明
 * 原语推导的用户画布模型）。 */
int  zc_shift_payload_row(int orient, int r);
void zc_shift_row_bytes(int orient, uint8_t *row_rot);

/* ---- 快刷 diff 引擎 ---- */
void zc_set_render_scratch(bool on);   /* 渲染目标切到暂存位图 */
void zc_scratch_begin(const zc_rect_t *u); /* 暂存窗 = 变更控件并集（清 0=白） */
bool zc_scratch_active(void);
void zc_scratch_px(int ux, int uy, int black);
/* 动作行：0x00 保持 + 暂存(旧)↔区缓冲(新) 差异动作码。
 * 01=驱动到黑（H2 黑目标）、10=驱动到白（H3 白目标）——与 lut_build_num 一致。 */
void zc_action_row(int r, uint8_t *out192);
/* 布局指纹（方向+区矩形+摘要）：快刷可用性判定用。 */
uint32_t zc_fingerprint(uint32_t extra);

/* ---- 控件矩形工具 ---- */
bool zc_rect_valid(const zc_rect_t *r, int cw, int ch);
bool zc_rect_overlap(const zc_rect_t *a, const zc_rect_t *b);
void zc_rect_clamp(zc_rect_t *r, int cw, int ch);
/* 横竖屏切换派生：src(画布 wa×ha) → dst(画布 wb×hb)：尺寸按比例缩放，
 * 位置按「控件边缘靠哪边」贴中轴线锚定，最后收屏。 */
void zc_rect_derive(const zc_rect_t *src, int wa, int ha, int wb, int hb,
                    zc_rect_t *dst);

#endif /* MOINK_ZONE_CORE_H */
