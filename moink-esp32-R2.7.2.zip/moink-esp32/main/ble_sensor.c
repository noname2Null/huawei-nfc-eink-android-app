#include "ble_sensor.h"
#include "settings.h"

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_attr.h"    /* R2.7.0：RTC_NOINIT_ATTR（最后已知温湿度跨深睡存活） */

#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"
#include "host/ble_hs.h"
#include "host/ble_gap.h"
#include "host/util/util.h"
#include "psa/crypto.h"    /* IDF v6 = mbedTLS 4.x：mbedtls/ccm.h 已删除，AEAD 只能走 PSA */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>          /* R2.7.0：持久化判龄（假钟不写 seen_epoch） */

static const char *TAG = "ble";

/* ---------- 状态 ---------- */

static ble_state_t s_state = {
    .temp_c = -1000.0f, .hum_pct = -1.0f, .battery = -1, .rssi = 0,
    .last_seen_ms = 0, .last_cnt = 0,
};
static bool s_got_any = false;      /* 收到过绑定 MAC 的任何有效帧 */
static bool s_fresh = false;        /* ★R2.7.0：本次开机收到过帧（boot 门控等最新数据用） */
static uint8_t s_bind_addr[6];      /* 小端序（广播帧里 MAC 的字面顺序） */
static bool s_has_bind = false;
static uint8_t s_bind_key[16];
static bool s_has_key = false;
static bool s_scanning = false;
static volatile bool s_scan_window = false;  /* R2.1.0：页面扫描窗口（wifi 探测让路） */

/* ★R2.7.0 最后已知温湿度持久化（RTC noinit）：轻唤醒（分钟局刷）不起射频、
 *   不扫描 —— 温湿控件显示最后已知值而不是 "--.-"。全功能唤醒扫描刷新后
 *   随帧写 RTC（慢速内存，无 flash 磨损）。判龄 BLE_PERSIST_MAX_AGE_S：
 *   传感器离开/电池耗尽超过 1 天不再显示旧值（回 "--.-"）。 */
#define BLE_RTC_MAGIC        0x424C4531u   /* "BLE1" */
#define BLE_PERSIST_MAX_AGE_S (24LL * 3600)
#define BLE_TS_OK            1704067200LL /* 与 wifi_mgr TIME_OK_TS 同值（假钟判据） */
static struct {
    uint32_t magic;
    int16_t  t10;          /* 温度×10；-3000 = 无 */
    int16_t  h10;          /* 湿度×10；-1 = 无 */
    int8_t   battery;      /* %；-1 = 无 */
    uint8_t  have;         /* 1 = 有可显示值 */
    int64_t  seen_epoch;   /* 最后收帧时刻（钟未对上时 0 = 不判龄） */
} s_rtc_ble RTC_NOINIT_ATTR;

/* 慢速内存写入，无 flash 磨损，随帧写即可（NimBLE 主机任务上下文安全）。 */
static void ble_state_persist(void)
{
    s_rtc_ble.magic   = BLE_RTC_MAGIC;
    s_rtc_ble.t10     = (s_state.temp_c > -900.0f)
                        ? (int16_t)(s_state.temp_c * 10.0f +
                                    (s_state.temp_c >= 0 ? 0.5f : -0.5f))
                        : (int16_t)-3000;
    s_rtc_ble.h10     = (s_state.hum_pct >= 0)
                        ? (int16_t)(s_state.hum_pct * 10.0f + 0.5f)
                        : (int16_t)-1;
    s_rtc_ble.battery = (int8_t)s_state.battery;
    s_rtc_ble.have    = 1;
    time_t now = time(NULL);
    s_rtc_ble.seen_epoch = ((int64_t)now > BLE_TS_OK) ? (int64_t)now : 0;
}

/* 扫描候选（页面绑定用）。 */
#define CAND_MAX 12
static ble_candidate_t s_cands[CAND_MAX];
static int s_cand_n = 0;
static volatile bool s_collect = false;

/* ---------- 小工具 ---------- */

/* R2.1.0 需求 3：「成功获取到数据」标志 —— 首次解出温/湿度就落盘（NVS 只写
   这一次），上电门控据此决定要不要等最新数据；解绑时由 settings_set_ble 清除。
   运行在 NimBLE 主机任务里：NVS 线程安全，且只在标志从无到有时写一次。 */
static void ble_mark_ever_ok(void)
{
    if (!settings_ble_ever_ok()) settings_set_ble_ever_ok(true);
}

/* 可打印大写 MAC "AA:BB..." 的小端地址（val[0]=LSB）转 "AABBCCDDEEFF"。 */
static void addr_to_str(const uint8_t val[6], char *out, size_t n)
{
    snprintf(out, n, "%02X%02X%02X%02X%02X%02X",
             val[5], val[4], val[3], val[2], val[1], val[0]);
}

static bool hex_nibble(char c, uint8_t *out)
{
    if (c >= '0' && c <= '9') { *out = (uint8_t)(c - '0'); return true; }
    if (c >= 'A' && c <= 'F') { *out = (uint8_t)(c - 'A' + 10); return true; }
    if (c >= 'a' && c <= 'f') { *out = (uint8_t)(c - 'a' + 10); return true; }
    return false;
}

/* "AABBCCDDEEFF" -> val[0]=0xFF..val[5]=0xAA（小端，与广播帧一致）。 */
static bool str_to_addr(const char *hex, uint8_t val[6])
{
    for (int i = 0; i < 6; i++) {
        uint8_t hi, lo;
        if (!hex_nibble(hex[i * 2], &hi) || !hex_nibble(hex[i * 2 + 1], &lo))
            return false;
        val[5 - i] = (uint8_t)((hi << 4) | lo);
    }
    return true;
}

static bool str_to_key(const char *hex, uint8_t out[16])
{
    for (int i = 0; i < 16; i++) {
        uint8_t hi, lo;
        if (!hex_nibble(hex[i * 2], &hi) || !hex_nibble(hex[i * 2 + 1], &lo))
            return false;
        out[i] = (uint8_t)((hi << 4) | lo);
    }
    return true;
}

/* ---------- MiBeacon 解析 ---------- */

static void apply_tlvs(const uint8_t *tlv, size_t n)
{
    /* 明文 TLV 序列：[type][fixed][len][value...]，解析到不合法即停。 */
    size_t off = 0;
    while (n - off >= 3) {
        const uint8_t *p = tlv + off;
        if (p[1] != 0x10 && p[1] != 0x00 && p[1] != 0x4C && p[1] != 0x48)
            return;                          /* fixed 字节不对 = 剩余为垃圾 */
        uint8_t len = p[2];
        if (len < 1 || len > 4 || n - off < (size_t)3 + len) return;

        uint16_t vtype = (uint16_t)((p[1] << 8) | p[0]);
        const uint8_t *d = p + 3;

        switch (vtype) {
        case 0x100D:                          /* 温 + 湿（int16LE x0.1） */
            if (len == 4) {
                int16_t t = (int16_t)(d[0] | (d[1] << 8));
                int16_t h = (int16_t)(d[2] | (d[3] << 8));
                s_state.temp_c = t / 10.0f;
                s_state.hum_pct = h / 10.0f;
                ble_mark_ever_ok();            /* R2.1.0：成功取到温湿数据 */
            }
            break;
        case 0x1004:                          /* 温（int16LE x0.1） */
            if (len == 2) {
                s_state.temp_c = (int16_t)(d[0] | (d[1] << 8)) / 10.0f;
                ble_mark_ever_ok();
            }
            break;
        case 0x1006:                          /* 湿（int16LE x0.1） */
            if (len == 2) {
                s_state.hum_pct = (int16_t)(d[0] | (d[1] << 8)) / 10.0f;
                ble_mark_ever_ok();
            }
            break;
        case 0x100A:                          /* 电量 % */
        case 0x4803:
            if (len == 1) s_state.battery = d[0];
            break;
        case 0x4C01:                          /* 温（float32LE） */
            if (len == 4) {
                uint32_t u = (uint32_t)d[0] | ((uint32_t)d[1] << 8) |
                             ((uint32_t)d[2] << 16) | ((uint32_t)d[3] << 24);
                float f;
                memcpy(&f, &u, 4);
                s_state.temp_c = f;
            }
            break;
        case 0x4C02:                          /* 湿 % */
            if (len == 1) s_state.hum_pct = (float)d[0];
            break;
        case 0x4C08:                          /* 湿（float32LE） */
            if (len == 4) {
                uint32_t u = (uint32_t)d[0] | ((uint32_t)d[1] << 8) |
                             ((uint32_t)d[2] << 16) | ((uint32_t)d[3] << 24);
                float f;
                memcpy(&f, &u, 4);
                s_state.hum_pct = f;
            }
            break;
        default:
            break;
        }
        off += (size_t)3 + len;
    }
}

/*
 * MiBeacon 解密（1:1 对照 ESPHome xiaomi_ble decrypt_xiaomi_payload）：
 *   raw   = 0xFE95 service data 之后的部分（fctrl 起）
 *   size  = 其总长
 *   nonce = addr_val(6, 小端) + raw[2..4](pid+帧计数) + raw[size-7..size-5](扩展计数)
 *   AAD = 0x11；MIC = raw 末 4 字节；密文 = raw[11..]（含 MAC 帧）或 raw[5..]
 * AES-CCM 走 PSA Crypto 一次性接口（mbedTLS 4.x 删掉了 mbedtls_ccm_*）。
 * 成功后把明文 TLV 写回 raw 原密文位置并返回 true。
 */

/* CCM 4 字节标签。规范 1.1 把旧名 SHORTENED_TAG 换成 AT_LEAST_THIS_LENGTH；
 * 内建软件 CCM 按算法字里编码的标签长精确执行，这里效果 = 恰好 4 字节。 */
#if defined(PSA_ALG_AEAD_WITH_SHORTENED_TAG)
#define MIKEY_ALG  PSA_ALG_AEAD_WITH_SHORTENED_TAG(PSA_ALG_CCM, 4)
#else
#define MIKEY_ALG  PSA_ALG_AEAD_WITH_AT_LEAST_THIS_LENGTH_TAG(PSA_ALG_CCM, 4)
#endif

static mbedtls_svc_key_id_t s_key_id;    /* PSA key 句柄（懒导入缓存） */
static bool s_key_loaded = false;

/* 把 bind key 导入 PSA（成功一次后缓存；load_binding 换绑时作废）。 */
static bool ensure_key(void)
{
    if (s_key_loaded) return true;
    if (!s_has_key) return false;

    psa_key_attributes_t attrs = PSA_KEY_ATTRIBUTES_INIT;
    psa_set_key_type(&attrs, PSA_KEY_TYPE_AES);
    psa_set_key_bits(&attrs, 128);
    psa_set_key_usage_flags(&attrs, PSA_KEY_USAGE_DECRYPT);
    psa_set_key_algorithm(&attrs, MIKEY_ALG);

    psa_status_t st = psa_import_key(&attrs, s_bind_key, sizeof(s_bind_key), &s_key_id);
    if (st != PSA_SUCCESS) {
        ESP_LOGE(TAG, "psa_import_key: %d", (int)st);
        return false;
    }
    s_key_loaded = true;
    return true;
}

static bool mibeacon_decrypt(uint8_t *raw, size_t size, const uint8_t addr_val[6])
{
    if ((size != 19) && (size < 22 || size > 40)) return false;

    bool has_mac = (size != 19);           /* ESPHome：size==19 = 帧里无 MAC */
    size_t cipher_pos = has_mac ? 11 : 5;
    size_t datasize = has_mac ? size - 18 : size - 12;
    if (datasize < 3 || datasize > 16) return false;

    uint8_t nonce[12];
    memcpy(nonce, addr_val, 6);
    memcpy(nonce + 6, raw + 2, 3);
    memcpy(nonce + 9, raw + size - 7, 3);

    const uint8_t aad = 0x11;

    if (!ensure_key()) return false;

    /* PSA 要求“密文+标签”连续存放，而 MiBeacon 的 MIC 与密文之间隔着
       3 字节扩展计数，先拼到栈上再解。 */
    uint8_t ct[16 + 4];
    memcpy(ct, raw + cipher_pos, datasize);
    memcpy(ct + datasize, raw + size - 4, 4);

    uint8_t pt[16];
    size_t pt_len = 0;
    psa_status_t st = psa_aead_decrypt(
        s_key_id, MIKEY_ALG,
        nonce, sizeof(nonce),
        &aad, 1,
        ct, datasize + 4,
        pt, sizeof(pt), &pt_len);
    if (st != PSA_SUCCESS) {
        if (st == PSA_ERROR_NOT_SUPPORTED) {
            static bool warned = false;    /* 只吼一次：典型的配置坑 */
            if (!warned) {
                warned = true;
                ESP_LOGE(TAG, "PSA CCM not supported: enable "
                         "CONFIG_MBEDTLS_GCM_SUPPORT_NON_AES_CIPHER "
                         "(espressif/esp-idf#19065)");
            }
        }
        ESP_LOGD(TAG, "ccm decrypt failed: %d (key set=%d)", (int)st, (int)s_has_key);
        return false;
    }
    memcpy(raw + cipher_pos, pt, pt_len);
    /* fctrl 清除加密位，走与明文帧相同的 TLV 解析路径。 */
    raw[0] &= (uint8_t)~0x08;
    return true;
}

/* 解析一帧 0xFE95 service data（p 不含 UUID 前缀 2 字节）。 */
static void parse_mibeacon(const uint8_t *p, size_t n, const uint8_t addr_val[6], int rssi)
{
    if (n < 5) return;

    uint16_t fctrl = (uint16_t)(p[0] | (p[1] << 8));
    uint8_t  cnt   = p[4];

    if (fctrl & 0x08) {
        /* 加密帧：必须有 bind key。 */
        if (!s_has_key) return;
        /* 解密要就地改写，拷贝到栈上（上限 40B 足够 MiBeacon 温湿度帧）。 */
        uint8_t buf[40];
        size_t m = n > sizeof(buf) ? sizeof(buf) : n;
        memcpy(buf, p, m);
        if (!mibeacon_decrypt(buf, m, addr_val)) return;

        s_state.last_cnt = cnt;
        s_state.rssi = rssi;
        s_state.last_seen_ms = esp_timer_get_time();
        s_got_any = true;
        s_fresh = true;             /* ★R2.7.0：本次开机收到过帧 */
        /* 解密后 TLV 从密文位置开始。 */
        size_t tlv_off = (m == 19) ? 5 : 11;
        apply_tlvs(buf + tlv_off, m - tlv_off - 7);
        ble_state_persist();        /* ★R2.7.0：最后已知值随帧写 RTC */
    } else {
        /* 明文帧（pvvx/ATC 自定义固件，或米家少数明文模式）。 */
        size_t tlv_off;
        if (n >= 11) {
            tlv_off = 11;                    /* v5：fctrl+pid+cnt+MAC */
        } else if (n >= 5) {
            tlv_off = 5;                     /* 旧版本：fctrl+pid+cnt */
        } else {
            return;
        }
        s_state.last_cnt = cnt;
        s_state.rssi = rssi;
        s_state.last_seen_ms = esp_timer_get_time();
        s_got_any = true;
        s_fresh = true;             /* ★R2.7.0：本次开机收到过帧 */
        apply_tlvs(p + tlv_off, n - tlv_off);
        ble_state_persist();        /* ★R2.7.0：最后已知值随帧写 RTC */
    }
}

/* ---------- 广播回调 ---------- */

int start_scan(void);   /* 前置声明：gap_event_cb 在定义前调用（GCC14 隐式声明=错误） */

/* R2.5.0：扫描门控 —— 常开被动扫描是空闲时段最大的射频热源。
   只在「已绑定传感器」（要收它的广播）或「页面扫描窗口」期间才开扫。 */
static void scan_stop(void)
{
    if (!s_scanning) return;
    if (ble_gap_disc_cancel() == 0) {
        s_scanning = false;
        ESP_LOGI(TAG, "passive scan stopped (no binding)");
    } else {
        ESP_LOGW(TAG, "ble_gap_disc_cancel failed, keep scanning");
    }
}

static void scan_ensure(void)
{
    if (s_scanning) return;
    s_scanning = true;
    if (start_scan() != 0) s_scanning = false;
}

static void handle_adv(const struct ble_gap_event *ev)
{
    const uint8_t *addr_val = ev->disc.addr.val;
    const uint8_t *d = ev->disc.data;
    size_t dl = ev->disc.length_data;

    char macstr[13];
    addr_to_str(addr_val, macstr, sizeof(macstr));

    /* 收集窗口：任何米家系 0xFE95 广播都进候选列表。 */
    bool is_mi = false;

    /* 遍历 AD 结构找 0x16 service data 且 UUID == 0xFE95。 */
    size_t off = 0;
    while (off + 2 <= dl) {
        uint8_t len = d[off];
        if (len == 0 || off + 1 + len > dl) break;
        uint8_t type = d[off + 1];
        const uint8_t *field = d + off + 2;
        size_t flen = (size_t)len - 1;
        if (type == 0x16 && flen >= 2 && field[0] == 0x95 && field[1] == 0xFE) {
            is_mi = true;
            const uint8_t *mb = field + 2;
            size_t mn = flen - 2;
            if (s_collect) {
                int slot = -1;
                for (int i = 0; i < s_cand_n; i++)
                    if (strcmp(s_cands[i].mac, macstr) == 0) { slot = i; break; }
                if (slot < 0 && s_cand_n < CAND_MAX) {
                    slot = s_cand_n++;
                    memset(&s_cands[slot], 0, sizeof(s_cands[slot]));
                    strlcpy(s_cands[slot].mac, macstr, sizeof(s_cands[slot].mac));
                }
                if (slot >= 0) {
                    s_cands[slot].hits++;
                    if (ev->disc.rssi > s_cands[slot].rssi || s_cands[slot].rssi == 0)
                        s_cands[slot].rssi = ev->disc.rssi;
                }
            }
            /* 绑定 MAC 才解析。 */
            if (s_has_bind && memcmp(addr_val, s_bind_addr, 6) == 0 && mn >= 5) {
                /* 同一帧计数去重：广播每帧重复多播。 */
                static uint8_t last_cnt = 0xFF;
                if (ev->disc.rssi >= -100 && (mn < 5 || mb[4] != last_cnt)) {
                    last_cnt = mb[4];
                    parse_mibeacon(mb, mn, addr_val, ev->disc.rssi);
                    float t = s_state.temp_c;
                    int t10 = (t > -900.0f) ? (int)(t * 10) : -9999;
                    int h10 = (s_state.hum_pct >= 0) ? (int)(s_state.hum_pct * 10) : -1;
                    ESP_LOGI(TAG, "sensor %s: %d.%d C, %d.%d %% (rssi %d)",
                             macstr, t10 / 10, (t10 < 0 ? -t10 : t10) % 10,
                             h10 / 10, h10 % 10, ev->disc.rssi);
                }
            }
        }
        off += (size_t)1 + len;
    }
    (void)is_mi;
}

static int gap_event_cb(struct ble_gap_event *event, void *arg)
{
    (void)arg;
    if (event->type == BLE_GAP_EVENT_DISC) {
        handle_adv(event);
    } else if (event->type == BLE_GAP_EVENT_DISC_COMPLETE) {
        /* 意外停止（如控制器被共存打断）→ 重新开扫（仅当本该在扫：R2.5.0
           无绑定常态熄扫，扫描窗口外的意外停止不再自启）。 */
        if (s_scanning) {
            ESP_LOGW(TAG, "scan stopped unexpectedly, restarting");
            start_scan();
        }
    }
    return 0;
}

/* ---------- NimBLE 装配 ---------- */

int start_scan(void)
{
    if (!s_scanning) return 0;              /* 同步回调前先置位防递归 */
    struct ble_gap_disc_params params = {
        .itvl = 0,            /* 连续扫描（间隔=窗口），与 WiFi 共存由控制器分时 */
        .window = 0,
        .filter_policy = 0,
        .passive = 1,         /* 只收不发，更省电也更少干扰配网 */
        .limited = 0,
    };
    uint8_t own_addr_type;
    if (ble_hs_util_ensure_addr(0) != 0) {
        ESP_LOGE(TAG, "device address ensure failed");
        return -1;
    }
    if (ble_hs_id_infer_auto(0, &own_addr_type) != 0) {
        ESP_LOGE(TAG, "addr infer failed");
        return -1;
    }
    int rc = ble_gap_disc(own_addr_type, BLE_HS_FOREVER, &params, gap_event_cb, NULL);
    if (rc != 0) {
        ESP_LOGE(TAG, "ble_gap_disc rc=%d", rc);
        return -1;
    }
    ESP_LOGI(TAG, "continuous passive scan started");
    return 0;
}

static void on_sync(void)
{
    /* R2.5.0：已绑定才常态开扫；未绑定保持熄扫（页面扫描窗口自己开）。
       事件驱动休眠下，未绑定的设备不再拖着一块射频热源常开。 */
    if (s_has_bind) {
        scan_ensure();
    } else {
        ESP_LOGI(TAG, "nimble synced, no sensor bound, scan stays idle");
    }
}

static void on_reset(int reason)
{
    ESP_LOGW(TAG, "nimble reset, reason=%d", reason);
}

static void host_task(void *param)
{
    (void)param;
    /* 该任务由 nimble_port_freertos_init 拉起，run 返回即主机停。 */
    nimble_port_run();
    nimble_port_freertos_deinit();
}

static void load_binding(void)
{
    if (s_key_loaded) {          /* 换绑/换 key：作废已导入的 PSA key */
        psa_destroy_key(s_key_id);
        s_key_loaded = false;
    }
    const moink_settings_t *s = settings_get();
    s_has_bind = (s->ble_mac[0] != '\0') && str_to_addr(s->ble_mac, s_bind_addr);
    if (s->ble_key[0] != '\0')
        s_has_key = str_to_key(s->ble_key, s_bind_key);
    else
        s_has_key = false;
    if (s_has_bind) {
        ESP_LOGI(TAG, "bound sensor %s (bind key %s)", s->ble_mac,
                 s_has_key ? "set" : "MISSING -- encrypted frames will be dropped");
    }
}

/* 重新读 settings 里的 MAC / bind key（换绑、改 key 后由 HTTP 处理器调用）。
   扫描不中断 —— 只换匹配目标与解密钥；但扫描【有/无】随绑定变化：
   新绑上 → 立刻开扫（不等下次重启）；解绑 → 扫描窗口外立即熄扫。 */
void ble_sensor_reload_binding(void)
{
    bool was_bound = s_has_bind;
    load_binding();
    if (s_has_bind && !was_bound) scan_ensure();
    if (!s_has_bind && was_bound && !s_collect) scan_stop();
}

void ble_sensor_init(void)
{
    /* PSA Crypto：mbedTLS 4.x 起唯一的加密门面（AES-CCM 解密用）。
       已被 WiFi/TLS 初始化过则直接返回成功（幂等）。 */
    psa_status_t st = psa_crypto_init();
    if (st != PSA_SUCCESS) ESP_LOGE(TAG, "psa_crypto_init: %d", (int)st);

    load_binding();

    ESP_ERROR_CHECK(nimble_port_init());

    ble_hs_cfg.sync_cb = on_sync;
    ble_hs_cfg.reset_cb = on_reset;

    /* 纯观察者：不需要设备名与广播配置。 */
    nimble_port_freertos_init(host_task);
}

bool ble_sensor_bound(void) { return s_has_bind; }

ble_state_t ble_sensor_state(void) { return s_state; }

bool ble_sensor_valid(void) { return s_got_any; }

/* ★R2.7.0：本次开机是否收到过【新】帧（boot 门控等最新数据用 ——
 * valid() 含 RTC 恢复的旧值，不能拿来判「等最新」）。 */
bool ble_sensor_fresh(void) { return s_fresh; }

/* ★R2.7.0：跨深睡恢复最后已知温湿度（轻唤醒不起射频/不扫描期间，温湿
 *   控件显示最后已知值而不是 "--.-"）。app_main 无条件调用（无射频依赖，
 *   在 ble_sensor_init 之前）；全功能唤醒的扫描刷新后随帧覆写。判龄：
 *   seen_epoch（真钟）距今超 1 天不恢复（传感器离开/电池耗尽）。 */
void ble_sensor_restore(void)
{
    if (s_rtc_ble.magic != BLE_RTC_MAGIC || !s_rtc_ble.have) return;

    time_t now = time(NULL);
    bool clock_ok = ((int64_t)now > BLE_TS_OK);
    if (clock_ok && s_rtc_ble.seen_epoch > 0 &&
        (int64_t)now - s_rtc_ble.seen_epoch > BLE_PERSIST_MAX_AGE_S) {
        ESP_LOGI(TAG, "persisted sensor data %.1fh old, drop",
                 (double)((int64_t)now - s_rtc_ble.seen_epoch) / 3600.0);
        return;
    }

    if (s_rtc_ble.t10 != (int16_t)-3000)
        s_state.temp_c = (float)s_rtc_ble.t10 / 10.0f;
    if (s_rtc_ble.h10 >= 0)
        s_state.hum_pct = (float)s_rtc_ble.h10 / 10.0f;
    if (s_rtc_ble.battery >= 0)
        s_state.battery = s_rtc_ble.battery;
    s_got_any = true;            /* 有可显示值（s_fresh 仍 false） */
    ESP_LOGI(TAG, "sensor state restored from RTC (%d.%d C, %d.%d %%, %s)",
             s_rtc_ble.t10 / 10, ((s_rtc_ble.t10 < 0 ? -s_rtc_ble.t10 : s_rtc_ble.t10) % 10),
             s_rtc_ble.h10 / 10, s_rtc_ble.h10 % 10,
             clock_ok ? "aged" : "no clock");
}

/* R2.1.0：页面扫描窗口是否在进行（wifi_mgr 外网探测期间让路，需求 9）。 */
bool ble_sensor_scan_active(void) { return s_scan_window; }

/* ---------- 页面扫描 ---------- */

static void collect_stop_timer_cb(void *arg)
{
    (void)arg;
    s_collect = false;
    s_scan_window = false;                    /* R2.1.0：探测让路窗口结束 */
    if (!s_has_bind) scan_stop();             /* R2.5.0：窗口结束且无绑定 → 熄扫 */
    ESP_LOGI(TAG, "scan window closed, %d candidate(s)", s_cand_n);
}

void ble_sensor_scan_start(void)
{
    memset(s_cands, 0, sizeof(s_cands));
    s_cand_n = 0;
    s_collect = true;
    s_scan_window = true;                     /* R2.1.0：窗口内 wifi 探测让路 */
    scan_ensure();                            /* R2.5.0：未绑定常态熄扫，窗口现开 */

    static esp_timer_handle_t t;
    if (!t) {
        const esp_timer_create_args_t args = {
            .callback = &collect_stop_timer_cb,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "ble_collect",
        };
        esp_timer_create(&args, &t);
    } else {
        esp_timer_stop(t);
    }
    esp_timer_start_once(t, 10ULL * 1000000ULL);
    ESP_LOGI(TAG, "scan window open (10 s)");
}

int ble_sensor_scan_results(ble_candidate_t *out, int cap)
{
    s_collect = false;                    /* 读取即认为窗口结束 */
    s_scan_window = false;                /* R2.1.0：探测让路窗口一并结束 */
    int n = s_cand_n < cap ? s_cand_n : cap;
    for (int i = 0; i < n; i++) out[i] = s_cands[i];
    return s_cand_n;
}
