#ifndef MOINK_LUT_R20_H
#define MOINK_LUT_R20_H

/*
 * 墨印主固件（R2.4.0 自 verify_fw/video_fw 1:1 复制）—— R20 运行时波形表编码器
 *
 * 依据 ref/jd79665aa-driver（SE0398NZ07A1 四色屏 JD79665AA 控制器逆向研究，
 * docs/04-lut.md + host/lut_codec.py）1:1 移植，与本仓 scripts 下的 Python
 * 参照逐字节对拍（scripts/verify_lut_native.c + verify_lut_ref.py）。
 *
 * 结构回顾（详见 ref docs/04-lut.md）：
 *   - 命令 0x20 写入运行时波形表，写地址从 0 开始、2048 B 回绕；
 *   - PSR(0x00) 第二参数 bit7 置 1（4B E9 / 4B F9）后刷新改用寄存器表；
 *   - 表块 = 7 B 头部 + 6 路 × 8 状态 × 11 B；某路首状态偏移 = 7 + 88*H + 11*K；
 *   - H1..H4 分别被图像 RAM 的四个 2bit 像素码选择（00/01/10/11），
 *     H0 = 公共电极 VCOM，H5 = source 供电模式（Mode0/Mode1）；
 *   - 状态 11 字段：G(外层重复，0=终止) / ABC+DEF 电平码 / A..F 扫描数 /
 *     RA,RB(子组重复)；计划扫描数 N = G*((A+B+C)*RA + (D+E+F)*RB)；
 *   - wire 字节 = 0xFF ^ permute(逻辑字节)，逻辑 bit i → wire bit {4,7,6,1,0,3,2,5}。
 *
 * 本模块为纯 C（不依赖任何 ESP-IDF 头），可脱离目标机用 gcc 原生测试。
 */

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#define LUT_R20_BYTES   2048

/* 像素路径相位电平码（H1..H4 用；ref docs/04-lut.md §6.1） */
#define LVL_L00 0x00     /* 近 0V 输出；短时可近似保持 */
#define LVL_L01 0x01     /* VSP（Mode0 强正档）—— 白/黄变暗，黑目标 */
#define LVL_L10 0x02     /* VSN（负档）—— 黑变浅、红偏黄，白/浅色目标 */
#define LVL_L11 0x03     /* VSPL（弱正档）—— 变暗较慢 */

/* H5 source 供电模式相位码（ref docs/04-lut.md §6.2）：
   00/10 → Mode0（固定高压档）；01/11 → Mode1（R01 第 4/5/6 参数可配档） */
#define SUPPLY_MODE0 0x00
#define SUPPLY_MODE1 0x01

/* 六路时序通道 */
#define LANE_H0 0        /* VCOM；本固件不用（底板终止，VCOM 走寄存器基线） */
#define LANE_H1 1        /* 像素码 00 —— 验证固件中恒为「保持/终止」 */
#define LANE_H2 2        /* 像素码 01 —— 各表中安排为黑目标动作 */
#define LANE_H3 3        /* 像素码 10 —— 各表中安排为白/浅色目标动作 */
#define LANE_H4 4        /* 像素码 11 —— 备用（保持终止） */
#define LANE_H5 5        /* source 供电模式 */

typedef struct {
    uint8_t g;           /* 外层重复；0 = 终止（表底板全 FF 即终止） */
    uint8_t level[6];    /* A B C D E F 相位电平码（0..3） */
    uint8_t frames[6];   /* A B C D E F 扫描数（C/F ≤ 127，高位含义未知） */
    uint8_t ra;          /* ABC 子组重复 */
    uint8_t rb;          /* DEF 子组重复 */
} lut_state_t;

/* 逻辑字节 ↔ R20 wire 字节 */
uint8_t lut_wire_encode(uint8_t logical);
uint8_t lut_wire_decode(uint8_t wire);

/* 状态的计划扫描数 N = G*((A+B+C)*RA + (D+E+F)*RB) */
unsigned lut_state_scans(const lut_state_t *st);

/* 表构造（tbl 为调用方提供的 LUT_R20_BYTES 缓冲） */
void lut_table_clear(uint8_t *tbl);            /* 全 0xFF = 逻辑零底板（所有路径终止） */
void lut_table_set_header_ena(uint8_t *tbl);   /* 头部字节 6 = 逻辑 1（ref 实验配置） */
void lut_table_set_state(uint8_t *tbl, int lane, int slot, const lut_state_t *st);

/*
 * 预设表（与 ref docs/06-refresh-experiments.md 的短波形族同构）：
 *
 * lut_build_empty     纯逻辑零表（探测用：寄存器模式下 DRF 应约 2 ms 完成，
 *                     且不产生任何光学变化 —— 工厂模式下则是整帧工厂波形）。
 * lut_build_num       数字局刷：码01=H2 黑目标(P3/Mode0)、码10=H3 白目标(N3/Mode0)、
 *                     H5=Mode0×3。
 * lut_build_gray_m0   灰度剂量(Mode0)：码01=H2 正向 1 扫描(Mode0 强场)——深灰档。
 * lut_build_gray_m1   灰度剂量(Mode1)：码01=H2 正向 1 扫描(Mode1 弱场, VSP_1 由
 *                     R01 第 4 参数给定)——中浅灰档。
 * lut_build_yellow    黄色剂量：码10=H3 负向 1 扫描(Mode0)——白底上负向剂量
 *                     逐次累积黄色调（黄颗粒强负性，先于白颗粒上浮）。
 */
void lut_build_empty(uint8_t *tbl);
void lut_build_num(uint8_t *tbl);
/* ★R2.6.0 数字局刷·降残影版（主固件 R2.6.0 起用它替代 lut_build_num）；
 * ★R2.6.1 重写为 lut_build_num_clean 清理配方 × rounds 轮：
 *   码01=H2 黑目标 P3(Mode0)→L00×3(Mode1 段静默)；码10=H3 白目标
 *   P3(Mode0) 预脉冲→N3(Mode1，VSN_1=R01 第 5 参数)——轮内正负交变，
 *   把每轮当一次微型全刷：正场回收残留黑颗粒、负场拉白，
 *   R2.6.0 的纯目标场重复对「旧黑像素残影」打不满（用户实测反馈）；
 *   H5=Mode0×3→Mode1×3 与像素路同长段对齐。总扫描 6×rounds，
 *   rounds=3 → 18 扫描 ≈ 150ms DRF；rounds=1 与 lut_build_num_clean
 *   逐字节同构（test_lut_ghost 锁定）。未变更像素（码00/H1 终止）
 *   不受影响。 */
void lut_build_num_ghost(uint8_t *tbl, uint8_t rounds);
/* 周期清理表（VIDEO-R3 新增，ref docs/06 §5 六扫描配方）：
   码01=H2 黑目标 P3(Mode0)→L00×3(Mode1 段静默)；
   码10=H3 白目标 P3(Mode0)→N3(Mode1，VSN_1=R01 第 5 参数)；
   H5=Mode0×3→Mode1×3。六扫描 ≈ 50 ms（PLL 07），比 lut_build_num 慢
   一倍但白端黄度 R−B→0（ref 实测六扫描档 0.0 vs P3/N3 档 18.2）。
   用法：同一画布不动 RAM，换表多刷一次 DRF 再换回（play 循环周期插入）。 */
void lut_build_num_clean(uint8_t *tbl);
void lut_build_gray_m0(uint8_t *tbl);
void lut_build_gray_m1(uint8_t *tbl);
void lut_build_yellow(uint8_t *tbl);
/* 黄调正场尝试：码 10 → H3 VSPL(L11) 弱正场 × 1 扫描 Mode0——与
   lut_build_yellow（负场 VSN）极性相对。实测反馈：负场 N 3..24 扫描
   全部未显色 → 本表换弱正档验证「正场拉黄上浮」假说（黄颗粒带负电）。 */
void lut_build_yellow_pos(uint8_t *tbl);

/* 自检：256 值编解码回环 + 9 个已知向量 + 108 扫描算例（ref 文档 §4 例） */
bool lut_self_check(void);

#endif /* MOINK_LUT_R20_H */
