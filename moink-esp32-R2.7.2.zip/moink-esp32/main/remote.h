#ifndef MOINK_REMOTE_H
#define MOINK_REMOTE_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

/*
 * R2.1.0 远端内容拉取（需求 5/6/15/16）。
 *
 * 设备 = HTTP 客户端，按用户设置的间隔从远端（局域网 ip:port 或广域网域名）
 * 拉取屏幕 2bit 数据。远端软件 = tools/moink_remote_pc（Windows，Python）。
 *
 * ★ 拉取协议 MKRP v1：
 *   GET http://<host>[:port][/前缀]/moink/pull?style=<s>&cid=<16位HEX>&fw=<版本>&orient=<o>
 *     s：设备当前信息框显示状态（需求 6「向远端发送设备当前呈现样式」）
 *        0 = 信息框关闭 / 1 = 叠加 / 2 = 分割；
 *     cid：设备当前正在显示的远端内容唯一 id（16 位十六进制，没有则 0）。
 *     o（R2.2.1）：屏幕方向（以排线为基准 0=下/1=左/2=上/3=右）—— 远端收到后
 *        把默认画布切换成 竖屏 552×768（0/2）或 横屏 768×552（1/3）并提示
 *        （用户已在远端手动改过方向时以用户设置优先，仅提示不切换）。
 *   应答二选一：
 *     304           —— 内容未变（同 cid），设备保持当前画面不刷新；
 *     200 + 32B头 + 载荷 —— 新内容：
 *       偏移 0-3   魔数 "MKRP"
 *       偏移 4     协议版本 = 1
 *       偏移 5     样式：0 = 信息框关闭（全屏帧，192B/行）
 *                       1 = 分割（子帧 = 用户画布条带以下内容；形状随方向）
 *       偏移 6-7   帧行数 BE：全屏 552；分割 竖屏(orient 0/2)=552、横屏(1/3)=392
 *       偏移 8-9   每行字节数 BE：全屏 192；分割 竖屏=152、横屏=192
 *       （R2.2.1：分割子帧随屏幕方向变形状 —— 竖屏 = 每载荷行的 152B 字节段
 *        （o0 为字节 40..191、o2 为字节 0..151），横屏 = 整载荷行 192B
 *        （o1 为载荷行 0..391、o3 为载荷行 160..551）。布局由
 *        scripts/sim_orient_geom.py 机器证明，PC 工具同源打包。）
 *       偏移 10-13 载荷长度 BE = 行数 × 每行字节
 *       偏移 14-15 CRC16/CCITT-FALSE（poly 0x1021 init 0xFFFF，覆盖载荷）
 *       偏移 16-23 内容唯一 id（u64 BE，远端按内容生成 —— 需求 15「区分新旧」）
 *       偏移 24-31 保留 = 0
 *     载荷布局与上传帧同一契约（768 宽 2bpp、行自下而上；分割式只含每行
 *     【后】152 字节 = 载荷列 160..767 = 用户屏幕第 160..767 行）。
 *
 * 行为约束（需求 6/16）：
 *   - 拉取失败（无法访问 / 超时 / 校验不过）→ 内容页保持不变；
 *   - 远端数据不持久化：只写暂存槽（不置 alive、不进图库），上电后本次
 *     拉取成功前一律显示图库内容（boot gate 决定）；
 *   - 样式由远端配置定义：分割 = 设备拼「本地信息框 + 远端下方内容」，
 *     关闭 = 全屏远端内容、信息框一律不画；
 *   - 同 cid（或 304）不刷新 —— 轮播/仅最新的节奏完全由远端掌握。
 */

/* 拉取结果码（last_code，页面展示用）。 */
enum {
    RMT_CODE_OK_NEW   = 1,    /* 拉到新内容并已上屏 */
    RMT_CODE_OK_SAME  = 0,    /* 同内容/304，画面保持 */
    RMT_E_NO_LAN      = -1,   /* 不在局域网（纯热点/加入中） */
    RMT_E_PWD         = -2,   /* 密码重置占用屏幕 */
    RMT_E_NO_STORE    = -3,   /* store 分区不可用 */
    RMT_E_NO_HOST     = -4,   /* 未配置主机 */
    RMT_E_HTTP        = -5,   /* 连接/HTTP 层失败（超时、拒连、DNS） */
    RMT_E_BAD_HDR     = -6,   /* 应答头不合法 */
    RMT_E_BODY        = -7,   /* 载荷截断 */
    RMT_E_CRC         = -8,   /* CRC 校验不过 */
    RMT_E_NO_SLOT     = -9,   /* 无空暂存槽（图库满，删除一张或关远端） */
    RMT_E_STAGE       = -10,  /* 暂存写入失败 */
    RMT_E_DISPLAY     = -11,  /* 提交/刷屏失败 */
};

typedef struct {
    uint8_t  en;             /* 开关（含 host 非空判定） */
    uint8_t  iv;             /* 间隔分钟 */
    char     host[64];       /* 配置的主机串 */
    bool     active;         /* 当前屏幕是否为远端内容 */
    bool     split;          /* 远端样式（true=分割） */
    bool     last_ok;        /* 最近一次拉取成功 */
    int      last_code;      /* RMT_CODE_* */
    int64_t  last_ms;        /* 最近一次拉取完成时刻（esp_timer us） */
    uint64_t cid;            /* 当前内容 id */
    uint32_t pulls;          /* 累计上屏次数 */
    uint32_t fails;          /* 累计失败次数 */
    uint32_t skips;          /* 累计同内容跳过次数 */
} remote_status_t;

/* 初始化（创建拉取任务；内部按设置套用暂存槽预留）。在 store_init 之后调用。 */
void remote_init(void);

/* 触发一次拉取（分钟调度到点 / 上电门控 / 配置保存后）。幂等，非阻塞。 */
void remote_kick(void);
/* 兼容别名：overlay 分钟调度调用的口径。 */
#define remote_tick remote_kick

/* 上电门控等待首次拉取结果（true = 已有结果；false = 超时）。 */
bool remote_wait_first(uint32_t timeout_ms);

/* 配置变更（main.c 在 /api/remote 保存后调用）：套用暂存槽预留；
 * 关闭远端时在拉取任务里回落图库；开启时立即试拉一次。 */
void remote_settings_changed(void);

/* 当前屏幕是否为远端内容（main.c /api/info 用）。 */
bool remote_active(void);

/* R2.1.0：手动上传 / 图库切图接管了显示 —— 远端内容被暂时顶替，下一轮
 * 拉取即使同 cid 也要重新上屏（不重新拉就不会回到远端内容）。 */
void remote_notify_override(void);

/* 状态快照（/api/remote GET 用）。 */
void remote_get_status(remote_status_t *out);

/* 当前内容 id 的 16 位十六进制串（buf >= 17）；无内容给 "0"）。 */
void remote_cid_hex(char *buf, size_t n);

#endif /* MOINK_REMOTE_H */
