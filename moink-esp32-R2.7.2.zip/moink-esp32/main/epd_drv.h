#ifndef EPD_DRV_H
#define EPD_DRV_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

/*
 * JDY79668 协议四色电子墨水屏驱动（K/W/R/Y，2bpp，4 像素/字节）。
 * 从社区 InkSight 适配移植（epd_driver.cpp + 屏幕修改适配驱动/epd7in3g-A0.cpp）。
 *
 * 两种拆机屏运行时切换（无需重刷）：
 *   A0 - 768 x 552，隔行半屏 Y 映射（已在真机验证）
 *   A1 - 可见区 768 x 552（与 A0 外观一致）、TRES 768 x 600，完整 JD79665
 *        式初始化，单帧一次 0x83 布防。移植自 InkSight_adapt_HUAWEI_eink
 *        firmware/src/epd_driver.cpp (EPD_PANEL_38_JD79665_BWRY)，华为手机壳
 *        A1 版本；真机确认栅极为顺序寻址，768x552 帧顺序直写即 1:1 铺满可见区。
 *        编号同为 A1、但刷新分两半且有接缝的「A1.1 批次」也选 A1：
 *        R1.2.0 已删除 A1.1 专属画像与诊断变体（参数与 A1 完全相同）。
 *        R1.2.2 删除 800x600 对照诊断档，A1 只剩 768x552 顺序一种策略。
 *
 * epd_display_2bpp() / epd_display_2bpp_wh() 期望的帧缓冲布局：
 *   行 r 存逻辑行 y = H-1-r（缓冲自下而上存储），
 *   每字节 4 像素、MSB 优先，像素 x 在位 (6 - 2*(x%4))，
 *   色码 0x00=黑 0x01=白 0x02=黄 0x03=红（A0 实测）。
 */

typedef enum {
    EPD_PANEL_A0 = 0,
    EPD_PANEL_A1 = 1,
    EPD_PANEL_COUNT
} epd_panel_t;

typedef struct {
    uint16_t w;
    uint16_t h;
    uint32_t buf_len;        /* w/4*h 字节的 2bpp 载荷 */
    int8_t   lower_y_base;   /* 下半屏 Y 映射偏移（A0: -1） */
    uint8_t  linear;         /* 1 = 整窗 + 单次线性 0x10 写入 */
} epd_profile_t;

extern const epd_profile_t EPD_PROFILES[EPD_PANEL_COUNT];

/* 静态帧缓冲按 800x600/4 = 120000 字节分配（沿用旧上限，留出余量）；
   A0 / A1 的 768x552 帧（105984）用同一块缓冲的前段。 */
#define EPD_MAX_W         800
#define EPD_MAX_H         600
#define EPD_MAX_BUF_LEN   (EPD_MAX_W / 4 * EPD_MAX_H)   /* 120000 */
#define EPD_A0_W          768
#define EPD_A0_H          552
#define EPD_A1_W          768       /* A1 可见区 / 768x552 帧 */
#define EPD_A1_H          552
#define EPD_A1_GATES      600       /* A1 TRES / 刷新窗栅极行数（可见 552 + 边框 48） */

/*
 * 引脚映射（R1.2.2 起运行时可配，见 settings.h 的 pin_cfg_t / PIN_PRESETS）：
 *   ADC / 唤醒 / SCK / MOSI / CS / DC / RST / BUSY 八脚由设置决定，
 *   默认档 = SCK4 MOSI6 CS7 DC1 RST3 BUSY10、唤醒 5、ADC 0。
 *   另有「排线」「整合板」两档预设与用户自定义档；改引脚需重启生效。
 *   另有一个固件固定的自锁脚 GPIO2（MOS 一键开机），不在此表中。
 */

/* 初始化 SPI 总线 + GPIO（引脚取自 settings_pins()）。成功返回 0。 */
int epd_init(void);

/* 选择活动屏画像。成功返回 0。 */
int epd_set_panel(epd_panel_t panel);
epd_panel_t epd_get_panel(void);

/*
 * ★ A1 驱动策略（R1.2.2 起只有一种，不再可切换）。
 *
 *   FB-013 真机定案（2026-09-23，fw R1.1.2）：这块玻璃的**可见区恒为 768x552**
 *   （外观与 A0 一致），帧里多出来的行列**不显示**；且栅极是**顺序寻址**的
 *   ——顺序写栅极 0..599 得到的是**连续完整**的画面（无上下穿插、无横向条纹），
 *   只是右 32 列 / 下 48 行被可见区裁掉。因此此前由卖家固件取证反推的
 *   「两 bank 交错栅极」模型作废，交错映射路径（旧 2 / 3 / 4 档）已整体删除。
 *
 *   R1.2.2：真机验收通过后，只保留唯一正解——
 *       帧 768x552，TRES/刷新窗 768x600，写入窗口 (0..767, 0..551) +
 *       单次 0x10 连发 552 行 x 192 B，栅极号 = 行号（顺序）。
 *       1:1 铺满可见区：不裁切、不重采样、无白边。行内固定整行镜像。
 *   原「2 NATIVE800」800x600 对照诊断档连同其接收路径一并删除（api 仍为 2：
 *   帧头格式零变动，只是不再接受该对照几何）。
 */

/* 当前画像（永不为 NULL）。 */
const epd_profile_t *epd_profile(void);

/* 画像显示名（"A0" / "A1"）。 */
const char *epd_panel_name(epd_panel_t panel);

/*
 * 写帧时水平镜像开关（R1.2.2 起**保留但当前无生效档位**）。
 * 原唯一生效范围是已删除的 A1 800x600 对照档；现行 768x552 顺序档行内固定
 * 整行镜像、A0 的 180° 缓冲契约已含镜像，都不读本开关。保留函数与 NVS 键
 * 是为兼容既有调用点，后续版本可一并清理。
 */
void epd_set_hflip(bool on);
bool epd_get_hflip(void);

/*
 * 完整显示周期，最多尝试 3 次：
 * reset -> PSR/TRES/上电 -> 写 2bpp 帧 -> 刷新 -> 断电。
 * `frame` 必须为 epd_profile()->buf_len 字节。成功返回 0。
 */
int epd_display_2bpp(const uint8_t *frame);

/* 同 epd_display_2bpp()，但显式给出本帧几何（当前只接受 768x552）。 */
int epd_display_2bpp_wh(const uint8_t *frame, uint16_t w, uint16_t h);

/* R2.0.1 流式供行：整帧不再驻 RAM（WROOM-32 无 PSRAM，120KB 连续堆不可得，
   见 frame.c），帧内容改由回调按需供出：
     typedef const uint8_t *(*epd_row_get_t)(int r);
   r = 「缓冲行号」0..h-1（行自下而上 180° 契约下的行序，与整帧缓冲同布局），
   返回该行首指针（r*w/4 字节，内容保持到下一次回调即可）。
   驱动对返回行做与整帧路径完全相同的镜像后写面板 —— 硬件序列零改动。 */
typedef const uint8_t *(*epd_row_get_t)(int r);

/* 同 epd_display_2bpp_wh()，但帧内容来自 get_row 回调（不占用整帧 RAM）。 */
int epd_display_2bpp_wh_src(uint16_t w, uint16_t h, epd_row_get_t get_row);

/* 行 180° 镜像（字节倒序 + 字节内 2bit 组倒序），frame.c 流式合成「旋转视图行」
   用（与驱动的行镜像同一套变换，两次叠加 = 原样）。返回 dst。 */
const uint8_t *epd_row_mirror(uint8_t *dst, const uint8_t *src, int row_bytes);

/*
 * 校验帧几何是否被当前画像接受。
 *   A0 / A1：都只接受 768x552，载荷长度必须与几何自洽。
 *   （R1.2.2 起 A1 的 800x600 对照档与接收路径已删除。）
 */
bool epd_frame_geom_ok(uint16_t w, uint16_t h, uint32_t len);

/*
 * 残影清理：整屏填单色并刷新 `cycles` 次（黑/白交替）。
 * 每次约一次全刷新（本屏约 15~25 秒）。
 */
int epd_clear_cycles(int cycles);

/* 发送面板深睡命令（0x07 0xA5）。用完可安全调用；★R2.7.2 起 epd_init()
   之前调用也安全（SPI 未初始化时直接跳过 —— 假唤醒回睡路径用）。 */
void epd_panel_deep_sleep(void);

/* ★R2.7.2【修复2】：面板物理序列（整刷/快刷/清屏）是否正在进行 ——
 * display 入口置位、序列收尾（refresh done/超时/重试耗尽）清除。
 * power_should_sleep() 据此硬判据拒绝入睡，不再只依赖各任务自觉报
 * power_busy_pulse（判闲之后才启动的重画没有脉冲，正是 R2.7.1 睡死）。 */
bool epd_panel_busy(void);

/* ---------------- R2.4.0 快刷（局刷） ---------------- */

/* 整帧动作码写入（面板已上电，无再 0x04）。行契约与整帧显示相同：
 * get_row(r) 供 provider 行 r（0..h-1，驱动对行再镜像）。A0 逐行单栅窗 /
 * A1 整窗连发，与 epd_write_frame_2bpp 同一路线去掉上电两行。 */

/* 快刷一次显示周期：工厂初始化（复位+寄存器+PON，无工厂刷）→ 寄存器 LUT
 * 布防（A0 补 0xAA 解锁 + R01 供电 + PLL 120Hz + R20 表 + PSR 4B F9）→
 * 整帧动作码写入（保持码 0x00 + 差异动作）→ 三扫描 DRF → 断电。
 * lut2048 = lut_build_num() 表（2048B）。电气序列 1:1 自 verify_fw/
 * video_fw 真机验证路径（JD7966x 寄存器 LUT 已在本屏实机验证）。
 * 返回 0 = 面板序列完成；*accepted = DRF 是否见到忙脉冲（未接受 = 寄存器
 * LUT 未生效，调用方应回退整刷并拉黑快刷）；*elapsed_ms 可为 NULL。 */
int epd_fast_refresh(const uint8_t *lut2048, epd_row_get_t get_row,
                     int64_t *elapsed_ms, bool *accepted);

#endif /* EPD_DRV_H */
