#include "settings.h"
#include "epd_drv.h"

#include "nvs.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_random.h"      /* R2.0.0：esp_fill_random 自 IDF v6 起从 esp_system.h 拆出 */
#include <string.h>

static const char *TAG = "settings";

#define NVS_NS "moink"

/* ---------------- 引脚预设与校验（R1.2.2；ESP32 移植版改写） ----------------
   GPIO 白名单见 settings.h：排除片内 flash(6..11)、UART0(1/3)、strapping(0/2/12)、
   仅输入脚(34..39)、WROOM 未引出(20/24/37/38)。 */
const pin_cfg_t PIN_PRESETS[GPIO_PRESET_NPRESET] = {
    /* [0] 默认（★本移植版实际接线））：ADC=34 唤醒=25 SCK=18 MOSI=23 CS=5 DC=16 RST=17 BUSY=27 */
    [GPIO_PRESET_DEFAULT] = { { 34, 25, 18, 23, 5, 16, 17, 27 } },
    /* [1] 备用 A（VSPI 经典脚位）：ADC=35 唤醒=26 SCK=14 MOSI=13 CS=15 DC=22 RST=21 BUSY=27 */
    [GPIO_PRESET_LINE]    = { { 35, 26, 14, 13, 15, 22, 21, 27 } },
    /* [2] 备用 B（同默认 SPI 脚，ADC/唤醒另接）：ADC=36 唤醒=32 SCK=18 MOSI=23 CS=5 DC=19 RST=4 BUSY=33 */
    [GPIO_PRESET_BOARD]   = { { 36, 32, 18, 23, 5, 19, 4, 33 } },
};

/* ESP32 可输出 GPIO 白名单（SCK/MOSI/CS/DC/RST/BUSY 共用）。 */
bool pin_io_allowed(uint8_t io)
{
    switch (io) {
    case 4: case 5:
    case 13: case 14: case 15: case 16: case 17: case 18: case 19:
    case 21: case 22: case 23:
    case 25: case 26: case 27:
    case 32: case 33:
        return true;
    default:
        return false;   /* flash(6..11)、UART0(1/3)、strapping(0/2/12)、仅输入(34..39)等全排除 */
    }
}

/* ADC1 脚（仅输入）：GPIO32..36、39（37/38 在 WROOM-32 上未引出）。 */
bool pin_adc_allowed(uint8_t io)
{
    return io == 32 || io == 33 || io == 34 || io == 35 || io == 36 || io == 39;
}

/* ext0 深睡唤醒脚：仅 RTC 域 GPIO。 */
bool pin_wake_allowed(uint8_t io)
{
    switch (io) {
    case 4: case 5: case 13: case 14: case 15:
    case 25: case 26: case 27:
    case 32: case 33: case 34: case 35: case 36: case 39:
        return true;
    default:
        return false;
    }
}

bool pin_cfg_valid(const pin_cfg_t *c)
{
    if (!c) return false;
    for (int i = 0; i < PIN_IDX_COUNT; i++) {
        uint8_t io = c->v[i];
        if (i == PIN_IDX_ADC) {
            if (!pin_adc_allowed(io)) return false;
        } else if (i == PIN_IDX_WAKE) {
            if (!pin_wake_allowed(io)) return false;
        } else {
            if (!pin_io_allowed(io)) return false;
        }
        /* 互不重复。 */
        for (int j = 0; j < i; j++)
            if (c->v[j] == io) return false;
    }
    return true;
}

/* ---------------- 设置本体 ---------------- */

static const moink_settings_t DEFAULTS = {
    .panel       = EPD_PANEL_A0,
    .hflip       = 0,
    .wifi_pwr    = SETT_WIFI_PWR_HIGH,  /* ★ ESP32 移植版：开发板天线正常，默认高功率（C3 版低功率是板级补丁） */
    .gpio_preset = GPIO_PRESET_DEFAULT,
    .pins        = { { 34, 25, 18, 23, 5, 16, 17, 27 } },   /* 与 PIN_PRESETS[0] 一致 */
    .sleep_s     = SETT_SLEEP_DEF,     /* R2.5.0：上电 5 分钟无操作 → 事件驱动深睡（原「USB 供电常开默认不休眠」改为可选档） */
    .timeout_action = SETT_ACTION_SLEEP,
    .wake_s      = SETT_WAKE_OFF,
    .wake_show   = 1,        /* R1.3.3：定时唤醒后自动切图，默认开启 */
    .ap_ssid     = "",
    .ap_pass     = "",
    /* R2.0.0 新增字段 */
    .sta_ssid    = "",                    /* 未配网 = 纯热点模式 */
    .sta_pass    = "",
    .web_pass    = "",                    /* 未设置密码 = 免认证，页面引导首次设置 */
    .box_en      = 0,                     /* 信息框默认关，绑定传感器时页面自动开 */
    .box_density = 100,                   /* R2.0.2：默认实体白框（字最实；旧 50 抖动底会发虚） */
    .box_iv_min  = SETT_BOX_IV_10MIN,     /* 默认 10 分钟刷一次信息框 */
    .box_style   = SETT_BOX_STYLE_OVERLAY, /* R2.0.3：默认叠加（分割仅对之后新上传生效） */
    .box_ip_mode = SETT_BOX_IP_CYCLES,    /* R2.0.3：默认入网后显示 N 个刷新周期 */
    .box_ip_cyc  = 3,                     /* R2.0.3：默认 3 个周期 */
    /* R2.4.0 新增字段 */
    .box_pos     = SETT_BOX_POS_TOP,
    .box_dir     = SETT_BOX_DIR_HORIZ,
    .box_move_iv = SETT_BOX_MV_1D,       /* 防老化：默认每天换位一次 */
    .box_wg      = { 0 },
    /* R2.1.0 新增字段 */
    .box_show    = SETT_BOX_SHOW_ALL,      /* 元素全开 */
    .box_time_h  = SETT_BOX_AUTO,          /* 时间字高自适应 */
    .box_row_h   = SETT_BOX_AUTO,          /* 右侧行高自适应 */
    .box_gap_mid = SETT_BOX_AUTO,          /* 中部留白自适应（≥28px） */
    .box_pad_x   = 12,                     /* 左右内边距 12px（R2.0.6 版式原值） */
    .box_pad_y   = 6,                      /* 上下内边距 6px */
    .caro_iv     = SETT_CARO_30MIN,        /* 图库自动轮播默认 30 分钟（信息栏不展示时） */
    .netcheck_iv = SETT_NETCHECK_DEF_S,    /* 网络检测默认 30 秒 */
    .remote_en   = 0,
    .remote_host = "",
    .remote_iv   = SETT_REMOTE_IV_DEF,     /* 远端拉取默认 10 分钟 */
    .orient      = SETT_ORIENT_RIBBON_BOTTOM,  /* R2.2.1：默认排线在下（与历史几何一致） */
    .ble_mac     = "",
    .ble_key     = "",
};

/* R2.1.0：米家传感器「曾经成功取到数据」标志（独立于设置结构体，避免误重置）。
   放在 DEFAULTS 之外单独读，解绑时清除。 */
static bool s_ble_ever_ok = false;

/* 引脚 NVS 键名（逐个 u8 存；顺序与 PIN_IDX_* 一致）。 */
static const char *PIN_KEY[PIN_IDX_COUNT] = {
    "p_adc", "p_wake", "p_sck", "p_mosi", "p_cs", "p_dc", "p_rst", "p_busy"
};

static moink_settings_t s_cfg;
static nvs_handle_t s_nvs;
static bool s_ok = false;

static void read_u8(const char *key, uint8_t *out)
{
    uint8_t v;
    if (s_ok && nvs_get_u8(s_nvs, key, &v) == ESP_OK) *out = v;
}

static void read_u16(const char *key, uint16_t *out)   /* R2.1.0：网络检测间隔 */
{
    uint16_t v;
    if (s_ok && nvs_get_u16(s_nvs, key, &v) == ESP_OK) *out = v;
}

static void read_u32(const char *key, uint32_t *out)
{
    uint32_t v;
    if (s_ok && nvs_get_u32(s_nvs, key, &v) == ESP_OK) *out = v;
}

static void read_str(const char *key, char *out, size_t n)
{
    if (!s_ok) return;
    size_t need = 0;
    if (nvs_get_str(s_nvs, key, NULL, &need) != ESP_OK) return;
    if (need == 0 || need > n) return;
    char tmp[SETT_PASS_MAX];
    if (nvs_get_str(s_nvs, key, tmp, &need) == ESP_OK) strlcpy(out, tmp, n);
}

void settings_init(void)
{
    s_cfg = DEFAULTS;

    /* 命名空间小、字段少，逐键读取；读不到就落在默认值上。 */
    s_ok = (nvs_open(NVS_NS, NVS_READWRITE, &s_nvs) == ESP_OK);
    if (!s_ok) {
        ESP_LOGW(TAG, "nvs_open failed, using defaults");
        return;
    }

    read_u8("panel",   &s_cfg.panel);
    read_u8("hflip",   &s_cfg.hflip);
    read_u8("wifi_pwr", &s_cfg.wifi_pwr);
    read_u8("gpio_preset", &s_cfg.gpio_preset);
    for (int i = 0; i < PIN_IDX_COUNT; i++)
        read_u8(PIN_KEY[i], &s_cfg.pins.v[i]);
    read_u32("sleep_s", &s_cfg.sleep_s);
    read_u32("wake_s",  &s_cfg.wake_s);
    read_u8("to_act",   &s_cfg.timeout_action);   /* R1.3.3：无此键 = 默认休眠 */
    read_u8("wake_show", &s_cfg.wake_show);       /* R1.3.3：无此键 = 默认开 */
    read_str("ap_ssid", s_cfg.ap_ssid, SETT_SSID_MAX);
    read_str("ap_pass", s_cfg.ap_pass, SETT_PASS_MAX);
    /* R2.0.0 新增字段 */
    read_str("sta_ssid", s_cfg.sta_ssid, SETT_SSID_MAX);
    read_str("sta_pass", s_cfg.sta_pass, SETT_PASS_MAX);
    read_str("web_pass", s_cfg.web_pass, SETT_WEB_PASS_LEN);
    read_u8("box_en", &s_cfg.box_en);
    read_u8("box_density", &s_cfg.box_density);
    read_u8("box_iv", &s_cfg.box_iv_min);
    read_u8("box_style", &s_cfg.box_style);   /* R2.0.3：无此键 = 默认叠加 */
    read_u8("box_ipm", &s_cfg.box_ip_mode);   /* R2.0.3：无此键 = 默认周期档 */
    read_u8("box_ipc", &s_cfg.box_ip_cyc);    /* R2.0.3：无此键 = 默认 3 */
    read_str("ble_mac", s_cfg.ble_mac, SETT_BLE_MAC_LEN);
    read_str("ble_key", s_cfg.ble_key, SETT_BLE_KEY_LEN);
    /* R2.1.0 新增字段（无键 = 默认值） */
    read_u8("box_show", &s_cfg.box_show);
    read_u8("box_th", &s_cfg.box_time_h);
    read_u8("box_rh", &s_cfg.box_row_h);
    read_u8("box_gm", &s_cfg.box_gap_mid);
    read_u8("box_px", &s_cfg.box_pad_x);
    read_u8("box_py", &s_cfg.box_pad_y);
    read_u8("caro_iv", &s_cfg.caro_iv);
    /* R2.4.0 */
    read_u8("bpos", &s_cfg.box_pos);
    read_u8("bdir", &s_cfg.box_dir);
    read_u32("bmv",  &s_cfg.box_move_iv);
    {
        char hex[SETT_BOX_WG_BYTES * 2 + 1];
        read_str("boxwg", hex, sizeof(hex));
        memset(s_cfg.box_wg, 0, sizeof(s_cfg.box_wg));
        for (int i = 0; i < SETT_BOX_WG_BYTES && hex[2 * i] && hex[2 * i + 1]; i++) {
            unsigned b = 0;
            if (sscanf(hex + 2 * i, "%2x", &b) == 1) s_cfg.box_wg[i] = (uint8_t)b;
        }
    }
    read_u16("netiv", &s_cfg.netcheck_iv);
    read_u8("rmt_en", &s_cfg.remote_en);
    read_str("rmt_host", s_cfg.remote_host, SETT_REMOTE_HOST_MAX);
    read_u8("rmt_iv", &s_cfg.remote_iv);
    read_u8("orient", &s_cfg.orient);          /* R2.2.1：屏幕方向 */
    {
        uint8_t v = 0;
        read_u8("ble_ok", &v);
        s_ble_ever_ok = (v != 0);
    }

    /* R2.0.0：新字段越界归一 */
    if (s_cfg.box_en) s_cfg.box_en = 1;
    if (s_cfg.box_density > 100) s_cfg.box_density = 100;
    switch (s_cfg.box_iv_min) {
    case SETT_BOX_IV_1MIN: case SETT_BOX_IV_5MIN: case SETT_BOX_IV_10MIN:
    case SETT_BOX_IV_30MIN: case SETT_BOX_IV_60MIN:
        break;
    default:
        s_cfg.box_iv_min = SETT_BOX_IV_10MIN;
    }
    /* R2.0.3：样式 / IP 行模式 / 周期数越界归一 */
    if (s_cfg.box_style > SETT_BOX_STYLE_SPLIT) s_cfg.box_style = SETT_BOX_STYLE_OVERLAY;
    if (s_cfg.box_ip_mode > SETT_BOX_IP_CYCLES) s_cfg.box_ip_mode = SETT_BOX_IP_CYCLES;
    if (s_cfg.box_ip_cyc < SETT_BOX_IP_CYC_MIN || s_cfg.box_ip_cyc > SETT_BOX_IP_CYC_MAX)
        s_cfg.box_ip_cyc = 3;
    /* R2.4.0：位置 / 方向 / 换位越界归一 */
    if (s_cfg.box_pos > SETT_BOX_POS_RIGHT) s_cfg.box_pos = SETT_BOX_POS_TOP;
    if (s_cfg.box_dir > SETT_BOX_DIR_VERT) s_cfg.box_dir = SETT_BOX_DIR_HORIZ;
    switch (s_cfg.box_move_iv) {
    case SETT_BOX_MV_OFF: case SETT_BOX_MV_1H: case SETT_BOX_MV_6H:
    case SETT_BOX_MV_12H: case SETT_BOX_MV_1D:
        break;
    default:
        s_cfg.box_move_iv = SETT_BOX_MV_1D;
    }
    /* R2.1.0：自定义布局 / 轮播 / 网络 / 远端越界归一 */
    s_cfg.box_show &= SETT_BOX_SHOW_ALL;
    if (s_cfg.box_show == 0) s_cfg.box_show = SETT_BOX_SHOW_ALL;  /* 全关无意义 */
    if (s_cfg.box_time_h && (s_cfg.box_time_h < SETT_BOX_TIME_H_MIN ||
                             s_cfg.box_time_h > SETT_BOX_TIME_H_MAX))
        s_cfg.box_time_h = SETT_BOX_AUTO;
    if (s_cfg.box_row_h && (s_cfg.box_row_h < SETT_BOX_ROW_H_MIN ||
                            s_cfg.box_row_h > SETT_BOX_ROW_H_MAX))
        s_cfg.box_row_h = SETT_BOX_AUTO;
    if (s_cfg.box_gap_mid && (s_cfg.box_gap_mid < SETT_BOX_GAP_MIN ||
                              s_cfg.box_gap_mid > SETT_BOX_GAP_MAX))
        s_cfg.box_gap_mid = SETT_BOX_AUTO;
    if (s_cfg.box_pad_x > SETT_BOX_PAD_X_MAX) s_cfg.box_pad_x = 12;
    if (s_cfg.box_pad_y > SETT_BOX_PAD_Y_MAX) s_cfg.box_pad_y = 6;
    switch (s_cfg.caro_iv) {
    case SETT_CARO_OFF: case SETT_CARO_1MIN: case SETT_CARO_5MIN:
    case SETT_CARO_10MIN: case SETT_CARO_30MIN: case SETT_CARO_60MIN:
        break;
    default:
        s_cfg.caro_iv = SETT_CARO_30MIN;
    }
    if (s_cfg.netcheck_iv < SETT_NETCHECK_MIN_S || s_cfg.netcheck_iv > SETT_NETCHECK_MAX_S)
        s_cfg.netcheck_iv = SETT_NETCHECK_DEF_S;
    if (s_cfg.remote_en) s_cfg.remote_en = 1;
    switch (s_cfg.remote_iv) {
    case SETT_BOX_IV_1MIN: case SETT_BOX_IV_5MIN: case SETT_BOX_IV_10MIN:
    case SETT_BOX_IV_30MIN: case SETT_BOX_IV_60MIN:
        break;
    default:
        s_cfg.remote_iv = SETT_REMOTE_IV_DEF;
    }
    /* 远端主机字符白名单：主机名/数字/点/冒号/连字符/下划线/路径斜杠（防注入 URL） */
    {
        const char *h = s_cfg.remote_host;
        int bad = 0;
        for (size_t i = 0; h[i]; i++) {
            char c = h[i];
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') ||
                  (c >= 'A' && c <= 'Z') || c == '.' || c == ':' ||
                  c == '-' || c == '_' || c == '/')) { bad = 1; break; }
        }
        if (bad) s_cfg.remote_host[0] = '\0';
    }
    /* R2.2.1：方向越界归一（0..3） */
    if (s_cfg.orient >= SETT_ORIENT_COUNT) s_cfg.orient = SETT_ORIENT_RIBBON_BOTTOM;
    /* 网页密码只认 6 位纯数字；其他一律视为未设置 */
    {
        int ok = (strlen(s_cfg.web_pass) == 6);
        for (int i = 0; ok && i < 6; i++)
            if (s_cfg.web_pass[i] < '0' || s_cfg.web_pass[i] > '9') ok = 0;
        if (!ok) s_cfg.web_pass[0] = '\0';
    }
    /* MAC 归一为大写、12 位 hex；key 归一为大写 32 位 hex */
    {
        for (int i = 0; i < 12; i++) {
            char c = s_cfg.ble_mac[i];
            if (c >= 'a' && c <= 'f') s_cfg.ble_mac[i] = (char)(c - 'a' + 'A');
        }
        if (strlen(s_cfg.ble_mac) != 12) s_cfg.ble_mac[0] = '\0';
        for (int i = 0; i < 32; i++) {
            char c = s_cfg.ble_key[i];
            if (c >= 'a' && c <= 'f') s_cfg.ble_key[i] = (char)(c - 'a' + 'A');
        }
        if (strlen(s_cfg.ble_key) != 32) s_cfg.ble_key[0] = '\0';
    }

    /* R1.2.0：旧值不再做兼容归一；越界一律回落到默认档。 */
    if (s_cfg.panel >= EPD_PANEL_COUNT) s_cfg.panel = DEFAULTS.panel;
    if (s_cfg.hflip) s_cfg.hflip = 1;
    if (s_cfg.timeout_action > SETT_ACTION_OFF) s_cfg.timeout_action = SETT_ACTION_SLEEP;
    if (s_cfg.wake_show) s_cfg.wake_show = 1;

    /* 引脚：预设档直接用预设表；自定义档校验失败则整体回落默认（避免半套引脚
       启动，把设备带进「屏不亮」的不可诊断状态）。 */
    if (s_cfg.gpio_preset >= GPIO_PRESET_COUNT) s_cfg.gpio_preset = GPIO_PRESET_DEFAULT;
    if (s_cfg.gpio_preset == GPIO_PRESET_CUSTOM) {
        if (!pin_cfg_valid(&s_cfg.pins)) {
            ESP_LOGW(TAG, "custom pin map invalid, fallback to default preset");
            s_cfg.gpio_preset = GPIO_PRESET_DEFAULT;
            s_cfg.pins = PIN_PRESETS[GPIO_PRESET_DEFAULT];
        }
    } else {
        s_cfg.pins = PIN_PRESETS[s_cfg.gpio_preset];
    }

    ESP_LOGI(TAG, "panel=%u hflip=%u timeout=%lus action=%s wake=%lus wake_show=%u ssid='%s' open=%d",
             s_cfg.panel, s_cfg.hflip,
             (unsigned long)s_cfg.sleep_s,
             s_cfg.timeout_action == SETT_ACTION_OFF ? "off" : "sleep",
             (unsigned long)s_cfg.wake_s, s_cfg.wake_show,
             s_cfg.ap_ssid[0] ? s_cfg.ap_ssid : "(default)",
             s_cfg.ap_pass[0] == 0);
    ESP_LOGI(TAG, "gpio preset=%u ADC=%u WAKE=%u SCK=%u MOSI=%u CS=%u DC=%u RST=%u BUSY=%u",
             s_cfg.gpio_preset, s_cfg.pins.v[0], s_cfg.pins.v[1], s_cfg.pins.v[2],
             s_cfg.pins.v[3], s_cfg.pins.v[4], s_cfg.pins.v[5],
             s_cfg.pins.v[6], s_cfg.pins.v[7]);
}

const moink_settings_t *settings_get(void) { return &s_cfg; }
const pin_cfg_t *settings_pins(void) { return &s_cfg.pins; }

static void store_u8(const char *key, uint8_t v)
{
    if (s_ok && nvs_set_u8(s_nvs, key, v) != ESP_OK) ESP_LOGW(TAG, "set %s failed", key);
}

static void store_u16(const char *key, uint16_t v)   /* R2.1.0 */
{
    if (s_ok && nvs_set_u16(s_nvs, key, v) != ESP_OK) ESP_LOGW(TAG, "set %s failed", key);
}

static void store_u32(const char *key, uint32_t v)
{
    if (s_ok && nvs_set_u32(s_nvs, key, v) != ESP_OK) ESP_LOGW(TAG, "set %s failed", key);
}

static void store_str(const char *key, const char *v)
{
    if (s_ok && nvs_set_str(s_nvs, key, v) != ESP_OK) ESP_LOGW(TAG, "set %s failed", key);
}

/* R1.0.8：commit 收敛到 setter 末尾，一次保存一次落盘（NVS 擦写均衡友好）。 */
static void settings_commit(void)
{
    if (s_ok) nvs_commit(s_nvs);
}

esp_err_t settings_set_panel(uint8_t v)
{
    if (v >= EPD_PANEL_COUNT) return ESP_ERR_INVALID_ARG;
    s_cfg.panel = v;
    store_u8("panel", v);
    settings_commit();
    return ESP_OK;
}

esp_err_t settings_set_hflip(uint8_t v)
{
    s_cfg.hflip = v ? 1 : 0;
    store_u8("hflip", s_cfg.hflip);
    settings_commit();
    return ESP_OK;
}

esp_err_t settings_set_wifi_pwr(uint8_t v)
{
    if (v > SETT_WIFI_PWR_LOW) return ESP_ERR_INVALID_ARG;
    s_cfg.wifi_pwr = v;
    store_u8("wifi_pwr", v);
    settings_commit();
    return ESP_OK;
}

esp_err_t settings_set_gpio(uint8_t preset, const pin_cfg_t *custom)
{
    pin_cfg_t applied;

    if (preset >= GPIO_PRESET_NPRESET) {
        /* 自定义档：必须整体合法才接受。 */
        if (preset != GPIO_PRESET_CUSTOM || !pin_cfg_valid(custom))
            return ESP_ERR_INVALID_ARG;
        applied = *custom;
    } else {
        applied = PIN_PRESETS[preset];
    }

    s_cfg.gpio_preset = preset;
    s_cfg.pins = applied;
    store_u8("gpio_preset", preset);
    for (int i = 0; i < PIN_IDX_COUNT; i++)
        store_u8(PIN_KEY[i], applied.v[i]);
    settings_commit();

    ESP_LOGI(TAG, "gpio set: preset=%u ADC=%u WAKE=%u SCK=%u MOSI=%u CS=%u DC=%u RST=%u BUSY=%u",
             preset, applied.v[0], applied.v[1], applied.v[2], applied.v[3],
             applied.v[4], applied.v[5], applied.v[6], applied.v[7]);
    return ESP_OK;
}

esp_err_t settings_set_sleep(uint32_t v)
{
    /* 仅接受档位值（或任意 >0 秒，上限 86400）。 */
    if (v > SETT_WAKE_1D) return ESP_ERR_INVALID_ARG;
    s_cfg.sleep_s = v;
    store_u32("sleep_s", v);
    settings_commit();
    return ESP_OK;
}

esp_err_t settings_set_wake(uint32_t v)
{
    if (v > SETT_WAKE_1D) return ESP_ERR_INVALID_ARG;
    s_cfg.wake_s = v;
    store_u32("wake_s", v);
    settings_commit();
    return ESP_OK;
}

esp_err_t settings_set_timeout_action(uint8_t v)
{
    if (v > SETT_ACTION_OFF) return ESP_ERR_INVALID_ARG;
    s_cfg.timeout_action = v;
    store_u8("to_act", v);
    settings_commit();
    return ESP_OK;
}

esp_err_t settings_set_wake_show(uint8_t v)
{
    s_cfg.wake_show = v ? 1 : 0;
    store_u8("wake_show", s_cfg.wake_show);
    settings_commit();
    return ESP_OK;
}

esp_err_t settings_set_ap(const char *ssid, const char *pass)
{
    /* FB-014①：单字段更新 —— 任一参数为 NULL 表示「保持当前值」；
       pass 为空串表示清除密码（热点转开放）。两个都给则整体替换。 */
    if (!ssid && !pass) return ESP_ERR_INVALID_ARG;

    if (ssid) {
        if (!pass) pass = s_cfg.ap_pass;      /* 只改名字：密码保持不变 */
        if (strlen(ssid) >= SETT_SSID_MAX || strlen(pass) >= SETT_PASS_MAX)
            return ESP_ERR_INVALID_ARG;
        strlcpy(s_cfg.ap_ssid, ssid, SETT_SSID_MAX);
        strlcpy(s_cfg.ap_pass, pass, SETT_PASS_MAX);
        store_str("ap_ssid", s_cfg.ap_ssid);
        store_str("ap_pass", s_cfg.ap_pass);
    } else {
        /* 只改密码：热点名保持不变。 */
        if (strlen(pass) >= SETT_PASS_MAX) return ESP_ERR_INVALID_ARG;
        strlcpy(s_cfg.ap_pass, pass, SETT_PASS_MAX);
        store_str("ap_pass", s_cfg.ap_pass);
    }
    settings_commit();
    return ESP_OK;
}

/* ---- R2.0.0：STA 配网 ---- */
esp_err_t settings_set_sta(const char *ssid, const char *pass)
{
    if (!ssid && !pass) return ESP_ERR_INVALID_ARG;

    if (ssid) {
        if (strlen(ssid) >= SETT_SSID_MAX) return ESP_ERR_INVALID_ARG;
        /* 空串 = 清除配网（回纯热点模式） */
        if (ssid[0] == '\0') {
            s_cfg.sta_ssid[0] = '\0';
            s_cfg.sta_pass[0] = '\0';
            store_str("sta_ssid", "");
            store_str("sta_pass", "");
            settings_commit();
            return ESP_OK;
        }
        if (!pass) pass = s_cfg.sta_pass;
        if (strlen(pass) >= SETT_PASS_MAX) return ESP_ERR_INVALID_ARG;
        strlcpy(s_cfg.sta_ssid, ssid, SETT_SSID_MAX);
        strlcpy(s_cfg.sta_pass, pass, SETT_PASS_MAX);
        store_str("sta_ssid", s_cfg.sta_ssid);
        store_str("sta_pass", s_cfg.sta_pass);
    } else {
        /* 只改密码 */
        if (strlen(pass) >= SETT_PASS_MAX) return ESP_ERR_INVALID_ARG;
        strlcpy(s_cfg.sta_pass, pass, SETT_PASS_MAX);
        store_str("sta_pass", s_cfg.sta_pass);
    }
    settings_commit();
    return ESP_OK;
}

/* ---- R2.0.0：网页密码（6 位纯数字） ---- */
esp_err_t settings_set_web_pass(const char *pass)
{
    if (!pass) return ESP_ERR_INVALID_ARG;
    /* 空串 = 清除（免认证） */
    if (pass[0] == '\0') {
        s_cfg.web_pass[0] = '\0';
        store_str("web_pass", "");
        settings_commit();
        return ESP_OK;
    }
    if (strlen(pass) != 6) return ESP_ERR_INVALID_ARG;
    for (int i = 0; i < 6; i++)
        if (pass[i] < '0' || pass[i] > '9') return ESP_ERR_INVALID_ARG;
    strlcpy(s_cfg.web_pass, pass, SETT_WEB_PASS_LEN);
    store_str("web_pass", s_cfg.web_pass);
    settings_commit();
    return ESP_OK;
}

void settings_gen_web_pass(char *out, size_t n)
{
    uint32_t r[2];
    esp_fill_random(r, sizeof(r));
    char p[SETT_WEB_PASS_LEN];
    snprintf(p, sizeof(p), "%02u%02u%02u",
             (unsigned)(r[0] % 100u), (unsigned)((r[0] >> 8) % 100u),
             (unsigned)(r[1] % 100u));
    strlcpy(s_cfg.web_pass, p, SETT_WEB_PASS_LEN);
    store_str("web_pass", s_cfg.web_pass);
    settings_commit();
    if (out && n > 0) strlcpy(out, s_cfg.web_pass, n);
}

/* ---- R2.0.0：信息框 / 传感器绑定 ---- */
esp_err_t settings_set_box(uint8_t en, uint8_t density, uint8_t iv_min,
                           uint8_t style, uint8_t ip_mode, uint8_t ip_cyc)
{
    if (en > 1) return ESP_ERR_INVALID_ARG;
    if (density > 100) density = 100;
    switch (iv_min) {
    case SETT_BOX_IV_1MIN: case SETT_BOX_IV_5MIN: case SETT_BOX_IV_10MIN:
    case SETT_BOX_IV_30MIN: case SETT_BOX_IV_60MIN:
        break;
    default:
        return ESP_ERR_INVALID_ARG;
    }
    /* R2.0.3：样式 / IP 行模式 / 周期数校验（越界拒绝，不静默归一 ——
       让调用方明确传值，避免页面漏字段时把设置改坏） */
    if (style > SETT_BOX_STYLE_SPLIT) return ESP_ERR_INVALID_ARG;
    if (ip_mode > SETT_BOX_IP_CYCLES) return ESP_ERR_INVALID_ARG;
    if (ip_cyc < SETT_BOX_IP_CYC_MIN || ip_cyc > SETT_BOX_IP_CYC_MAX)
        return ESP_ERR_INVALID_ARG;
    s_cfg.box_en = en;
    s_cfg.box_density = density;
    s_cfg.box_iv_min = iv_min;
    s_cfg.box_style = style;
    s_cfg.box_ip_mode = ip_mode;
    s_cfg.box_ip_cyc = ip_cyc;
    store_u8("box_en", en);
    store_u8("box_density", density);
    store_u8("box_iv", iv_min);
    store_u8("box_style", style);
    store_u8("box_ipm", ip_mode);
    store_u8("box_ipc", ip_cyc);
    settings_commit();
    return ESP_OK;
}

/* ---- R2.1.0：信息框内容自定义 ---- */
esp_err_t settings_set_box_layout(uint8_t show, uint8_t time_h, uint8_t row_h,
                                  uint8_t gap_mid, uint8_t pad_x, uint8_t pad_y)
{
    show &= SETT_BOX_SHOW_ALL;
    if (show == 0) return ESP_ERR_INVALID_ARG;          /* 全关无意义 */
    if (time_h && (time_h < SETT_BOX_TIME_H_MIN || time_h > SETT_BOX_TIME_H_MAX))
        return ESP_ERR_INVALID_ARG;
    if (row_h && (row_h < SETT_BOX_ROW_H_MIN || row_h > SETT_BOX_ROW_H_MAX))
        return ESP_ERR_INVALID_ARG;
    if (gap_mid && (gap_mid < SETT_BOX_GAP_MIN || gap_mid > SETT_BOX_GAP_MAX))
        return ESP_ERR_INVALID_ARG;
    if (pad_x > SETT_BOX_PAD_X_MAX) return ESP_ERR_INVALID_ARG;
    if (pad_y > SETT_BOX_PAD_Y_MAX) return ESP_ERR_INVALID_ARG;

    s_cfg.box_show = show;
    s_cfg.box_time_h = time_h;
    s_cfg.box_row_h = row_h;
    s_cfg.box_gap_mid = gap_mid;
    s_cfg.box_pad_x = pad_x;
    s_cfg.box_pad_y = pad_y;
    store_u8("box_show", show);
    store_u8("box_th", time_h);
    store_u8("box_rh", row_h);
    store_u8("box_gm", gap_mid);
    store_u8("box_px", pad_x);
    store_u8("box_py", pad_y);
    settings_commit();
    return ESP_OK;
}

/* ---- R2.4.0：信息框位置 / 方向 / 换位间隔 ---- */
esp_err_t settings_set_box2(uint8_t pos, uint8_t dir, uint32_t move_iv)
{
    if (pos > SETT_BOX_POS_RIGHT || dir > SETT_BOX_DIR_VERT) return ESP_ERR_INVALID_ARG;
    switch (move_iv) {
    case SETT_BOX_MV_OFF: case SETT_BOX_MV_1H: case SETT_BOX_MV_6H:
    case SETT_BOX_MV_12H: case SETT_BOX_MV_1D:
        break;
    default:
        return ESP_ERR_INVALID_ARG;
    }
    s_cfg.box_pos = pos;
    s_cfg.box_dir = dir;
    s_cfg.box_move_iv = move_iv;
    store_u8("bpos", pos);
    store_u8("bdir", dir);
    store_u32("bmv", move_iv);
    settings_commit();
    return ESP_OK;
}

/* ---- R2.4.0：自定义控件布局 blob（hex 串落 NVS；全 0 = 清除键） ---- */
esp_err_t settings_set_box_wg(const uint8_t *blob)
{
    char hex[SETT_BOX_WG_BYTES * 2 + 1];
    bool all0 = true;
    for (int i = 0; i < SETT_BOX_WG_BYTES; i++) {
        if (blob[i]) all0 = false;
        snprintf(hex + 2 * i, 3, "%02x", blob[i]);
    }
    if (all0) {
        memset(s_cfg.box_wg, 0, sizeof(s_cfg.box_wg));
        if (s_ok) (void)nvs_erase_key(s_nvs, "boxwg");
        settings_commit();
        return ESP_OK;
    }
    memcpy(s_cfg.box_wg, blob, SETT_BOX_WG_BYTES);
    store_str("boxwg", hex);
    settings_commit();
    return ESP_OK;
}

/* ---- R2.1.0：图库自动轮播间隔 ---- */
esp_err_t settings_set_caro_iv(uint8_t iv_min)
{
    switch (iv_min) {
    case SETT_CARO_OFF: case SETT_CARO_1MIN: case SETT_CARO_5MIN:
    case SETT_CARO_10MIN: case SETT_CARO_30MIN: case SETT_CARO_60MIN:
        break;
    default:
        return ESP_ERR_INVALID_ARG;
    }
    s_cfg.caro_iv = iv_min;
    store_u8("caro_iv", iv_min);
    settings_commit();
    return ESP_OK;
}

/* ---- R2.1.0：网络状态检测间隔 ---- */
esp_err_t settings_set_netcheck_iv(uint16_t sec)
{
    if (sec < SETT_NETCHECK_MIN_S || sec > SETT_NETCHECK_MAX_S)
        return ESP_ERR_INVALID_ARG;
    s_cfg.netcheck_iv = sec;
    store_u16("netiv", sec);
    settings_commit();
    return ESP_OK;
}

/* ---- R2.1.0：远端拉取配置 ---- */
esp_err_t settings_set_remote(uint8_t en, const char *host, uint8_t iv_min)
{
    if (en > 1) return ESP_ERR_INVALID_ARG;
    switch (iv_min) {
    case SETT_BOX_IV_1MIN: case SETT_BOX_IV_5MIN: case SETT_BOX_IV_10MIN:
    case SETT_BOX_IV_30MIN: case SETT_BOX_IV_60MIN:
        break;
    default:
        return ESP_ERR_INVALID_ARG;
    }
    if (host) {
        if (strlen(host) >= SETT_REMOTE_HOST_MAX) return ESP_ERR_INVALID_ARG;
        /* 白名单与 init 一致：字母/数字/点/冒号/连字符/下划线/斜杠 */
        for (const char *p = host; *p; p++) {
            char c = *p;
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') ||
                  (c >= 'A' && c <= 'Z') || c == '.' || c == ':' ||
                  c == '-' || c == '_' || c == '/'))
                return ESP_ERR_INVALID_ARG;
        }
        strlcpy(s_cfg.remote_host, host, sizeof(s_cfg.remote_host));
        store_str("rmt_host", s_cfg.remote_host);
    }
    s_cfg.remote_en = en;
    s_cfg.remote_iv = iv_min;
    store_u8("rmt_en", en);
    store_u8("rmt_iv", iv_min);
    settings_commit();
    return ESP_OK;
}

/* ---- R2.2.1：屏幕方向 ---- */
esp_err_t settings_set_orient(uint8_t orient)
{
    if (orient >= SETT_ORIENT_COUNT) return ESP_ERR_INVALID_ARG;
    if (orient == s_cfg.orient) return ESP_OK;      /* 未变不写 flash */
    s_cfg.orient = orient;
    store_u8("orient", orient);
    settings_commit();
    return ESP_OK;
}

uint8_t settings_get_orient(void) { return s_cfg.orient; }

/* ---- R2.1.0：传感器「曾经取到数据」标志 ---- */
bool settings_ble_ever_ok(void) { return s_ble_ever_ok; }

void settings_set_ble_ever_ok(bool ok)
{
    if (ok) {
        if (!s_ble_ever_ok) store_u8("ble_ok", 1);   /* 只在首次置位时写 flash */
        s_ble_ever_ok = true;
    } else {
        store_u8("ble_ok", 0);
        s_ble_ever_ok = false;
    }
}

esp_err_t settings_set_ble(const char *mac, const char *key)
{
    /* mac=NULL 保持不变；空串 = 解绑 */
    if (mac) {
        if (strlen(mac) >= SETT_BLE_MAC_LEN) return ESP_ERR_INVALID_ARG;
        if (mac[0] == '\0') {
            s_cfg.ble_mac[0] = '\0';
            store_str("ble_mac", "");
            settings_set_ble_ever_ok(false);   /* R2.1.0：解绑时清「取到过数据」标志 */
        } else {
            if (strlen(mac) != 12) return ESP_ERR_INVALID_ARG;
            for (int i = 0; i < 12; i++) {
                char c = mac[i];
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
                    return ESP_ERR_INVALID_ARG;
                if (c >= 'a' && c <= 'f') c = (char)(c - 'a' + 'A');
                s_cfg.ble_mac[i] = c;
            }
            s_cfg.ble_mac[12] = '\0';
            store_str("ble_mac", s_cfg.ble_mac);
        }
    }
    /* key=NULL 保持不变；空串 = 清除（只用于加密广播） */
    if (key) {
        if (strlen(key) >= SETT_BLE_KEY_LEN) return ESP_ERR_INVALID_ARG;
        if (key[0] == '\0') {
            s_cfg.ble_key[0] = '\0';
            store_str("ble_key", "");
        } else {
            if (strlen(key) != 32) return ESP_ERR_INVALID_ARG;
            for (int i = 0; i < 32; i++) {
                char c = key[i];
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
                    return ESP_ERR_INVALID_ARG;
                if (c >= 'a' && c <= 'f') c = (char)(c - 'a' + 'A');
                s_cfg.ble_key[i] = c;
            }
            s_cfg.ble_key[32] = '\0';
            store_str("ble_key", s_cfg.ble_key);
        }
    }
    settings_commit();
    return ESP_OK;
}

void settings_factory_reset(void)
{
    /* R1.2.0（FB-015）：整个命名空间一起擦 —— 「恢复出厂」就该回到出厂状态。
       旧实现刻意保留 web_len/web_crc/page_ver（页面热更标记），理由是「页面是
       系统资产」；现在恢复出厂连热更页面一起清掉、回到内嵌页，才是预期行为。 */
    if (s_ok) {
        nvs_erase_all(s_nvs);
        nvs_commit(s_nvs);
    }
    s_cfg = DEFAULTS;
    s_ble_ever_ok = false;              /* R2.1.0：ble_ok 随命名空间一起回默认 */
    ESP_LOGW(TAG, "factory reset: nvs namespace erased");
}

void settings_reset_for_upgrade(void)
{
    /* R1.2.2：升级**不再强制重置设置**，只清理「本版已经不存在、留着会让旧值被
       误读」的废弃键；其余用户设置（屏型 / 翻转 / 功率 / GPIO 接法 / 休眠 / 唤醒 /
       热点凭据）一律原样保留。
       回退到全量重置会误伤真正描述硬件的项：R1.2.0 的重置会让 A1 设备升级后按 A0
       驱动、让排线 / 整合板接线按默认引脚启动，用户升级完得重新配一遍，甚至先看到
       「屏不亮」。 */
    static const char *DROP_KEYS[] = {
        "a1_mode",   /* R1.2.2：A1 只剩 768x552 顺序一档，旧档位值 1..4 已无对应含义 */
        "a11_var",   /* R1.2.0：A1.1 诊断变体整体删除 */
    };

    if (s_ok) {
        for (size_t i = 0; i < sizeof(DROP_KEYS) / sizeof(DROP_KEYS[0]); i++)
            nvs_erase_key(s_nvs, DROP_KEYS[i]);   /* 键不存在时返回 NOT_FOUND，忽略即可 */
        nvs_commit(s_nvs);
    }

    ESP_LOGW(TAG, "upgrade: dropped %u obsolete key(s), settings kept (panel=%u preset=%u)",
             (unsigned)(sizeof(DROP_KEYS) / sizeof(DROP_KEYS[0])),
             (unsigned)s_cfg.panel, (unsigned)s_cfg.gpio_preset);
}
