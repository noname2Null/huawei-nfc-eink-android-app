#include "frame.h"
#include "epd_drv.h"
#include "power.h"
#include "store.h"
#include "overlay.h"
#include "remote.h"       /* R2.1.0：远端拉取（显示源被顶替时通知） */
#include "auth.h"
#include "settings.h"     /* R2.2.1：条带截取/行供数按 settings.orient 选段 */

#include "esp_log.h"
#include "esp_partition.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

static const char *TAG = "frame";

/* ★ R2.0.1 内存架构：整帧不再驻 RAM。
 *
 * WROOM-32 无 PSRAM：开机总堆 ~213KB，且被 WiFi/BT 静态数据切成
 * 111+57+16+14+7KB 多块碎片 —— R2.0.0 的 malloc(EPD_MAX_BUF_LEN=120000)
 * 在 frame_init 必然失败 → abort → 开机重启循环（679ms 就崩，WiFi 任务
 * 从未起过，热点发不出来也是它）。即便缩到 105984 塞进 111KB 块，
 * WiFi(~45KB)+NimBLE(~55KB)+HTTP+mDNS 起来后也必然二次 OOM。
 *
 * 新架构：store 分区槽就是「帧缓存」（128KB/槽 >= 最大合法帧 106000B）：
 *
 *   显示（epd_display_2bpp_wh_src 行回调，逐行）：
 *     原始行 (s_fh-1-r) 从 flash 读出
 *     -> epd_row_mirror = 旧 rotate180 后的「旋转视图行 r」（等价物）
 *     -> overlay_strip_blend 把顶部 40 字节替换成条带（信息框/密码屏）
 *     -> 驱动对行再做一次镜像后写面板：两次镜像抵消，
 *        面板行 j == 原始上传行 j（用户视角正立，与 R2.0.0 行为一致）。
 *
 *   上传：载荷边收边 store_stream_put 写进暂存物理槽（整槽已擦、未置
 *   alive，失败 = 槽保持空）；CRC 过了再 finish（save=1 置 alive 入库 /
 *   无 save 只写帧头当显示源）。掉电时 NVS 位图未置 → 槽视为空，安全。
 *
 *   条带：overlay 的 21KB s_strip 是唯一的 RAM 画布；干净条带随时可从
 *   flash 重截（frame_capture_strip*），不再备份照片副本。
 *
 * 内存代价：行暂存 2x192B + 上传对齐缓冲 1KB + overlay 条带 21KB（原有）。
 */

#define ROW_BYTES   (EPD_A0_W / 4)   /* 192：当前只接受 768 宽几何（epd_frame_geom_ok） */
/* ★ R2.2.1 方向化条带段（以屏幕排线为基准，settings.orient 0..3）：
   每个载荷行里属于"用户画布顶部 160 行信息框条带"的字节段（overlay 吃完整段）：
     orient 0 排线下：行首 40B（字节 0..39），载荷行 0..551（历史行为）；
     orient 2 排线上：行末 40B（字节 152..191），载荷行 0..551；
     orient 1 排线左：整行 192B，载荷行 392..551；
     orient 3 排线右：整行 192B，载荷行 0..159。
   用户条带与载荷的搬移公式在 overlay.c（sim_orient_geom.py 机器证明）。 */
#define STRIP_SEG40   40            /* 竖屏段长 */
#define STRIP_SEG192  ROW_BYTES     /* 横屏段长 */

/* 当前显示源。s_src_phys < 0 = 白底（无图）；否则 = 供行回调流式读的物理槽
   （可能是未置 alive 的暂存槽 —— store 选新暂存槽时会避开它）。
   s_src_split：当前显示源是否为分割式合成（R2.0.3，随帧头 hdr[15] 走）。
   s_src_remote_split：R2.1.0 远端分割子帧源 —— 暂存槽里存的是远端分割式内容
   （每帧行仅【后】152 字节 = 载荷列 160..767 = 用户屏幕第 160..767 行），
   顶部 160 行由本地信息框条带提供（设备自行拼接本地+远端）。 */
static int s_src_phys = -1;
static bool s_src_split = false;
static bool s_src_remote_split = false;
static uint16_t s_fw = EPD_A0_W, s_fh = EPD_A0_H;

/* R2.1.0/2.2.1：远端分割子帧（竖屏方向）每段字节数（192-40；条带让出的字节段）。
   横屏方向（orient 1/3）子帧 = 392 段 x 整行 192B（provider 分支内联处理）。 */
#define REMOTE_SUB_RB 152

static SemaphoreHandle_t s_fb_mutex = NULL;   /* 串行化：显示/上传/清理/源切换 */
static SemaphoreHandle_t s_frame_ready = NULL;

static int frame_slot_source_locked(int slot, bool compose);   /* ★R2.6.0 前向声明 */
static int frame_phys_source_locked(int phys, bool compose);   /* ★R2.6.2 前向声明 */

/* ★R2.6.2：本地显示源变更 → NVS 持久化（store_src_set，跨深睡/掉电）。
 * 只收【本地】源收尾点（均在帧锁内）：上传显示 / 图库切图 / 源失效回落
 * 白底 / boot 恢复。远端提交/恢复【刻意不写】—— 远端有自己的 RTC 恢复链
 * （remote s_rtc + cid），本地恢复侧会拒收远端哑帧槽（hdr[15] bit1），
 * 两侧各自闭环互不污染。 */
static void frame_src_persist(void)
{
    store_src_set(s_src_phys);
}

/* 行供数暂存（全部在帧锁下访问）。 */
static uint8_t s_row_raw[ROW_BYTES];   /* flash 原始行 */
static uint8_t s_row_rot[ROW_BYTES];   /* 旋转视图行（回给驱动） */

/* 上传接收暂存（httpd 任务，帧锁下）。 */
static uint8_t s_upbuf[1024];

/* 条带截取游标（上传流式喂段用，帧锁下）。R2.2.1：段长随方向（40/192）。 */
static int s_cap_have = 0;     /* 当前段已收字节数 */
static int s_cap_segs = 0;     /* 已完成的段数（完成性校验用） */
static uint8_t s_cap_buf[ROW_BYTES];

/* CRC-16/CCITT-FALSE：poly 0x1021，init 0xFFFF，无反射、无终异或。 */
static uint16_t crc16_update(uint16_t crc, const uint8_t *d, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        crc ^= (uint16_t)d[i] << 8;
        for (int b = 0; b < 8; b++) {
            crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021)
                                 : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

void frame_init(void)
{
    s_fb_mutex = xSemaphoreCreateMutex();
    s_frame_ready = xSemaphoreCreateBinary();
    s_src_phys = -1;                       /* 初始显示源 = 纯白 */
    s_fw = epd_profile()->w;
    s_fh = epd_profile()->h;
    overlay_strip_fill_white();            /* R2.0.0 语义保留：白底（2bpp 白 = 0b01） */
    ESP_LOGI(TAG, "streaming frame ready (no RAM framebuffer, source white %ux%u)",
             (unsigned)s_fw, (unsigned)s_fh);
}

void frame_wait(void)
{
    xSemaphoreTake(s_frame_ready, portMAX_DELAY);
}

/* ---------------- 帧锁 ---------------- */

static uint32_t s_lock_fail_streak = 0;   /* ★R2.7.1：连续拿锁失败计数 */

bool frame_lock(uint32_t timeout_ms)
{
    if (!s_fb_mutex) return false;
    TickType_t t = (timeout_ms == (uint32_t)portMAX_DELAY)
                   ? portMAX_DELAY : pdMS_TO_TICKS(timeout_ms);
    bool ok = xSemaphoreTake(s_fb_mutex, t) == pdTRUE;
    /* ★R2.7.1：连续拿锁失败计数 + 错误日志 —— 5s 都拿不到锁 = 刷屏路径
       互卡（TWDT 风险），不再静默吞掉（悬空态由各调用方的 forget 兜底）。 */
    if (ok) {
        s_lock_fail_streak = 0;
    } else {
        s_lock_fail_streak++;
        ESP_LOGE(TAG, "frame lock timeout %ums (streak %u)",
                 (unsigned)timeout_ms, (unsigned)s_lock_fail_streak);
    }
    return ok;
}

void frame_unlock(void)
{
    if (s_fb_mutex) xSemaphoreGive(s_fb_mutex);
}

/* ---------------- 条带截取 ---------------- */

/* 从 phys 槽的原始载荷逐行重截干净条带（须持帧锁）。
   原始行 r 的【首】40 字节（字节 0..39 = 载荷列 0..159 = 用户屏幕顶部 160 行，
   R2.0.3 修正）-> overlay_strip_capture_row（镜像搬移在 overlay.c）。 */
static bool frame_capture_strip_phys(int phys, uint16_t w, uint16_t h)
{
    const esp_partition_t *sp = store_part();
    if (!sp || phys < 0) return false;
    int rb = w / 4;
    /* R2.4.0：区化截取 —— 区可位于上/下/左/右任意边或自定义包围盒，
       载荷行足迹由 overlay（zone_core）给出；逐行读完整 192B 行喂入。 */
    int r0 = 0, r1 = (int)h;
    overlay_capture_row_range(&r0, &r1);
    if (r1 > (int)h) r1 = (int)h;
    uint8_t line[ROW_BYTES];
    for (int r = r0; r < r1; r++) {
        uint32_t off = (uint32_t)phys * STORE_SLOT_SZ + 16u +
                       (uint32_t)r * (uint32_t)rb;
        if (esp_partition_read(sp, off, line, (size_t)rb) != ESP_OK) {
            ESP_LOGE(TAG, "strip capture: read phys %d row %d failed", phys, r);
            return false;
        }
        overlay_payload_capture_row(r, line);
    }
    overlay_strip_capture_done();
    return true;
}

bool frame_capture_strip_locked(void)
{
    /* R2.1.0：远端分割子帧不含顶部 160 行 —— 那是本地信息框的地盘，纯白。 */
    if (s_src_remote_split) {
        overlay_strip_fill_white();
        return true;
    }
    if (s_src_phys < 0) {
        overlay_strip_fill_white();
        return true;
    }
    if (!frame_capture_strip_phys(s_src_phys, s_fw, s_fh)) {
        ESP_LOGW(TAG, "strip recapture failed (phys %d), fallback white", s_src_phys);
        overlay_strip_fill_white();
        return false;
    }
    return true;
}

bool frame_capture_strip(void)
{
    if (!frame_lock(5000)) return false;
    bool ok = frame_capture_strip_locked();
    frame_unlock();
    return ok;
}

/* ---------------- 显示（行供数回调） ---------------- */

/* 供出「旋转视图行 r」（= 旧 rotate180 后缓冲行 r 的等价物）：
   flash 原始行 (s_fh-1-r) 镜像而来，顶部 40 字节由 overlay 条带替换。
   R2.1.0：远端分割子帧源读每行的【后】152 字节（镜像后落在旋转行 0..151），
   旋转行 152..191 仍由条带替换（= 本地信息框）。
 * ★R2.6.0 换位让位：框在「下」且分割式源时照片整体上移 160 用户行 ——
 *   横屏方向（o1/o3）换行号（o1 读段 pr-160 / o3 读段 pr，框区行整行白），
 *   竖屏方向（o0/o2）行号不变（字节平移在 overlay_strip_blend 里做）。
 *   对拍：scripts/test_shift_geom.c。 */
static const uint8_t *frame_row_provider(int r)
{
    int rb = s_fw / 4;
    const bool shift = overlay_photo_shift_active();   /* ★R2.6.0 */
    if (r < 0 || r >= s_fh || rb > (int)sizeof(s_row_rot) ||
        s_src_phys < 0 || !store_part()) {
        memset(s_row_rot, 0x55, sizeof(s_row_rot));   /* 白底 / 防御：越界行 */
    } else if (s_src_remote_split) {
        /* R2.2.1：远端分割子帧按方向布局（sim_orient_geom.py 证明，与 PC 工具
           打包逐字节一致）。暂存槽里子帧按载荷行序连续存放：
             o0：552 段 x 152B（载荷行字节 40..191），provider 行 r 读段 551-r；
             o2：552 段 x 152B（载荷行字节 0..151），provider 行 r 读段 551-r；
             o1：392 段 x 192B（载荷行 0..391 整行），provider 行 r 读段 551-r；
             o3：392 段 x 192B（载荷行 160..551 整行），provider 行 r 读段 551-r-160。 */
        const uint8_t o = settings_get()->orient;
        int pr = s_fh - 1 - r;                       /* 本行对应的载荷行号 */
        if (o == 0 || o == 2) {
            uint32_t off = (uint32_t)s_src_phys * STORE_SLOT_SZ + 16u +
                           (uint32_t)pr * REMOTE_SUB_RB;
            if (esp_partition_read(store_part(), off, s_row_raw, REMOTE_SUB_RB) != ESP_OK) {
                ESP_LOGE(TAG, "remote sub-row %d flash read failed, white", r);
                memset(s_row_raw, 0x55, REMOTE_SUB_RB);
            }
            epd_row_mirror(s_row_rot, s_row_raw, REMOTE_SUB_RB);
            if (o == 0)
                memset(s_row_rot + REMOTE_SUB_RB, 0x55, ROW_BYTES - REMOTE_SUB_RB);
            else {          /* o2：镜像结果落在 provider 字节 40..191，0..39 留给条带 */
                memmove(s_row_rot + 40, s_row_rot, REMOTE_SUB_RB);
                memset(s_row_rot, 0x55, 40);
            }
        } else {
            int sub_rows = (int)s_fh - 160;          /* 392 */
            /* ★R2.6.0 换位让位：o1 读段 pr-160 / o3 读段 pr（未让位时
               o1 段 pr / o3 段 pr-160，正好互换）；段号越界 = 框区行
               整行白（blend 整行覆盖）。 */
            int srow = (o == 1) ? (shift ? (pr - 160) : pr)
                                : (shift ? pr : (pr - 160));
            if (srow >= 0 && srow < sub_rows) {
                uint32_t off = (uint32_t)s_src_phys * STORE_SLOT_SZ + 16u +
                               (uint32_t)srow * (uint32_t)ROW_BYTES;
                if (esp_partition_read(store_part(), off, s_row_raw, ROW_BYTES) != ESP_OK) {
                    ESP_LOGE(TAG, "remote sub-row %d flash read failed, white", r);
                    memset(s_row_raw, 0x55, ROW_BYTES);
                }
                epd_row_mirror(s_row_rot, s_row_raw, ROW_BYTES);
            } else {
                memset(s_row_rot, 0x55, ROW_BYTES);  /* 条带区行：blend 整行覆盖 */
            }
        }
    } else {
        /* ★R2.6.0 换位让位：横屏方向换行号（overlay_photo_shift_row 内
           o1: 391-r / o3: 711-r；框区行返回 -1 整行白）；竖屏方向行号
           不变（字节平移在 blend 侧）。 */
        int pr = s_fh - 1 - r;
        if (shift) {
            pr = overlay_photo_shift_row(r, pr);
            if (pr < 0) {
                memset(s_row_rot, 0x55, sizeof(s_row_rot));
                overlay_strip_blend(s_row_rot, r);
                return s_row_rot;
            }
        }
        uint32_t off = (uint32_t)s_src_phys * STORE_SLOT_SZ + 16u +
                       (uint32_t)pr * (uint32_t)rb;
        if (esp_partition_read(store_part(), off, s_row_raw, (size_t)rb) != ESP_OK) {
            ESP_LOGE(TAG, "row %d flash read failed, white fallback", r);
            memset(s_row_raw, 0x55, sizeof(s_row_raw));
        }
        epd_row_mirror(s_row_rot, s_row_raw, rb);
    }
    overlay_strip_blend(s_row_rot, r);
    return s_row_rot;
}

int frame_display_locked(void)
{
    int r = epd_display_2bpp_wh_src(s_fw, s_fh, frame_row_provider);
    if (r == 0) epd_panel_deep_sleep();
    return r;
}

int frame_display_now(void)
{
    if (!frame_lock((uint32_t)portMAX_DELAY)) return -1;
    int r = frame_display_locked();
    frame_unlock();
    return r;
}

/* R2.0.0：图库非空时启动恢复当前槽 —— 电子纸断电后仍保留旧画面，但「帧」
 * 已不在 RAM；从 store 分区把当前槽整屏刷回（条带随之重建），掉电后照样可刷。
 * ★R2.6.0：only_source 档 —— 只恢复显示源 + 条带（不刷屏）。深睡事件
 * 唤醒且面板已显示该槽时用：首屏交给分钟调度/补刷（快刷基准已从 RTC
 * 恢复则局刷，否则按需整刷），免去每次唤醒的无条件整刷闪屏。
 * ★R2.6.2：恢复优先级改为【持久化显示源 → 图库 cur → 白底】。
 *   「上传并刷新屏幕」（无 save）的画面在暂存槽里，但源指针原先只在
 *   RAM：深睡唤醒后这里只认图库 cur，暂存画面挂在面板上（墨水屏保持），
 *   直到某次整刷从丢失的源重画 → 照片区被图库旧图/白底顶替（实测
 *   「上传的图某次全局刷新后变成空白」）。暂存槽内容本就在 flash ——
 *   先试 NVS 持久化的源指针（store_src_get），槽头校验不过再回落图库。 */
void frame_boot_restore_source(void)
{
    /* 持帧锁：boot 门控跑在独立任务，display_task / frame_task 已在跑
       （双击切图等事件可与本恢复并发）。 */
    if (!frame_lock(5000)) {
        ESP_LOGW(TAG, "boot source restore: lock timeout");
        return;
    }

    const int saved = store_src_get();
    if (saved >= 0) {
        if (frame_phys_source_locked(saved, false) == 0) {
            ESP_LOGI(TAG, "boot source restore: saved phys %d", saved);
            frame_unlock();
            return;
        }
        ESP_LOGW(TAG, "boot source restore: saved phys %d invalid, fallback gallery",
                 saved);
    }

    int count = 0, cur = 0;
    store_meta_get(&count, &cur);
    if (count <= 0) {
        overlay_strip_fill_white();
        frame_src_persist();      /* ★R2.6.2：失效的持久化源一并清掉 */
        frame_unlock();
        return;
    }
    if (frame_slot_source_locked(cur, false) != 0) {
        ESP_LOGW(TAG, "boot source restore: slot %d bad, fallback white", cur);
        s_src_phys = -1;
        s_src_split = false;
        overlay_set_photo_split(false);
        overlay_strip_fill_white();
        frame_src_persist();      /* ★R2.6.2 */
    }
    frame_unlock();
}

void frame_boot_restore(void)
{
    int count = 0, cur = 0;
    store_meta_get(&count, &cur);

    /* ★R2.6.2：持久化显示源优先 —— 无 save 上传的暂存槽也是合法首屏源
       （图库 cur 只是它的子集：save=1 上传后两者一致）。 */
    const int saved = store_src_get();
    if (saved >= 0) {
        if (frame_lock(5000)) {
            int r = frame_phys_source_locked(saved, true);
            if (r == 0) r = frame_display_locked();
            frame_unlock();
            if (r == 0) {
                ESP_LOGI(TAG, "boot restore: saved source phys %d", saved);
                return;
            }
        }
        ESP_LOGW(TAG, "boot restore: saved phys %d invalid, fallback gallery", saved);
    }

    if (count <= 0) {
        ESP_LOGI(TAG, "boot restore: carousel empty, keep white frame");
        overlay_strip_fill_white();
        return;
    }
    ESP_LOGI(TAG, "boot restore: slot %d (count %d)", cur, count);
    if (frame_display_slot(cur) != 0) {
        ESP_LOGW(TAG, "boot restore: slot %d bad, fallback white", cur);
        overlay_strip_fill_white();
    }
}

/* R1.0.8：残影清理与显示/传图共用同一 SPI 与行缓冲，必须持同一把锁。 */
int frame_clear_cycles(int cycles)
{
    if (!frame_lock((uint32_t)portMAX_DELAY)) return -1;
    int r = epd_clear_cycles(cycles);
    frame_unlock();
    if (r == 0) {
        power_activity();
        /* ★R2.6.0：清理把整屏洗成纯色 —— 面板框区真值未知，快刷基准
           （含 RTC 持久化）作废，下一个到点刷新回退整刷。 */
        overlay_box_basis_forget();
    }
    return r;
}

/* ---------------- 上传 ---------------- */

/* 排空请求体剩余 n 字节（图库满等早退场景）：应答前把 socket 收干净，
   避免同一 keep-alive 连接上的下一个请求错位。 */
static void frame_drain_body(httpd_req_t *req, uint32_t n)
{
    int waits = 0;
    while (n) {
        uint32_t k = n > sizeof(s_upbuf) ? (uint32_t)sizeof(s_upbuf) : n;
        int r = httpd_req_recv(req, (char *)s_upbuf, (size_t)k);
        if (r > 0) { n -= (uint32_t)r; waits = 0; continue; }
        if (r == 0) {                       /* recv 超时：客户端慢传，稍候 */
            if (++waits > 500) break;
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        break;                              /* 连接断开：不用再排 */
    }
}

/* R2.2.1 上传流式条带截取：载荷按行序到达，按方向把属于条带的字节段
   （文件头注释表：o0 行首 40B / o2 行末 40B / o1 行 392..551 整行 /
    o3 行 0..159 整行）攒成完整段喂给 overlay。段内字节在载荷里连续，
   顺序流保证单调收满。 */
static void strip_cap_feed(uint32_t off, const uint8_t *d, uint32_t n, uint32_t rb)
{
    int r_lo = 0, r_hi = 552;
    overlay_capture_row_range(&r_lo, &r_hi);

    while (n--) {
        uint32_t row = off / rb;
        if ((int)row >= r_lo && (int)row < r_hi) {
            s_cap_buf[s_cap_have++] = *d;
            if (s_cap_have >= (int)rb) {
                overlay_payload_capture_row((int)row, s_cap_buf);
                s_cap_segs++;
                s_cap_have = 0;
            }
        }
        off++;
        d++;
    }
}

/* 上传作废后还原条带（须持帧锁）。
   角落场景：暂存槽原地复用了当前显示源（唯一空位时 store 允许）——
   那张预览已被覆盖写坏，无处可截，回退白底；否则从原显示源重截。 */
static void upload_recover_strip(int phys)
{
    if (s_src_phys == phys) {
        s_src_phys = -1;
        s_src_split = false;
        overlay_strip_fill_white();
        frame_src_persist();    /* ★R2.6.2：源被原地复用写坏 → 白底，同步持久化 */
        ESP_LOGW(TAG, "display source was the reused staging slot, fall back white");
    } else {
        frame_capture_strip_locked();
    }
    /* R2.0.3：还原后把信息框立即画回条带（否则到点重画前刷屏都是无框照片）。 */
    overlay_set_photo_split(s_src_split);
    overlay_box_compose_strip();
}

esp_err_t frame_upload_handler(httpd_req_t *req)
{
    power_activity();   /* R1.0.8：上传期间不许空闲休眠 */
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    /* 先按最大合法载荷粗筛（A1 原生 800x600 = 120000），细筛在读头后
       按 hdr 里的宽高做（几何最终由 epd_frame_geom_ok 收口）。 */
    if (req->content_len < (int)(FRAME_HDR_LEN + 1) ||
        req->content_len > (int)(FRAME_HDR_LEN + EPD_MAX_BUF_LEN +
                                 16 + STORE_THUMB_JPEG_MAX)) {
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "size mismatch");
    }

    uint8_t hdr[FRAME_HDR_LEN];
    /* httpd_req_recv 单次不保证收满（TCP 分段会短读），必须循环收满 16 字节 */
    size_t got = 0;
    while (got < FRAME_HDR_LEN) {
        int n = httpd_req_recv(req, (char *)(hdr + got), FRAME_HDR_LEN - got);
        if (n <= 0) {
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad header");
        }
        got += (size_t)n;
    }

    if (hdr[0] != FRAME_MAGIC0 || hdr[1] != FRAME_MAGIC1)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad magic");
    if (hdr[2] != FRAME_FMT_VERSION && hdr[2] != FRAME_FMT_VERSION_NATIVE)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad version");

    uint16_t width  = (uint16_t)((hdr[4] << 8) | hdr[5]);
    uint16_t height = (uint16_t)((hdr[6] << 8) | hdr[7]);
    uint32_t len    = ((uint32_t)hdr[8] << 24) | ((uint32_t)hdr[9] << 16) |
                      ((uint32_t)hdr[10] << 8) | hdr[11];
    uint16_t crc_hdr = (uint16_t)((hdr[12] << 8) | hdr[13]);

    /* 载荷长度必须与几何自洽（4 像素/字节），且被当前画像接受。 */
    if ((width & 3) || len != (uint32_t)(width / 4) * (uint32_t)height)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "len mismatch");
    if (!epd_frame_geom_ok(width, height, len))
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "unsupported geometry");
    if (req->content_len != (int)(FRAME_HDR_LEN + len) &&
        (req->content_len <= (int)(FRAME_HDR_LEN + len) ||
         req->content_len > (int)(FRAME_HDR_LEN + len + 16 +
                                  STORE_THUMB_JPEG_MAX)))
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "size mismatch");

    /* 面板类型字段（hdr[3]）仅信息性；实际面板由设置决定，不随帧切换。 */

    if (!frame_lock(5000)) {
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "busy");
    }

    /* R1.3.0 轮播：query 参数
       save=1           存槽并显示
       save=1&noshow=1  只存不显示（批量上传前几张，避免逐张刷屏）
       无 save           只显示不存（写入暂存槽当显示源，不入图库）
       split=1          R2.0.3 分割式合成（页面样式=分割时附带：照片让出顶部
                        信息框区、框底纯白；标记随帧头 hdr[15] 按张携带）
       tlen=<N>         R1.3.2 缩略载荷长（网页离线预生成，随帧上传，
                        body = 帧头+帧载荷+缩略头+缩略载荷）
       ★R2.1.0：query 提前到暂存前解析 —— save=1 且图库已满（含远端预留槽）
       时立刻 507，不再白传整帧后才发现存不下。 */
    bool want_save = false, want_show = true, want_split = false;
    uint32_t tlen = 0;
    int qlen = httpd_req_get_url_query_len(req);
    if (qlen > 0 && qlen < 64) {
        char qbuf[64], vbuf[8];
        if (httpd_req_get_url_query_str(req, qbuf, sizeof(qbuf)) == ESP_OK) {
            if (httpd_query_key_value(qbuf, "save", vbuf, sizeof(vbuf)) == ESP_OK &&
                strcmp(vbuf, "1") == 0) {
                want_save = true;
                if (httpd_query_key_value(qbuf, "noshow", vbuf, sizeof(vbuf)) == ESP_OK &&
                    strcmp(vbuf, "1") == 0)
                    want_show = false;
            }
            if (httpd_query_key_value(qbuf, "split", vbuf, sizeof(vbuf)) == ESP_OK &&
                strcmp(vbuf, "1") == 0)
                want_split = true;
            if (httpd_query_key_value(qbuf, "tlen", vbuf, sizeof(vbuf)) == ESP_OK) {
                long tl = atol(vbuf);
                /* R1.3.4 修复：上限用 STORE_THUMB_JPEG_MAX（彩色 JPEG 可达 ~15KB） */
                if (tl > 0 && tl <= (long)STORE_THUMB_JPEG_MAX) tlen = (uint32_t)tl;
            }
        }
    }
    if (want_save && store_free_gallery() <= 0) {
        frame_drain_body(req, (uint32_t)(req->content_len - (int)FRAME_HDR_LEN));
        frame_unlock();
        return httpd_resp_send_err(req, 507,
            "carousel full: delete one first (remote pull reserves a staging slot)");
    }

    /* ★ R2.0.1：载荷不进 RAM —— 边收边写进暂存物理槽（整槽已擦、未置
       alive）。当前显示源槽由 store 选槽时避开（防止边显示边覆盖）。 */
    int phys = store_stream_begin(s_src_phys);
    if (phys == STORE_ERR_FULL) {
        frame_drain_body(req, (uint32_t)(req->content_len - (int)FRAME_HDR_LEN));
        frame_unlock();
        return httpd_resp_send_err(req, 507,
                                   "carousel full: delete or clear first");
    }
    if (phys < 0) {
        frame_unlock();
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                                   "store off");
    }

    /* 条带截取游标复位（载荷按行序到达，段长随方向）。 */
    s_cap_have = 0;
    s_cap_segs = 0;

    uint32_t off = 0;
    uint16_t crc = 0xFFFF;
    int err = 0;
    int f_waits = 0;
    while (off < len) {
        uint32_t want = len - off;
        if (want > sizeof(s_upbuf)) want = (uint32_t)sizeof(s_upbuf);
        int n = httpd_req_recv(req, (char *)s_upbuf, (size_t)want);
        if (n > 0) {
            power_activity();   /* R1.0.8：传输中途不许空闲休眠 */
            crc = crc16_update(crc, s_upbuf, (size_t)n);
            strip_cap_feed(off, s_upbuf, (uint32_t)n, (uint32_t)(width / 4));
            if (store_stream_put(s_upbuf, (uint32_t)n) != 0) { err = -2; break; }
            off += (uint32_t)n;
            f_waits = 0;
            continue;
        }
        if (n == 0) {                    /* recv 超时：慢传等待重试 */
            if (++f_waits > 500) { err = -1; break; }
            vTaskDelay(pdMS_TO_TICKS(10));
            continue;
        }
        err = -1;
        break;
    }

    /* 校验失败：暂存槽作废（不置 alive = 空槽），条带还原为当前显示源。 */
    /* R2.2.1：完成性校验改按段数（方向决定段数：竖屏 552 段 / 横屏 160 段）。 */
    if (err != 0 || off != len || crc != crc_hdr ||
        s_cap_segs != overlay_strip_capture_segs() || s_cap_have != 0) {
        store_stream_abort();
        upload_recover_strip(phys);
        frame_unlock();
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                   err ? "body truncated" : "CRC mismatch");
    }
    overlay_strip_capture_done();   /* 条带 = 新照片干净条带（未画信息框） */

    ESP_LOGI(TAG, "frame accepted: %ux%u (%lu bytes), CRC ok -> staging phys %d",
             width, height, (unsigned long)len, phys);

    /* R2.0.3：分割式标记写进帧头（存槽 / 暂存槽都带）：hdr[14]=0xA5 表示
       hdr[15] 有效；hdr[15] bit0 = 1 = 分割式。旧槽无标记 → 按叠加式处理。
       CRC 只覆盖载荷，改头不影响校验；切图 / 开机恢复时由此重建 overlay 状态。 */
    hdr[14] = 0xA5;
    hdr[15] = want_split ? 0x01 : 0x00;

    /* 精确校验：body 长度必须等于 帧头+帧载荷 [+缩略头+缩略载荷] */
    if (want_save && tlen &&
        (uint32_t)req->content_len != (uint32_t)(FRAME_HDR_LEN + len) + 16u + tlen) {
        store_stream_abort();
        upload_recover_strip(phys);
        frame_unlock();
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "size mismatch");
    }

    if (want_save) {
        uint8_t *thumb = NULL;
        if (tlen) {
            /* 收缩略数据：16B 缩略头（同构帧头，magic 0xA5 0x5A）+ tlen 载荷。
               CRC 字段前端填 0，固件不校验；几何按头内字段自洽。 */
            uint8_t thdr[16];
            size_t tg = 0;
            int tg_waits = 0;
            while (tg < sizeof(thdr)) {
                int n = httpd_req_recv(req, (char *)(thdr + tg),
                                       sizeof(thdr) - tg);
                if (n > 0) { tg += (size_t)n; tg_waits = 0; continue; }
                if (n == 0) {            /* recv 超时：WiFi 慢传，短暂等待重试 */
                    if (++tg_waits > 100) break;
                    vTaskDelay(pdMS_TO_TICKS(10));
                    continue;
                }
                break;
            }
            uint32_t tw = ((uint32_t)thdr[4] << 8) | thdr[5];
            uint32_t th = ((uint32_t)thdr[6] << 8) | thdr[7];
            uint32_t tl = ((uint32_t)thdr[8] << 24) | ((uint32_t)thdr[9] << 16) |
                          ((uint32_t)thdr[10] << 8) | thdr[11];
            /* fmt=1 2bit 缩略：几何须 4 的倍数且载荷自洽；
               fmt=2 彩色 JPEG：仅校验长度（JPEG 无几何约束） */
            int geom_ok = (thdr[2] == 1) ?
                          (tw != 0 && !(tw & 3) && tl == (tw / 4u) * th) :
                          (thdr[2] == 2);
            if (tg != sizeof(thdr) || thdr[0] != 0xA5 || thdr[1] != 0x5A ||
                !geom_ok || tl != tlen ||
                tl > (uint32_t)((thdr[2] == 2) ? STORE_THUMB_JPEG_MAX
                                                : STORE_THUMB_LEN)) {
                ESP_LOGW(TAG, "bad thumb: got=%u magic=%02X%02X fmt=%u "
                         "w=%lu h=%lu tl=%lu tlen=%lu", (unsigned)tg,
                         thdr[0], thdr[1], thdr[2], (unsigned long)tw,
                         (unsigned long)th, (unsigned long)tl,
                         (unsigned long)tlen);
                store_stream_abort();      /* R2.0.0 此路径曾漏放帧锁，一并修复 */
                upload_recover_strip(phys);
                frame_unlock();
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                           "bad thumb");
            }
            thumb = malloc(16u + tlen);
            if (!thumb) {
                store_stream_abort();
                upload_recover_strip(phys);
                frame_unlock();
                return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                                           "oom");
            }
            memcpy(thumb, thdr, 16);
            size_t to = 0;
            int to_waits = 0;
            while (to < tlen) {
                int n = httpd_req_recv(req, (char *)(thumb + 16 + to),
                                       tlen - to);
                if (n > 0) { to += (size_t)n; to_waits = 0; continue; }
                if (n == 0) {
                    if (++to_waits > 100) break;
                    vTaskDelay(pdMS_TO_TICKS(10));
                    continue;
                }
                break;
            }
            if (to != tlen) {
                ESP_LOGW(TAG, "thumb truncated: got=%u want=%lu",
                         (unsigned)to, (unsigned long)tlen);
                free(thumb);
                store_stream_abort();
                upload_recover_strip(phys);
                frame_unlock();
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                           "thumb truncated");
            }
        }
        int slot = store_stream_finish_save(hdr, thumb, tlen);
        free(thumb);
        if (slot == STORE_ERR_FULL) {      /* 理论不可达（begin 已查满） */
            upload_recover_strip(phys);
            frame_unlock();
            return httpd_resp_send_err(req, 507,
                                       "carousel full: delete or clear first");
        }
        if (slot < 0) {
            ESP_LOGW(TAG, "carousel save failed (flash/NVS?)");
            upload_recover_strip(phys);
            frame_unlock();
            return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                                       "save failed");
        }
        ESP_LOGI(TAG, "carousel: saved to slot %d%s", slot,
                 tlen ? " (with thumb)" : "");
    } else {
        /* 无 save：不入图库（不置 alive），帧头写进暂存槽当显示源。 */
        if (store_stream_finish_nosave(hdr) != 0) {
            upload_recover_strip(phys);
            frame_unlock();
            return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                                       "staging failed");
        }
        ESP_LOGI(TAG, "staged to phys %d (not in carousel)", phys);
    }

    /* 排空未消费的剩余请求体（如无 save 却带了缩略），保 keep-alive 干净。 */
    {
        int consumed = (int)(FRAME_HDR_LEN + len) +
                       ((want_save && tlen) ? (int)(16u + tlen) : 0);
        int leftover = req->content_len - consumed;
        if (leftover > 0) frame_drain_body(req, (uint32_t)leftover);
    }

    if (want_show) {
        s_src_phys = phys;      /* 显示源 = 刚写入的暂存/图库槽 */
        s_fw = width;
        s_fh = height;
        s_src_split = want_split;
        s_src_remote_split = false;         /* R2.1.0：手动上传接管显示，退出远端样式 */
        overlay_set_remote(false, false);
        remote_notify_override();            /* 下一轮拉取同 cid 也要重新上屏 */
        overlay_set_photo_split(want_split);
        frame_src_persist();                /* ★R2.6.2：无 save 暂存槽也要跨深睡存活 */
        /* R2.0.3：上传即画框 —— 旧版只截干净条带，刷出来的是无框照片，
           要等下一次到点重画才有框（"上传后框内空白"就是它）。 */
        overlay_box_compose_strip();
    } else {
        /* 只存不显示：显示源不动，条带还原为当前源（截取的是新照片的）。 */
        upload_recover_strip(phys);
    }
    frame_unlock();
    if (want_show) xSemaphoreGive(s_frame_ready); /* 唤醒显示任务 */

    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_sendstr(req, "OK");
}

/* R1.3.0 轮播切图：校验 store 槽 -> 重截条带 -> 整屏显示。
   与传图 / 残影清理共用帧锁，显示后送面板深睡。
   R2.1.0：拆出锁内实现 frame_display_slot_locked（远端回落复用），
   切图接管显示时退出远端样式。
   ★R2.6.0：再拆「只恢复源」层 frame_slot_source_locked —— 深睡事件唤醒
   的免整刷路径用（面板已显示同内容，只需让固件重新知道「显示源是谁」，
   首屏交给分钟调度/补刷：快刷或按需整刷）。compose=false 供该路径：
   不把当前时间的信息框合进条带（那会让快刷基准领先面板一帧 —— 面板
   显示的还是睡前那一帧，基准应从 RTC 恢复而不是重算）。
   ★R2.6.2：再拆「物理槽」层 frame_phys_source_locked —— 持久化显示源
   指向的是未置 alive 的暂存槽（无逻辑序号），恢复只能走物理槽；它比
   逻辑槽版多拒一道【远端哑帧】（hdr[15] bit1：远端行布局 152B/行，
   按本地 192B 截条带会读串行；远端源由 remote 的 RTC 链自己恢复）。
   成功后源指针写 NVS（store_src_set）—— 图库切图 / boot 回落都在这里收口。 */
static int frame_phys_source_locked(int phys, bool compose)
{
    const esp_partition_t *sp = store_part();
    uint8_t hdr[16];
    if (phys < 0 || !sp ||
        esp_partition_read(sp, (uint32_t)phys * STORE_SLOT_SZ,
                           hdr, sizeof(hdr)) != ESP_OK ||
        hdr[0] != STORE_MAGIC0 || hdr[1] != STORE_MAGIC1 ||
        (hdr[14] == 0xA5 && (hdr[15] & 0x02))) {   /* ★R2.6.2：远端哑帧拒收 */
        return -1;
    }
    uint16_t w = (uint16_t)((hdr[4] << 8) | hdr[5]);
    uint16_t h = (uint16_t)((hdr[6] << 8) | hdr[7]);
    uint32_t len = ((uint32_t)hdr[8] << 24) | ((uint32_t)hdr[9] << 16) |
                   ((uint32_t)hdr[10] << 8) | hdr[11];
    if (!epd_frame_geom_ok(w, h, len)) {
        return -1;
    }

    /* 重截该槽干净条带（信息框据此可随时重建；掉电防护同 R2.0.0 语义）。
       R2.0.3：帧头携带的分割式标记同步给 overlay（旧槽无标记 = 叠加式）。 */
    s_src_split = (hdr[14] == 0xA5) && (hdr[15] & 1);
    if (!frame_capture_strip_phys(phys, w, h)) {
        return -1;
    }
    s_src_phys = phys;
    s_fw = w;
    s_fh = h;
    s_src_remote_split = false;         /* R2.1.0：图库接管显示，退出远端样式 */
    overlay_set_remote(false, false);
    remote_notify_override();           /* 图库上屏 = 远端内容被顶替（回落路径也无害） */
    overlay_set_photo_split(s_src_split);
    if (compose) overlay_box_compose_strip();
    frame_src_persist();                /* ★R2.6.2：源变更落盘（幂等） */
    return 0;
}

static int frame_slot_source_locked(int slot, bool compose)
{
    return frame_phys_source_locked(store_slot_phys(slot), compose);
}

static int frame_display_slot_locked(int slot)
{
    if (frame_slot_source_locked(slot, true) != 0) return -1;
    return frame_display_locked();
}

int frame_display_slot(int slot)
{
    if (!frame_lock(5000)) return -1;
    int r = frame_display_slot_locked(slot);
    frame_unlock();
    return r;
}

/* ---------------- R2.1.0 远端内容显示源 ----------------
 *
 * 远端帧与上传同一套暂存槽机制（不占整帧 RAM）：拉取流边收边写进空槽，
 * 校验过了才提交为显示源。与上传的区别只在「谁来收数据」—— remote.c 的
 * HTTP 客户端而非 httpd。
 *
 * 分割式（split）：远端只发每载荷行的【后】152 字节（= 用户屏幕 160..767 行），
 * 顶部 160 行由本地信息框提供（frame_row_provider 的 remote_split 分支 +
 * overlay 条带拼接）。全屏式（off）：与普通帧完全同构（192 字节/行）。 */

int frame_src_phys(void)
{
    return s_src_phys;
}

bool frame_src_remote_split(void)
{
    return s_src_remote_split;
}

/* R2.2.1：当前显示源是否为「分割式合成」（帧头 hdr[15] 按张携带）。
   main.c GEOM_CHANGED 重截条带后同步 overlay 的分割标记用。 */
bool frame_src_split(void)
{
    return s_src_split;
}

int frame_remote_stage_begin(void)
{
    /* 避开当前显示源选空槽。返回值：>=0 新暂存槽；STORE_ERR_FULL(-2) =
       无空位；-1 = 其它失败。若返回的槽 == frame_src_phys()，说明是原地复用
       （图库几乎满时的唯一空位），调用方须在流式写入期间持帧锁。 */
    return store_stream_begin(s_src_phys);
}

/* ★R2.6.0：深睡唤醒后恢复远端显示源（remote_init 调用，不刷屏 ——
 * 面板本来就显示着这帧远端内容）。phys = 睡前远端暂存槽（内容在
 * flash 里跨深睡存活）；split 同远端样式。返回 0 成功；失败时 remote
 * 侧回落「未激活」（首拉重新拉取 + 整刷上屏，与 R2.5 行为一致）。 */
int frame_remote_restore(int phys, bool split)
{
    const esp_partition_t *sp = store_part();
    uint8_t hdr[16];
    if (phys < 0 || !sp ||
        esp_partition_read(sp, (uint32_t)phys * STORE_SLOT_SZ,
                           hdr, sizeof(hdr)) != ESP_OK ||
        hdr[0] != FRAME_MAGIC0 || hdr[1] != FRAME_MAGIC1 ||
        !(hdr[14] == 0xA5 && (hdr[15] & 0x02))) {
        return -1;                              /* 槽头不是远端哑帧：已被复用 */
    }
    uint32_t len = ((uint32_t)hdr[8] << 24) | ((uint32_t)hdr[9] << 16) |
                   ((uint32_t)hdr[10] << 8) | hdr[11];
    if (len == 0 || len > STORE_FRAME_MAX) return -1;

    if (!frame_lock(5000)) return -1;
    s_src_phys = phys;
    s_fw = EPD_A0_W;
    s_fh = EPD_A0_H;
    s_src_split = split;
    s_src_remote_split = split;
    overlay_set_photo_split(split);
    overlay_set_remote(true, split);
    if (split) {
        overlay_strip_fill_white();       /* 顶部 160 行 = 本地信息框区 */
    } else {
        frame_capture_strip_locked();      /* 全屏远端：截顶部条带（密码屏等用） */
    }
    frame_unlock();
    ESP_LOGI(TAG, "remote source restored (phys %d, %s)", phys,
             split ? "split+local box" : "fullscreen");
    return 0;
}

int frame_remote_stage_put(const uint8_t *d, uint32_t n)
{
    return store_stream_put(d, n);
}

void frame_remote_stage_abort(void)
{
    store_stream_abort();
}

/* 提交暂存槽为远端显示源并整屏刷新（★帧锁内调用★）。
 * split=true：子帧布局（152B/行），顶部由本地信息框拼接；
 *             false：全屏帧（192B/行）。返回 0 成功。 */
int frame_remote_commit_locked(int phys, bool split, const uint8_t hdr[16])
{
    if (phys < 0 || !hdr) return -1;
    if (store_stream_finish_nosave(hdr) != 0) return -1;

    s_src_phys = phys;
    s_fw = EPD_A0_W;
    s_fh = EPD_A0_H;
    s_src_split = split;
    s_src_remote_split = split;
    overlay_set_photo_split(split);
    overlay_set_remote(true, split);
    if (split) {
        overlay_strip_fill_white();       /* 顶部 160 行 = 本地信息框区 */
    } else {
        frame_capture_strip_locked();      /* 全屏远端：截顶部条带（密码屏等用） */
    }
    overlay_box_compose_strip();           /* split=画框；off=overlay 内部压制 */
    int r = frame_display_locked();
    ESP_LOGI(TAG, "remote frame committed (phys %d, %s)", phys,
             split ? "split+local box" : "fullscreen");
    return r;
}

/* R2.1.0：退出远端显示 —— 清远端标记并回落图库当前槽（图库空则白底），
 * 整屏刷新。远端关闭 / 上电拉取失败后的回退路径。 */
void frame_remote_revert(void)
{
    if (!frame_lock(5000)) {
        /* 锁拿不到也要把标记清了，避免后续条带合成继续按远端处理 */
        s_src_remote_split = false;
        overlay_set_remote(false, false);
        return;
    }
    s_src_remote_split = false;
    overlay_set_remote(false, false);

    int count = 0, cur = 0;
    store_meta_get(&count, &cur);
    if (count > 0) {
        if (frame_display_slot_locked(cur) != 0) {
            ESP_LOGW(TAG, "remote revert: slot %d bad, fallback white", cur);
            s_src_phys = -1;
            s_src_split = false;
            overlay_set_photo_split(false);
            overlay_strip_fill_white();
            frame_src_persist();    /* ★R2.6.2：白底也是源变更，落盘 */
            frame_display_locked();
        }
    } else {
        s_src_phys = -1;
        s_src_split = false;
        overlay_set_photo_split(false);
        overlay_strip_fill_white();
        frame_src_persist();        /* ★R2.6.2 */
        frame_display_locked();
    }
    frame_unlock();
}
