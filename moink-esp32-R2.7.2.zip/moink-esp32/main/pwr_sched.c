/* 事件驱动休眠调度：分钟边界数学（纯 C，见 pwr_sched.h 头注释）。 */
#include "pwr_sched.h"

/* 单路整分对齐事件的下次触发秒距。
   iv = 0 视为关闭（返回 0）。分钟序号地板除对齐 —— 与 minute_cb 的
   `mnow % iv == 0` 同一判据（★R2.7.1 两例统一为 epoch 分钟基准：
   epoch 分钟 m 对齐 ⇔ m % iv == 0）。

   ★ R2.6.0 提前量模型：首选边界前 PWR_SCHED_LEAD_S 唤醒（给 boot +
   网络门控留时间）；放不下退 PWR_SCHED_LEAD_MIN_S。
   ★ R2.6.1 贴边唤醒：连 LEAD_MIN 都放不下（距边界 < LEAD_MIN+MIN_S，
   上一事件的忙碌尾巴常把入睡决策推进这一窗）时，不再「顺延一个周期」——
   那等于把眼前的边界【无声跳过】（无唤醒、无 RTC 标记，唤醒侧无从补发，
   时钟/拉取要再 stale 整整一个间隔 —— 用户实测「时钟偶尔不跳 / 远端拉取
   失败」的主根因）。改为贴边唤醒（now + MIN_S）：唤醒必然迟到边界几秒到
   几十秒，交给唤醒侧补刷（pwr_sched_missed 窗口已扩 1 分钟）兜底 ——
   宁可迟到，不可缺席。
 * ★ R2.7.0 lead 按事件分档：BOX（轻唤醒，门控 ≈ 2~3s）传
 *   PWR_SCHED_LEAD_LIGHT_S；REMOTE/CAROUSEL/MOVE（全功能，门控 5~32s）
 *   传 PWR_SCHED_LEAD_S。退档 LEAD_MIN / 贴边 MIN_S 判据不变，各自按
 *   本档 lead 评估。
   返回：距唤醒时刻的秒数；*at_out = 事件边界 epoch 秒（贴边档 = 唤醒 +
   一个小于 MIN_S 的负偏移，即唤醒落在边界之后）。
   iv == 0 时 *at_out = 0。 */
static uint32_t next_iv_s(int64_t now, uint32_t iv_min, int64_t lead_in,
                          int64_t *at_out)
{
    if (at_out) *at_out = 0;
    if (iv_min == 0) return 0;

    int64_t m    = now / 60;                       /* 当前所在分钟序号 */
    int64_t next = (m / (int64_t)iv_min + 1) * (int64_t)iv_min;
    int64_t bnd  = next * 60;                      /* 下一个对齐边界（epoch 秒） */

    int64_t lead = lead_in;
    if (bnd - lead < now + PWR_SCHED_MIN_S) lead = PWR_SCHED_LEAD_MIN_S;
    if (bnd - lead >= now + PWR_SCHED_MIN_S) {
        if (at_out) *at_out = bnd;
        return (uint32_t)(bnd - lead - now);
    }
    /* 边界太近，贴边唤醒（迟到交给补刷），目标边界不变 */
    if (at_out) *at_out = bnd;
    return (uint32_t)PWR_SCHED_MIN_S;
}

void pwr_sched_next(int64_t now, const pwr_sched_in_t *in,
                    pwr_sched_out_t *out)
{
    uint32_t best = 0;
    uint8_t  evt  = PWR_EVT_NONE;
    int64_t  at   = 0;

    /* 同距时先到先得（BOX -> REMOTE -> CAROUSEL -> MOVE）：结果确定性，
       测试与日志可复现。★R2.7.0：BOX 传轻档提前量（它赢出时本次唤醒是
       轻唤醒，主控不起射频、不走门控等待）；全功能事件传全档。
       ★同边界抢断：分档后全功能事件（lead 30）的唤醒点早于 BOX（lead 6）
       —— 同一边界两者都命中时【全功能必须赢】：它的门控+补刷会顺带覆盖
       该边界的分钟刷新；BOX 赢了反而把拉取/换位挤掉整个间隔（同距时
       全功能事件从 BOX 手里抢下，全功能之间仍先到先得）。 */
#define CONSIDER(iv, e, lead, steal) do {                              \
        int64_t at_ = 0;                                               \
        uint32_t s_ = next_iv_s(now, (iv), (lead), &at_);              \
        if (s_ != 0 && (best == 0 || s_ < best ||                      \
                        ((steal) && s_ == best && evt == PWR_EVT_BOX))) { \
            best = s_; evt = (e); at = at_;                            \
        }                                                              \
    } while (0)
    CONSIDER(in->box_iv_min,  PWR_EVT_BOX,      PWR_SCHED_LEAD_LIGHT_S, false);
    CONSIDER(in->rmt_iv_min,  PWR_EVT_REMOTE,   PWR_SCHED_LEAD_S,      true);
    CONSIDER(in->caro_iv_min, PWR_EVT_CAROUSEL, PWR_SCHED_LEAD_S,      true);
    CONSIDER(in->move_iv_min, PWR_EVT_MOVE,     PWR_SCHED_LEAD_S,      true);
#undef CONSIDER

    if (in->wake_s != 0) {
        /* wake_s：自本次入睡起算的固定间隔（不与整分对齐，无提前量——
           它本来就不是踩边界的触发器，而是「到点等人」的闹钟）。
           同样保底 PWR_SCHED_MIN_S，防极小值配置造成醒睡乒乓。 */
        uint32_t s = in->wake_s;
        if (s < PWR_SCHED_MIN_S) s = PWR_SCHED_MIN_S;
        if (best == 0 || s < best) {
            best = s;
            evt  = PWR_EVT_WAKE;
            at   = now + s;
        }
    }

    out->in_s  = best;
    out->event = (best != 0) ? evt : PWR_EVT_NONE;
    out->at_epoch = (best != 0) ? at : 0;
}

bool pwr_sched_missed(int64_t now_epoch, int64_t tgt_epoch, uint32_t iv_min)
{
    if (iv_min == 0 || tgt_epoch <= 0) return false;
    int64_t m = now_epoch / 60;
    int64_t tgt = tgt_epoch / 60;
    /* 目标边界已到、且仍在同一对齐周期内（再晚就该等下个边界了）。
       ★ R2.6.1：窗口右端扩 1 分钟（tgt + iv + 1）—— 补刷只在 boot_done
       一处执行且先于任何 minute_cb 触发（s_boot_done 置位与补发之间没有
       整分边界可触发），扩窗不会重复补发；而 RTC 慢漂（RC 振荡器随温度
       可达 ±%级，10 分钟睡眠可漂出 ±30s）+ 慢路由器门控 + 贴边唤醒三者
       叠加，边界落后 60s 以上是实测可达的 —— 1 分钟档恰好整窗错过就
       表现为「时钟偶尔不跳」。 */
    return m >= tgt && m < tgt + (int64_t)iv_min + 1;
}

const char *pwr_sched_evt_name(uint8_t evt)
{
    switch (evt) {
    case PWR_EVT_BOX:     return "box tick";
    case PWR_EVT_REMOTE:  return "remote pull";
    case PWR_EVT_CAROUSEL:return "carousel";
    case PWR_EVT_MOVE:    return "box move";
    case PWR_EVT_WAKE:    return "user wake";
    case PWR_EVT_SYNC:    return "time sync";
    default:              return "none";
    }
}
