#include "netif_ap.h"
#include "settings.h"
#include "captive.h"

#include "esp_wifi.h"
#include "esp_netif.h"
#include "esp_event.h"
#include "esp_mac.h"
#include "esp_log.h"

#include <string.h>
#include <stdio.h>

static const char *TAG = "netif_ap";

#define AP_MAX_CONN 4
/* R1.0.10：信道 1→6。SuperMini 部分批次板载天线阻抗失配 + 40MHz 晶振
   60 次谐波落在 2400~2412MHz（信道 1 频段），信道 6 避开谐波密集区，
   对正常批次无副作用（FB-001）。 */
#define AP_CHANNEL  6

static esp_netif_t *s_ap = NULL;
static char s_ssid[SETT_SSID_MAX];

static void configure_dhcp_portal(void)
{
    /* DHCP 选项只能在服务停止时修改。此前把 IP 地址本身传给
       ESP_NETIF_DOMAIN_NAME_SERVER（该选项实际只接收 1 字节开关），调用会失败。 */
    esp_err_t err = esp_netif_dhcps_stop(s_ap);
    if (err != ESP_OK && err != ESP_ERR_ESP_NETIF_DHCP_ALREADY_STOPPED) {
        ESP_LOGW(TAG, "stop DHCP server failed: %s", esp_err_to_name(err));
    }

    esp_netif_dns_info_t dns = { 0 };
    dns.ip.type = ESP_IPADDR_TYPE_V4;
    dns.ip.u_addr.ip4.addr = esp_ip4addr_aton("192.168.4.1");
    err = esp_netif_set_dns_info(s_ap, ESP_NETIF_DNS_MAIN, &dns);
    if (err != ESP_OK) ESP_LOGW(TAG, "set DHCP DNS failed: %s", esp_err_to_name(err));

    uint8_t dns_offer = 1;
    err = esp_netif_dhcps_option(s_ap, ESP_NETIF_OP_SET,
                                 ESP_NETIF_DOMAIN_NAME_SERVER,
                                 &dns_offer, sizeof(dns_offer));
    if (err != ESP_OK) ESP_LOGW(TAG, "enable DHCP DNS offer failed: %s", esp_err_to_name(err));

    /* 不下发 DHCP Option 114。该选项必须指向带可信 TLS 证书的 RFC 8908 JSON API，
       不能直接填写本机 HTTP 页面；错误下发会让 iOS 识别到无网络却不打开门户。
       纯离线 ESP32 热点继续使用兼容性更广的 DNS 劫持 + HTTP 探测重定向。 */

    err = esp_netif_dhcps_start(s_ap);
    if (err != ESP_OK && err != ESP_ERR_ESP_NETIF_DHCP_ALREADY_STARTED) {
        ESP_LOGW(TAG, "start DHCP server failed: %s", esp_err_to_name(err));
    }
}

void netif_ap_apply_tx_power(void)
{
    /* esp_wifi_set_max_tx_power 单位 0.25dBm：高 18dBm=72 / 中 10dBm=40 /
       低 8.5dBm=34。低档针对天线阻抗失配批次——反射失真随功率升高而加重，
       社区实测降功率反而改善连接（FB-001）。phy 层上限已在 sdkconfig 收到 18。 */
    static const int PWR_QDBM[] = { 72, 40, 34 };
    const moink_settings_t *s = settings_get();
    uint8_t lvl = s->wifi_pwr;
    if (lvl > SETT_WIFI_PWR_LOW) lvl = SETT_WIFI_PWR_HIGH;

    esp_err_t err = esp_wifi_set_max_tx_power((int8_t)PWR_QDBM[lvl]);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "set_max_tx_power(%d) failed: %s", PWR_QDBM[lvl], esp_err_to_name(err));
        return;
    }
    int8_t actual = 0;
    if (esp_wifi_get_max_tx_power(&actual) == ESP_OK)
        ESP_LOGI(TAG, "wifi tx power level %u (%d qdBm, actual %d)", lvl, PWR_QDBM[lvl], (int)actual);
}

static void wifi_event_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    (void)arg;
    if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STACONNECTED) {
        wifi_event_ap_staconnected_t *e = (wifi_event_ap_staconnected_t *)data;
        ESP_LOGI(TAG, "station " MACSTR " joined", MAC2STR(e->mac));
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_AP_STADISCONNECTED) {
        wifi_event_ap_stadisconnected_t *e = (wifi_event_ap_stadisconnected_t *)data;
        ESP_LOGI(TAG, "station " MACSTR " left", MAC2STR(e->mac));
        captive_apple_station_disconnected();
    }
}

static void build_ssid(char *out, size_t n)
{
    const moink_settings_t *s = settings_get();
    if (s->ap_ssid[0]) {
        strlcpy(out, s->ap_ssid, n);
        return;
    }
    uint8_t mac[6];
    esp_read_mac(mac, ESP_MAC_WIFI_STA);
    snprintf(out, n, "MoInk-%02X%02X", mac[4], mac[5]);
}

/* R2.0.0：只创建 netif + 注册事件；netif / 事件循环 / WiFi 驱动初始化与
   模式决策全部上移到 wifi_mgr.c（本函数只允许调用一次）。 */
void netif_ap_setup(void)
{
    s_ap = esp_netif_create_default_wifi_ap();
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL, NULL));
}

void netif_ap_apply(void)
{
    const moink_settings_t *s = settings_get();
    build_ssid(s_ssid, sizeof(s_ssid));

    wifi_config_t ap = { 0 };
    strlcpy((char *)ap.ap.ssid, s_ssid, sizeof(ap.ap.ssid));
    ap.ap.ssid_len = (uint8_t)strlen(s_ssid);
    ap.ap.channel = AP_CHANNEL;
    ap.ap.max_connection = AP_MAX_CONN;

    if (s->ap_pass[0]) {
        ap.ap.authmode = WIFI_AUTH_WPA2_PSK;
        strlcpy((char *)ap.ap.password, s->ap_pass, sizeof(ap.ap.password));
    } else {
        ap.ap.authmode = WIFI_AUTH_OPEN;
    }

    /* R1.0.8：运行时改热点配置不再用 ESP_ERROR_CHECK（失败即 abort 重启），
       记录错误并让现有 AP 继续跑。 */
    esp_err_t e1 = esp_wifi_set_config(WIFI_IF_AP, &ap);
    if (e1 != ESP_OK) {
        /* ★R2.7.2【修复3】：失败路径如实报错并提前返回 —— 旧代码
           set_config 失败后照样走完 DHCP 配置并打印 "SoftAP configured"，
           把 ESP_ERR_WIFI_STOP_STATE（驱动停机中，R2.7.1 实测）掩盖成
           「成功」，排障被严重误导。失败时热点配置并未生效，不能打成功
           日志；驱动停机（入睡/重启加入）期间本函数本就不该被调用
           （wifi_mgr R2.7.2 已加 sleeping/停机闸），这里只兜底如实报错。 */
        ESP_LOGE(TAG, "SoftAP set_config FAILED: %s (NOT configured)",
                 esp_err_to_name(e1));
        return;
    }

    configure_dhcp_portal();

    ESP_LOGI(TAG, "SoftAP '%s' configured (open=%d, max %d)",
             s_ssid, s->ap_pass[0] == 0, AP_MAX_CONN);
}

int netif_ap_client_count(void)
{
    wifi_sta_list_t list;
    if (esp_wifi_ap_get_sta_list(&list) != ESP_OK) return 0;
    return list.num;
}

const char *netif_ap_ssid(void) { return s_ssid; }
