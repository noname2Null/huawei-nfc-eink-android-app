#include "overlay.h"
#include "frame.h"
#include "settings.h"
#include "store.h"          /* R2.1.0：轮播自动轮播到点查图库张数 */
#include "wifi_mgr.h"
#include "ble_sensor.h"
#include "remote.h"        /* R2.1.0：分钟调度到点提醒远端拉取 */
#include "font8x8.h"
#include "font_cjk32.h"
#include "zone_core.h"     /* R2.4.0：区域引擎（通用方向映射/差分） */
#include "epd_drv.h"       /* R2.4.0：epd_fast_refresh 局刷 */
#include "lut_r20.h"       /* R2.4.0：lut_build_num 快刷表 */
#include "pwr_sched.h"     /* R2.5.0：事件驱动休眠 —— 下次调度事件秒距 */
#include "power.h"        /* R2.6.0：唤醒补刷（power_wake_purpose/event + 忙脉冲） */

#include "esp_log.h"
#include "esp_timer.h"
#include "esp_attr.h"      /* R2.6.0：RTC_NOINIT_ATTR（快刷基准跨深睡存活） */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <time.h>
#include <stdio.h>
#include <string.h>

static const char *TAG = "overlay";

/* ★ R2.4.0：固定顶部条带推广为【任意矩形区】（上/下/左/右 + 横向/竖向
 *   + 自定义控件布局）。几何/截取/合成/快刷差分全部下沉 zone_core.c
 *   （纯 C，原生可测，与 R2.2.1 顶部条带公式对拍）；本文件只做：
 *   渲染调度（solve/draw）、快刷触发、分钟调度、密码屏。 */

/* 2bpp 色码：0=黑 1=白 2=黄 3=红。 */
#define C_BLACK 0
#define C_WHITE 1
#define C_RED   3

/* ★R2.6.0 快刷降残影：变更像素（黑→白 / 白→黑）的驱动轮数。
 * ★R2.6.1 每轮 = 验证过的六扫描清理配方（P3 预脉冲 + N3/L00，lut_build_num_ghost
 * 清理配方多轮化）：轮内正负交变，把每轮当一次微型全刷 —— R2.6.0 的纯目标场
 * 重复对旧黑像素残影打不满（用户实测）。3 轮共 18 扫描 ≈ 150ms DRF
 * （原 3 扫描 ≈ 27ms）。轮数越多残影越轻但单次局刷越慢；
 * 1 = 退回单轮清理配方。
 * ★R2.7.0 3 → 5（30 扫描 ≈ 250ms DRF）：用户实测 3 轮仍影响黑色像素；
 *   轻唤醒（分钟局刷）不起射频、门控捷径 ≈2~3s —— 每分钟的时间预算
 *   充裕，多两轮换更干净的黑白翻转（未变更像素动作码 00 不受影响，
 *   不多耗面板寿命；换位/全刷周期仍有工厂刷清屏兜底）。 */
#define OVL_FAST_DRIVE_ROUNDS 5

/* ---- 运行时几何（与 settings.orient 同步） ---- */
static uint8_t s_orient = 0;              /* 上次同步到的方向 */
static int      s_cw = 552, s_ch = 768;   /* 用户画布宽/高 */
static volatile bool s_geom_dirty = false;/* 几何切换提示（内容已随区失效） */

static bool s_state_valid;               /* 快刷基准有效（= 区内容与面板一致） */

/* ★R2.6.0 快刷基准 RTC 持久化（实现见下方「快刷基准 RTC 持久化」段）。
 * 声明前置：geom_sync（方向切换作废）在文件顶部就要引用。 */
#define OVL_RTC_MAGIC  0x4F564C36u   /* "OVL6" */
static struct {
    uint32_t magic;
    uint32_t fp;                     /* box_fp()（含换位 parity + 全部版式设置） */
    uint8_t  vis;                    /* 控件可见位掩码（bit k = ZC_WG_k） */
    uint8_t  icon;
    uint8_t  synced;
    uint8_t  wday;
    char     time_s[8];
    char     date_s[16];
    char     tv[12];
    char     hv[12];
    char     ip_s[16];
} s_rtc_box RTC_NOINIT_ATTR;

/* ★R2.7.1 整刷失败标记（RTC noinit）：整刷失败 = 面板真值未知，且
 * box_compose 在刷屏【前】已把快刷基准写进 RTC（基准领先面板一帧）——
 * 置位后 box_state_restore 拒绝恢复，下次开机首个到点刷新强制整刷；
 * 整刷成功即清除。魔数校验，掉电/乱码按无标记处理。 */
#define OVL_RTC_FF_MAGIC  0x4F564C38u   /* "OVL8" */
static struct {
    uint32_t magic;
} s_rtc_ffail RTC_NOINIT_ATTR;

/* ★R2.7.1 温湿数值防抖跨深睡持久化（RTC noinit）：s_last_val_min 原为
 * RAM 变量，深睡即丢 —— 醒后同一分钟的重复触发会绕过 2 分钟防抖。 */
#define OVL_RTC_VAL_MAGIC 0x4F564C39u   /* "OVL9" */
static struct {
    uint32_t magic;
    int32_t  last_val_min;    /* 上次因数值变化触发的分钟数（epoch 分） */
} s_rtc_val RTC_NOINIT_ATTR;

/* 与 settings.orient 同步几何；方向变了 → 区内容按新坐标系无效。 */
static void geom_sync(void)
{
    uint8_t o = settings_get()->orient;
    if (o >= 4) o = 0;
    if (o != s_orient) {
        s_orient = o;
        s_cw = (o == 1 || o == 3) ? 768 : 552;
        s_ch = (o == 1 || o == 3) ? 552 : 768;
        zc_invalidate();              /* 旧区是旧坐标系的，须重截/重画 */
        s_state_valid = false;        /* 快刷基准同样失效 */
        s_geom_dirty = true;
        s_rtc_box.magic = 0;          /* ★R2.6.0：方向切换，持久化基准作废 */
    }
}

int overlay_canvas_w(void) { geom_sync(); return s_cw; }
int overlay_canvas_h(void) { geom_sync(); return s_ch; }

/* ---------------- 像素原语（显示坐标 → zone_core 双目标分发） ----------------
 * 正常态写 2bpp 区缓冲；快刷前把控件【旧值】重渲染时切到 1bpp 暂存
 * （黑笔画=1，白描边/白底=0）—— diff 出动作码。 */

static inline void px_set(int dx, int dy, int c)
{
    if (zc_scratch_active()) zc_scratch_px(dx, dy, c == C_BLACK);
    else                     zc_px_set(dx, dy, c);
}

static void fill_rect(int x0, int y0, int w, int h, int c)
{
    for (int y = y0; y < y0 + h; y++)
        for (int x = x0; x < x0 + w; x++)
            px_set(x, y, c);
}

/* ---------------- 32x32 中文点阵（R2.0.4：真宋体字库替换手绘 12x12） ----------------
 *
 * 字体源 Noto Serif SC Bold（思源宋体·粗），由 tools/gen_cjk32.py 渲染生成
 * main/font_cjk32.h。旧版 12x12 手绘点阵放大后笔画糊（用户反馈"看不清"），
 * 真字库 32px（scale 1）笔画锐利；粗体保证墨水屏低分辨率下横画不断。
 * 字符序与 font_cjk32.h 一一对应：一二三四五六日周中重置密码新℃% */

typedef enum {
    CJK_YI = 0, CJK_ER, CJK_SAN, CJK_SI, CJK_WU, CJK_LIU,
    CJK_RI, CJK_ZHOU, CJK_ZHONG, CJK_CHONG, CJK_ZHI, CJK_MI, CJK_MA, CJK_XIN,
    CJK_DEGC,          /* ℃（信息框温度单位） */
    CJK_PCT,           /* %（信息框湿度单位） */
    CJK_COUNT
} cjk_idx_t;

/* ---------------- 状态 ---------------- */

/* 区缓冲在 zone_core.c（38.4KB，用户坐标行主序）：当前「信息框区应该
   显示什么」——干净照片区 / 照片+信息框 / 密码重置屏；R2.4.0 起区可
   位于上/下/左/右任意边或自定义控件包围盒。 */
static volatile bool s_box_drawn = false;   /* 当前区是否已画信息框 */
static volatile int  s_pwd_phase = 0;       /* 0 空闲 / 1 重置中 */
static bool s_photo_split = false;          /* R2.0.3：当前显示源为分割式合成
                                              （照片让出顶部 160 行、框底纯白） */
static volatile int s_ip_left = 0;          /* R2.0.3：IP 行剩余显示的刷新周期
                                              （box_ip_mode = 周期档；入网时重置） */
static esp_timer_handle_t s_min_timer;
static esp_timer_handle_t s_pwd_timer;
static bool s_started = false;

/* ★R2.6.0：防烧屏换位让位是否生效（定义见下方「换位让位」段；
 * 截取/合成/行供数三处都要问，先予声明）。 */
static bool photo_shift_on(void);

/* ★R2.6.0：快刷基准 RTC 持久化（定义见下方「快刷基准 RTC 持久化」段；
 * box_compose 在定义点之前就要写入，先予声明）。 */
static void box_state_persist(void);

/* ---------------- 截取 / 合成（frame.c 在帧锁下调用） ---------------- */

/* R2.4.0：区的载荷行足迹 [r0,r1) —— frame.c 逐行读整行喂入。
 * ★R2.6.0：换位让位生效时框区底下无照片（照片已上移 160 行），
 * 足迹为空 —— 截取侧不读 flash，完成侧走白底。 */
void overlay_capture_row_range(int *r0, int *r1)
{
    geom_sync();
    if (photo_shift_on()) {
        *r0 = 0;
        *r1 = 0;
        return;
    }
    zc_capture_range(r0, r1);
}

/* 喂一个完整载荷行（192B）；zone_core 按方向把区内像素摘进区缓冲。 */
void overlay_payload_capture_row(int row, const uint8_t *line192)
{
    geom_sync();
    zc_capture_row(row, line192);
}

/* R2.4.1：区截取期望段数（段 = 一条完整 192B 载荷行；区足迹连续，
 * 期望值 = r1-r0）。frame.c 上传完成性校验用：实收段数不等 →
 * 帧几何/方向与当前区不符，判失败还原条带（R2.2.1 老校验的区化推广）。 */
int overlay_strip_capture_segs(void)
{
    int r0 = 0, r1 = 0;
    overlay_capture_row_range(&r0, &r1);
    return r1 - r0;
}

void overlay_strip_capture_done(void)
{
    /* ★R2.6.0：换位让位生效时，干净基线不是「框区照片」而是白底 ——
 * 照片整体上移后，框区（下 160 行）没有对应载荷内容。 */
    if (photo_shift_on()) {
        zc_fill_white();
    } else {
        zc_capture_done();                   /* 区 = 干净照片（未画信息框） */
    }
    s_geom_dirty = false;
    s_box_drawn = false;
}

void overlay_strip_fill_white(void)
{
    geom_sync();
    zc_fill_white();
    s_geom_dirty = false;
    s_box_drawn = false;
}

/* 刷屏行合成：把区内容按方向写进 provider 行 r（frame.c 行供数回调）。
 * ★R2.6.0：换位让位生效时先把行内的照片段平移 40 字节（竖屏方向；
 * 横屏方向的平移已在行号级完成，此处的字节平移为恒等），再叠加框。 */
void overlay_strip_blend(uint8_t *row_rot, int r)
{
    geom_sync();
    if (photo_shift_on()) zc_shift_row_bytes((int)s_orient, row_rot);
    zc_blend_row(row_rot, r);
}

/* ---------------- R2.1.0 新状态 ----------------
 *
 * 远端拉取样式压制（remote.c 提交远端帧时设置）：
 *   s_remote_active && !s_remote_split —— 全屏远端（信息框关闭）；
 *   s_remote_active &&  s_remote_split —— 分割式（顶部 160 行 = 本地信息框）。
 * 上电门控（boot gate）未完成前分钟调度不触发任何重画/轮播（需求 3）。
 * 温湿度数值变化触发（需求 7.3）：留痕本次画上屏的温/湿串 + 上次触发分钟数。 */
static volatile bool s_remote_active = false;
static volatile bool s_remote_split  = false;
static volatile bool s_boot_done     = false;
static char s_drawn_tv[12] = "";        /* 上次画上屏的温度串（"23.5"） */
static char s_drawn_hv[12] = "";        /* 上次画上屏的湿度串 */
/* s_last_val_min 已改挂 RTC noinit（s_rtc_val）跨深睡持久化，见文件顶部。 */

/* 事件投递（由 main.c 注入 ui_post）。 */
static void (*s_post)(int ev) = NULL;

/* ---------------- 文字渲染 ----------------
 *
 * ★ R2.0.4 白描边回归（两遍渲染）：密度 <100 或叠加暗色照片时，纯黑字压暗图不可读
 *   （用户实测反馈）。旧版描边是"逐像素先白后黑"—— 后画像素的白边会把先画像素的
 *   黑笔画啃掉（这也是 R2.0.2 描边发虚的根因），本版一律两遍：先把全部笔画的白边
 *   铺完，再统一落黑笔画。白底（密度 100 / 分割式）上白边不可见，无副作用。 */

/* font8x8 单字符（密码屏数字用）。scale 像素放大；halo=白描边半径（0 无）。 */
static void draw_char8(char ch, int x, int y, int scale, int color, int halo)
{
    if ((unsigned char)ch < 0x20 || (unsigned char)ch > 0x7E) return;

    const unsigned char *g = FONT8X8[(unsigned char)ch];
    /* dhepper/font8x8 点阵 LSB = 最左像素（R2.0.3 修正读位方向）。 */
    if (halo > 0) {
        for (int r = 0; r < 8; r++) {
            unsigned char row = g[r];
            for (int c = 0; c < 8; c++) {
                if ((row >> c) & 1)
                    fill_rect(x + c * scale - halo, y + r * scale - halo,
                              scale + 2 * halo, scale + 2 * halo, C_WHITE);
            }
        }
    }
    for (int r = 0; r < 8; r++) {
        unsigned char row = g[r];
        for (int c = 0; c < 8; c++) {
            if ((row >> c) & 1)
                fill_rect(x + c * scale, y + r * scale, scale, scale, color);
        }
    }
}

static void draw_text8(const char *s, int x, int y, int scale, int color, int halo)
{
    int adv = 8 * scale + scale;
    for (const char *p = s; *p; p++) {
        draw_char8(*p, x, y, scale, color, halo);
        x += adv;
    }
}

/* 32x32 宋体字符。halo=白描边半径（两遍渲染）。 */
static void draw_cjk32(cjk_idx_t idx, int x, int y, int scale, int color, int halo)
{
    if ((int)idx < 0 || idx >= CJK_COUNT) return;
    const uint32_t *g = CJK32[idx];
    if (halo > 0) {
        for (int r = 0; r < CJK32_CELL; r++)
            for (int c = 0; c < CJK32_CELL; c++)
                if ((g[r] >> (31 - c)) & 1)
                    fill_rect(x + c * scale - halo, y + r * scale - halo,
                              scale + 2 * halo, scale + 2 * halo, C_WHITE);
    }
    for (int r = 0; r < CJK32_CELL; r++)
        for (int c = 0; c < CJK32_CELL; c++)
            if ((g[r] >> (31 - c)) & 1)
                fill_rect(x + c * scale, y + r * scale, scale, scale, color);
}

/* 单个 32px 宋体字符的显示宽度（含右侧 2px 字距）。 */
#define CJK32_ADV (CJK32_CELL + 2)

/* ---------------- 7 段数码管字体（信息框内数字一律用它） ----------------
 *
 * 段位布局（数字宽 w、高 h、笔划厚 t）：
 *         aaaa
 *      f        b
 *      f        b
 *         gggg
 *      e        c
 *      e        c
 *         dddd
 * 段表按经典 7 段编码（a=bit0..g=bit6）；支持字符：
 * '0'-'9'、'-'（仅中段）、'.'（右下点）、':'（上下双点）、'/'（★R2.1.0 连续
 * 斜杠，见 seg7_slash —— 旧版 3 点阶梯已按用户要求换掉）、' '。
 * R2.0.4：先集段为矩形表再两遍绘制（白描边 + 黑笔画），描边不再啃笔画。 */

static const uint8_t SEG7_MAP[10] = {
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F
};

static int seg7_w(int h)   { return h / 2 + h / 16; }   /* 数字宽 */
static int seg7_gap(int h) { return h / 12 + 1; }       /* 字间距 */

/* R2.1.0：连续斜杠单元宽（约 0.6×字高，斜度足够看起来是「/」而不是竖条）。 */
static int seg7_slash_w(int h)
{
    int t = h / 10 + 1;
    int w = (h * 3) / 5;
    return w < t + 2 ? t + 2 : w;
}

/* 单字符水平步进（含右侧间距）。 */
static int seg7_adv(char ch, int h)
{
    int w = seg7_w(h), gap = seg7_gap(h);
    if (ch == '.') return h / 6 + gap;
    if (ch == ':') return h / 5 + gap;
    if (ch == '/') return seg7_slash_w(h) + gap;   /* R2.1.0：连续斜杠单元 */
    if (ch == ' ') return w / 3 + gap;
    return w + gap;                       /* 数字与 '-' */
}

/* 整串显示宽度（末尾不计间距）——居中排版用。 */
static int seg7_strw(const char *s, int h)
{
    int w = 0;
    for (const char *p = s; *p; p++) w += seg7_adv(*p, h);
    return w ? w - seg7_gap(h) : 0;
}

typedef struct { int16_t x, y, w, h; } seg_rect_t;

/* 字符 -> 笔画矩形表（最多 7 段 + 3 斜杠点）。返回矩形数（0 = 空白）。 */
static int seg7_rects(int x, int y, int h, char ch, seg_rect_t *out)
{
    int w = seg7_w(h);
    int t = h / 10 + 1;
    int half = (h - 3 * t) / 2;           /* 上下两段竖笔各占的高度 */
    uint8_t seg = 0;
    if (ch >= '0' && ch <= '9') seg = SEG7_MAP[ch - '0'];
    else if (ch == '-') seg = 0x40;       /* 仅中段 */
    if (seg) {
        int n = 0;
        if (seg & 0x01) { out[n].x = x + t;         out[n].y = y;               out[n].w = w - 2 * t; out[n].h = t;    n++; } /* a */
        if (seg & 0x40) { out[n].x = x + t;         out[n].y = y + t + half;    out[n].w = w - 2 * t; out[n].h = t;    n++; } /* g */
        if (seg & 0x08) { out[n].x = x + t;         out[n].y = y + h - t;       out[n].w = w - 2 * t; out[n].h = t;    n++; } /* d */
        if (seg & 0x20) { out[n].x = x;             out[n].y = y + t;           out[n].w = t;         out[n].h = half; n++; } /* f */
        if (seg & 0x02) { out[n].x = x + w - t;     out[n].y = y + t;           out[n].w = t;         out[n].h = half; n++; } /* b */
        if (seg & 0x10) { out[n].x = x;             out[n].y = y + 2 * t + half;out[n].w = t;         out[n].h = half; n++; } /* e */
        if (seg & 0x04) { out[n].x = x + w - t;     out[n].y = y + 2 * t + half;out[n].w = t;         out[n].h = half; n++; } /* c */
        return n;
    }
    int d = t + 2;
    if (ch == '.') {
        out[0].x = x; out[0].y = y + h - d - 1; out[0].w = d; out[0].h = d;
        return 1;
    }
    if (ch == ':') {
        out[0].x = x; out[0].y = y + h / 4 - d / 2;         out[0].w = d; out[0].h = d;
        out[1].x = x; out[1].y = y + (3 * h) / 4 - d / 2;   out[1].w = d; out[1].h = d;
        return 2;
    }
    return 0;                             /* '/'（连续斜杠见 seg7_slash）、' ' 及其他 */
}

/* R2.1.0：连续斜杠 —— 旧版是 3 个点组成的阶梯斜杠（点阵感），用户要求换成
 * 连续的「/」。实现：逐行 1px 高的横条沿对角线排布，相邻行首尾相接成连续
 * 斜划；两遍渲染（先全部白描边再落黑笔画）与数字一致，白底上白边不可见。 */
static void seg7_slash(int x, int y, int h, int color, int halo)
{
    int span = seg7_slash_w(h);           /* 斜杠单元宽 */
    int t = h / 10 + 1;                   /* 笔划厚（与数字段一致） */
    if (t < 2) t = 2;
    int run = span - t;                   /* 水平行程：左下 → 右上 */
    int hh = h > 1 ? h - 1 : 1;
    if (halo > 0) {
        for (int j = 0; j < h; j++) {
            int xc = x + ((h - 1 - j) * run) / hh;
            fill_rect(xc - halo, y + j - halo, t + 2 * halo, 1 + 2 * halo, C_WHITE);
        }
    }
    for (int j = 0; j < h; j++) {
        int xc = x + ((h - 1 - j) * run) / hh;
        fill_rect(xc, y + j, t, 1, color);
    }
}

static void seg7_char(int x, int y, int h, char ch, int color, int halo)
{
    if (ch == '/') {                      /* R2.1.0：连续斜杠 */
        seg7_slash(x, y, h, color, halo);
        return;
    }
    seg_rect_t rs[8];
    int n = seg7_rects(x, y, h, ch, rs);
    if (halo > 0) {
        for (int i = 0; i < n; i++)
            fill_rect(rs[i].x - halo, rs[i].y - halo,
                      rs[i].w + 2 * halo, rs[i].h + 2 * halo, C_WHITE);
    }
    for (int i = 0; i < n; i++)
        fill_rect(rs[i].x, rs[i].y, rs[i].w, rs[i].h, color);
}

static void seg7_text(const char *s, int x, int y, int h, int color, int halo)
{
    for (const char *p = s; *p; p++) {
        seg7_char(x, y, h, *p, color, halo);
        x += seg7_adv(*p, h);
    }
}

/* ---------------- 图标 ---------------- */

/* 两遍描画：先把所有笔画点的白光晕铺完，再统一落黑。 */
static void icon_two_pass(int x0, int y0, const bool on[22][22])
{
    for (int y = 0; y < 22; y++)
        for (int x = 0; x < 22; x++)
            if (on[y][x]) fill_rect(x0 + x - 1, y0 + y - 1, 3, 3, C_WHITE);
    for (int y = 0; y < 22; y++)
        for (int x = 0; x < 22; x++)
            if (on[y][x]) px_set(x0 + x, y0 + y, C_BLACK);
}

/* wifi 弧形图标。STA+有外网 = wifi 图标。 */
static void draw_icon_wifi(int x0, int y0)
{
    int cx = x0 + 11, cy = y0 + 18;
    static const int radii[3] = { 4, 9, 14 };
    bool on[22][22] = { false };

    for (int y = 0; y < 22; y++) {
        for (int x = 0; x < 22; x++) {
            int dx = (x0 + x) - cx, dy = cy - (y0 + y);   /* dy>0 = 图标上方 */
            if (dy < 0) continue;
            int d2 = dx * dx + dy * dy;
            if (d2 <= 4) { on[y][x] = true; continue; }   /* 底部圆点 */
            for (int k = 0; k < 3; k++) {
                int r = radii[k];
                if (d2 > (r - 1) * (r - 1) && d2 <= (r + 1) * (r + 1) &&
                    4 * (dx >= 0 ? dx : -dx) <= 3 * dy)
                    on[y][x] = true;
            }
        }
    }
    icon_two_pass(x0, y0, on);
}

/* 感叹号图标：STA 连上但无外网。 */
static void draw_icon_excl(int x0, int y0)
{
    bool on[22][22] = { false };
    for (int y = 2; y < 12; y++)
        for (int x = 9; x < 13; x++)
            on[y][x] = true;
    for (int y = 15; y < 19; y++)
        for (int x = 9; x < 13; x++)
            on[y][x] = true;
    icon_two_pass(x0, y0, on);
}

/* ---------------- R2.4.0 信息框引擎：区求解 / 控件帧 / 渲染 / 快刷 ---------------- */

/* 一次渲染所需的全部值 + 求解出的控件矩形（快刷 diff 基准 = 上屏后的本帧） */
typedef struct {
    bool      vis[ZC_WG_COUNT];
    zc_rect_t r[ZC_WG_COUNT];
    int       dh, thh;               /* 日期 / 温湿数字字高（求解器输出） */
    char      time_s[8];
    char      date_s[16];
    char      tv[12], hv[12];
    char      ip_s[16];
    bool      synced;
    int       wday;
    int       icon;                  /* 0 无 / 1 wifi / 2 感叹号 */
} box_frame_t;

static box_frame_t s_state;            /* 上次上屏帧（快刷 diff 基准） */
static uint32_t s_state_fp = 0;
static bool     s_fast_ok = true;      /* 快刷可用（DRF 未接受/失败即拉黑） */
static bool     s_pwd_zone = false;    /* 密码屏借用顶部全幅条带（临时区覆盖） */
static uint8_t  s_fast_lut[LUT_R20_BYTES];
static bool     s_fast_lut_ready = false;
static uint8_t  s_act_row[ZC_RBYTES];

static const cjk_idx_t WD7[7] = {
    CJK_RI, CJK_YI, CJK_ER, CJK_SAN, CJK_SI, CJK_WU, CJK_LIU
};
#define TH_ROW_GAP 16    /* 温组与湿组间距（沿用 R2.1.0 版式） */

/* IP 行当前是否显示：仅入网（STA）；模式 0 关 / 1 常显 / 2 = 剩余周期 > 0。 */
static bool box_show_ip(void)
{
    const moink_settings_t *s = settings_get();
    if (wifi_mgr_mode() != NETIF_MODE_STA) return false;
    if (s->box_ip_mode == SETT_BOX_IP_OFF) return false;
    if (s->box_ip_mode == SETT_BOX_IP_ALWAYS) return true;
    return s_ip_left > 0;
}

static uint32_t dither_hash(int x, int y)
{
    uint32_t h = (uint32_t)x * 0x9E3779B1u ^ ((uint32_t)y * 0x85EBCA6Bu);
    h ^= h >> 13;
    h *= 0xC2B2AE35u;
    h ^= h >> 16;
    return h;
}

/* 信息栏当前是否应显示：设置开 + 非远端全屏 +（已入网 或 蓝牙数据有效
   或 ★R2.6.2 单机时钟态）。
   ★R2.6.2 单机时钟可见性 —— 单机 24h 实测「局刷成功 1 次后主控睡死，
   直到半小时/一小时后的全局刷新才工作」的主根因：可见性绑死在网络态上，
   而网络态在每个唤醒周期内是【瞬时值】——
     · 入睡侧 overlay_next_wake_s 的 box_on 用「此刻可见」判定，门控期末
       BLE 6s 窗没等到广播 / STA 重连慢于门控窗时可见性为假 → 分钟事件
       被整个丢弃，下次唤醒落在换位/轮播的 30/60min 边界；
     · 分钟侧 minute_cb 触发 B 虽不看可见性，overlay_box_tick 里
       「不可见 → clear 空转」，到点刷新照样空转。
   时钟的本体是【时间控件】：RTC 走时跨深睡存活（对过一次时永远 synced，
   build_frame 照常出真实时间/日期，IP/图标行自动隐藏、温湿无数据显示
   "--.-"），离线完全可画。故不在局域网也无蓝牙数据时，只要时间控件开着
   且钟有效（epoch > TIME_OK_TS，从未对过时的假钟保持旧隐藏行为 ——
   "--:--" 没有可看内容）就返回可见。由此入睡调度 / 分钟刷新 / 防老化
   换位在单机下整链可用，且不再随网络抖动。 */
bool overlay_box_visible(void)
{
    const moink_settings_t *s = settings_get();
    if (!s->box_en) return false;
    if (s_remote_active && !s_remote_split) return false;
    if (wifi_mgr_mode() == NETIF_MODE_STA || ble_sensor_valid()) return true;
    return (s->box_show & SETT_BOX_SHOW_TIME) != 0 && wifi_mgr_time_synced();
}

/* ★R2.7.1 BOX 分钟事件统一判据：入睡计划（overlay_next_wake_s 的 box_on）
 * 与 minute_cb 触发 B 共用 —— 原入睡侧只看可见性、触发侧另要求
 * synced||蓝牙有效，单机时钟/未校时态入睡侧照样每分钟唤醒、触发侧永不
 * 发火 = 每分钟空唤醒；两侧同进同退（无变更时 tick 空过不整刷）。 */
static bool box_minute_on(void)
{
    return settings_get()->box_en && overlay_box_visible();
}

/* 布局求解器版本（进 box_fp）：固件改版式算法后，旧持久化基准自动作废
（跨深睡/跨 OTA 的快刷基准不再与新版求解器对拍）。改 solve_* 必须加一。 */
#define OVL_LAYOUT_VER 6

/* 布局指纹：影响版式/触发语义的全部设置位（防老化换位 parity 变化也会变） */
static uint32_t box_fp(void)
{
    const moink_settings_t *s = settings_get();
    uint32_t h = 2166136261u;
    #define FP_MIX(v) do { h ^= (uint32_t)(v); h *= 16777619u; } while (0)
    FP_MIX(OVL_LAYOUT_VER);   /* ★R2.6.0：求解器版本入指纹 */
    FP_MIX(s->box_show);   FP_MIX(s->box_time_h);  FP_MIX(s->box_row_h);
    FP_MIX(s->box_gap_mid); FP_MIX(s->box_pad_x);  FP_MIX(s->box_pad_y);
    FP_MIX(s->box_style);  FP_MIX(s->box_density); FP_MIX(s->box_ip_mode);
    FP_MIX(s->box_ip_cyc); FP_MIX(s->box_pos);     FP_MIX(s->box_dir);
    FP_MIX(s->box_move_iv);
    /* R2.4.1：blob 全量哈希 —— 只取首尾会漏检中间控件矩形的变更，
       导致快刷基于过期布局 diff 出花屏（编译期越界 [85] 也一并消除）。 */
    for (int i = 0; i < SETT_BOX_WG_BYTES; i++)
        FP_MIX(settings_get()->box_wg[i]);
    {
        time_t now = time(NULL);
        uint32_t iv = s->box_move_iv;
        FP_MIX(iv ? (uint32_t)((now / 60) / iv) : 0u);   /* 换位 parity 在指纹里 */
    }
    #undef FP_MIX
    return h;
}

/* 生效位置（0上 1下 2左 3右）与方向（0横 1竖）。方向档矫正合法性；
 * 防老化换位：epoch 分 / 间隔 = 奇数时在对侧（上↔下 / 左↔右）——
 * 确定性 parity，跨重启稳定，无需持久化。 */
static int eff_pos_dir(int *dir_out)
{
    const moink_settings_t *s = settings_get();
    int dir = (s->box_dir == 1) ? 1 : 0;
    int pos = s->box_pos & 3;
    if (dir == 0 && pos >= 2) pos = 0;
    if (dir == 1 && pos < 2)  pos = 2;
    if (s->box_move_iv) {
        time_t now = time(NULL);
        if (((uint32_t)(now / 60) / s->box_move_iv) & 1u) pos ^= 1;
    }
    *dir_out = dir;
    return pos;
}

/* 自定义控件布局（settings.box_wg blob；组 0=竖屏(o0/o2) 1=横屏(o1/o3)）。
 * 本组已定义 → 直接用；另一组已定义 → 派生（比例缩放+贴边吸附+收屏+推挤
 * 去重叠）；两组都没定义 → 返回 false 走默认版式。 */
typedef struct {
    uint8_t defined[2];
    uint8_t _rsv[2];                   /* R2.4.1：补齐 84B（版本预留，恒 0） */
    int16_t rect[2][ZC_WG_COUNT][4];   /* [组][控件]{x,y,w,h} */
} box_wg_t;                            /* 与 settings.box_wg 同层，布局勿改 */
_Static_assert(sizeof(box_wg_t) == SETT_BOX_WG_BYTES, "box_wg blob layout");

static bool custom_rects(box_frame_t *f, zc_rect_t *zone_out)
{
    const moink_settings_t *s = settings_get();
    const box_wg_t *wg = (const box_wg_t *)s->box_wg;
    const int slot = s_orient & 1;
    zc_rect_t r[ZC_WG_COUNT];

    if (wg->defined[slot] || wg->defined[slot ^ 1]) {
        const int oslot = wg->defined[slot] ? slot : (slot ^ 1);
        const int16_t (*src)[4] = wg->rect[oslot];
        const int sw = oslot ? 768 : 552, sh = oslot ? 552 : 768;
        for (int k = 0; k < ZC_WG_COUNT; k++) {
            zc_rect_t t = { src[k][0], src[k][1], src[k][2], src[k][3] };
            if (oslot != slot) zc_rect_derive(&t, sw, sh, s_cw, s_ch, &r[k]);
            else               r[k] = t;
            if (r[k].w < 8) r[k].w = 8;
            if (r[k].h < 8) r[k].h = 8;
            zc_rect_clamp(&r[k], s_cw, s_ch);
        }
    } else {
        return false;
    }

    /* 只收可见控件；重叠消解：y 升序放置，冲突向下推挤，推挤出屏则弃用 */
    int idx[ZC_WG_COUNT], n = 0;
    for (int k = 0; k < ZC_WG_COUNT; k++)
        if (f->vis[k]) {
            f->r[k] = r[k];
            idx[n++] = k;
        }
    if (!n) return false;
    for (int i = 1; i < n; i++) {                    /* 按 y 插入序（近插排） */
        int a = idx[i], j = i - 1;
        while (j >= 0 && f->r[idx[j]].y > f->r[a].y) { idx[j + 1] = idx[j]; j--; }
        idx[j + 1] = a;
    }
    for (int i = 0; i < n; i++) {
        zc_rect_t *a = &f->r[idx[i]];
        for (int guard = 0; guard < 64; guard++) {
            bool hit = false;
            for (int j = 0; j < i && !hit; j++)
                if (zc_rect_overlap(a, &f->r[idx[j]])) hit = true;
            if (!hit) break;
            a->y = (int16_t)(a->y + 2);              /* 向下推挤 */
            if (a->y + a->h > s_ch) return false;    /* 推挤出屏：回默认版式 */
        }
    }
    int x0 = s_cw, y0 = s_ch, x1 = 0, y1 = 0;
    for (int i = 0; i < n; i++) {
        const zc_rect_t *t = &f->r[idx[i]];
        if (t->x < x0) x0 = t->x;
        if (t->y < y0) y0 = t->y;
        if (t->x + t->w > x1) x1 = t->x + t->w;
        if (t->y + t->h > y1) y1 = t->y + t->h;
    }
    x0 -= 8; y0 -= 8; x1 += 8; y1 += 8;              /* 呼吸边 */
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > s_cw) x1 = s_cw;
    if (y1 > s_ch) y1 = s_ch;
    *zone_out = (zc_rect_t){ (int16_t)x0, (int16_t)y0,
                             (int16_t)(x1 - x0), (int16_t)(y1 - y0) };
    return true;
}

/* ---------------- ★R2.6.0 防烧屏换位让位（照片跟随框上移） ----------------
 *
 * 背景：防老化换位（box_move_iv）把信息框上下对调时，分割式载荷的照片
 * 不会跟着动 —— 旧呈现：顶部留 160 行白边 + 照片底部被框压住（用户
 * 实测反馈「图像位置不会自己变，被挡住了」）。
 *
 * 方案：显示侧把照片整体上移 160 用户行 —— 显示行 0..H-1 ← 载荷用户行
 * H..末尾（H = ZC_HBAR_H），框区（下 160 行）底下无照片（白底 + 控件）。
 * 几何：竖屏方向（o0/o2）= 行内 40 字节平移；横屏方向（o1/o3）= 行号
 * 平移（zc_shift_payload_row）；公式对拍见 scripts/test_shift_geom.c。
 * 生效条件（photo_shift_on）：
 *   1. 显示源为分割式（s_photo_split：本地上传 split / 远端分割均置位）；
 *   2. 标准横向条带且生效位置在「下」（换位 parity 翻转时自动跟随）；
 *   3. 无自定义控件布局（包围盒不随换位移动，无让位语义）；
 *   4. 非密码屏、非远端全屏；
 *   5. 信息框实际在画（框关/隐藏时照片回原位，不留白条）。 */

static bool custom_layout_defined(void)
{
    const box_wg_t *wg = (const box_wg_t *)settings_get()->box_wg;
    const int slot = s_orient & 1;
    return wg->defined[slot] || wg->defined[slot ^ 1];
}

static bool photo_shift_on(void)
{
    if (s_pwd_phase || s_pwd_zone) return false;      /* 密码屏独占条带 */
    if (!s_photo_split) return false;                 /* 非分割源：照片满幅 */
    if (s_remote_active && !s_remote_split) return false;  /* 远端全屏 */
    if (!overlay_box_visible()) return false;         /* 框没画：回原位 */
    if (custom_layout_defined()) return false;        /* 自定义布局不换位 */
    int dir = 0;
    int pos = eff_pos_dir(&dir);
    if (dir != 0) return false;                       /* 竖向条带无横向白边 */
    return pos == SETT_BOX_POS_BOTTOM;
}

bool overlay_photo_shift_active(void)
{
    geom_sync();
    return photo_shift_on();
}

int overlay_photo_shift_row(int r, int fallback_row)
{
    geom_sync();                       /* frame.c 行供数最早触达点：先同步几何 */
    if (!photo_shift_on()) return fallback_row;
    return zc_shift_payload_row((int)s_orient, r);
}

/* 区矩形求解：密码屏/远端分割 = 顶部全幅（兼容）；自定义 = 控件包围盒；
 * 默认 = 按方向档（横向 160 满幅 × 上/下；竖向 200 满高 × 左/右）。 */
static void zone_compute(zc_rect_t *z)
{
    geom_sync();
    if (s_pwd_zone || (s_remote_active && s_remote_split)) {
        *z = (zc_rect_t){ 0, 0, (int16_t)s_cw, ZC_HBAR_H };
        return;
    }
    zc_rect_t cz;
    /* ★R2.6.0 修复：此处原传零帧 —— custom_rects 对「可见控件全关」返回
       false，自定义布局的包围盒从未生效，条带外的自定义控件被 zc_px_set
       静默丢弃（屏上看不见）。改为按注释本意的「全开近似」：五个控件
       全可见求包围盒（包围盒由 solve_layout 阶段再次精确求解，误差只
       影响空带边距）。包围盒超区缓冲上限（ZC_BYTES_MAX）时退默认条带
       （zc_zone_set 对超限矩形是静默忽略，必须前置拦截）。 */
    {
        box_frame_t all;
        memset(&all, 0, sizeof(all));
        for (int k = 0; k < ZC_WG_COUNT; k++) all.vis[k] = true;
        if (custom_rects(&all, &cz) && cz.w > 8 &&
            (size_t)cz.w * (size_t)cz.h / 4u <= ZC_BYTES_MAX) {
            *z = cz;
            return;
        }
    }
    int dir = 0;
    int pos = eff_pos_dir(&dir);
    if (dir == 0) {
        int y = (pos == 1) ? (s_ch - ZC_HBAR_H) : 0;
        *z = (zc_rect_t){ 0, (int16_t)y, (int16_t)s_cw, ZC_HBAR_H };
    } else {
        int x = (pos == 3) ? (s_cw - ZC_VBAR_W) : 0;
        *z = (zc_rect_t){ (int16_t)x, 0, ZC_VBAR_W, (int16_t)s_ch };
    }
}

/* 应用区（变化才重设 —— 重设会清内容有效标志）。截取/合成/渲染入口都先走它。 */
static int s_zc_o = -1;
static zc_rect_t s_zc_r = { 0, 0, 0, 0 };
static void zone_prepare(void)
{
    geom_sync();
    zc_rect_t z;
    zone_compute(&z);
    if (s_zc_o != (int)s_orient || s_zc_r.x != z.x || s_zc_r.y != z.y ||
        s_zc_r.w != z.w || s_zc_r.h != z.h) {
        zc_zone_set(s_orient, &z);
        s_zc_o = s_orient;
        s_zc_r = z;
    }
}

/* 温度/湿度 0.1 精度格式化（不用 %f）。无数据 "--.-"。 */
static void fmt_tenth(char *buf, size_t sz, float v)
{
    if (v > -9000.0f && v < 9000.0f) {
        int t10 = (int)(v * 10 + (v >= 0 ? 0.5f : -0.5f));
        /* R2.4.1：钳位 ±999.9 —— 温湿物理量远小于此；同时封死 snprintf
           输出上界（"-999.9" = 7B 含 NUL ≤ 调用方 12B 缓冲），
           -O2 下 -Wformat-truncation 不再误报。 */
        if (t10 >  9999) t10 =  9999;
        if (t10 < -9999) t10 = -9999;
        int ip = t10 / 10, fp = t10 % 10;
        if (fp < 0) fp = -fp;
        snprintf(buf, sz, "%s%d.%d", (t10 < 0 ? "-" : ""), ip, fp);
    } else {
        strlcpy(buf, "--.-", sz);
    }
}

/* 控件帧取值（时间/日期/温湿/IP/图标 + 元素可见性） */
static void build_frame(box_frame_t *f)
{
    const moink_settings_t *s = settings_get();
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    bool synced = wifi_mgr_time_synced();
    bool ip_line = box_show_ip();
    bool sta = (wifi_mgr_mode() == NETIF_MODE_STA);

    memset(f, 0, sizeof(*f));
    if (synced) strftime(f->time_s, sizeof(f->time_s), "%H:%M", &tmv);
    else        strlcpy(f->time_s, "--:--", sizeof(f->time_s));
    if (synced) strftime(f->date_s, sizeof(f->date_s), "%Y/%m/%d", &tmv);
    else        strlcpy(f->date_s, "----/--/--", sizeof(f->date_s));
    f->synced = synced;
    f->wday = tmv.tm_wday;

    ble_state_t bs = ble_sensor_state();
    fmt_tenth(f->tv, sizeof(f->tv), bs.temp_c);
    fmt_tenth(f->hv, sizeof(f->hv), bs.hum_pct >= 0 ? bs.hum_pct : -9999.0f);
    strlcpy(f->ip_s, wifi_mgr_ip(), sizeof(f->ip_s));
    f->icon = wifi_mgr_internet() ? 1 : 2;

    f->vis[ZC_WG_TIME] = (s->box_show & SETT_BOX_SHOW_TIME) != 0;
    f->vis[ZC_WG_DATE] = (s->box_show & SETT_BOX_SHOW_DATE) != 0;
    f->vis[ZC_WG_TH]   = (s->box_show & SETT_BOX_SHOW_TH) != 0;
    f->vis[ZC_WG_IP]   = ip_line;
    f->vis[ZC_WG_ICON] = sta;          /* 图标只在 STA 模式画；挂哪行由求解器定 */
}

static int date_w(const box_frame_t *f, int h1)
{
    return seg7_strw(f->date_s, h1) + 6 + 2 * CJK32_ADV;
}
static int th_w(const box_frame_t *f, int h2)
{
    return seg7_strw(f->tv, h2) + 4 + CJK32_CELL + TH_ROW_GAP +
           seg7_strw(f->hv, h2) + 4 + CJK32_CELL;
}

/* 横向版式（R2.1.0 四稿版式的区化推广：y 全部加区偏移，IP 行贴区底） */
static void solve_h(box_frame_t *f, const zc_rect_t *z)
{
    const moink_settings_t *s = settings_get();
    const bool show_time = f->vis[ZC_WG_TIME];
    const bool show_date = f->vis[ZC_WG_DATE];
    const bool show_th   = f->vis[ZC_WG_TH];
    const bool both_rows = show_date && show_th;
    const bool right_any = show_date || show_th;

    int x0 = z->x + s->box_pad_x, x1 = z->x + z->w - 1 - s->box_pad_x;
    int y0 = z->y + s->box_pad_y;
    int y1 = f->vis[ZC_WG_IP] ? (z->y + 110) : (z->y + z->h - 1 - s->box_pad_y);
    int area_w = x1 - x0;

    int mgap = s->box_gap_mid ? s->box_gap_mid : 28;
    int th_max = y1 - y0;
    int h1 = s->box_row_h ? s->box_row_h : 30;
    int h2 = s->box_row_h ? s->box_row_h : 40;
    int th_pref = s->box_time_h ? s->box_time_h : th_max;

    int th, r1h, r2h, gapv = 0;
    for (;;) {
        int w1 = show_date ? date_w(f, h1) : 0;
        int w2 = show_th ? th_w(f, h2) : 0;
        int rw = w1 > w2 ? w1 : w2;
        int lw = right_any ? (area_w - rw - mgap) : area_w;
        if (lw < 24) lw = 24;
        th = th_pref > th_max ? th_max : th_pref;
        if (show_time)
            while (th > 24 && seg7_strw(f->time_s, th) > lw) th--;
        r1h = show_date ? (h1 > CJK32_CELL ? h1 : CJK32_CELL) : 0;
        r2h = show_th   ? (h2 > CJK32_CELL ? h2 : CJK32_CELL) : 0;
        if (both_rows && th < r1h + r2h + 4) th = r1h + r2h + 4;
        gapv = th - r1h - r2h;
        if (!both_rows || gapv >= 18) break;
        if (s->box_row_h) break;
        if (w1 >= w2 && h1 > 26)      h1--;
        else if (w2 > w1 && h2 > 32)  h2--;
        else if (h1 > 26)             h1--;
        else if (h2 > 32)             h2--;
        else break;
    }
    if (both_rows && gapv < 4) gapv = 4;
    f->dh = h1;
    f->thh = h2;

    int ey = y0 + (y1 - y0 - th) / 2;
    if (ey < y0) ey = y0;

    if (show_time) {
        int w = seg7_strw(f->time_s, th);
        int tx = right_any ? x0 : x0 + (area_w - w) / 2;
        f->r[ZC_WG_TIME] = (zc_rect_t){ (int16_t)tx, (int16_t)ey, (int16_t)w, (int16_t)th };
    }
    if (show_date) {
        int w = date_w(f, h1);
        int x = show_time ? (x1 - w) : x0 + (area_w - w) / 2;
        int r1y = both_rows ? ey : ey + (th - r1h) / 2;
        f->r[ZC_WG_DATE] = (zc_rect_t){ (int16_t)x, (int16_t)r1y, (int16_t)w, (int16_t)r1h };
    }
    if (show_th) {
        int w = th_w(f, h2);
        int tx = show_time ? (x1 - w) : x0 + (area_w - w) / 2;
        int r2y = both_rows ? (ey + th - r2h) : ey + (th - r2h) / 2;
        f->r[ZC_WG_TH] = (zc_rect_t){ (int16_t)tx, (int16_t)r2y, (int16_t)w, (int16_t)r2h };
    }
    if (f->vis[ZC_WG_IP]) {
        int ih = 30;
        int iw = seg7_strw(f->ip_s, ih);
        int itot = iw + (f->vis[ZC_WG_ICON] ? 22 + 18 : 0);
        int ix = x0 + (x1 - x0 - itot) / 2;
        int iy = z->y + 120;
        f->r[ZC_WG_IP] = (zc_rect_t){ (int16_t)ix, (int16_t)iy, (int16_t)iw, (int16_t)ih };
        if (f->vis[ZC_WG_ICON])
            f->r[ZC_WG_ICON] = (zc_rect_t){ (int16_t)ix, (int16_t)(iy + (ih - 22) / 2), 22, 22 };
    } else if (f->vis[ZC_WG_ICON] && right_any) {
        /* 无 IP 行：图标挂第一个可见右侧行的行尾 */
        const zc_rect_t *host = show_date ? &f->r[ZC_WG_DATE] : &f->r[ZC_WG_TH];
        f->r[ZC_WG_ICON] = (zc_rect_t){ (int16_t)(host->x + host->w + 10),
                                        (int16_t)(host->y + (host->h - 22) / 2), 22, 22 };
    } else if (!f->vis[ZC_WG_ICON]) {
        f->vis[ZC_WG_ICON] = false;
    }
}

/* 竖向版式（R2.4.0 新增）：控件自上而下堆叠，水平居中，整组垂直居中 */
static void solve_v(box_frame_t *f, const zc_rect_t *z)
{
    const moink_settings_t *s = settings_get();
    int pad = s->box_pad_x;
    if (pad > 24) pad = 24;
    int x0 = z->x + pad, aw = z->w - 2 * pad - 1;
    int y0 = z->y + s->box_pad_y, y1 = z->y + z->h - 1 - s->box_pad_y;
    int gap = 18;

    int th = s->box_time_h ? s->box_time_h : 110;
    if (th < 48) th = 48;
    if (th > 140) th = 140;
    while (th > 40 && seg7_strw(f->time_s, th) > aw) th--;

    int h1 = s->box_row_h ? s->box_row_h : 32;
    if (h1 < 24) h1 = 24;
    if (h1 > 44) h1 = 44;
    while (h1 > 18 && date_w(f, h1) > aw) h1--;
    int r1h = h1 > CJK32_CELL ? h1 : CJK32_CELL;

    int h2 = s->box_row_h ? s->box_row_h : 36;
    if (h2 < 26) h2 = 26;
    if (h2 > 44) h2 = 44;
    while (h2 > 20 && th_w(f, h2) > aw) h2--;
    int r2h = h2 > CJK32_CELL ? h2 : CJK32_CELL;

    int ih = 26;
    while (ih > 18 && seg7_strw(f->ip_s, ih) > aw) ih--;
    f->dh = h1;
    f->thh = h2;

    bool icon_ip = f->vis[ZC_WG_ICON] && f->vis[ZC_WG_IP];
    if (f->vis[ZC_WG_ICON] && !f->vis[ZC_WG_IP] && !f->vis[ZC_WG_TH] && !f->vis[ZC_WG_DATE])
        f->vis[ZC_WG_ICON] = false;      /* 孤图标无挂点：隐藏 */

    int total = 0;
    if (f->vis[ZC_WG_TIME]) total += th;
    if (f->vis[ZC_WG_DATE]) total += gap + r1h;
    if (f->vis[ZC_WG_TH])   total += gap + r2h;
    if (f->vis[ZC_WG_IP])   total += gap + ih;
    if (icon_ip)            total += 0;  /* 图标与 IP 同行 */
    int y = y0 + (y1 - y0 - total) / 2;
    if (y < y0) y = y0;

    if (f->vis[ZC_WG_TIME]) {
        int w = seg7_strw(f->time_s, th);
        f->r[ZC_WG_TIME] = (zc_rect_t){ (int16_t)(x0 + (aw - w) / 2), (int16_t)y,
                                        (int16_t)w, (int16_t)th };
        y += th + gap;
    }
    if (f->vis[ZC_WG_DATE]) {
        int w = date_w(f, h1);
        f->r[ZC_WG_DATE] = (zc_rect_t){ (int16_t)(x0 + (aw - w) / 2), (int16_t)y,
                                        (int16_t)w, (int16_t)r1h };
        y += r1h + gap;
    }
    if (f->vis[ZC_WG_TH]) {
        int w = th_w(f, h2);
        f->r[ZC_WG_TH] = (zc_rect_t){ (int16_t)(x0 + (aw - w) / 2), (int16_t)y,
                                      (int16_t)w, (int16_t)r2h };
        y += r2h + gap;
    }
    if (f->vis[ZC_WG_IP]) {
        int iw = seg7_strw(f->ip_s, ih);
        int itot = iw + (icon_ip ? 22 + 12 : 0);
        int ix = x0 + (aw - itot) / 2;
        f->r[ZC_WG_IP] = (zc_rect_t){ (int16_t)ix, (int16_t)y, (int16_t)iw, (int16_t)ih };
        if (icon_ip)
            f->r[ZC_WG_ICON] = (zc_rect_t){ (int16_t)(ix + iw + 12),
                                            (int16_t)(y + (ih - 22) / 2), 22, 22 };
        y += ih + gap;
    }
}

static void solve_layout(box_frame_t *f, const zc_rect_t *z)
{
    zc_rect_t cz;
    if (custom_rects(f, &cz)) return;    /* 用户自定义：矩形与包围盒都已填 */
    int dir = 0;
    if (s_pwd_zone || (s_remote_active && s_remote_split)) dir = 0;
    else eff_pos_dir(&dir);
    if (dir == 0) solve_h(f, z);
    else          solve_v(f, z);
}

/* 快刷可用底：solid（与整刷同判据）。非 solid（叠加半透明）时像素目标态
 * 含照片色，快刷只有黑白动作码，会失真 → 回退整刷（页面上有说明）。 */
static bool solid_bg(void)
{
    const moink_settings_t *s = settings_get();
    return (s->box_style == SETT_BOX_STYLE_SPLIT && s_photo_split) ||
           s->box_density >= 100 || (s_remote_active && s_remote_split);
}

static void draw_widget(int kind, const zc_rect_t *r, const box_frame_t *f)
{
    if (!r || r->w <= 0 || r->h <= 0) return;
    switch (kind) {
    case ZC_WG_TIME:
        seg7_text(f->time_s, r->x, r->y, r->h, C_BLACK, r->h >= 64 ? 3 : 2);
        break;
    case ZC_WG_DATE: {
        seg7_text(f->date_s, r->x, r->y + (r->h - f->dh) / 2, f->dh, C_BLACK, 2);
        int cx = r->x + seg7_strw(f->date_s, f->dh) + 6;
        int cy = r->y + (r->h - CJK32_CELL) / 2;
        if (f->synced) {
            draw_cjk32(CJK_ZHOU, cx, cy, 1, C_BLACK, 2);
            draw_cjk32(WD7[f->wday & 7], cx + CJK32_ADV, cy, 1, C_BLACK, 2);
        }
        break;
    }
    case ZC_WG_TH: {
        int uy = r->y + (r->h - CJK32_CELL) / 2;
        int hy = r->y + (r->h - f->thh) / 2;
        seg7_text(f->tv, r->x, hy, f->thh, C_BLACK, 2);
        draw_cjk32(CJK_DEGC, r->x + seg7_strw(f->tv, f->thh) + 4, uy, 1, C_BLACK, 2);
        int hx = r->x + seg7_strw(f->tv, f->thh) + 4 + CJK32_CELL + TH_ROW_GAP;
        seg7_text(f->hv, hx, hy, f->thh, C_BLACK, 2);
        draw_cjk32(CJK_PCT, hx + seg7_strw(f->hv, f->thh) + 4, uy, 1, C_BLACK, 2);
        break;
    }
    case ZC_WG_IP:
        seg7_text(f->ip_s, r->x, r->y, r->h, C_BLACK, 2);
        break;
    case ZC_WG_ICON:
        if (f->icon == 1) draw_icon_wifi(r->x, r->y);
        else              draw_icon_excl(r->x, r->y);
        break;
    default:
        break;
    }
}

static void box_compose(void)
{
    const moink_settings_t *s = settings_get();
    if (s_remote_active && !s_remote_split) return;

    zone_prepare();
    const zc_rect_t *z = zc_zone();

    /* 框底：solid = 实体白；叠加 = 哈希抖动（逐像素确定性，跨 tick 稳定，
       快刷对抖动洞外的像素全部保持即可）。 */
    if (solid_bg()) {
        for (int y = z->y; y < z->y + z->h; y++)
            for (int x = z->x; x < z->x + z->w; x++)
                zc_px_set(x, y, C_WHITE);
    } else if (s->box_density > 0) {
        for (int y = z->y; y < z->y + z->h; y++)
            for (int x = z->x; x < z->x + z->w; x++)
                if ((int)(dither_hash(x, y) % 100u) < s->box_density)
                    zc_px_set(x, y, C_WHITE);
    }

    box_frame_t f;
    build_frame(&f);
    solve_layout(&f, z);
    for (int k = 0; k < ZC_WG_COUNT; k++)
        if (f.vis[k]) draw_widget(k, &f.r[k], &f);

    s_state = f;
    s_state_valid = true;
    s_state_fp = box_fp();
    strlcpy(s_drawn_tv, f.vis[ZC_WG_TH] ? f.tv : "", sizeof(s_drawn_tv));
    strlcpy(s_drawn_hv, f.vis[ZC_WG_TH] ? f.hv : "", sizeof(s_drawn_hv));
    s_box_drawn = true;
    box_state_persist();              /* ★R2.6.0：即将上屏的帧写入 RTC 基准 */
}

/* ---- 快刷（局刷）执行 ---- */

static const uint8_t *action_row_provider(int r)
{
    zc_action_row(r, s_act_row);
    return s_act_row;
}

static bool widget_changed(int k, const box_frame_t *a, const box_frame_t *b)
{
    if (a->vis[k] != b->vis[k]) return true;
    if (!b->vis[k]) return false;
    if (a->r[k].x != b->r[k].x || a->r[k].y != b->r[k].y ||
        a->r[k].w != b->r[k].w || a->r[k].h != b->r[k].h) return true;
    switch (k) {
    case ZC_WG_TIME: return strcmp(a->time_s, b->time_s) != 0;
    case ZC_WG_DATE: return strcmp(a->date_s, b->date_s) != 0 ||
                            a->wday != b->wday || a->synced != b->synced;
    case ZC_WG_TH:   return strcmp(a->tv, b->tv) != 0 || strcmp(a->hv, b->hv) != 0;
    case ZC_WG_IP:   return strcmp(a->ip_s, b->ip_s) != 0;
    case ZC_WG_ICON: return a->icon != b->icon;
    default:         return true;
    }
}

static zc_rect_t runion(const zc_rect_t *a, const zc_rect_t *b)
{
    int x0 = a->x < b->x ? a->x : b->x;
    int y0 = a->y < b->y ? a->y : b->y;
    int x1 = (a->x + a->w > b->x + b->w) ? a->x + a->w : b->x + b->w;
    int y1 = (a->y + a->h > b->y + b->h) ? a->y + a->h : b->y + b->h;
    zc_rect_t r = { (int16_t)x0, (int16_t)y0, (int16_t)(x1 - x0), (int16_t)(y1 - y0) };
    return r;
}

/* ---------------- ★R2.6.0 快刷基准 RTC 持久化（深睡唤醒续用局刷） ----------------
 *
 * R2.5.0 事件驱动休眠后，深睡丢 RAM —— 唤醒后的首个分钟刷新只能整刷
 * （15~25 s 闪屏）。快刷基准其实只有几十字节（上次上屏的控件值 + 布局
 * 指纹），存 RTC noinit 即可跨深睡存活：唤醒后的分钟刷新继续走局刷
 * （~0.2 s DRF 不闪屏）。
 *
 * 一致性契约：标记内容 =「面板框区正在显示的那一帧」。
 *   写入点：box_compose / 快刷成功（即将/已经上屏的帧；若随后整刷失败
 *          标记会领先面板一帧 —— 罕见，下一个整刷路径自愈）；
 *   作废点：密码屏（画了别的）、整框清除、方向切换、远端全屏接管、
 *          快刷失败（面板真值未知）、信息框不可见的 compose 跳过；
 *   保留点：深睡本身（overlay_zone_invalidate 只废 RAM 基准 —— 面板
 *          画面不变，标记正是为它而存）。 */

static void box_state_persist(void)
{
    uint8_t vis = 0;
    for (int k = 0; k < ZC_WG_COUNT; k++)
        if (s_state.vis[k]) vis |= (uint8_t)(1u << k);
    s_rtc_box.magic  = OVL_RTC_MAGIC;
    s_rtc_box.fp     = s_state_fp;
    s_rtc_box.vis    = vis;
    s_rtc_box.icon   = (uint8_t)s_state.icon;
    s_rtc_box.synced = s_state.synced ? 1 : 0;
    s_rtc_box.wday   = (uint8_t)s_state.wday;
    strlcpy(s_rtc_box.time_s, s_state.time_s, sizeof(s_rtc_box.time_s));
    strlcpy(s_rtc_box.date_s, s_state.date_s, sizeof(s_rtc_box.date_s));
    strlcpy(s_rtc_box.tv,     s_state.tv,     sizeof(s_rtc_box.tv));
    strlcpy(s_rtc_box.hv,     s_state.hv,     sizeof(s_rtc_box.hv));
    strlcpy(s_rtc_box.ip_s,   s_state.ip_s,   sizeof(s_rtc_box.ip_s));
}

static void box_state_forget(void)
{
    s_rtc_box.magic = 0;             /* RTC 标记作废 */
    s_state_valid = false;           /* RAM 基准一并作废（面板真值已偏离） */
}

/* 深睡唤醒后重建快刷基准（overlay_box_tick 快路径前置，须先 zone_prepare）。
 * 要求布局指纹仍一致（版式/换位 parity 未变 —— 换位到点自动退回整刷）
 * + solid 底。区缓冲内容对快刷无关紧要（diff 只发生在控件并集内，并集
 * 会被重画后 diff），fill_white 仅用于把区置「有效」。失败 = 保持整刷回退。 */
static bool box_state_restore(void)
{
    if (s_rtc_box.magic != OVL_RTC_MAGIC) return false;
    /* ★R2.7.1：上次整刷失败留下的强制全刷标记 —— 拒绝恢复快刷基准
       （面板真值未知），首个到点刷新走整刷重建。 */
    if (s_rtc_ffail.magic == OVL_RTC_FF_MAGIC) {
        ESP_LOGW(TAG, "force-full flag set (last full refresh failed), no fast restore");
        return false;
    }
    if (!solid_bg() || s_pwd_phase) return false;
    if (s_remote_active && !s_remote_split) return false;
    if (s_rtc_box.fp != box_fp()) return false;

    box_frame_t f;
    memset(&f, 0, sizeof(f));
    for (int k = 0; k < ZC_WG_COUNT; k++)
        f.vis[k] = ((s_rtc_box.vis >> k) & 1u) != 0;
    strlcpy(f.time_s, s_rtc_box.time_s, sizeof(f.time_s));
    strlcpy(f.date_s, s_rtc_box.date_s, sizeof(f.date_s));
    strlcpy(f.tv,     s_rtc_box.tv,     sizeof(f.tv));
    strlcpy(f.hv,     s_rtc_box.hv,     sizeof(f.hv));
    strlcpy(f.ip_s,   s_rtc_box.ip_s,   sizeof(f.ip_s));
    f.icon   = (int)s_rtc_box.icon;
    f.synced = s_rtc_box.synced != 0;
    f.wday   = (int)s_rtc_box.wday;

    solve_layout(&f, zc_zone());
    s_state = f;
    s_state_valid = true;
    s_state_fp = s_rtc_box.fp;
    strlcpy(s_drawn_tv, f.vis[ZC_WG_TH] ? f.tv : "", sizeof(s_drawn_tv));
    strlcpy(s_drawn_hv, f.vis[ZC_WG_TH] ? f.hv : "", sizeof(s_drawn_hv));
    zc_fill_white();                  /* 区置有效（内容占位，diff 只用并集内） */
    ESP_LOGI(TAG, "box fast basis restored from RTC (last %s)", s_state.time_s);
    return true;
}

/* ---- ★R2.7.1 快刷黑名单冷却期 ----
 * 失败拉黑 OVL_FAST_COOLDOWN_MS：期间到点刷新直接整刷（不再每刷两次
 * LUT 探测），期满自动放行一次快刷试探；连续失败达 OVL_FAST_FAIL_ALARM
 * 次告警（LUT/面板疑似硬件性问题，不再是静默悬空态）。 */
#define OVL_FAST_COOLDOWN_MS (10ULL * 60 * 1000)
#define OVL_FAST_FAIL_ALARM  5
static uint32_t s_fast_fail_streak = 0;
static int64_t  s_fast_cooldown_until = 0;    /* esp_timer 毫秒；0 = 未拉黑 */

static bool fast_path_ready(void)
{
    if (s_fast_ok) return true;
    if (s_fast_cooldown_until == 0) return false;
    if ((int64_t)esp_timer_get_time() / 1000 < s_fast_cooldown_until) return false;
    ESP_LOGI(TAG, "fast refresh cooldown over, retry");
    return true;    /* 放行试探：失败会重新拉黑并续冷却 */
}

static void fast_fail_note(void)
{
    s_fast_fail_streak++;
    s_fast_cooldown_until = (int64_t)esp_timer_get_time() / 1000 +
                            (int64_t)OVL_FAST_COOLDOWN_MS;
    if (s_fast_fail_streak >= OVL_FAST_FAIL_ALARM)
        ESP_LOGE(TAG, "fast refresh failed %u times in a row (LUT/panel suspect?)",
                 (unsigned)s_fast_fail_streak);
}

/* 到点 / 数值变化统一入口（display_task 上下文）：条件满足走快刷（局刷，
 * 仅变更控件重画 + 动作码 DRF），否则整刷。count_cycle 语义同 redraw。
 * ★R2.6.0：本函数由 power_enter_deep_sleep（深睡前）调用 —— 只废 RAM
 * 基准；RTC 持久化基准【刻意保留】（面板画面不变，唤醒后续用，见
 * 「快刷基准 RTC 持久化」段）。其它「面板真值未知」的路径请改调
 * box_state_forget() 语义（直接置 s_rtc_box.magic = 0）。 */
void overlay_zone_invalidate(void)
{
    zc_invalidate();
    s_state_valid = false;
}

void overlay_box_basis_forget(void)
{
    /* ★R2.6.0：残影清理等把整屏洗成纯色 —— 面板框区真值未知，
       RAM + RTC 基准一并作废（下一次到点刷新回退整刷）。 */
    box_state_forget();
}

/* HTTP bwg 串 → blob："t:x,y,w,h;d:..;h:..;i:..;n:.."（t时间 d日期 h温湿
 * iIP n图标；坐标为当前方向组用户画布）。"clear" = 清除本组自定义。
 * 校验：屏内 + w/h≥8 + 互不重叠（需求：不越屏不重叠）。返回 0 成功。 */
int overlay_box_wg_parse(const char *str, uint8_t blob[SETT_BOX_WG_BYTES])
{
    const moink_settings_t *s = settings_get();
    box_wg_t *wg = (box_wg_t *)blob;
    const box_wg_t *cur = (const box_wg_t *)s->box_wg;

    geom_sync();
    const int slot = s_orient & 1;
    memset(blob, 0, SETT_BOX_WG_BYTES);
    wg->defined[slot ^ 1] = cur->defined[slot ^ 1];
    memcpy(wg->rect[slot ^ 1], cur->rect[slot ^ 1], sizeof(wg->rect[0]));

    if (!strcmp(str, "clear")) return 0;

    bool seen[ZC_WG_COUNT] = { false };
    zc_rect_t r[ZC_WG_COUNT];
    const char *p = str;
    while (*p) {
        int kind;
        switch (*p) {
        case 't': kind = ZC_WG_TIME; break;
        case 'd': kind = ZC_WG_DATE; break;
        case 'h': kind = ZC_WG_TH;   break;
        case 'i': kind = ZC_WG_IP;   break;
        case 'n': kind = ZC_WG_ICON; break;
        default:  return -1;
        }
        int x, y, w, h, used = 0;
        if (sscanf(p, "%*c:%d,%d,%d,%d%n", &x, &y, &w, &h, &used) != 4 || used < 6)
            return -1;
        zc_rect_t t = { (int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h };
        if (!zc_rect_valid(&t, s_cw, s_ch)) return -1;
        r[kind] = t;
        seen[kind] = true;
        p += used;
        if (*p == ';') p++;
        else if (*p)   return -1;
    }
    for (int a = 0; a < ZC_WG_COUNT; a++)
        for (int b = a + 1; b < ZC_WG_COUNT; b++)
            if (seen[a] && seen[b] && zc_rect_overlap(&r[a], &r[b])) return -1;
    bool any = false;
    for (int k = 0; k < ZC_WG_COUNT; k++)
        if (seen[k]) {
            wg->rect[slot][k][0] = r[k].x;
            wg->rect[slot][k][1] = r[k].y;
            wg->rect[slot][k][2] = r[k].w;
            wg->rect[slot][k][3] = r[k].h;
            any = true;
        }
    wg->defined[slot] = any ? 1 : 0;
    return 0;
}

void overlay_box_tick(bool count_cycle)
{
    bool ip_now = false;

    if (!overlay_box_visible()) {
        overlay_box_clear();
        return;
    }
    /* ★R2.7.1：轻唤醒（无射频）整体跳过联网探测 —— check_internet 契约
       上无网络栈第一时间空回，这里显式分流防未来实现回归阻塞轻链路。 */
    if (!power_wake_is_light()) wifi_mgr_check_internet();
    ip_now = box_show_ip();

    if (fast_path_ready() && !s_pwd_phase && !(s_remote_active && !s_remote_split)) {
        zone_prepare();
        /* ★R2.6.0：深睡唤醒后 RAM 基准丢失 —— 先试 RTC 恢复（布局指纹
           一致才成，换位到点自动退回整刷）；恢复不成走下方整刷。 */
        if (!s_state_valid || !zc_valid()) box_state_restore();
        const zc_rect_t *az = zc_zone();
        if (s_state_valid && zc_valid() && s_state_fp == box_fp() && solid_bg()) {
            box_frame_t f;
            build_frame(&f);
            solve_layout(&f, az);

            bool changed[ZC_WG_COUNT] = { false };
            zc_rect_t u = { 0, 0, 0, 0 };
            bool any = false;
            for (int k = 0; k < ZC_WG_COUNT; k++) {
                if (!widget_changed(k, &s_state, &f)) continue;
                changed[k] = true;
                zc_rect_t uk = runion(&s_state.r[k], &f.r[k]);
                u = any ? runion(&u, &uk) : uk;
                any = true;
            }
            if (!any) {
                /* ★R2.7.1 无变更控件的到点 tick 直接空过 —— 原先回落整刷，
                   无网/纯温湿档会变成「每分钟全刷」功耗回退；画面本无变化。 */
                return;
            }
            if ((size_t)((u.w + 7) / 8) * (size_t)u.h <= ZC_SCRATCH_MAX) {
                if (frame_lock(5000)) {
                    /* 旧值重渲染进 1bpp 暂存（确定性渲染 = 完整旧态重建） */
                    zc_scratch_begin(&u);
                    zc_set_render_scratch(true);
                    for (int k = 0; k < ZC_WG_COUNT; k++)
                        if (changed[k] && s_state.vis[k])
                            draw_widget(k, &s_state.r[k], &s_state);
                    zc_set_render_scratch(false);
                    /* 并集白底 + 新值进区缓冲 */
                    for (int y = u.y; y < u.y + u.h; y++)
                        for (int x = u.x; x < u.x + u.w; x++)
                            zc_px_set(x, y, C_WHITE);
                    for (int k = 0; k < ZC_WG_COUNT; k++)
                        if (changed[k] && f.vis[k])
                            draw_widget(k, &f.r[k], &f);

                    int64_t el = 0;
                    bool acc = false;
                    int rr = epd_fast_refresh(s_fast_lut, action_row_provider,
                                              &el, &acc);
                    if (rr == 0 && acc) {
                        s_state = f;
                        strlcpy(s_drawn_tv, f.vis[ZC_WG_TH] ? f.tv : "", sizeof(s_drawn_tv));
                        strlcpy(s_drawn_hv, f.vis[ZC_WG_TH] ? f.hv : "", sizeof(s_drawn_hv));
                        box_state_persist();  /* ★R2.6.0：快刷成功即新基准 */
                        s_fast_ok = true;         /* ★R2.7.1：冷却试探成功，恢复快刷常路径 */
                        s_fast_fail_streak = 0;
                        frame_unlock();
                        ESP_LOGI(TAG, "box fast tick (DRF %lld ms)", (long long)el);
                        goto cycle;
                    }
                    /* 快刷不可用：拉黑 + 状态作废（区缓冲已画新值未上屏），
                       下方整刷重截重画自愈 */
                    s_fast_ok = false;
                    zc_invalidate();
                    s_state_valid = false;
                    box_state_forget();      /* ★R2.6.0：面板真值未知，RTC 基准同废 */
                    frame_unlock();
                    fast_fail_note();        /* ★R2.7.1：拉黑计数 + 冷却期 + 超限告警 */
                    ESP_LOGW(TAG, "fast refresh %s -> blacklist %dmin, full redraw",
                             rr != 0 ? "failed" : "LUT not accepted",
                             (int)(OVL_FAST_COOLDOWN_MS / 60000));
                }
            }
        }
    }

    overlay_box_redraw(count_cycle);
    return;

cycle:
    if (count_cycle && ip_now &&
        settings_get()->box_ip_mode == SETT_BOX_IP_CYCLES && s_ip_left > 0)
        s_ip_left--;
}

/* ★R2.6.1：NTP 步进后再对齐（wifi_mgr SNTP 回调 → UI_EV_TIME_STEP → 这里）。
 * 深睡唤醒后系统钟带 RTC 慢漂（分钟边界跟着钟一起漂），SNTP 步进把钟拗回
 * 真时后：
 *   1) 分钟定时器按新钟重排（原 one-shot 按旧钟计算，下一个整分会走偏）；
 *   2) 时钟控件显示值落后了一个分钟（步进跨分界才会发生）且快刷可用时，
 *      立即走局刷校正（~0.2s 不闪屏，不消耗 IP 周期）；快刷不可用/基准
 *      丢失时只重排定时器 —— 下一个到点刷新自然纠正，不为秒级误差整刷。
 * display_task 上下文（事件经 ui_q 串行，与 minute_cb 的重排并发安全：
 * 两侧都算「下一个整分」，目标一致）。 */
void overlay_time_realign(void)
{
    if (s_pwd_phase || !s_boot_done) return;

    /* 1) 分钟定时器重排到「新钟」的下一个整分。 */
    time_t now = time(NULL);
    time_t next = ((now / 60) + 1) * 60;
    esp_timer_stop(s_min_timer);
    esp_timer_start_once(s_min_timer, (uint64_t)(next - now) * 1000000ULL);

    /* 2) 时钟显示校正：仅步进跨分界（当前分钟 != 上屏分钟）且快刷可用。 */
    if (!overlay_box_visible()) return;
    if (s_remote_active && !s_remote_split) return;    /* 远端全屏无本地框 */
    if (!(s_fast_ok && s_state_valid && zc_valid() &&
          s_state_fp == box_fp() && solid_bg())) {
        return;   /* 快刷不可用：只重排定时器，交给下一个到点刷新 */
    }
    box_frame_t f;
    build_frame(&f);
    if (!f.vis[ZC_WG_TIME]) return;                     /* 时钟控件未开 */
    if (strcmp(f.time_s, s_state.time_s) == 0) return;  /* 同一分钟：无需校正 */
    ESP_LOGI(TAG, "time stepped: clock stale (%s -> %s), re-align",
             s_state.time_s, f.time_s);
    overlay_box_tick(false);        /* 复用 tick 的快刷路径；不消耗 IP 周期 */
}

/* 到点重画信息框（含干净条带重截 + 合成 + 整刷）。在 display_task 上下文调用。
   count_cycle：本次刷新是否消耗一个 IP 显示周期 —— 到点/数值变化刷新（BOX_TICK）
   为真；改设置触发的重画（BOX_APPLY/NET_CHANGED）与上传合成不消耗。
   R2.1.0：当前不应显示信息栏（无网无蓝牙 / 远端全屏）时改为还原纯照片。 */
void overlay_box_redraw(bool count_cycle)
{
    if (!overlay_box_visible()) {
        overlay_box_clear();
        return;
    }

    /* ★R2.7.0：整刷 15~25s —— 轻唤醒（分钟局刷）的事件入口脉冲只有 3s，
       这里自报 25s 忙脉冲（多源取最长），防整刷中途被判闲入睡（面板
       序列波死中间）。 */
    power_busy_pulse(25);

    /* ★R2.7.1：轻唤醒（无射频）跳过联网探测（与 tick 同一分流）。 */
    if (!power_wake_is_light()) wifi_mgr_check_internet();

    bool ip_now = box_show_ip();   /* 先留样：本帧是否显示 IP 行 */

    /* 持锁段：重截干净条带（覆盖上一次的信息框/密码屏）-> 叠新信息框 -> 整刷。
       锁内进行可避免与上传的条带截取并发写 s_strip。 */
    if (!frame_lock(5000)) {
        ESP_LOGW(TAG, "frame lock timeout, box redraw skipped");
        return;
    }
    zone_prepare();                    /* 截取前应用区（位置/方向/换位变化在此生效） */
    frame_capture_strip_locked();      /* 失败时 frame.c 兜底白底，照画不误 */
    box_compose();
    int dr = frame_display_locked();
    frame_unlock();
    if (dr != 0) {
        /* ★R2.7.1 整刷失败 = 面板真值未知（compose 在刷屏前已把快刷基准写
           进 RTC，基准领先面板一帧）：作废基准 + 置 RTC 强制全刷标记
           （下次开机首个到点刷新必整刷，成功后清除）。 */
        s_rtc_ffail.magic = OVL_RTC_FF_MAGIC;
        box_state_forget();
        ESP_LOGE(TAG, "full refresh failed: basis dropped, force-full next boot");
        return;
    }
    s_rtc_ffail.magic = 0;             /* ★R2.7.1：整刷成功，清除强制全刷标记 */

    /* IP 行按"刷新周期"计数：周期模式下本帧显示了 IP → 消耗一个周期。 */
    if (count_cycle && ip_now &&
        settings_get()->box_ip_mode == SETT_BOX_IP_CYCLES && s_ip_left > 0)
        s_ip_left--;

    ESP_LOGI(TAG, "box redrawn (ip line %s, %d cycles left)",
             ip_now ? "on" : "off", s_ip_left);
}

/* 信息框从开改关：重截干净条带并整屏刷新（display_task 上下文）。 */
void overlay_box_clear(void)
{
    if (!s_box_drawn) return;
    if (!frame_lock(5000)) return;
    frame_capture_strip_locked();
    frame_display_locked();
    frame_unlock();
    s_box_drawn = false;
    s_state_valid = false;            /* ★R2.6.0：面板框区已不是任何基准帧 */
    s_rtc_box.magic = 0;
    ESP_LOGI(TAG, "box cleared");
}

/* R2.0.3：把信息框画进【当前】条带（不刷屏）。用于上传显示 / 切图 / 条带还原后
 * 让框立即跟上 —— 此前只有到点重画才有框，上传后框内空白就是它。
 * R2.1.0：信息栏当前不应显示（box_en 关 / 无网无蓝牙 / 远端全屏）时不画。 */
void overlay_box_compose_strip(void)
{
    if (!overlay_box_visible() || s_pwd_phase || !zc_valid()) {
        /* ★R2.6.0：框此刻不画（不可见/密码屏/区失效）—— 面板上没有基准帧，
           RTC 基准一并作废，防「唤醒后快刷对着不存在的旧框 diff」。 */
        if (!s_pwd_phase) s_rtc_box.magic = 0;
        return;
    }
    box_compose();
}

/* R2.0.3：标记当前显示源是否为"分割式合成"（页面上传 split=1，帧头 hdr[15]
 * 携带；分割式 = 照片让出顶部 160 行，信息框底恒为纯白）。
 * 切换显示源（上传 / 切图 / 开机恢复）时由 frame.c 设置。 */
void overlay_set_photo_split(bool on)
{
    s_photo_split = on;
}

/* R2.0.6：把 IP 行周期计数重置为当前设置值。两个入口共用：
 *   - STA 拿到 IP（入网成功，wifi_mgr 调用 overlay_ip_notify_joined）；
 *   - 信息框设置变更且 IP 行处于周期档（main.c 调用）—— 已入网状态下从
 *     关闭/常显切到周期档若不重置，计数恒 0，IP 行要等下次重新入网才出现，
 *     用户会误以为设置无效。 */
void overlay_ip_cycles_reset(void)
{
    s_ip_left = settings_get()->box_ip_cyc;
    ESP_LOGI(TAG, "IP line cycles reset to %d", s_ip_left);
}

/* R2.0.3：STA 拿到 IP（入网成功）时重置 IP 行的显示周期计数（wifi_mgr 调用）。 */
void overlay_ip_notify_joined(void)
{
    overlay_ip_cycles_reset();
    ESP_LOGI(TAG, "LAN joined: IP line cycles reset to %d", s_ip_left);
}

/* ---------------- R2.1.0：远端样式 / 上电门控 / 网络变化 ---------------- */

void overlay_set_remote(bool active, bool split)
{
    s_remote_active = active;
    s_remote_split = split;
    /* ★R2.6.0：远端全屏接管 → 框区被远端内容覆盖，快刷基准（含 RTC）作废。 */
    if (active && !split) {
        s_state_valid = false;
        s_rtc_box.magic = 0;
    }
}

/* ★R2.6.0：唤醒补刷 —— 深睡定时唤醒所瞄准的到点事件若被上电门控吃掉
 *（唤醒提前量不够 / RTC 慢漂 / 门控耗时长，边界分钟在 s_boot_done 置位
 * 前溜走），minute_cb 的整分判据要再等整个间隔。这里在门控完成即刻按
 * RTC 标记补发：目标分钟已到且仍在同一对齐周期内 → 立即触发对应事件
 *（时钟分钟刷新 / 远端拉取 / 轮播 / 换位）。*/
static void catchup_check(void)
{
    if (power_wake_purpose() != WAKE_PURPOSE_TIMER_EVENT) return;

    uint8_t evt = PWR_EVT_NONE;
    int64_t tgt = 0;
    if (!power_wake_event(&evt, &tgt)) return;

    const moink_settings_t *s = settings_get();
    uint32_t iv = 0;
    int post_ev = 0;
    bool kick_remote = false;

    switch (evt) {
    case PWR_EVT_BOX:      iv = s->box_iv_min;  post_ev = OV_EV_BOX_TICK; break;
    case PWR_EVT_MOVE:     iv = s->box_move_iv; post_ev = OV_EV_BOX_TICK; break;
    case PWR_EVT_REMOTE:   iv = s->remote_iv;   kick_remote = true;       break;
    case PWR_EVT_CAROUSEL: iv = s->caro_iv;     post_ev = OV_EV_CAROUSEL_NEXT; break;
    case PWR_EVT_SYNC:
        /* ★R2.7.0 校时保底升格的全功能唤醒：SNTP 已在 boot 门控里试过
           （步进则 OV_EV_TIME_STEP 已即时校正），无拉取/切图语义 ——
           只补发一次分钟刷新（换位 parity 变了则 tick 内部自动整刷）。 */
        post_ev = OV_EV_BOX_TICK;
        break;
    default:               return;              /* WAKE / NONE：无补刷语义 */
    }
    if (iv == 0 && evt != PWR_EVT_SYNC) return;  /* 睡着期间该事件被关了
                                                     （SYNC 无对齐间隔恒补发） */
    if (kick_remote && !wifi_mgr_up()) return;   /* ★R2.7.0：无网络栈的轻开机
                                                     不启拉取（remote 靠 WiFi） */
    /* SYNC 无对齐间隔（power 侧升格而来），唤醒晚于目标几分钟很正常 ——
       恒补发（补的是分钟刷新，晚几分钟也只是多跳一个数字）。 */
    if (evt != PWR_EVT_SYNC && !pwr_sched_missed((int64_t)time(NULL), tgt, iv))
        return;

    /* 抢在 idle_monitor 前占住忙窗：补发的事件（快刷/整刷/拉取）真正开始
       前的几秒不能被判成「闲到点」而睡掉（事件窗口可能已经耗尽）。 */
    power_busy_pulse(10);
    if (kick_remote) remote_kick();
    if (post_ev && s_post) s_post(post_ev);
    ESP_LOGI(TAG, "wake catch-up: %s boundary missed during boot gate, re-fire",
             pwr_sched_evt_name(evt));
}

void overlay_set_boot_done(void)
{
    if (!s_boot_done) {
        s_boot_done = true;
        ESP_LOGI(TAG, "boot gate done, minute scheduler armed");
        catchup_check();          /* ★R2.6.0：门控吃掉的到点事件立即补发 */
    }
}

/* ★R2.7.1：boot 门控是否已完成（power_should_sleep 的「门控未完成绝不
 * 入睡」判据用；腰斩 boot_gate_task = 「永不清醒」循环的防线）。 */
bool overlay_boot_done(void)
{
    return s_boot_done;
}

/* 需求 7.2：网络状态变化触发 —— wifi_mgr 三连确认后投 OV_EV_NET_CHANGED，
 * display_task 调到这里：应显示则重画（不消耗 IP 周期），应隐藏则还原纯照片。 */
void overlay_box_refresh(void)
{
    if (s_pwd_phase || !s_boot_done) return;
    if (overlay_box_visible()) overlay_box_redraw(false);
    else                       overlay_box_clear();
}

/* ---------------- 分钟调度（R2.1.0 起为统一刷新触发的发源地） ---------------- */

static void minute_cb(void *arg)
{
    (void)arg;

    /* 对齐下一个整分钟边界重排（按时间而非时长：NTP 校时后自动走准）。 */
    time_t now = time(NULL);
    time_t next = ((now / 60) + 1) * 60;
    esp_timer_stop(s_min_timer);
    esp_timer_start_once(s_min_timer, (uint64_t)(next - now) * 1000000ULL);

    if (s_pwd_phase) return;                  /* 重置流程独占屏幕 */
    if (!s_boot_done) return;                 /* R2.1.0：上电门控未完成（需求 3） */
    const moink_settings_t *s = settings_get();

    /* ★R2.7.1 取模基准统一：B0/B/C/D 全部用 epoch 分钟（mnow）—— 与
       pwr_sched_next / pwr_sched_missed 及换位 parity（eff_pos_dir）同
       基准；CST-8 下间隔档（1/5/10/30/60，均整除 480 分钟时差）与 tm_min
       对齐等价，SNTP 步进后的本地边界语义不变。 */
    long mnow = (long)(now / 60);

    /* ★R2.7.1：温湿防抖基准跨深睡持久化（s_rtc_val，RTC noinit）——
       magic/范围校验，掉电/乱码按从未触发处理（-100）。 */
    if (s_rtc_val.magic != OVL_RTC_VAL_MAGIC ||
        s_rtc_val.last_val_min < 0 || s_rtc_val.last_val_min > (int32_t)mnow) {
        s_rtc_val.magic = OVL_RTC_VAL_MAGIC;
        s_rtc_val.last_val_min = -100;
    }

    /* ---- 触发 A（需求 7.3）：温湿度数值变化 → 立即重画（不等间隔边界）。
       与上次画上屏的串比对；最小间隔 2 分钟防 0.1 抖动频繁闪屏。 */
    if (s->box_en && (s->box_show & SETT_BOX_SHOW_TH) && overlay_box_visible() &&
        ble_sensor_bound() && ble_sensor_valid()) {
        ble_state_t bs = ble_sensor_state();
        char tv[12], hv[12];
        fmt_tenth(tv, sizeof(tv), bs.temp_c);
        fmt_tenth(hv, sizeof(hv), bs.hum_pct >= 0 ? bs.hum_pct : -9999.0f);
        if ((strcmp(tv, s_drawn_tv) || strcmp(hv, s_drawn_hv)) &&
            mnow - (long)s_rtc_val.last_val_min >= 2) {
            s_rtc_val.last_val_min = (int32_t)mnow;
            ESP_LOGI(TAG, "th value changed (%s C / %s %%), trigger redraw", tv, hv);
            if (s_post) s_post(OV_EV_BOX_TICK);
            return;                /* 本分钟已刷：不再叠加到点刷新 */
        }
    }

    /* ---- 触发 B0（R2.4.0 防老化换位）：换位间隔到点 —— parity 翻转，
       指纹随之变化，tick 内部自动回退整刷（新位置整幅重画 + 工厂刷清屏，
       顺带清理信息框残影 —— 防屏幕老化的本意）。 */
    if (s->box_en && s->box_move_iv && overlay_box_visible() &&
        (uint32_t)mnow % (uint32_t)s->box_move_iv == 0) {
        if (s_post) s_post(OV_EV_BOX_TICK);
        return;                       /* 本分钟已刷：不再叠加到点刷新 */
    }

    /* ---- 触发 B（需求 7.1）：时间对齐到点重画 —— 分钟数 % 间隔 == 0。
       ★R2.7.1：判据与入睡侧统一（box_minute_on，见其注释）—— 单机
       时钟态离线也照常分钟触发（时钟控件离线可画），两侧不再不对称。 */
    if (s->box_iv_min && box_minute_on() &&
        (uint32_t)mnow % (uint32_t)s->box_iv_min == 0) {
        if (s_post) s_post(OV_EV_BOX_TICK);   /* 外网探测移入 display_task（DNS 可能
                                                 阻塞秒级，不能卡 esp_timer 任务） */
    }

    /* ---- 触发 C（需求 6）：远端拉取到点 —— remote_iv 对齐，提醒拉取任务。
       remote 模块自己判断网络/开关/密码重置状态，拉不到时内容页保持不变。
       ★R2.7.0：无网络栈的轻开机（分钟局刷不起射频）不启拉取 —— 拉取
       依赖 WiFi 栈；下一个全功能唤醒的补刷/到点自然补拉。 */
    if (s->remote_en && s->remote_iv && wifi_mgr_time_synced() &&
        wifi_mgr_up() &&
        (uint32_t)mnow % (uint32_t)s->remote_iv == 0) {
        remote_tick();
    }

    /* ---- 触发 D（需求 12）：信息栏不展示（含 box_en 关 / 无网无蓝牙隐藏）且
       远端未接管时，图库按用户间隔自动轮播。 */
    if (s->caro_iv && !s_remote_active && !overlay_box_visible() &&
        (uint32_t)mnow % (uint32_t)s->caro_iv == 0) {
        int count = 0, cur = 0;
        store_meta_get(&count, &cur);
        if (count > 1) {
            ESP_LOGI(TAG, "gallery auto-rotate tick (count %d)", count);
            if (s_post) s_post(OV_EV_CAROUSEL_NEXT);
        }
    }
}

void overlay_init(void (*post)(int ev))
{
    s_post = post;
    if (!s_fast_lut_ready) {
        if (lut_self_check()) {
            /* ★R2.6.1：清理配方多轮化（降残影）—— 每轮六扫描：
               P3(Mode0) 预脉冲 + N3(Mode1)/L00 目标段，轮内正负交变
               （旧黑残影的正场回收 + 负场拉白），总扫描 6×轮 = 18
               （R2.6.0 为 15），DRF ≈ 150ms，仍远快于整刷；
               未变更像素动作码 00 不受影响。 */
            lut_build_num_ghost(s_fast_lut, OVL_FAST_DRIVE_ROUNDS);
        }
        else ESP_LOGE(TAG, "R20 encoder self-check failed, fast refresh disabled");
        s_fast_lut_ready = true;
    }
    if (!s_started) {
        const esp_timer_create_args_t margs = {
            .callback = &minute_cb,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "ovl_minute",
        };
        esp_timer_create(&margs, &s_min_timer);
        /* 先 1 秒一跳，等 NTP 对上后 minute_cb 自然切换到整分钟对齐。 */
        esp_timer_start_periodic(s_min_timer, 1000000ULL);
        s_started = true;
        ESP_LOGI(TAG, "minute scheduler started");
    }
}

/* ---------------- R2.5.0：事件驱动休眠的入睡侧问询 ----------------
 *
 * 判据与 minute_cb 触发器一一对应，但按入睡时刻评估（唤醒后状态可能已变，
 * 触发侧 minute_cb 实判；判重最多浪费一个 60s 收尾窗口）：
 *   BOX/MOVE   box_en 且睡时信息栏可见（可见 = 醒后大概率有得重画；
 *              ★R2.6.2 单机时钟态也算可见 —— 时钟离线可画，分钟唤醒
 *              链不再随 STA/蓝牙的瞬时状态断链）
 *   REMOTE     remote 开 + host 已配 + 睡时在 STA 模式（拉取要走路由器）
 *   CAROUSEL   caro_iv 且图库 >1 且非远端接管、信息栏不展示
 * 全不满足 → 返回 0（power 侧只剩按键 / wake_s / 看护唤醒）。 */
uint32_t overlay_next_wake_s(uint8_t *evt_out, int64_t *at_out)
{
    const moink_settings_t *s = settings_get();
    pwr_sched_in_t in = {0};
    const bool box_on = box_minute_on();   /* ★R2.7.1：与 minute_cb 触发 B 同判据 */

    if (box_on && s->box_iv_min)
        in.box_iv_min = s->box_iv_min;
    if (box_on && s->box_move_iv)
        in.move_iv_min = s->box_move_iv;
    if (s->remote_en && s->remote_host[0] && s->remote_iv &&
        wifi_mgr_mode() == NETIF_MODE_STA)
        in.rmt_iv_min = s->remote_iv;
    if (s->caro_iv && !s_remote_active && !overlay_box_visible()) {
        int count = 0, cur = 0;
        store_meta_get(&count, &cur);
        if (count > 1) in.caro_iv_min = s->caro_iv;
    }

    pwr_sched_out_t o;
    pwr_sched_next((int64_t)time(NULL), &in, &o);
    if (evt_out) *evt_out = o.event;
    if (at_out)  *at_out  = o.at_epoch;
    return o.in_s;
}

/* ---------------- 密码重置流程 ---------------- */

static void pwd_timer_cb(void *arg)
{
    (void)arg;
    if (s_post) s_post(OV_EV_PWD_SHOW);
}

void overlay_pwd_timer_start(void)
{
    if (!s_pwd_timer) {
        const esp_timer_create_args_t targs = {
            .callback = &pwd_timer_cb,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "ovl_pwd",
        };
        esp_timer_create(&targs, &s_pwd_timer);
    } else {
        esp_timer_stop(s_pwd_timer);
    }
    esp_timer_start_once(s_pwd_timer, 60ULL * 1000000ULL);
}

bool overlay_pwd_reset_active(void) { return s_pwd_phase != 0; }

bool overlay_pwd_reset_request(void)
{
    if (s_pwd_phase) return false;
    s_pwd_phase = 1;
    if (s_post) s_post(OV_EV_PWD_RESET);
    return true;
}

void overlay_pwd_phase1_draw(void)
{
    if (!frame_lock(5000)) { s_pwd_phase = 0; return; }

    /* ★R2.6.0：密码屏要画别的内容 —— 快刷基准（含 RTC 持久化）作废，
       否则阶段结束后首个分钟快刷会对着不存在的旧框 diff 出花屏。 */
    s_state_valid = false;
    s_rtc_box.magic = 0;

    /* 顶部全幅条带（密码屏临时区覆盖；流程结束后恢复正常信息框区）：
       纯白铺底 + 红色「重置密码中」（R2.0.4：32px 思源宋体，96px 高）。 */
    s_pwd_zone = true;
    zone_prepare();
    overlay_strip_fill_white();
    static const cjk_idx_t MSG1[5] = { CJK_CHONG, CJK_ZHI, CJK_MI, CJK_MA, CJK_ZHONG };
    int scale = 3, adv = CJK32_CELL * scale + 3;
    int x = (overlay_canvas_w() - (5 * adv - 3)) / 2;
    for (int i = 0; i < 5; i++) {
        draw_cjk32(MSG1[i], x, (160 - CJK32_CELL * scale) / 2, scale, C_RED, 0);
        x += adv;
    }
    frame_display_locked();
    frame_unlock();
    s_pwd_zone = false;
    ESP_LOGW(TAG, "pwd reset phase 1 shown");
}

void overlay_pwd_phase2_draw(void)
{
    char pass[SETT_WEB_PASS_LEN];
    settings_gen_web_pass(pass, sizeof(pass));

    if (!frame_lock(5000)) { s_pwd_phase = 0; return; }

    s_state_valid = false;            /* ★R2.6.0：同 phase1 —— 基准作废 */
    s_rtc_box.magic = 0;

    s_pwd_zone = true;
    zone_prepare();
    overlay_strip_fill_white();
    /* 「新密码」红色（32px 宋体 64px 高）+ 6 位数字红色加粗（48px），条带内垂直居中。 */
    static const cjk_idx_t MSG2[3] = { CJK_XIN, CJK_MI, CJK_MA };
    int cscale = 2, dsc = 6;
    int cadv = CJK32_CELL * cscale + 2, dadv = 8 * dsc + dsc;
    int total = 3 * cadv - 2 + 20 + (6 * dadv - dsc);
    int x = (overlay_canvas_w() - total) / 2;
    int cy = (160 - CJK32_CELL * cscale) / 2;

    for (int i = 0; i < 3; i++) {
        draw_cjk32(MSG2[i], x, cy, cscale, C_RED, 0);
        x += cadv;
    }
    x += 20 - 2;
    draw_text8(pass, x, cy + (CJK32_CELL * cscale - 8 * dsc) / 2, dsc, C_RED, 0);

    frame_display_locked();
    frame_unlock();
    s_pwd_zone = false;
    s_pwd_phase = 0;
    ESP_LOGW(TAG, "pwd reset phase 2 shown (new pass set)");
}
