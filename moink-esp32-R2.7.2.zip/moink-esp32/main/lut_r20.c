/*
 * 墨印主固件（R2.4.0 自 verify_fw/video_fw 1:1 复制）—— R20 波形表编码器实现（纯 C，无 ESP-IDF 依赖）。
 * 编码关系与 host/lut_codec.py 一致；任何改动都要重跑原生对拍闸门。
 */
#include "lut_r20.h"

#include <string.h>

/* 逻辑 bit i → wire bit WIRE_BIT[i]（ref docs/04-lut.md §5 实测位重排） */
static const uint8_t WIRE_BIT[8] = {4, 7, 6, 1, 0, 3, 2, 5};

uint8_t lut_wire_encode(uint8_t logical)
{
    uint8_t p = 0;
    for (int i = 0; i < 8; i++) {
        if (logical & (uint8_t)(1u << i)) {
            p |= (uint8_t)(1u << WIRE_BIT[i]);
        }
    }
    return (uint8_t)(0xFFu ^ p);
}

uint8_t lut_wire_decode(uint8_t wire)
{
    uint8_t p = (uint8_t)(wire ^ 0xFFu);
    uint8_t l = 0;
    for (int i = 0; i < 8; i++) {
        if (p & (uint8_t)(1u << WIRE_BIT[i])) {
            l |= (uint8_t)(1u << i);
        }
    }
    return l;
}

unsigned lut_state_scans(const lut_state_t *st)
{
    unsigned abc = (unsigned)st->frames[0] + st->frames[1] + st->frames[2];
    unsigned def = (unsigned)st->frames[3] + st->frames[4] + st->frames[5];
    return (unsigned)st->g * (abc * st->ra + def * st->rb);
}

void lut_table_clear(uint8_t *tbl)
{
    memset(tbl, 0xFF, LUT_R20_BYTES);
}

void lut_table_set_header_ena(uint8_t *tbl)
{
    /* ref 短波形族的共同配置：2048B 逻辑零底板 + 头部字节 6 置逻辑 1
       （使 H1 首槽恢复随扫描数计数；本族表的动作都在 H2/H3/H5，不受影响） */
    tbl[6] = lut_wire_encode(0x01);
}

void lut_table_set_state(uint8_t *tbl, int lane, int slot, const lut_state_t *st)
{
    /* 状态的 11 个逻辑字节（偏移序）：G, ABC_levels, DEF_levels,
       A, B, C, RA, D, E, F, RB —— 与 ref docs/04-lut.md §4 字段表一致。
       ABC/DEF 电平字节低两位保留位保持 0（同 lut_codec.pack_state）。 */
    uint8_t abc = (uint8_t)(((st->level[0] & 3u) << 6) |
                            ((st->level[1] & 3u) << 4) |
                            ((st->level[2] & 3u) << 2));
    uint8_t def = (uint8_t)(((st->level[3] & 3u) << 6) |
                            ((st->level[4] & 3u) << 4) |
                            ((st->level[5] & 3u) << 2));
    const uint8_t logical[11] = {
        st->g, abc, def,
        st->frames[0], st->frames[1], st->frames[2], st->ra,
        st->frames[3], st->frames[4], st->frames[5], st->rb,
    };
    uint8_t *dst = tbl + 7 + 88 * lane + 11 * slot;
    for (int i = 0; i < 11; i++) {
        dst[i] = lut_wire_encode(logical[i]);
    }
}

/* 单相简单状态：G=1，仅 A 相（电平 a_level × a_frames 扫描），RA=1，无 DEF。 */
static void simple_state(lut_state_t *st, uint8_t a_level, uint8_t a_frames)
{
    memset(st, 0, sizeof(*st));
    st->g = 1;
    st->level[0] = a_level;
    st->frames[0] = a_frames;
    st->ra = 1;
}

void lut_build_empty(uint8_t *tbl)
{
    /* 纯逻辑零表（连头部使能都不带）：寄存器模式下所有路径立即终止，
       DRF 约 2 ms、无光学变化 —— 用作「寄存器 LUT 是否被接受」的探针。 */
    lut_table_clear(tbl);
}

void lut_build_num(uint8_t *tbl)
{
    lut_state_t st;
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    /* 码 01 → H2：黑目标 = L01(VSP) × 3 扫描（ref P3） */
    simple_state(&st, LVL_L01, 3);
    lut_table_set_state(tbl, LANE_H2, 0, &st);
    /* 码 10 → H3：白/浅色目标 = L10(VSN) × 3 扫描（ref N3） */
    simple_state(&st, LVL_L10, 3);
    lut_table_set_state(tbl, LANE_H3, 0, &st);
    /* H5：Mode0 覆盖 3 扫描（与像素路径同长） */
    simple_state(&st, SUPPLY_MODE0, 3);
    lut_table_set_state(tbl, LANE_H5, 0, &st);
}

/* 双相状态（A 相 + D 相各 n 扫描，RA=RB=1，G=1）——清理表用 */
static void two_phase_state(lut_state_t *st,
                            uint8_t a_level, uint8_t a_frames,
                            uint8_t d_level, uint8_t d_frames)
{
    memset(st, 0, sizeof(*st));
    st->g = 1;
    st->level[0] = a_level;
    st->frames[0] = a_frames;
    st->level[3] = d_level;
    st->frames[3] = d_frames;
    st->ra = 1;
    st->rb = 1;
}

/* ★R2.6.0 多轮驱动状态（降残影）：G 轮 × [驱动段 n_drive 扫描 + 静默段
 * n_idle 扫描（L00 近似保持，粒子相位间歇）]，RA=RB=1。
 * ★R2.6.1 重写为清理配方多轮化（lut_build_num_clean 同构）：G 轮 ×
 * [Mode0 正场预脉冲 P3 + Mode1 目标场 N3/L00 静默]。R2.6.0 的纯目标场
 * 重复（N3+L00）×轮 对「旧黑像素残影」打不满（用户实测：残影有效
 * 降低但仍影响黑色像素）——正负交变把每轮当一次微型全刷：正场先把
 * 残留黑颗粒压回、再由负场拉白，这是 ref docs/06 §5 验证过的
 * 清残影配方本尊。 */
static void ghost_state(lut_state_t *st, uint8_t drive_level,
                        uint8_t rounds, uint8_t n_drive, uint8_t n_settle)
{
    two_phase_state(st, drive_level, n_drive, LVL_L00, n_settle);
    st->g = rounds;
}

void lut_build_num_ghost(uint8_t *tbl, uint8_t rounds)
{
    /* 数字局刷·降残影版（R2.6.1 重写：lut_build_num_clean 配方 × G 轮）：
     *   码 01 → H2：黑目标 P3(Mode0) → L00×3（Mode1 段静默），×G 轮
     *              —— 黑目标每轮都有 P3 驱动（比 R2.6.0 的 P3+L00×2 只多不少）；
     *   码 10 → H3：白目标 P3(Mode0) 预脉冲 → N3(Mode1，VSN_1=R01 第 5 参数)，
     *              ×G 轮 —— 轮内正负交变：旧黑笔画残影的正场回收 + 负场拉白，
     *              黑像素残影的针对性解法（用户实测 R2.6.0 纯 N3 重复仍留黑影）；
     *   H5   ：Mode0×3 → Mode1×3，×G 轮（供电路与像素路同长、段对齐 ——
     *          第二段的 Mode1 负场电压由 R01 第 5 参数给定）。
     * 总扫描 = 6×rounds：rounds=3 → 18 扫描 ≈ 150ms（PLL 07=120Hz），仍远快
     * 于整刷；未变更像素动作码 00 → H1 终止，不受影响。
     * rounds=1 与 lut_build_num_clean 逐字节同构（六扫描清理配方本尊，
     * 由 test_lut_ghost 字节级对拍锁定）。 */
    if (rounds == 0) rounds = 1;
    if (rounds > 6) rounds = 6;                 /* 上限：帧数字段 6bit + 时长约束 */

    lut_state_t st;
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    /* 码 01 → H2：P3(Mode0) → L00×3（Mode1 段静默），×G 轮 */
    ghost_state(&st, LVL_L01, rounds, 3, 3);
    lut_table_set_state(tbl, LANE_H2, 0, &st);
    /* 码 10 → H3：P3(Mode0) 预脉冲 → N3(Mode1)，×G 轮（正负交变拉白） */
    two_phase_state(&st, LVL_L01, 3, LVL_L10, 3);
    st.g = rounds;
    lut_table_set_state(tbl, LANE_H3, 0, &st);
    /* H5：Mode0×3 → Mode1×3，×G 轮（供电与像素路同长、段对齐） */
    two_phase_state(&st, SUPPLY_MODE0, 3, SUPPLY_MODE1, 3);
    st.g = rounds;
    lut_table_set_state(tbl, LANE_H5, 0, &st);
}

void lut_build_num_clean(uint8_t *tbl)
{
    /* ref docs/06 §5「正向 3 → Mode1 负向 3」六扫描清理配方：
     * 白目标先 Mode0 正向预脉冲（改变粒子内部状态/压黄）再在 Mode1
     * 负向拉白（VSN_1=R01 第 5 参数，播放路径 0x50）；黑目标 Mode1 段
     * 接 L00 静默等待（同长度走表）。扫描数 6 ≈ 50 ms（PLL 07=120Hz）。 */
    lut_state_t st;
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    /* 码 01 → H2：黑目标 P3(Mode0) → L00×3（Mode1 段静默） */
    two_phase_state(&st, LVL_L01, 3, LVL_L00, 3);
    lut_table_set_state(tbl, LANE_H2, 0, &st);
    /* 码 10 → H3：白目标 P3(Mode0) → N3(Mode1) */
    two_phase_state(&st, LVL_L01, 3, LVL_L10, 3);
    lut_table_set_state(tbl, LANE_H3, 0, &st);
    /* H5：Mode0 × 3 → Mode1 × 3（Mode1 供电由 R01 第 4/5 参数给定） */
    two_phase_state(&st, SUPPLY_MODE0, 3, SUPPLY_MODE1, 3);
    lut_table_set_state(tbl, LANE_H5, 0, &st);
}

void lut_build_gray_m0(uint8_t *tbl)
{
    lut_state_t st;
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    /* 码 01 → H2：Mode0 强正场 × 1 扫描（深灰剂量；多次 DRF 累积） */
    simple_state(&st, LVL_L01, 1);
    lut_table_set_state(tbl, LANE_H2, 0, &st);
    simple_state(&st, SUPPLY_MODE0, 1);
    lut_table_set_state(tbl, LANE_H5, 0, &st);
}

void lut_build_gray_m1(uint8_t *tbl)
{
    lut_state_t st;
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    /* 码 01 → H2：Mode1 弱正场（VSP_1，R01 第 4 参数）× 1 扫描 —— 中浅灰剂量 */
    simple_state(&st, LVL_L01, 1);
    lut_table_set_state(tbl, LANE_H2, 0, &st);
    simple_state(&st, SUPPLY_MODE1, 1);
    lut_table_set_state(tbl, LANE_H5, 0, &st);
}

void lut_build_yellow(uint8_t *tbl)
{
    lut_state_t st;
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    /* 码 10 → H3：Mode0 负场 × 1 扫描 —— 白底负向剂量，黄色调随 DRF 次数累积 */
    simple_state(&st, LVL_L10, 1);
    lut_table_set_state(tbl, LANE_H3, 0, &st);
    simple_state(&st, SUPPLY_MODE0, 1);
    lut_table_set_state(tbl, LANE_H5, 0, &st);
}

void lut_build_yellow_pos(uint8_t *tbl)
{
    lut_state_t st;
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    /* 码 10 → H3：VSPL(L11) 弱正场 × 1 扫描 Mode0 —— 正场假说对照表：
       黄颗粒带负电，正场应将其拉向显示面；负场(lut_build_yellow)
       实测 3..24 扫描不显色，本表以弱正档小剂量逐次累积验证。 */
    simple_state(&st, LVL_L11, 1);
    lut_table_set_state(tbl, LANE_H3, 0, &st);
    simple_state(&st, SUPPLY_MODE0, 1);
    lut_table_set_state(tbl, LANE_H5, 0, &st);
}

bool lut_self_check(void)
{
    static const uint8_t KNOWN_L[9] = {
        0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,
    };
    static const uint8_t KNOWN_W[9] = {
        0xFF, 0xEF, 0x7F, 0xBF, 0xFD, 0xFE, 0xF7, 0xFB, 0xDF,
    };

    for (int v = 0; v < 256; v++) {
        uint8_t w = lut_wire_encode((uint8_t)v);
        if (lut_wire_decode(w) != (uint8_t)v) return false;
    }
    for (int i = 0; i < 9; i++) {
        if (lut_wire_encode(KNOWN_L[i]) != KNOWN_W[i]) return false;
        if (lut_wire_decode(KNOWN_W[i]) != KNOWN_L[i]) return false;
    }

    /* ref docs/04-lut.md §4 算例：G=3，A/B/C=2/3/4、RA=2，D/E/F=1/2/3、RB=3
       → 3*((2+3+4)*2+(1+2+3)*3) = 108 扫描 */
    lut_state_t st = {
        .g = 3,
        .level = {LVL_L00, LVL_L01, LVL_L10, LVL_L00, LVL_L01, LVL_L10},
        .frames = {2, 3, 4, 1, 2, 3},
        .ra = 2, .rb = 3,
    };
    if (lut_state_scans(&st) != 108) return false;

    /* 表布局哨兵：H5 首槽偏移应为 7 + 88*5 = 447 */
    uint8_t tbl[LUT_R20_BYTES];
    lut_table_clear(tbl);
    lut_table_set_header_ena(tbl);
    memset(&st, 0, sizeof(st));
    st.g = 1; st.level[0] = SUPPLY_MODE0; st.frames[0] = 7; st.ra = 1;
    lut_table_set_state(tbl, LANE_H5, 0, &st);
    if (tbl[447] != lut_wire_encode(1)) return false;        /* G=1 */
    if (tbl[450] != lut_wire_encode(7)) return false;        /* A=7 扫描 */
    if (tbl[6] != lut_wire_encode(1)) return false;          /* 头部字节 6 */

    return true;
}
