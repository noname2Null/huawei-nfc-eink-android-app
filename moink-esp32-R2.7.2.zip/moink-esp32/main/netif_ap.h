#ifndef MOINK_NETIF_AP_H
#define MOINK_NETIF_AP_H

#include "esp_err.h"

/*
 * SoftAP 侧工具（R2.0.0 起为 wifi_mgr 的从属模块）。
 *
 * R2.0.0 变更：netif 初始化 / 事件循环 / WiFi 驱动初始化 / 模式决策全部上移到
 * wifi_mgr.c；本模块只负责热点自己的事：
 *   - netif_ap_setup()：创建 AP netif + 注册 AP 事件（连接 / 断开日志），只调一次；
 *   - netif_ap_apply()：按设置套用热点 SSID / 密码 / 信道（幂等，模式切换后重套用）；
 *   - 功率档、客户端计数、SSID 查询照旧。
 * 热点凭据默认开放，SSID 默认 MoInk-XXXX（XXXX = MAC 末 4 位）。
 */

/* 创建 AP netif 并注册 AP 侧事件处理（在 esp_netif_init / 事件循环就绪后调用一次）。 */
void netif_ap_setup(void);

/* 按当前设置套用热点配置（SSID / 密码 / 信道 / 最大连接数），幂等。 */
void netif_ap_apply(void);

/* 按当前设置的功率档位调整发射功率（高 18dBm / 中 10dBm / 低 8.5dBm）。
 * 启动时与页面改档后调用，幂等。 */
void netif_ap_apply_tx_power(void);

/* 当前已连接 STA 数（供 /api/info 展示）。 */
int netif_ap_client_count(void);

/* 生效中的热点 SSID（默认或用户设置）。 */
const char *netif_ap_ssid(void);

#endif /* MOINK_NETIF_AP_H */
