/*
 * 墨印 · MoInk — 固件主装配（R 系列，重构版）
 *
 * 职责一句话：固件只做「热点 / 接收 / 刷图 / 休眠 / 唤醒 / OTA」，画面全部由页面
 * 在浏览器里合成。没有任何 STA 配网、没有拉图、没有固件端图像处理。
 *
 * 模块分工：
 *   epd_drv   屏驱动（A0/A1；引脚 R1.2.2 起运行时可配）
 *   settings  持久化：面板 / 翻转 / GPIO 引脚 / 休眠时长 / 自动唤醒 / 热点凭据
 *   netif_ap  SoftAP 侧工具（SSID / 信道 / 客户端计数；R2.0.0 起隶属 wifi_mgr）
 *   captive   DNS 劫持 + OS 探测劫持（连上即弹控制页；STA 模式下自动退位）
 *   wifi_mgr  R2.0.0 双模式：STA 加入路由器（10 次失败回落热点）/ mDNS /
 *             SNTP 对时 / 外网探测；连上后热点关闭
 *   auth      R2.0.0 配置页访问密码（Basic，6 位数字，可跳过，忘密屏上重置）
 *   ble_sensor R2.0.0 米家温湿度计监听（MiBeacon v5 解密，单只绑定）
 *   overlay   R2.0.0 顶部信息框（时间/温湿度/IP/联网图标）+ 密码重置屏
 *   frame     帧接收（16B 头 + CRC16 校验）+ 显示触发（★R2.0.0 入图自动 180°）
 *   power     电池 ADC / 深睡 / 唤醒源 / 空闲休眠
 *   ota_web   OTA 双槽 + 控制页热更（web 分区）+ 统一升级入口
 *
 * 路由（★ R2.0.0 新增的均需认证，除标注免认证外）：
 *   GET  /                控制页（web 分区优先，否则内嵌页）
 *   GET  /api/info        状态（版本 / 接口 / 面板 / 堆 / 电量 / 客户端数 / 网络）
 *   GET/POST /api/settings 读写设置
 *   POST /api/frame       传图
 *   POST /api/wifi        ★配网：保存 SSID/密码并重启尝试加入（10 次失败回落热点）
 *   POST /api/pass        ★修改访问密码（需认证）
 *   POST /api/pwdreset    ★忘记密码（免认证：屏上重置）
 *   GET/POST /api/ble     ★信息框/传感器：状态、绑定 MAC/bind key、密度/间隔
 *   POST/GET /api/ble/scan ★扫描周围米家传感器（页面绑定用）
 *   POST /api/upload      ★统一升级入口（自动识别 .bin 固件 / .html 控制页）
 *   POST /api/web/clear   清除已上传控制页，回退内嵌页
 *   POST /api/clear       残影清理
 *   POST /api/reboot      重启设备（GPIO 设置改后由页面调用）
 *   POST /api/factory     恢复出厂
 */
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdbool.h>

#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "esp_sleep.h"
#include "esp_pm.h"      /* R2.4.0：空闲自动浅睡（降发热） */
#include "nvs_flash.h"
#include "esp_http_server.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#include "version.h"
#include "epd_drv.h"
#include "settings.h"
#include "netif_ap.h"
#include "wifi_mgr.h"
#include "auth.h"
#include "captive.h"
#include "frame.h"
#include "power.h"
#include "ota_web.h"
#include "store.h"
#include "ble_sensor.h"
#include "overlay.h"
#include "remote.h"       /* R2.1.0：远端拉取 */
#include "pwr_sched.h"    /* R2.6.0：唤醒事件种类名（boot 门控分流日志） */

#include "index_html.h"     /* 由 tools/make_index_header.py 固化（gzip 流），改页必重跑 */

static const char *TAG = "main";

#define HOLD_RESET_S    20         /* 长按恢复出厂（R1.3.2：5 s -> 20 s） */
#define HTTPD_STACK     8192       /* R1.3.1：轮播 list 组装 base64 需要更大栈 */
#define HTTPD_MAX_URI   40         /* R2.1.0：/api/remote 入列后业务路由 21 条，
                                       再留 OTA + captive 余量（原 32 偏紧） */

/* ---------------- 按键识别参数（R1.3.2） ----------------
   BTN_SAMPLE_MS 采样周期；BTN_DEBOUNCE_N 次一致才认电平变化（60 ms 消抖）。
   BTN_DOUBLE_MS 双击第二击的间隔上限；BTN_WAKE_ARM_MS 唤醒宽限窗口（见 button_task）。 */
#define BTN_SAMPLE_MS     20
#define BTN_DEBOUNCE_N    3
#define BTN_DOUBLE_MS     400
#define BTN_WAKE_ARM_MS   1500     /* 唤醒后补认双击的窗口（R1.3.2：2.5 s -> 1.5 s） */
#define UI_QUEUE_LEN      8    /* R2.6.1：4 → 8 —— 唤醒期 NET_CHANGED/TIME_STEP/
                                  补刷 BOX_TICK 可能同时入队，防满丢事件 */

/* ---------------- 本次启动的唤醒来源（R1.3.2） ----------------
   深睡唤醒每次都会重跑 app_main，所以这里记录的就是「本次醒来」的原因；
   设备持续运行期间保持不变。后续按来源分流功能（例如定时唤醒自动轮播、
   按键唤醒才响应双击）统一读 wake_src()，不要再各自调 esp_sleep_*，
   避免多处判断分叉。 */
typedef enum {
    WAKE_SRC_POWER_ON = 0,   /* 上电 / 复位 / OTA 重启：并非从深睡醒来 */
    WAKE_SRC_BUTTON,         /* 按键（GPIO）唤醒 */
    WAKE_SRC_TIMER,          /* RTC 定时自动唤醒 */
    WAKE_SRC_OTHER,          /* 其他唤醒源（预留） */
} wake_src_t;

static wake_src_t s_wake_src  = WAKE_SRC_POWER_ON;
static uint64_t   s_wake_bits = 0;
static wake_purpose_t s_wake_purpose = WAKE_PURPOSE_POWER_ON;   /* R2.5.0：唤醒用途（事件/等人） */

/* 位图 -> 单一来源。两源同时命中时按键优先：用户在场，按键语义更该生效。
   ★ ESP32 移植版：esp_sleep_source_t 枚举值本身就是位掩码（1ull<<n），
   直接按位或后与位图相与（原 C3 版的「1u << 枚举」双重移位在 32 位上是
   未定义行为）；并补充 ESP32 深睡按键唤醒的 EXT0/EXT1 位。 */
static wake_src_t wake_src_from_bits(uint64_t bits)
{
    if (bits & ((uint64_t)ESP_SLEEP_WAKEUP_EXT0 | (uint64_t)ESP_SLEEP_WAKEUP_EXT1 |
                (uint64_t)ESP_SLEEP_WAKEUP_GPIO))
        return WAKE_SRC_BUTTON;
    if (bits & (uint64_t)ESP_SLEEP_WAKEUP_TIMER)
        return WAKE_SRC_TIMER;
    if (bits == 0)
        return WAKE_SRC_POWER_ON;
    return WAKE_SRC_OTHER;
}

static const char *wake_src_name(wake_src_t s)
{
    switch (s) {
    case WAKE_SRC_BUTTON: return "button";
    case WAKE_SRC_TIMER:  return "timer";
    case WAKE_SRC_OTHER:  return "other";
    default:              return "power_on";
    }
}

/* ---------------- 请求小工具 ---------------- */

static void url_decode(char *s)
{
    char *r = s, *w = s;
    while (*r) {
        if (*r == '+') { *w++ = ' '; r++; }
        else if (*r == '%' && r[1] && r[2]) {
            int hi = 0, lo = 0;
            char h = r[1], l = r[2];
            hi = (h <= '9') ? h - '0' : ((h | 0x20) - 'a' + 10);
            lo = (l <= '9') ? l - '0' : ((l | 0x20) - 'a' + 10);
            *w++ = (char)((hi << 4) | lo);
            r += 3;
        } else { *w++ = *r++; }
    }
    *w = '\0';
}

/* 从 key=value&... 串里取值，命中返回 1，值经 URL 解码写入 out。 */
static int kv_get(const char *qs, const char *key, char *out, size_t outlen)
{
    size_t klen = strlen(key);
    const char *p = qs;
    while (p && *p) {
        const char *amp = strchr(p, '&');
        size_t seg = amp ? (size_t)(amp - p) : strlen(p);
        if (seg > klen && strncmp(p, key, klen) == 0 && p[klen] == '=') {
            size_t vlen = seg - klen - 1;
            if (vlen >= outlen) vlen = outlen - 1;
            memcpy(out, p + klen + 1, vlen);
            out[vlen] = '\0';
            url_decode(out);
            return 1;
        }
        p = amp ? amp + 1 : NULL;
    }
    return 0;
}

/* 读请求体到栈缓冲（限长），成功返回长度。
   R1.0.8：httpd_req_recv 单次可能短读（TCP 分段），必须循环收满；
   超出缓冲的部分读走丢弃，避免残体污染 keep-alive 的下一个请求。 */
static int read_body(httpd_req_t *req, char *buf, size_t n)
{
    size_t len = req->content_len;
    if (len == 0) return 0;
    size_t cap = (len > n - 1) ? n - 1 : len;
    size_t got = 0;
    while (got < len) {
        if (got < cap) {
            int k = httpd_req_recv(req, buf + got, cap - got);
            if (k <= 0) break;
            got += (size_t)k;
        } else {
            char sink[64];                    /* 溢出部分丢弃 */
            int k = httpd_req_recv(req, sink, sizeof(sink));
            if (k <= 0) break;
            got += (size_t)k;
        }
    }
    if (got == 0) return 0;
    size_t kept = (got < cap) ? got : cap;
    buf[kept] = '\0';
    return (int)kept;
}

/* ---------------- 显示事件队列（R1.3.2；R2.0.0 扩展） ----------------
   刷屏统一由 display_task 串行执行；任何触发源只投事件。
   ★ R2.0.0 新增：信息框到点刷新（BOX_TICK）、密码重置两阶段。
   数值与 overlay.h 的 OV_EV_* 一致（ui_post 以 int 收发）。 */
typedef enum {
    UI_EV_CAROUSEL_NEXT = 0,     /* 切到下一张轮播 */
    UI_EV_BOX_TICK    = 1,       /* 信息框到点重画（消耗 IP 周期；box_en 关时还原条带） */
    UI_EV_PWD_RESET   = 2,       /* 忘记密码：画「重置密码中」+ 起表 60s */
    UI_EV_PWD_SHOW    = 3,       /* 60s 到：屏上显示新密码 */
    UI_EV_BOX_APPLY   = 4,       /* R2.0.3：改设置触发重画（不消耗 IP 周期） */
    UI_EV_NET_CHANGED = 5,       /* R2.1.0：网络状态三连确认变化 → 刷屏（需求 2/7） */
    UI_EV_GEOM_CHANGED = 6,      /* R2.2.1：屏幕方向（排线基准）改变 → 重截条带刷屏
                                    （远端显示中则回落图库并按新方向重拉） */
    UI_EV_TIME_STEP = 7,         /* ★R2.6.1：NTP 步进时钟（wifi_mgr SNTP 回调）→
                                    重排分钟定时器 + 时钟显示立即局刷校正 */
} ui_event_t;

static QueueHandle_t s_ui_q = NULL;

static void ui_post(int ev)
{
    if (!s_ui_q) return;
    if (xQueueSend(s_ui_q, &ev, 0) != pdTRUE) {
        ESP_LOGW(TAG, "ui queue full, drop event %d", ev);
    }
}

/* ---------------- 控制页 ---------------- */

static esp_err_t page_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    if (ota_web_has_page()) return ota_web_stream_page(req);

    /* R2.2.0：内嵌页为 gzip 流（tools/make_index_header.py 固化），带
       Content-Encoding: gzip 头浏览器自动解压 —— 固件瘦身约 145KB、
       页面加载提速约 3 倍。热更页路径（ota_web_stream_page）仍为原始
       HTML，互不影响。
       页面随固件一起更新，浏览器缓存会让人误判「没生效」——必须禁缓存。
       热更页那条路径在 ota_web_stream_page() 里同样设了 no-store。 */
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_set_hdr(req, "Content-Encoding", "gzip");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    return httpd_resp_send(req, (const char *)index_html_gz, index_html_gz_len);
}

/* ---------------- /api/info ---------------- */

static esp_err_t info_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    const moink_settings_t *s = settings_get();
    char buf[1024];   /* R2.1.0：加远端/轮播/信息栏字段，832 → 1024 */

    /* ver = 统一版本号 = 当前生效页面版本（热更页优先，否则等于固件编译号）。
       fw  = 固件编译进去的号：仅供排障，以及判断「热更控制页是否落后于固件」
             （ver < fw 时页面给黄色警示），界面只显示 ver。
       api 仍是帧格式契约号，与发布版本号解耦，页面状态栏另起一行显示。
       store_slots / store_count / store_cur：轮播容量与当前状态（R1.3.0）。
       wake_reason / wake_bits：本次启动的唤醒来源（R1.3.2），见 wake_src_t。 */
    int caro_count = 0, caro_cur = 0;
    store_meta_get(&caro_count, &caro_cur);
    int n = snprintf(buf, sizeof(buf),
        "{\"ver\":\"%s\",\"fw\":\"%s\",\"api\":%d,"
        "\"panel\":\"%s\",\"gpio_preset\":%u,\"heap\":%lu,\"bat_mv\":%d,"
        "\"sleep_s\":%lu,\"wake_s\":%lu,\"clients\":%d,"
        "\"ssid\":\"%s\",\"uptime\":%lld,\"store_slots\":%d,"
        "\"store_count\":%d,\"store_cur\":%d,"
        "\"wake_reason\":\"%s\",\"wake_bits\":%llu,"
        /* R2.0.0：网络 / 密码状态 */
        "\"mode\":\"%s\",\"ip\":\"%s\",\"rssi\":%d,\"net\":%s,"
        "\"tsync\":%s,\"sta_fails\":%d,\"pass_set\":%s,"
        /* R2.1.0：网络共存 / 远端 / 轮播 / 信息栏可见性 */
        "\"ap_also\":%s,\"remote\":%s,\"rmt_en\":%s,\"caro_iv\":%u,"
        "\"free_gal\":%d,\"box_show\":%u,\"ble_ok\":%s,\"box_vis\":%s,"
        "\"orient\":%u,\"cw\":%d,\"ch\":%d}",
        ota_web_page_version(), MOINK_VERSION, MOINK_API_VERSION,
        epd_panel_name((epd_panel_t)s->panel), (unsigned)s->gpio_preset,
        (unsigned long)esp_get_free_heap_size(), power_battery_mv(),
        (unsigned long)s->sleep_s, (unsigned long)s->wake_s,
        netif_ap_client_count(),
        (wifi_mgr_mode() == NETIF_MODE_STA) ? wifi_mgr_ip() : netif_ap_ssid(),
        (long long)(esp_timer_get_time() / 1000000), store_slots(),
        caro_count, caro_cur,
        wake_src_name(s_wake_src), (unsigned long long)s_wake_bits,
        wifi_mgr_mode_name(), wifi_mgr_ip(), wifi_mgr_rssi(),
        wifi_mgr_internet() ? "true" : "false",
        wifi_mgr_time_synced() ? "true" : "false",
        wifi_mgr_sta_fails(),
        s->web_pass[0] ? "true" : "false",
        wifi_mgr_ap_also() ? "true" : "false",
        remote_active() ? "true" : "false",
        (s->remote_en && s->remote_host[0]) ? "true" : "false",
        (unsigned)s->caro_iv,
        store_free_gallery(), (unsigned)s->box_show,
        settings_ble_ever_ok() ? "true" : "false",
        overlay_box_visible() ? "true" : "false",
        (unsigned)s->orient, overlay_canvas_w(), overlay_canvas_h());
    if (n < 0 || n >= (int)sizeof(buf)) buf[sizeof(buf) - 1] = '\0';

    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, buf, strlen(buf));
}

/* ---------------- /api/settings ---------------- */

static esp_err_t settings_get_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    /* buf 容量注意：R2.1.0 加了远端/轮播字段，扩到 1KB。 */
    const moink_settings_t *s = settings_get();
    char buf[1024];

    snprintf(buf, sizeof(buf),
        "{\"panel\":%u,\"hflip\":%u,\"wifi_pwr\":%u,\"gpio_preset\":%u,"
        "\"pins\":[%u,%u,%u,%u,%u,%u,%u,%u],"
        "\"sleep_s\":%lu,\"timeout_action\":%u,\"wake_s\":%lu,\"wake_show\":%u,"
        "\"ssid\":\"%s\",\"pass_set\":%s,"
        /* R2.0.0 新增 */
        "\"sta_ssid\":\"%s\",\"web_set\":%s,"
        "\"box_en\":%u,\"box_density\":%u,\"box_iv\":%u,"
        "\"box_style\":%u,\"box_ipm\":%u,\"box_ipc\":%u,"
        "\"box_pos\":%u,\"box_dir\":%u,\"box_mv\":%u,\"bwg\":%u,"
        "\"ble_mac\":\"%s\",\"ble_key_set\":%s,"
        /* R2.1.0 新增：图库轮播 / 网络检测间隔；R2.2.1 新增 orient（排线基准方向） */
        "\"caro_iv\":%u,\"netcheck_iv\":%u,\"orient\":%u}",
        s->panel, s->hflip, s->wifi_pwr, s->gpio_preset,
        s->pins.v[0], s->pins.v[1], s->pins.v[2], s->pins.v[3],
        s->pins.v[4], s->pins.v[5], s->pins.v[6], s->pins.v[7],
        (unsigned long)s->sleep_s, s->timeout_action,
        (unsigned long)s->wake_s, s->wake_show,
        s->ap_ssid, s->ap_pass[0] ? "true" : "false",
        s->sta_ssid, s->web_pass[0] ? "true" : "false",
        s->box_en, s->box_density, s->box_iv_min,
        s->box_style, s->box_ip_mode, s->box_ip_cyc,
        (unsigned)s->box_pos, (unsigned)s->box_dir, (unsigned)s->box_move_iv,
        s->box_wg[0] ? 1 : 0,
        s->ble_mac, s->ble_key[0] ? "true" : "false",
        (unsigned)s->caro_iv, (unsigned)s->netcheck_iv, (unsigned)s->orient);

    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, buf, strlen(buf));
}

/* FB-014②：AP 配置延迟应用 —— 先把 200 应答发回给页面，300ms 后再把新配置
   应用到热点。改名 / 改密码会立刻踢掉手机连接，若「先应用后应答」，页面大概率
   收不到 200，成败只能靠回读猜；应答先行后，保存判定走正常成功路径。
   esp_timer 一次性回调，绝不在 httpd 任务栈里等。 */
static esp_timer_handle_t s_ap_timer;

static void ap_apply_timer_cb(void *arg)
{
    (void)arg;
    netif_ap_apply();
}

static esp_err_t settings_post_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    char body[512];
    read_body(req, body, sizeof(body));

    char v[SETT_PASS_MAX];
    bool ap_changed = false;
    bool panel_changed = false, hflip_changed = false;
    const uint8_t orient_prev = settings_get()->orient;   /* R2.2.1 */

    if (kv_get(body, "panel", v, sizeof(v))) {
        settings_set_panel((uint8_t)atoi(v));
        panel_changed = true;
    }
    if (kv_get(body, "hflip", v, sizeof(v))) {
        settings_set_hflip((uint8_t)atoi(v));
        hflip_changed = true;
    }
    /* GPIO 设置（R1.2.2）：preset 0/1/2 用固定预设，3 = 自定义（须带 8 个引脚）。
       引脚变更只落盘、不改运行时——SPI 总线与 ADC 通道在启动时按引脚初始化，
       运行中重映射会把屏驱动搞死；由页面引导用户重启生效。 */
    bool gpio_changed = false;
    if (kv_get(body, "gpio_preset", v, sizeof(v))) {
        uint8_t preset = (uint8_t)atoi(v);
        if (preset == GPIO_PRESET_CUSTOM) {
            static const char *PK[PIN_IDX_COUNT] = {
                "p_adc", "p_wake", "p_sck", "p_mosi", "p_cs", "p_dc", "p_rst", "p_busy"
            };
            pin_cfg_t c;
            bool have = true;
            for (int i = 0; i < PIN_IDX_COUNT; i++) {
                char pv[8];
                if (!kv_get(body, PK[i], pv, sizeof(pv))) { have = false; break; }
                c.v[i] = (uint8_t)atoi(pv);
            }
            if (!have)
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "custom pins incomplete");
            if (settings_set_gpio(GPIO_PRESET_CUSTOM, &c) != ESP_OK)
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "invalid pin map");
        } else if (settings_set_gpio(preset, NULL) != ESP_OK) {
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad gpio preset");
        }
        gpio_changed = true;
    }
    if (kv_get(body, "wifi_pwr", v, sizeof(v))) {
        settings_set_wifi_pwr((uint8_t)atoi(v));
        netif_ap_apply_tx_power();
    }
    if (kv_get(body, "sleep_s", v, sizeof(v))) {
        settings_set_sleep((uint32_t)atoi(v));
    }
    if (kv_get(body, "timeout_action", v, sizeof(v))) {
        settings_set_timeout_action((uint8_t)atoi(v));
    }
    if (kv_get(body, "wake_s", v, sizeof(v))) {
        settings_set_wake((uint32_t)atoi(v));
    }
    if (kv_get(body, "wake_show", v, sizeof(v))) {
        settings_set_wake_show((uint8_t)atoi(v));
    }

    /* R2.1.0：图库自动轮播间隔 + 网络检测间隔。 */
    if (kv_get(body, "caro_iv", v, sizeof(v))) {
        settings_set_caro_iv((uint8_t)atoi(v));
    }
    if (kv_get(body, "netcheck_iv", v, sizeof(v))) {
        uint16_t sec = (uint16_t)atoi(v);
        if (settings_set_netcheck_iv(sec) == ESP_OK) {
            wifi_mgr_set_netcheck_iv(sec);   /* 探测定时器立刻按新间隔走 */
        }
    }

    /* R2.2.1：屏幕方向（排线基准 0..3）。改的是「载荷→面板」的映射与信息框
       条带几何；载荷/图库内容不动 —— 重截条带 + 整屏重刷即可，旧照片在任一
       方向下都能正确显示（同一载荷，换一种映射）。 */
    bool orient_changed = false;
    if (kv_get(body, "orient", v, sizeof(v))) {
        uint8_t o = (uint8_t)atoi(v);
        if (settings_set_orient(o) == ESP_OK && o != orient_prev) orient_changed = true;
    }

    /* 热点凭据（FB-014①）：单字段可改 —— pass 键缺省 = 保持当前密码，
       pass 空串 = 清除密码（热点转开放）；ssid 键缺省 = 保持当前热点名。
       页面据此区分「留空不动」与「勾选清除」。 */
    char ssid[SETT_SSID_MAX], pass[SETT_PASS_MAX];
    bool have_ssid = kv_get(body, "ssid", ssid, sizeof(ssid));
    bool have_pass = kv_get(body, "pass", pass, sizeof(pass));
    if (have_ssid || have_pass) {
        settings_set_ap(have_ssid ? ssid : NULL, have_pass ? pass : NULL);
        ap_changed = true;
    }

    /* 应用到运行时。 */
    if (panel_changed) epd_set_panel((epd_panel_t)settings_get()->panel);
    if (hflip_changed) epd_set_hflip(settings_get()->hflip != 0);

    httpd_resp_set_type(req, "text/plain");
    esp_err_t err = httpd_resp_sendstr(req, gpio_changed ? "OK GPIO" : "OK");

    /* R2.2.1：方向已落盘 —— 刷屏统一由 display_task 做（约 20s 整刷，
       不能堵 httpd）。投 GEOM 事件：重截条带 + 整屏重刷；远端显示中则
       回落图库并按新方向重拉（display_task 内处理）。 */
    if (orient_changed) ui_post(UI_EV_GEOM_CHANGED);

    /* 应答已发出，再延迟应用 AP 配置（FB-014②）。 */
    if (ap_changed) {
        if (!s_ap_timer) {
            const esp_timer_create_args_t targs = {
                .callback = &ap_apply_timer_cb,
                .arg = NULL,
                .dispatch_method = ESP_TIMER_TASK,
                .name = "ap_apply",
            };
            esp_timer_create(&targs, &s_ap_timer);
        } else {
            esp_timer_stop(s_ap_timer);     /* 连续保存：重置 300ms 窗口 */
        }
        esp_timer_start_once(s_ap_timer, 300 * 1000);
    }
    return err;
}

/* ---------------- /api/clear / /api/factory ---------------- */

static esp_err_t clear_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    int cycles = 2;
    char v[16];
    if (kv_get(req->uri, "cycles", v, sizeof(v))) cycles = atoi(v);
    if (cycles < 1) cycles = 1;
    if (cycles > 4) cycles = 4;

    ESP_LOGI(TAG, "ghost clear x%d", cycles);
    int r = frame_clear_cycles(cycles);   /* R1.0.8：持帧锁，防与传图并发互踩 */
    if (r != 0) return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "clear failed");
    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_sendstr(req, "OK");
}

static esp_err_t factory_handler(httpd_req_t *req)
{
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    settings_factory_reset();
    httpd_resp_set_type(req, "text/plain");
    httpd_resp_sendstr(req, "OK");
    vTaskDelay(pdMS_TO_TICKS(500));
    esp_restart();
    return ESP_OK;
}

/* R1.3.0：清空轮播（只清元数据，不擦 flash，槽位留待下次写入覆盖）。 */
static esp_err_t clear_carousel_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    store_clear();
    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_sendstr(req, "OK");
}

/* ---------------- R1.3.1 轮播管理：list / delete / full ---------------- */

/* base64 分块编码并逐块发送：源数据按 3 字节/块编码为 4 字符，
   缓冲固定 ~5.5KB，避免为整图开 40KB 堆缓冲（C3 堆余量 8~26KB）。 */
static void b64_send_chunked(httpd_req_t *req, const uint8_t *in, size_t n)
{
    static const char T[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    char buf[4096 * 4 / 3 + 8];
    size_t off = 0;
    while (off < n) {
        size_t cnt = n - off;
        if (cnt > 4095) cnt = 4095;    /* 3 的倍数，避免跨块截断三元组 */
        size_t i = 0, o = 0;
        while (i + 3 <= cnt) {
            uint32_t v = ((uint32_t)in[off+i] << 16) | ((uint32_t)in[off+i+1] << 8) |
                         in[off+i+2];
            buf[o++] = T[(v >> 18) & 63]; buf[o++] = T[(v >> 12) & 63];
            buf[o++] = T[(v >> 6) & 63];  buf[o++] = T[v & 63];
            i += 3;
        }
        if (i + 1 == cnt) {
            uint32_t v = (uint32_t)in[off+i] << 16;
            buf[o++] = T[(v >> 18) & 63]; buf[o++] = T[(v >> 12) & 63];
            buf[o++] = '='; buf[o++] = '=';
        } else if (i + 2 == cnt) {
            uint32_t v = ((uint32_t)in[off+i] << 16) | ((uint32_t)in[off+i+1] << 8);
            buf[o++] = T[(v >> 18) & 63]; buf[o++] = T[(v >> 12) & 63];
            buf[o++] = T[(v >> 6) & 63];  buf[o++] = '=';
        }
        httpd_resp_send_chunk(req, buf, o);
        off += cnt;
    }
}

static esp_err_t carousel_list_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    int count = 0, cur = 0;
    store_meta_get(&count, &cur);

    char head[96];
    snprintf(head, sizeof(head), "{\"slots\":%d,\"count\":%d,\"cur\":%d,\"items\":[",
             store_slots(), count, cur);
    httpd_resp_set_type(req, "application/json");
    httpd_resp_send_chunk(req, head, strlen(head));

    char item[160];
    for (int i = 0; i < count; i++) {
        int fmt = 1, tw = 0, th = 0;
        uint32_t tlen = 0;
        const uint8_t *payload = NULL;
        uint8_t *dyn = NULL;

        /* 路径 A：预存缩略（R1.3.2/3）。直接读缩略头拿 fmt/tlen，
           按实际大小 malloc，避免按 20KB 上限一次性分配 */
        const esp_partition_t *sp = store_part();
        /* R1.3.4：i 是逻辑序号，物理槽允许留空洞（删除不再搬移），
           必须换算后再算偏移，否则图库缩略图会整体错位。 */
        int phys = store_slot_phys(i);
        uint32_t off = (uint32_t)(phys < 0 ? i : phys) * STORE_SLOT_SZ;
        uint8_t fhdr[16], thdr[16];
        int has_pre = 0;
        uint32_t flen = 0;
        if (sp &&
            esp_partition_read(sp, off, fhdr, sizeof(fhdr)) == ESP_OK &&
            fhdr[0] == STORE_MAGIC0 && fhdr[1] == STORE_MAGIC1) {
            flen = ((uint32_t)fhdr[8] << 24) | ((uint32_t)fhdr[9] << 16) |
                   ((uint32_t)fhdr[10] << 8) | fhdr[11];
            if (flen && flen <= STORE_FRAME_MAX &&
                esp_partition_read(sp, off + 16 + flen, thdr,
                                   sizeof(thdr)) == ESP_OK &&
                thdr[0] == STORE_MAGIC0 && thdr[1] == STORE_MAGIC1) {
                uint32_t tl = ((uint32_t)thdr[8] << 24) | ((uint32_t)thdr[9] << 16) |
                              ((uint32_t)thdr[10] << 8) | thdr[11];
                uint32_t lim = (thdr[2] == 2) ? STORE_THUMB_JPEG_MAX
                                               : STORE_THUMB_LEN;
                if (tl && tl <= lim) {
                    fmt = (thdr[2] == 2) ? 2 : 1;
                    tw = (int)((thdr[4] << 8) | thdr[5]);
                    th = (int)((thdr[6] << 8) | thdr[7]);
                    tlen = tl;
                    has_pre = 1;
                }
            }
        }
        if (!has_pre) {
            /* 路径 B：回退固件现算 2bit 缩略 */
            dyn = malloc(STORE_THUMB_ENTRY);
            if (!dyn) { fmt = 1; tw = 0; th = 0; tlen = 0; }
            else {
                int n = store_thumb_frame(i, dyn, STORE_THUMB_ENTRY);
                if (n <= 16) {
                    free(dyn); dyn = NULL;
                    fmt = 1; tw = 0; th = 0; tlen = 0;
                } else {
                    fmt = 1;
                    tw = (int)((dyn[4] << 8) | dyn[5]);
                    th = (int)((dyn[6] << 8) | dyn[7]);
                    tlen = (uint32_t)(n - 16);
                    payload = dyn + 16;
                }
            }
        } else {
            /* 路径 A：按实际 tlen 分配并读载荷 */
            dyn = malloc(tlen);
            if (!dyn || esp_partition_read(sp, off + 16 + flen + 16,
                                           dyn, tlen) != ESP_OK) {
                free(dyn); dyn = NULL;
                tw = 0; th = 0; tlen = 0;
            } else {
                payload = dyn;
            }
        }

        if (!tlen) {
            snprintf(item, sizeof(item), "%s{\"slot\":%d,\"fmt\":1,\"w\":0,\"h\":0,\"len\":0,\"data\":\"\"}",
                     i ? "," : "", i);
            httpd_resp_send_chunk(req, item, strlen(item));
        } else {
            snprintf(item, sizeof(item), "%s{\"slot\":%d,\"fmt\":%d,\"w\":%d,\"h\":%d,\"len\":%lu,\"data\":\"",
                     i ? "," : "", i, fmt, tw, th, (unsigned long)tlen);
            httpd_resp_send_chunk(req, item, strlen(item));
            b64_send_chunked(req, payload, tlen);
            httpd_resp_send_chunk(req, "\"}", 2);
        }
        free(dyn);
    }
    httpd_resp_send_chunk(req, "]}", 2);
    httpd_resp_send_chunk(req, NULL, 0);
    return ESP_OK;
}

/* POST /api/carousel/delete?slot=N：删除并紧凑前移。
   R1.3.4（FB-020）：错误不再一律 400——越界 404 / 忙 503 / 搬移失败 500，
   控制页据此给出可读原因；串口日志带 slot 与 count 便于定位。 */
static esp_err_t carousel_delete_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    char qbuf[40], vs[8];
    if (httpd_req_get_url_query_len(req) <= 0 ||
        httpd_req_get_url_query_len(req) >= (int)sizeof(qbuf) ||
        httpd_req_get_url_query_str(req, qbuf, sizeof(qbuf)) != ESP_OK ||
        !kv_get(qbuf, "slot", vs, sizeof(vs))) {
        ESP_LOGW(TAG, "delete: 缺少 slot 参数");
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad query");
    }
    int slot = atoi(vs);

    int count = 0, cur = 0;
    store_meta_get(&count, &cur);
    if (slot < 0 || slot >= count) {
        ESP_LOGW(TAG, "delete: slot %d 越界（count=%d，前端索引可能已过期）",
                 slot, count);
        return httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "no such slot");
    }

    int r = store_delete_slot(slot);
    if (r != STORE_DEL_OK) {
        ESP_LOGE(TAG, "delete: slot %d 失败 err=%d（count=%d）", slot, r, count);
        if (r == STORE_DEL_EBUSY) {
            httpd_resp_set_status(req, "503 Service Unavailable");
            httpd_resp_set_type(req, "text/plain");
            return httpd_resp_sendstr(req, "busy");
        }
        if (r == STORE_DEL_EIO)
            return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                                       "move failed");
        return httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "no such slot");
    }

    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_sendstr(req, "OK");
}

/* GET /api/carousel/full?slot=N：返回整帧二进制（16B 头 + 2bpp 载荷），
   供网页「点击缩略图 → 大图预览」。流式读 flash 分块发送：
   不整帧 malloc（120KB 在堆紧张时失败导致 500），只开 4KB 小块缓冲。 */
static esp_err_t carousel_full_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    char qbuf[40], vs[8];
    if (httpd_req_get_url_query_len(req) <= 0 ||
        httpd_req_get_url_query_len(req) >= (int)sizeof(qbuf) ||
        httpd_req_get_url_query_str(req, qbuf, sizeof(qbuf)) != ESP_OK ||
        !kv_get(qbuf, "slot", vs, sizeof(vs)))
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad query");
    int slot = atoi(vs);
    /* R1.3.4：slot 是逻辑序号；越界（含已删除的空洞）统一 404。 */
    int phys = store_slot_phys(slot);
    if (phys < 0)
        return httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "no such slot");

    const esp_partition_t *sp = store_part();
    if (!sp)
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "store off");
    uint32_t off = (uint32_t)phys * STORE_SLOT_SZ;

    uint8_t hdr[16];
    if (esp_partition_read(sp, off, hdr, sizeof(hdr)) != ESP_OK ||
        hdr[0] != STORE_MAGIC0 || hdr[1] != STORE_MAGIC1)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad slot");
    uint32_t len = ((uint32_t)hdr[8] << 24) | ((uint32_t)hdr[9] << 16) |
                   ((uint32_t)hdr[10] << 8) | hdr[11];
    if (len == 0 || len > STORE_FRAME_MAX)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad slot");

    httpd_resp_set_type(req, "application/octet-stream");
    if (httpd_resp_send_chunk(req, (const char *)hdr, sizeof(hdr)) != ESP_OK)
        return ESP_FAIL;

    uint8_t *chunk = malloc(4096);
    if (!chunk)
        return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "oom");
    uint32_t sent = 0;
    while (sent < len) {
        uint32_t k = (len - sent > 4096) ? 4096 : len - sent;
        if (esp_partition_read(sp, off + 16 + sent, chunk, k) != ESP_OK) {
            free(chunk);
            return httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR,
                                       "read fail");
        }
        if (httpd_resp_send_chunk(req, (const char *)chunk, k) != ESP_OK) {
            free(chunk);
            return ESP_FAIL;
        }
        sent += k;
    }
    httpd_resp_send_chunk(req, NULL, 0);
    free(chunk);
    return ESP_OK;
}

/* R1.2.2：改 GPIO 后由页面调用 —— SPI 总线与 ADC 通道只能在启动时按引脚
   初始化，因此引脚生效的唯一途径是重启。先应答再重启，避免页面收不到 200。 */
static esp_err_t reboot_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    httpd_resp_set_type(req, "text/plain");
    httpd_resp_sendstr(req, "OK rebooting");
    ESP_LOGW(TAG, "reboot requested by page");
    vTaskDelay(pdMS_TO_TICKS(500));
    esp_restart();
    return ESP_OK;
}

/* ---------------- R2.5.0：/api/alive 页面保活心跳 ----------------
 * 设备默认 5 分钟无操作入深睡；控制页开着时每 20s 发一次心跳
 *（页面 JS，见 page/index.html）——「还有设备停在配置页」就不睡。
 * 免认证（响应只有 {"ok":true}，无信息泄露；也避免密码过期时
 * 心跳被 401 拦住让人误判设备已睡）。失败不重连 —— 页面侧提示一次。 */
static esp_err_t alive_handler(httpd_req_t *req)
{
    power_activity();
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_sendstr(req, "{\"ok\":true}");
}

/* ---------------- R2.0.0 新接口：配网 / 密码 / 传感器 ---------------- */

/* 延迟重启（先把应答发回页面）。 */
static void reboot_timer_cb(void *arg)
{
    (void)arg;
    ESP_LOGW(TAG, "rebooting to apply wifi settings");
    esp_restart();
}

/* POST /api/wifi：ssid=&pass= 保存并重启尝试加入；ssid 为空 = 清除配网。 */
static esp_err_t wifi_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    char body[SETT_PASS_MAX + 64];
    read_body(req, body, sizeof(body));

    char ssid[SETT_SSID_MAX], pass[SETT_PASS_MAX];
    bool have_ssid = kv_get(body, "ssid", ssid, sizeof(ssid));
    bool have_pass = kv_get(body, "pass", pass, sizeof(pass));
    if (!have_ssid)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "need ssid");

    esp_err_t r = settings_set_sta(ssid, have_pass ? pass : NULL);
    if (r != ESP_OK)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad ssid/pass");

    const moink_settings_t *s = settings_get();
    httpd_resp_set_type(req, "text/plain");
    if (s->sta_ssid[0] == '\0') {
        httpd_resp_sendstr(req, "OK cleared, rebooting to hotspot mode");
    } else {
        httpd_resp_sendstr(req, "OK saved, rebooting to join LAN");
    }

    static esp_timer_handle_t t;
    if (!t) {
        const esp_timer_create_args_t args = {
            .callback = &reboot_timer_cb,
            .arg = NULL,
            .dispatch_method = ESP_TIMER_TASK,
            .name = "wifi_reboot",
        };
        esp_timer_create(&args, &t);
    } else {
        esp_timer_stop(t);
    }
    esp_timer_start_once(t, 800 * 1000);
    return ESP_OK;
}

/* POST /api/pass：pass=6 位数字（已认证才能改）；空 = 清除密码。 */
static esp_err_t pass_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    char body[32];
    read_body(req, body, sizeof(body));
    char pass[16];
    if (!kv_get(body, "pass", pass, sizeof(pass)))
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "need pass");

    esp_err_t r = settings_set_web_pass(pass);
    if (r != ESP_OK)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                   "pass must be 6 digits (or empty to clear)");
    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_sendstr(req, settings_get()->web_pass[0] ? "OK set" : "OK cleared");
}

/* POST /api/pwdreset：免认证（忘记密码的物理旁路）。
   墨水屏顶部红色「重置密码中」→ 60 秒后屏上显示新密码。 */
static esp_err_t pwdreset_handler(httpd_req_t *req)
{
    power_activity();
    if (!overlay_pwd_reset_request()) {
        httpd_resp_set_status(req, "409 Conflict");
        httpd_resp_set_type(req, "text/plain; charset=utf-8");
        return httpd_resp_sendstr(req, "reset already in progress");
    }
    httpd_resp_set_type(req, "text/plain; charset=utf-8");
    return httpd_resp_sendstr(req,
        "OK: check the e-paper screen, new code appears in 60 seconds");
}

/* GET /api/ble：传感器 + 信息框状态。 */
static esp_err_t ble_get_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    const moink_settings_t *s = settings_get();
    ble_state_t st = ble_sensor_state();
    char buf[512];
    /* 温湿度用 0.1 单位整数输出（规避 newlib-nano 的 %f 风险）：t10 = 235 => 23.5C */
    snprintf(buf, sizeof(buf),
        "{\"mac\":\"%s\",\"key_set\":%s,\"bound\":%s,"
        "\"temp10\":%d,\"hum10\":%d,\"batt\":%d,\"rssi\":%d,"
        "\"valid\":%s,\"seen_ms\":%lld,"
        "\"box_en\":%u,\"density\":%u,\"iv\":%u,"
        "\"style\":%u,\"ipm\":%u,\"ipc\":%u,"
        "\"bshow\":%u,\"bth\":%u,\"brh\":%u,\"bgm\":%u,\"bpx\":%u,\"bpy\":%u}",
        s->ble_mac, s->ble_key[0] ? "true" : "false",
        ble_sensor_bound() ? "true" : "false",
        (int)((st.temp_c > -900.0f) ? (st.temp_c * 10) : -9999),
        (int)((st.hum_pct >= 0) ? (st.hum_pct * 10) : -1),
        st.battery, st.rssi,
        ble_sensor_valid() ? "true" : "false",
        (long long)st.last_seen_ms,
        s->box_en, s->box_density, s->box_iv_min,
        s->box_style, s->box_ip_mode, s->box_ip_cyc,
        s->box_show, s->box_time_h, s->box_row_h,
        s->box_gap_mid, s->box_pad_x, s->box_pad_y);
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, buf, strlen(buf));
}

/* POST /api/ble：绑定/解绑传感器、改 bind key、信息框开关/密度/间隔。
   mac 为空 = 解绑；key 为空 = 清除；redraw=1 时立即重画信息框。
   ★R2.1.0：新增信息框内容自定义键（bshow/bth/brh/bgm/bpx/bpy）。 */
static esp_err_t ble_post_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    char body[320];
    read_body(req, body, sizeof(body));

    char v[64];
    const char *mac = NULL, *key = NULL;
    if (kv_get(body, "mac", v, sizeof(v))) mac = v;
    char keybuf[SETT_BLE_KEY_LEN];
    if (kv_get(body, "key", keybuf, sizeof(keybuf))) key = keybuf;

    if (mac || key) {
        esp_err_t r = settings_set_ble(mac, key);
        if (r != ESP_OK)
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                       "mac must be 12 hex, key 32 hex");
        /* ★ R2.0.1：保存即重载绑定 —— s_has_bind/s_bind_key 只在 init 时读
           一次，不重载的话扫描回调永远匹配不上，页面永远显示"未绑定"。 */
        ble_sensor_reload_binding();
    }

    uint8_t en = settings_get()->box_en, dens = settings_get()->box_density, iv = settings_get()->box_iv_min;
    if (kv_get(body, "en", v, sizeof(v))) en = (uint8_t)atoi(v);
    if (kv_get(body, "density", v, sizeof(v))) dens = (uint8_t)atoi(v);
    if (kv_get(body, "iv", v, sizeof(v))) iv = (uint8_t)atoi(v);
    /* R2.0.3：显示样式 / IP 行模式 / 周期数（缺省 = 保持当前值） */
    uint8_t style = settings_get()->box_style;
    uint8_t ipm = settings_get()->box_ip_mode;
    uint8_t ipc = settings_get()->box_ip_cyc;
    if (kv_get(body, "style", v, sizeof(v))) style = (uint8_t)atoi(v);
    if (kv_get(body, "ipm", v, sizeof(v))) ipm = (uint8_t)atoi(v);
    if (kv_get(body, "ipc", v, sizeof(v))) ipc = (uint8_t)atoi(v);
    if (en > 1) en = 1;
    if (dens > 100) dens = 100;
    switch (iv) {
    case SETT_BOX_IV_1MIN: case SETT_BOX_IV_5MIN: case SETT_BOX_IV_10MIN:
    case SETT_BOX_IV_30MIN: case SETT_BOX_IV_60MIN:
        break;
    default:
        iv = SETT_BOX_IV_10MIN;
    }
    if (style > SETT_BOX_STYLE_SPLIT) style = SETT_BOX_STYLE_OVERLAY;
    if (ipm > SETT_BOX_IP_CYCLES) ipm = SETT_BOX_IP_CYCLES;
    if (ipc < SETT_BOX_IP_CYC_MIN || ipc > SETT_BOX_IP_CYC_MAX) ipc = 3;

    /* R2.1.0：信息框内容自定义（元素开关 + 位置/大小；缺省 = 保持当前值）。 */
    const moink_settings_t *sc = settings_get();
    uint8_t bshow = sc->box_show;
    uint8_t bth = sc->box_time_h, brh = sc->box_row_h;
    uint8_t bgm = sc->box_gap_mid, bpx = sc->box_pad_x, bpy = sc->box_pad_y;
    if (kv_get(body, "bshow", v, sizeof(v))) bshow = (uint8_t)atoi(v);
    if (kv_get(body, "bth",  v, sizeof(v))) bth  = (uint8_t)atoi(v);
    if (kv_get(body, "brh",  v, sizeof(v))) brh  = (uint8_t)atoi(v);
    if (kv_get(body, "bgm",  v, sizeof(v))) bgm  = (uint8_t)atoi(v);
    if (kv_get(body, "bpx",  v, sizeof(v))) bpx  = (uint8_t)atoi(v);
    if (kv_get(body, "bpy",  v, sizeof(v))) bpy  = (uint8_t)atoi(v);

    bool box_changed = (en != settings_get()->box_en || dens != settings_get()->box_density ||
                        iv != settings_get()->box_iv_min || style != settings_get()->box_style ||
                        ipm != settings_get()->box_ip_mode || ipc != settings_get()->box_ip_cyc);
    if (box_changed) {
        if (settings_set_box(en, dens, iv, style, ipm, ipc) != ESP_OK)
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad box params");
        /* R2.0.6：IP 行处于周期档时重置周期计数 —— 已入网状态下切到/改周期档
           立即再显示 N 个刷新周期，不必等重新入网（改设置重画不消耗周期）。 */
        if (ipm == SETT_BOX_IP_CYCLES) overlay_ip_cycles_reset();
    }
    /* R2.4.0：位置 / 方向 / 换位 / 自定义控件布局（缺省 = 保持当前值）。 */
    {
        uint8_t bpos = settings_get()->box_pos;
        uint8_t bdir = settings_get()->box_dir;
        uint8_t bmv  = settings_get()->box_move_iv;
        if (kv_get(body, "bpos", v, sizeof(v))) bpos = (uint8_t)atoi(v);
        if (kv_get(body, "bdir", v, sizeof(v))) bdir = (uint8_t)atoi(v);
        if (kv_get(body, "bmv",  v, sizeof(v))) bmv  = (uint8_t)atoi(v);
        if (bpos != settings_get()->box_pos || bdir != settings_get()->box_dir ||
            bmv != settings_get()->box_move_iv) {
            if (settings_set_box2(bpos, bdir, bmv) != ESP_OK)
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad pos/dir/mv");
            box_changed = true;
        }
        if (kv_get(body, "bwg", v, sizeof(v))) {
            uint8_t blob[SETT_BOX_WG_BYTES];
            if (overlay_box_wg_parse(v, blob) != 0)
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                        "bad bwg (t/d/h/i/n:x,y,w,h;... or clear)");
            if (settings_set_box_wg(blob) != ESP_OK)
                return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad box wg");
            box_changed = true;
        }
    }

    /* 版式变化单独落盘（与上面互不干扰：两套键各改各的）。 */
    if (bshow != sc->box_show || bth != sc->box_time_h || brh != sc->box_row_h ||
        bgm != sc->box_gap_mid || bpx != sc->box_pad_x || bpy != sc->box_pad_y) {
        if (settings_set_box_layout(bshow, bth, brh, bgm, bpx, bpy) != ESP_OK)
            return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "bad box layout");
        box_changed = true;
    }

    httpd_resp_set_type(req, "text/plain");
    httpd_resp_sendstr(req, "OK");

    /* 参数变化立即生效：开→重画；关→还原条带（不消耗 IP 周期）。 */
    if (box_changed) {
        ui_post(UI_EV_BOX_APPLY);   /* display_task 里按 box_en 分流：开=重画，关=还原 */
    }
    return ESP_OK;
}

/* POST /api/ble/scan：开 10 秒收集窗口。 */
static esp_err_t ble_scan_start_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;
    ble_sensor_scan_start();
    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_sendstr(req, "OK scanning 10s");
}

/* GET /api/ble/scan：取候选列表（页面在 10 秒后来读）。 */
static esp_err_t ble_scan_results_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    ble_candidate_t cands[12];
    int n = ble_sensor_scan_results(cands, 12);
    if (n > 12) n = 12;

    char buf[1024];
    int off = snprintf(buf, sizeof(buf), "{\"items\":[");
    for (int i = 0; i < n && off < (int)sizeof(buf) - 96; i++) {
        off += snprintf(buf + off, sizeof(buf) - (size_t)off,
                        "%s{\"mac\":\"%s\",\"rssi\":%d,\"hits\":%d}",
                        i ? "," : "", cands[i].mac, cands[i].rssi, cands[i].hits);
    }
    snprintf(buf + off, sizeof(buf) - (size_t)off, "]}");
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, buf, strlen(buf));
}

/* ---------------- R2.1.0：/api/remote（远端拉取配置 + 状态） ---------------- */

static esp_err_t remote_get_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    remote_status_t st;
    remote_get_status(&st);
    char cid[17];
    remote_cid_hex(cid, sizeof(cid));
    char buf[512];
    snprintf(buf, sizeof(buf),
        "{\"en\":%u,\"host\":\"%s\",\"iv\":%u,"
        "\"active\":%s,\"split\":%s,\"last_ok\":%s,\"last_code\":%d,"
        "\"last_s\":%lld,\"cid\":\"%s\","
        "\"pulls\":%lu,\"fails\":%lu,\"skips\":%lu,\"free_gal\":%d}",
        st.en, st.host, (unsigned)st.iv,
        st.active ? "true" : "false",
        st.split ? "true" : "false",
        st.last_ok ? "true" : "false", st.last_code,
        (long long)(st.last_ms / 1000000), cid,
        (unsigned long)st.pulls, (unsigned long)st.fails,
        (unsigned long)st.skips, store_free_gallery());
    httpd_resp_set_type(req, "application/json");
    return httpd_resp_send(req, buf, strlen(buf));
}

/* POST /api/remote：en=&host=&iv=（host 支持 ip:port / 域名，可带路径前缀）。 */
static esp_err_t remote_post_handler(httpd_req_t *req)
{
    power_activity();
    esp_err_t au = auth_guard(req);
    if (au != ESP_OK) return au;

    char body[192];
    read_body(req, body, sizeof(body));

    /* R2.2.1 修复：host/en/iv 必须各用各的缓冲区 —— 旧版三者共用 v，
       取完 host 再取 en 时把 v 覆盖成 "1"，导致保存的主机名变成 "1"。 */
    char hostv[SETT_REMOTE_HOST_MAX];
    char v[16];
    const moink_settings_t *cur = settings_get();
    uint8_t en = cur->remote_en;
    uint8_t iv = cur->remote_iv;
    bool have_host = kv_get(body, "host", hostv, sizeof(hostv));
    if (kv_get(body, "en", v, sizeof(v))) en = (uint8_t)atoi(v);
    if (kv_get(body, "iv", v, sizeof(v))) iv = (uint8_t)atoi(v);
    if (en > 1) en = 1;

    /* 开启时必须有主机（本次没传就用已存的）。 */
    if (en && !have_host && cur->remote_host[0] == '\0')
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "need host");
    if (en && have_host && hostv[0] == '\0')
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "need host");

    esp_err_t r = settings_set_remote(en, have_host ? hostv : NULL, iv);
    if (r != ESP_OK)
        return httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST,
                                   "bad host or iv (iv: 1/5/10/30/60)");

    /* 预留暂存槽 / 关闭回落 / 开启试拉 —— 都在拉取任务里串行处理。 */
    remote_settings_changed();

    httpd_resp_set_type(req, "text/plain");
    return httpd_resp_sendstr(req, en ? "OK enabled" : "OK disabled");
}

/* ---------------- CORS 预检（离线客户端走 file://） ---------------- */

static esp_err_t options_handler(httpd_req_t *req)
{
    httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    httpd_resp_set_hdr(req, "Access-Control-Allow-Headers", "Content-Type");
    httpd_resp_send(req, NULL, 0);
    return ESP_OK;
}

/* ---------------- HTTP 服务器 ---------------- */

static httpd_handle_t start_server(void)
{
    httpd_config_t cfg = HTTPD_DEFAULT_CONFIG();
    /* 默认是精确匹配，OPTIONS * 通配路由永远不触发 → 跨源预检 404 →
       离线/本地页面的上传被浏览器拦截。启用通配匹配后预检正常。 */
    cfg.uri_match_fn = httpd_uri_match_wildcard;
    cfg.stack_size = HTTPD_STACK;
    cfg.max_uri_handlers = HTTPD_MAX_URI;
    /* iOS 会并发发起多条 captive 探测连接；容量与 Espressif 官方 captive portal
       示例保持一致，避免低上限下探测连接被 LRU 提前清掉。 */
    cfg.max_open_sockets = 13;
    cfg.lru_purge_enable = true;
    cfg.recv_wait_timeout = 10;
    cfg.send_wait_timeout = 10;

    httpd_handle_t server = NULL;
    if (httpd_start(&server, &cfg) != ESP_OK) {
        ESP_LOGE(TAG, "httpd_start failed");
        return NULL;
    }

    httpd_uri_t routes[] = {
        { .uri = "/",               .method = HTTP_GET,    .handler = page_handler,         .user_ctx = NULL },
        { .uri = "/api/info",       .method = HTTP_GET,    .handler = info_handler,         .user_ctx = NULL },
        { .uri = "/api/settings",   .method = HTTP_GET,    .handler = settings_get_handler, .user_ctx = NULL },
        { .uri = "/api/settings",   .method = HTTP_POST,   .handler = settings_post_handler,.user_ctx = NULL },
        { .uri = "/api/frame",      .method = HTTP_POST,   .handler = frame_upload_handler, .user_ctx = NULL },
        { .uri = "/api/carousel/clear", .method = HTTP_POST, .handler = clear_carousel_handler, .user_ctx = NULL },
        { .uri = "/api/carousel/list",  .method = HTTP_GET,  .handler = carousel_list_handler,  .user_ctx = NULL },
        { .uri = "/api/carousel/delete",.method = HTTP_POST, .handler = carousel_delete_handler,.user_ctx = NULL },
        { .uri = "/api/carousel/full",  .method = HTTP_GET,  .handler = carousel_full_handler,  .user_ctx = NULL },
        { .uri = "/api/clear",      .method = HTTP_POST,   .handler = clear_handler,        .user_ctx = NULL },
        { .uri = "/api/reboot",     .method = HTTP_POST,   .handler = reboot_handler,       .user_ctx = NULL },
        { .uri = "/api/alive",      .method = HTTP_GET,    .handler = alive_handler,        .user_ctx = NULL },   /* R2.5.0：页面保活心跳 */
        { .uri = "/api/factory",    .method = HTTP_POST,   .handler = factory_handler,      .user_ctx = NULL },
        /* ---- R2.0.0 新路由：配网 / 密码 / 传感器 / 信息框 ---- */
        { .uri = "/api/wifi",       .method = HTTP_POST,   .handler = wifi_handler,         .user_ctx = NULL },
        { .uri = "/api/pass",       .method = HTTP_POST,   .handler = pass_handler,         .user_ctx = NULL },
        { .uri = "/api/pwdreset",   .method = HTTP_POST,   .handler = pwdreset_handler,     .user_ctx = NULL },
        { .uri = "/api/ble",        .method = HTTP_GET,    .handler = ble_get_handler,      .user_ctx = NULL },
        { .uri = "/api/ble",        .method = HTTP_POST,   .handler = ble_post_handler,    .user_ctx = NULL },
        { .uri = "/api/ble/scan",  .method = HTTP_POST,   .handler = ble_scan_start_handler,   .user_ctx = NULL },
        { .uri = "/api/ble/scan",  .method = HTTP_GET,    .handler = ble_scan_results_handler, .user_ctx = NULL },
        /* ---- R2.1.0 新路由：远端拉取 ---- */
        { .uri = "/api/remote",     .method = HTTP_GET,    .handler = remote_get_handler,   .user_ctx = NULL },
        { .uri = "/api/remote",     .method = HTTP_POST,   .handler = remote_post_handler,  .user_ctx = NULL },
        { .uri = "/hotspot-detect.html", .method = HTTP_GET, .handler = captive_apple_landing, .user_ctx = NULL },
        { .uri = "/library/test/success.html", .method = HTTP_GET, .handler = captive_apple_landing, .user_ctx = NULL },
        { .uri = "*",               .method = HTTP_OPTIONS,.handler = options_handler,      .user_ctx = NULL },
    };
    for (size_t i = 0; i < sizeof(routes) / sizeof(routes[0]); i++) {
        if (httpd_register_uri_handler(server, &routes[i]) != ESP_OK) {
            ESP_LOGE(TAG, "register %s %d failed", routes[i].uri, routes[i].method);
        }
    }

    ota_web_register(server);

    /* 必须在所有业务路由之后注册：OS 探测路径此前直接 404，根本进不了首页。
       兜底 GET 同时覆盖带查询参数的探测与厂商自定义路径。 */
    const httpd_uri_t captive = {
        .uri = "/*", .method = HTTP_GET, .handler = captive_redirect, .user_ctx = NULL,
    };
    ESP_ERROR_CHECK(httpd_register_uri_handler(server, &captive));
    return server;
}

/* ★R2.7.0 轻唤醒按需起网：单击按键临时打开配置页时才初始化网络栈
 *（WiFi 热点/加入 + HTTP 服务器 + captive）。本开机内幂等；蓝牙扫描
 * 不在此起（传感器数据交给全功能唤醒）。有人触发 → wifi_mgr_init(false)
 * 全力尝试加入（连败计数清零）。 */
static void net_start_on_demand(void)
{
    static bool s_net_started = false;
    if (s_net_started) return;
    s_net_started = true;
    wifi_mgr_set_ui_post(ui_post);
    wifi_mgr_init(false);
    if (start_server() == NULL) {
        ESP_LOGE(TAG, "on-demand HTTP server failed to start");
    }
    ESP_LOGI(TAG, "network started on demand (human present during light wake)");
}

/* ---------------- 任务 ---------------- */

static void frame_task(void *arg)
{
    (void)arg;
    for (;;) {
        frame_wait();
        if (frame_display_now() == 0) {
            power_activity();
        }
    }
}

static void idle_monitor_task(void *arg)
{
    (void)arg;
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(1000));
        if (!power_should_sleep()) continue;
        /* 超时动作（R1.3.3）：默认休眠；选「关机」则释放自锁断电。
           ★R2.7.2：两条路径【不再保证不返回】—— 入睡序列的二次校验
           发现有活动（刷屏/拉取/有人续命）会中止入睡并返回，本任务
           下一秒轮询重试即可（活动结束后自然入睡；被停掉的 WiFi 由
           wifi_mgr slow_retry 恢复）。 */
        if (settings_get()->timeout_action == SETT_ACTION_OFF) {
            power_self_lock_off();
        }
        power_enter_deep_sleep();
    }
}

/* R1.3.0 轮播：切到下一张（读 store 槽并整屏显示）。count<=1 时无动作。
   R1.3.2：只在 display_task 里调用，与按键采样彻底解耦。
   ★ R2.5.0：不再刷新活动计时 —— 轮播是调度活/按键活（按键已在
   button_task 续命），调度活续命会让深睡永远进不去；display_task
   事件入口统一报忙脉冲防刷屏中途入睡。 */
static void carousel_next(void)
{
    int count = 0, cur = 0;
    store_meta_get(&count, &cur);
    if (count <= 0) return;
    /* ★R2.7.0：切图整刷 15~25s —— 轻唤醒的事件入口脉冲只有 3s，
       这里自报 25s 忙脉冲（多源取最长），防整刷中途被判闲入睡。 */
    power_busy_pulse(25);

    int next = (cur + 1) % count;
    if (frame_display_slot(next) != 0) {
        /* R1.3.2：刷屏失败不推进 cur，否则下次按键会「跳过一张」。
           旧实现先写 NVS 再刷屏，失败也照样前移。 */
        ESP_LOGW(TAG, "carousel: slot %d display failed, keep cur %d", next, cur);
        return;
    }
    store_meta_set(count, next);
    ESP_LOGI(TAG, "carousel: next -> slot %d (count %d)", next, count);
}

/* R1.3.2 显示任务：固件里唯一执行「UI 触发刷屏」的任务（按键动作经队列进到这里）。
   上传帧的刷屏仍走 frame_task，两者由帧缓冲互斥量串行。
   ★ R2.0.0：新增信息框到点重画 / 密码重置两阶段两个事件。 */
static void display_task(void *arg)
{
    (void)arg;
    if (s_ui_q == NULL) {
        ESP_LOGE(TAG, "no ui queue, display task exits");
        vTaskDelete(NULL);
        return;
    }
    ui_event_t ev;
    for (;;) {
        if (xQueueReceive(s_ui_q, &ev, portMAX_DELAY) != pdTRUE) continue;
        /* ★R2.7.2【修复1b】：入睡序列进行中 —— 暂缓一切 UI 事件（含
           UI_EV_NET_CHANGED 重画）：不投忙脉冲、不碰面板。入睡成功：
           事件随深睡消亡（下一次唤醒由 pwr_sched 目标事件 + overlay
           补刷机制重发，无丢失语义）；入睡被二次校验中止（标志清除）：
           事件照常处理。R2.7.1 睡死正是 esp_wifi_stop 触发的
           NET_CHANGED 重画在入睡序列内启动 15s 整刷、随后被
           esp_deep_sleep_start 拦腰斩断 —— 事件在 sleeping 窗口内
           不允许触碰面板，这条链就从源头断开。 */
        if (power_sleeping()) {
            /* 重新入队（刚出队必有一个空位）+ 短歇轮询，防空转 */
            if (xQueueSend(s_ui_q, &ev, 0) != pdTRUE) {
                ESP_LOGW(TAG, "display: ev %d dropped (sleeping, q full)", (int)ev);
            }
            vTaskDelay(pdMS_TO_TICKS(100));
            continue;
        }
        /* R2.5.0：调度刷屏（信息框到点/轮播/换位/网络变化重画）不重置空闲
           计时 —— 否则信息框 1 分钟档/温湿变化局刷会无限续命，深睡永远
           进不去；这里改报忙脉冲（整屏刷新 2~4s 期间 idle_monitor 不入睡）。
           真正的「有人在用」（HTTP 请求 / 按键）在各自路径续命。
           ★R2.7.0：BOX_TICK 轻唤醒的快刷只 ~0.3s —— 脉冲缩短到 3s
           （轻唤醒收尾窗口 4s，长脉冲会把每分钟醒着的时长拉满）；
           整刷路径（换位/基准丢失）在 overlay_box_redraw 自报 25s。 */
        power_busy_pulse((ev == UI_EV_BOX_TICK && power_wake_is_light()) ? 3 : 15);
        switch (ev) {
        case UI_EV_CAROUSEL_NEXT:
            carousel_next();
            break;
        case UI_EV_BOX_TICK:
            /* 开着就重画信息框（消耗一个 IP 显示周期）；刚关上则把条带还原成纯照片。
               R2.1.0：不可见（无网无蓝牙/远端全屏）时 overlay 内部自行分流。 */
            if (settings_get()->box_en) overlay_box_tick(true);
            else overlay_box_clear();
            break;
        case UI_EV_BOX_APPLY:
            /* R2.0.3：改设置触发的重画 —— 不消耗 IP 周期（不是到点刷新）。 */
            if (settings_get()->box_en) overlay_box_redraw(false);
            else overlay_box_clear();
            break;
        case UI_EV_PWD_RESET:
            overlay_pwd_phase1_draw();
            overlay_pwd_timer_start();
            break;
        case UI_EV_PWD_SHOW:
            overlay_pwd_phase2_draw();
            break;
        case UI_EV_NET_CHANGED:
            /* R2.1.0 需求 2/7：网络状态三连确认变化 —— 信息栏该显示就重画
               （IP/图标/隐藏态都可能变了），不该显示就还原纯照片。 */
            overlay_box_refresh();
            break;
        case UI_EV_GEOM_CHANGED:
            /* R2.2.1：屏幕方向改变 —— 载荷→面板的映射全变：
               远端显示中：暂存子帧布局已失效 → 回落图库（内部按新方向重截条带
               + 刷屏）并按新方向重拉；
               图库/本地图：重截条带（frame_capture_strip）+ 整屏重刷。
               条带在 overlay 侧检测到方向变化时已自动失效，此处必须重截。 */
            if (remote_active()) {
                remote_notify_override();
                frame_remote_revert();
                remote_kick();
            } else if (frame_capture_strip()) {
                overlay_set_photo_split(frame_src_split());
                overlay_box_compose_strip();   /* box_en 关时内部无动作 */
                frame_display_now();
            } else {
                overlay_strip_fill_white();
                frame_display_now();
            }
            break;
        case UI_EV_TIME_STEP:
            /* ★R2.6.1：NTP 步进 —— 重排分钟定时器 + 时钟显示立即局刷校正
               （内部自判快刷可用性，不可用只重排定时器不整刷）。 */
            overlay_time_realign();
            break;
        default:
            break;
        }
        /* R2.5.0：此处原是每事件一律 power_activity() —— 已移除，见循环顶部
           注释；忙脉冲防的是「刷屏中途入睡」，续命只认人机交互。 */
    }
}

/* ---------------- 按键识别（R1.3.2 重写） ----------------
   只做识别，不做任何刷屏动作；与刷屏解耦后采样不会被整屏刷新阻塞。

   动作定义：
     单击  按下-松开，BTN_DOUBLE_MS 内没有第二击 → 只唤醒（重置空闲计时），不刷图
     双击  两次按下间隔 ≤ BTN_DOUBLE_MS        → 投 UI_EV_CAROUSEL_NEXT（切图）
     长按  持续 HOLD_RESET_S 秒                 → 恢复出厂并重启

   唤醒语义：被按键唤醒时，那一击已经被「唤醒」这件事消耗掉。
     · 任务启动瞬间键已松开 —— 第一击完整发生在启动期，
       此后 BTN_WAKE_ARM_MS 内的第一次单击视为「第二击」，直接切图；
     · 任务启动瞬间键仍按住 —— 按着的这一下就是第一击本身，松手只算单击。
   注：深睡唤醒到本任务启动之间约 0.3 s 内按键无法采样，若两击都落在该窗口，
       只能识别为单击 —— 属启动时序的物理限制。 */
static void button_task(void *arg)
{
    (void)arg;
    const gpio_num_t btn = (gpio_num_t)settings_pins()->v[PIN_IDX_WAKE];

    enum { ST_IDLE = 0, ST_DOWN, ST_WAIT_SECOND };
    int st = ST_IDLE;

    int raw_prev = gpio_get_level(btn);
    int stable = raw_prev;
    int agree = 0;
    bool second = false;              /* 本次按下是双击的第二击 */
    bool long_warned = false;
    TickType_t t_down = 0, t_release = 0;

    const bool woken_by_btn = (s_wake_src == WAKE_SRC_BUTTON);
    bool wake_armed = woken_by_btn && (stable != 0);
    TickType_t wake_deadline = xTaskGetTickCount() + pdMS_TO_TICKS(BTN_WAKE_ARM_MS);
    if (woken_by_btn) {
        ESP_LOGI(TAG, "btn: woken by key, level %s",
                 stable == 0 ? "low(held)" : "high(released)");
    }

    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(BTN_SAMPLE_MS));
        TickType_t now = xTaskGetTickCount();
        int raw = gpio_get_level(btn);

        /* 消抖：同一电平连续 BTN_DEBOUNCE_N 次采样才认为稳定 */
        if (raw != raw_prev) {
            raw_prev = raw;
            agree = 0;
        } else if (++agree >= BTN_DEBOUNCE_N && stable != raw) {
            stable = raw;
            agree = 0;
            if (stable == 0) {
                /* 按下沿 */
                t_down = now;
                long_warned = false;
                second = (st == ST_WAIT_SECOND);
                st = ST_DOWN;
            } else if (st == ST_DOWN) {
                /* 松开沿 */
                if (second) {
                    second = false;
                    st = ST_IDLE;
                    ESP_LOGI(TAG, "btn: double click -> carousel next");
                    ui_post(UI_EV_CAROUSEL_NEXT);
                } else if (wake_armed) {
                    wake_armed = false;
                    st = ST_IDLE;
                    ESP_LOGI(TAG, "btn: wake + click -> carousel next");
                    ui_post(UI_EV_CAROUSEL_NEXT);
                } else {
                    st = ST_WAIT_SECOND;
                    t_release = now;
                }
            }
        }

        if (st == ST_DOWN) {
            /* 按住期间持续刷新活动计时：否则空闲休眠可能先把设备睡掉，
               20 s 长按永远走不完。 */
            power_activity();
            TickType_t held = now - t_down;
            if (!long_warned && held >= pdMS_TO_TICKS((HOLD_RESET_S - 3) * 1000)) {
                long_warned = true;
                ESP_LOGW(TAG, "keep holding %d s more to factory reset", 3);
            }
            if (held >= pdMS_TO_TICKS(HOLD_RESET_S * 1000)) {
                ESP_LOGW(TAG, "long press %d s: factory reset + reboot", HOLD_RESET_S);
                settings_factory_reset();
                vTaskDelay(pdMS_TO_TICKS(300));
                esp_restart();
            }
        } else if (st == ST_WAIT_SECOND) {
            if ((now - t_release) >= pdMS_TO_TICKS(BTN_DOUBLE_MS)) {
                st = ST_IDLE;
                ESP_LOGI(TAG, "btn: single click (wake only)");
                power_activity();       /* 单击也算有人在用：重置空闲计时 */
                /* ★R2.7.0 轻唤醒中单击 = 有人要配置页：按需起网
                   （WiFi+热点+HTTP），收尾窗口升格「等人」档（sleep_s，
                   默认 5min）—— 不必等下一个全功能唤醒。 */
                if (power_wake_is_light()) {
                    net_start_on_demand();
                    power_human_open_window();
                }
            }
        }

        if (wake_armed && (int32_t)(now - wake_deadline) >= 0) {
            wake_armed = false;
        }
    }
}

/* ---------------- R2.1.0：上电门控（需求 3：首屏刷新时序） ----------------
 *
 * 上电/复位（含深睡唤醒）后，首屏刷新统一等：
 *   1. 网络状态落定（已入局域网 / 回落热点待命 / 无凭据纯热点 / 超时）；
 *   2. 已入局域网 → NTP 对上北京时间；
 *   3. 绑定了传感器且【历史上成功取到过数据】→ 等本次开机收到最新温湿度
 *      （ble_ok 标志未曾置位则跳过 —— 防止屏幕显示错误数据，也防空等）；
 *   4. 远端拉取开启且在局域网 → 首拉成功即远端内容上屏；失败/未开 → 图库
 *      （图库空则白底）；定时唤醒自动切下一张也在这里（原 app_main 尾部逻辑）。
 *
 * 深睡唤醒（timer/button）走快速档（等待上限缩短）；期间屏幕保持旧画面
 *（墨水屏不刷不灭），分钟调度在门控完成前不触发任何重画（overlay 门控标记）。 */
static void boot_gate_task(void *arg)
{
    (void)arg;

    /* ★R2.7.0 轻唤醒捷径（分钟局刷）：不起射频、不等任何网络/NTP/蓝牙/
       远端 —— 面板画面保持（墨水屏不刷不灭），只恢复显示源，分钟调度
       立即接管：快刷基准从 RTC 恢复则 ~0.3s 局刷，否则补刷按需整刷。
       收尾窗口 4s（power_should_sleep 轻档）—— 主控每分钟只醒 ≈2~6s。 */
    if (power_wake_is_light()) {
        power_activity();
        frame_boot_restore_source();   /* 只恢复源+条带，不刷屏 */
        overlay_set_boot_done();       /* catch-up 立即补发被吃掉的边界 */
        ESP_LOGI(TAG, "boot gate: light wake (minute tick), radio off, scheduler armed");
        vTaskDelete(NULL);
        return;
    }

    /* ★R2.7.0：崩溃/看门狗/掉电复位重启也走快速档 —— 没有人在配置页
       等着，崩溃自愈不必陪跑 45s 全档门控（power 侧另有 15s 短收尾窗）。 */
    bool quick = (s_wake_src != WAKE_SRC_POWER_ON) || power_unattended_reboot();
    /* ★R2.6.1：快速档放宽 —— 原 net 8s / ntp 4s 在慢路由器（唤后入网
       > 8s）下门控空腹放行：首拉被跳过（mode 仍非 STA）、NTP 带不走，
       时钟/拉取双双换饿 —— 「时钟偶尔不跳 / 远端拉取失败」的实测根因
       之一。net 12s / ntp 6s：慢路由吃得下，快路由不受影响（提前退出）；
       总耗时上限 12+6+6+8=32s + boot ~2s 仍留提前量与补刷窗口余量。 */
    const uint32_t net_wait = quick ? 12000 : 45000;
    const uint32_t ntp_wait = quick ? 6000 : 12000;
    const uint32_t ble_wait = quick ? 6000 : 20000;
    const uint32_t rmt_wait = quick ? 8000 : 15000;

    power_activity();

    /* 1. 等网络落定。 */
    uint32_t w = 0;
    while (w < net_wait && !wifi_mgr_net_settled()) {
        vTaskDelay(pdMS_TO_TICKS(250));
        w += 250;
        power_activity();
    }
    ESP_LOGI(TAG, "boot gate: net %s after %ums (%s)",
             wifi_mgr_net_settled() ? "settled" : "TIMEOUT",
             w, wifi_mgr_mode_name());

    /* 2. NTP（北京时间）。 */
    if (wifi_mgr_mode() == NETIF_MODE_STA) {
        w = 0;
        while (w < ntp_wait && !wifi_mgr_time_synced()) {
            vTaskDelay(pdMS_TO_TICKS(250));
            w += 250;
        }
        ESP_LOGI(TAG, "boot gate: time %s (%ums)",
                 wifi_mgr_time_synced() ? "synced" : "NOT synced", w);
    }

    /* 3. 温湿度最新数据（仅绑定过且拿到过的；否则跳过）。
       ★R2.7.0：改等【本次开机收到的新帧】（fresh）—— valid() 含 RTC
       恢复的最后已知值，拿它判会立即放行；有新帧到来即刻走，最多等
       ble_wait（传感器广播间隔秒级）。 */
    const moink_settings_t *st = settings_get();
    if (st->ble_mac[0] && settings_ble_ever_ok()) {
        w = 0;
        while (w < ble_wait && !ble_sensor_fresh()) {
            vTaskDelay(pdMS_TO_TICKS(250));
            w += 250;
        }
        ESP_LOGI(TAG, "boot gate: ble data %s (%ums)",
                 ble_sensor_fresh() ? "fresh" : "stale (RTC value shown)", w);
    } else {
        ESP_LOGI(TAG, "boot gate: ble wait skipped (bound=%d ever_ok=%d)",
                 st->ble_mac[0] != 0, settings_ble_ever_ok());
    }

    /* 4. 远端首拉（开启且在局域网才试；结果出来再决定首屏）。 */
    bool remote_shown = false;
    if (st->remote_en && st->remote_host[0] && wifi_mgr_mode() == NETIF_MODE_STA) {
        remote_kick();
        remote_wait_first(rmt_wait);
        remote_shown = remote_active();
        ESP_LOGI(TAG, "boot gate: remote %s", remote_shown ? "shown" : "fallback");
    }

    /* 5. 首屏：远端没接管 → 图库当前槽（wake_s 定时唤醒且开启切图 → 下一张。
       R2.5.0：调度事件唤醒（分钟刷新/远端拉取）不切图 —— 那是干活不是等人。
       ★R2.6.0：调度事件唤醒且面板已有画面时不再无条件整刷 —— 只恢复显示源
       （frame_boot_restore_source，面板画面保持），首屏交给分钟调度/补刷：
       快刷基准从 RTC 恢复则局刷（~0.2s 不闪屏），否则补刷事件按需整刷。
       上电/按键/等人唤醒维持原行为（首屏整刷）。 */
    if (!remote_shown) {
        if (s_wake_purpose == WAKE_PURPOSE_TIMER_HUMAN && settings_get()->wake_show) {
            ESP_LOGI(TAG, "timer wake: auto carousel next");
            carousel_next();
        } else if (s_wake_purpose == WAKE_PURPOSE_TIMER_EVENT) {
            uint8_t wevt = PWR_EVT_NONE;
            (void)power_wake_event(&wevt, NULL);
            /* ★R2.6.2：调度事件唤醒【一律 defer】（只恢复显示源，面板保持
               睡前画面，首屏交给分钟调度/补刷）。原 BOX/MOVE 档还要看
               「门控期末 overlay_box_visible()」—— 那是瞬时值：BLE 6s 窗
               没等到广播 / STA 重连慢于门控窗时为假 → 走 frame_boot_restore()
               无谓整刷（闪屏 + 快刷基准作废），单机实测一晚可多几十次整刷；
               可见性交给唤醒后的调度实判（不可见时 tick 空转、画面原地
               保持，墨水屏无内容可丢）。标记丢失（wevt=NONE，如上电位
               图不清）维持回落整刷的老行为。 */
            const bool defer =
                remote_active() ||                          /* 远端已在屏：拉取失败保画面不变 */
                wevt == PWR_EVT_REMOTE ||                   /* ★R2.6.1：远端事件唤醒：拉取在途
                                                               （或即将由补刷补发），面板保持
                                                               旧画面 —— 不回落图库整刷，
                                                               慢服务器下省一次双重闪屏，
                                                               拉取失败也保持原画面 */
                wevt == PWR_EVT_CAROUSEL ||                 /* 轮播补刷自己会整刷下一张 */
                wevt == PWR_EVT_BOX ||                      /* ★R2.6.2：分钟刷新/补刷接管首屏 */
                wevt == PWR_EVT_MOVE;                       /* ★R2.6.2：换位补刷接管首屏 */
            if (defer) {
                ESP_LOGI(TAG, "boot gate: event wake (%s), keep screen, source only",
                         pwr_sched_evt_name(wevt));
                /* 远端已在屏（remote_init 已从 RTC 恢复远端显示源）时不再
                   回落图库源 —— 否则等于把远端顶替掉。 */
                if (!remote_active()) frame_boot_restore_source();
            } else {
                frame_boot_restore();
            }
        } else {
            frame_boot_restore();
        }
    }

    overlay_set_boot_done();     /* 分钟调度开始接管（到点重画/远端/轮播） */
    ESP_LOGI(TAG, "boot gate done (heap %lu)",
             (unsigned long)esp_get_free_heap_size());
    vTaskDelete(NULL);
}

/* ---------------- 主入口 ---------------- */

void app_main(void)
{
    /* ★ ESP32 移植版：已删除 C3 版的 GPIO2 MOS 自锁块（上电拉高 GPIO2 会
       影响下次复位进入 UART 下载模式）；USB 供电常开，无需自锁。 */

    ESP_LOGI(TAG, "=== MoInk %s | 4-color | ap + unified upgrade ===", MOINK_VERSION);

    /* NVS */
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    settings_init();

    /* R2.4.0 电源管理：空闲自动降频 + 浅睡（RAM 保持 —— 信息框快刷基准、
       网络连接不丢；唤醒零开销）。面板侧发热已由分钟局刷（15~25s → ~0.6s）
       大头解决，SoC 侧由此收尾。 */
    {
        esp_pm_config_t pm = {
            .max_freq_mhz = 80,
            .min_freq_mhz = 40,
            .light_sleep_enable = true,
        };
        esp_pm_configure(&pm);
    }

    /* 唤醒来源：GPIO = 按键，TIMER = 定时自动唤醒，位图 0 = 上电/复位。
       放在 settings_init() 之后，日志才能打出运行时解析出的唤醒脚。
       R2.5.0：定时唤醒再分用途 —— 调度事件（分钟刷新/远端拉取，短窗口干活）
       还是 wake_s 等人窗口（自动切图）—— 由深睡前写入 RTC 内存的标记决定。 */
    s_wake_bits = power_wakeup_causes();
    s_wake_src  = wake_src_from_bits(s_wake_bits);
    s_wake_purpose = power_boot_purpose(s_wake_src == WAKE_SRC_TIMER,
                                        s_wake_src == WAKE_SRC_BUTTON);
    switch (s_wake_src) {
    case WAKE_SRC_BUTTON:
        ESP_LOGI(TAG, "wake src: button (GPIO%u)", settings_pins()->v[PIN_IDX_WAKE]);
        /* 这一击只用于唤醒、不自动切图；语义见 button_task 顶部注释。 */
        break;
    case WAKE_SRC_TIMER:
        ESP_LOGI(TAG, "wake src: timer, purpose %s (planned %lus)",
                 power_purpose_name(s_wake_purpose),
                 (unsigned long)power_planned_sleep_s());
        break;
    case WAKE_SRC_POWER_ON:
        ESP_LOGI(TAG, "wake src: power-on/reset (reset reason %d)",
                 (int)esp_reset_reason());
        break;
    default:
        ESP_LOGI(TAG, "wake src: other (bits 0x%lx)", (unsigned long)s_wake_bits);
        break;
    }
    /* ★R2.7.0 两档功耗状态机：轻唤醒（分钟局刷）日志分流。 */
    if (power_wake_is_light()) {
        ESP_LOGI(TAG, "light wake: minute tick only, radio stays off");
    }

    /* ★R2.7.1 boot 门控深睡保护：无条件忙脉冲盖住门控期 —— NVS/分区扫描/
       SPI init 合计可能超过轻唤醒 4s 收尾窗，腰斩 boot_gate_task 即
       「永不清醒」循环；门控本身另有 boot-done 判据兜底（power_should_sleep）。 */
    power_busy_pulse(15);

    power_init();       /* 配好按键脚与电池 ADC，按键任务依赖它 */

    /* ★R2.7.0：无条件先恢复最后已知温湿度（RTC noinit → RAM，无射频依赖）
 *      —— 轻唤醒不扫描期间温湿控件显示最后已知值而非 "--.-"；
 *      全功能唤醒的扫描刷新后随帧覆写。 */
    ble_sensor_restore();

    /* 按键识别尽早启动（上电后约 0.3 s）：双击的第二击才来得及被采样到。
       本任务只投事件、不刷屏，display_task 就绪前投来的事件先在队列里排着。 */
    s_ui_q = xQueueCreate(UI_QUEUE_LEN, sizeof(ui_event_t));
    if (s_ui_q == NULL) {
        ESP_LOGE(TAG, "ui queue create failed");
    }
    xTaskCreate(button_task, "button", 3072, NULL, 6, NULL);

    store_init();       /* 轮播存储底座（FB-017 第一部分）：只探测，不写入 */

    if (epd_init() != 0) {
        ESP_LOGE(TAG, "EPD init failed");
    }
    epd_set_panel((epd_panel_t)settings_get()->panel);
    epd_set_hflip(settings_get()->hflip != 0);

    /* ★R2.7.2【修复6】：ext0 按键唤醒去抖确认。ext0 是纯电平唤醒：
       按键抖动/干扰的毫秒级低脉冲同样会唤醒整机，旧版会空转一轮
       完整开机 + sleep_s 空闲窗（默认 300s）才睡回。开机到此处
       ≈0.2s，再等 50ms 采样：仍为低 = 真按住，正常开机；已回高 =
       假唤醒，直接重新入睡。放在 store_init/epd_init 之后：
       唤醒计划评估（overlay_next_wake_s）依赖的 settings/store 状态
       已就绪，与轻唤醒路径的入睡条件完全一致；此刻无射频、无任务
       在刷屏（panel 仍处深睡态），走强制入睡口 power_deep_sleep_now。
       ⚠️ 已知代价：极短（<50ms）的真人快击可能被误判为抖动而回睡
       （见 CHANGELOG_R2.7.2 风险与验证建议）。 */
    if (s_wake_src == WAKE_SRC_BUTTON) {
        vTaskDelay(pdMS_TO_TICKS(50));
        if (gpio_get_level((gpio_num_t)settings_pins()->v[PIN_IDX_WAKE]) != 0) {
            ESP_LOGW(TAG, "btn wake was a glitch (high after 50ms), back to sleep");
            power_deep_sleep_now();   /* 不返回 */
        }
    }

    frame_init();
    /* ★ R2.1.0：不再立即恢复图库显示 —— 上电门控统一时序（需求 3）：
       等网络落定 → NTP → 温湿度 → （远端首拉）→ 再刷首屏；期间屏幕保持旧画面。 */

    /* R2.1.0：远端拉取底座（暂存槽预留 + 拉取任务；须在 store_init 之后）。 */
    remote_init();

    /* ★R2.7.0 两档功耗状态机：轻唤醒（分钟局刷）【不起射频】—— WiFi/
       HTTP 服务器/蓝牙扫描一概不初始化（热点/配置页只在全功能唤醒与
       按键按需窗口可用）；全功能唤醒照旧，unattended = 调度事件唤醒
       （路由器连败抑制生效，见 wifi_mgr_init）。 */
    if (!power_wake_is_light()) {
        wifi_mgr_set_ui_post(ui_post);   /* R2.1.0：网络状态变化事件口（队列已建） */
        wifi_mgr_init(s_wake_purpose == WAKE_PURPOSE_TIMER_EVENT);
        if (start_server() == NULL) {
            ESP_LOGE(TAG, "HTTP server failed to start");
        }
    }

    xTaskCreate(frame_task, "frame", 4096, NULL, 5, NULL);
    xTaskCreate(idle_monitor_task, "idle_mon", 3072, NULL, 4, NULL);
    /* 刷屏任务最后启动：store / epd / frame 全部就绪后才可能消费到切图事件 */
    xTaskCreate(display_task, "display", 4096, NULL, 4, NULL);

    /* ★ R2.0.0：米家温湿度计 BLE 监听（WiFi 已起，共存由控制器分时）
       + 信息框分钟调度（事件走 ui_q，由 display_task 串行刷屏）。
       ★R2.7.0：BLE 扫描是射频 —— 轻唤醒不起（温湿度显示 RTC 恢复的
       最后已知值），只在全功能唤醒监听。 */
    if (!power_wake_is_light()) ble_sensor_init();
    overlay_init(ui_post);

    /* R1.3.3：定时唤醒后自动切到下一张 —— R2.1.0 起移入上电门控：
       等网络/时间/温湿度（含远端首拉）之后再决定切图还是远端上屏。 */

    ota_web_confirm();

    /* ★R2.7.0：轻唤醒无网络栈 —— 不打误导性的 LAN/热点日志。 */
    if (power_wake_is_light()) {
        ESP_LOGI(TAG, "ready: light wake, radio off (heap %lu)",
                 (unsigned long)esp_get_free_heap_size());
    } else if (wifi_mgr_mode() == NETIF_MODE_STA) {
        ESP_LOGI(TAG, "ready: LAN %s | http://%s/ | http://moink.local/ (heap %lu)",
                 wifi_mgr_ip(), wifi_mgr_ip(),
                 (unsigned long)esp_get_free_heap_size());
    } else {
        ESP_LOGI(TAG, "ready: SoftAP '%s' @ http://192.168.4.1 (heap %lu)",
                 netif_ap_ssid(), (unsigned long)esp_get_free_heap_size());
    }

    /* R2.1.0：上电门控任务最后起 —— store/epd/frame/display 全部就绪后，
       再按「网络→NTP→温湿度→远端→首屏」时序走第一次刷屏。 */
    xTaskCreate(boot_gate_task, "bootgate", 4096, NULL, 3, NULL);
}
