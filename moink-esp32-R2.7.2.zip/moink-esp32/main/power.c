#include "power.h"
#include "epd_drv.h"
#include "settings.h"
#include "overlay.h"       /* R2.4.0：深睡前作废信息框区面板真值状态 */
#include "pwr_sched.h"     /* R2.5.0：入睡定时 = 下一次调度事件 */
#include "wifi_mgr.h"      /* ★R2.7.2【修复1c】：esp_wifi_stop 前查 wifi_mgr_up（轻唤醒未起射频则不停） */

#include "driver/gpio.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_sleep.h"
#include "esp_attr.h"       /* R2.5.1：RTC_NOINIT_ATTR（IDF 6.x noinit 段改名后必须用官方宏） */
#include "esp_timer.h"      /* R2.5.0：忙脉冲用 esp_timer 单调钟 */
#include "esp_wifi.h"
#include "esp_log.h"
#include "esp_system.h"     /* R2.7.0：esp_reset_reason（崩溃自愈判据） */
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <time.h>            /* R2.7.0：校时保底升格用 time(NULL) */

static const char *TAG = "power";

#define AUTO_WAKE_WINDOW_S 180   /* wake_s 定时唤醒后等人的窗口（秒） */
#define PWR_EVENT_WINDOW_S 60    /* R2.5.0：调度事件唤醒后的收尾窗口上限（秒）
                                    —— 刷屏/拉取/网络门控全部完成后再留一段
                                    给「正好有人打开配置页」接管；事件越密
                                    收尾越紧（见下方自适应），1 分钟档几乎
                                    干完即睡 */
#define PWR_EVENT_WINDOW_MIN_S 15 /* 事件窗自适应下限（秒） */
/* ★R2.7.0 轻唤醒（分钟局刷）收尾窗口（秒）：不起射频、无配置页可接管
 *   —— 没有可等的人，刷完即睡。忙脉冲仍生效（快刷 ~0.3s / 换位整刷
 *   在 overlay 侧自报 25s，不会拦腰打断）。 */
#define PWR_EVENT_WINDOW_LIGHT_S 4
#define PWR_FALLBACK_S     900   /* R2.5.0：无任何调度事件时的看护唤醒（15 分钟）
                                    —— 否则没接唤醒键又没事件的设备会一睡不醒；
                                    也兼作「路由器恢复后自动回 STA」的自愈入口 */

/* R2.5.0：入睡意图标记，写入 RTC 慢速内存 noinit 段 —— 深睡保持、上电/复位
 * 后内容未定义（魔数 + 范围校验，不可靠一律按无标记处理）。
 * 用迹：定时器唤醒分清「调度事件（短窗口干活）」与「wake_s 等人（长窗口）」；
 * planned_s 仅供唤醒后串口日志比对 RTC 漂移。
 * ★R2.6.0：新增 evt + tgt_epoch —— 入睡时本次定时唤醒所瞄准的调度事件
 *   （BOX/REMOTE/CAROUSEL/MOVE）及其边界时刻；唤醒侧 overlay 依此判断
 *   「边界是否被上电门控吃掉」并立即补发（错过整分判据 = 时钟 stale 一个周期）。
 * R2.5.1：改挂官方 RTC_NOINIT_ATTR 宏。R2.5.0 手写旧段名 section(".rtc.noinit")
 * 在 IDF 6.x 已被改名（.rtc.noinit -> .rtc_noinit，宏跟随新名）后无人归置成
 * 孤儿段，而 IDF 6.x 默认 -Wl,--orphan-handling=error，链接直接报
 * "unplaced orphan section"。官方宏的段名永远跟随当前 IDF，v4/v5/v6 通用。 */
#define PWR_RTC_MAGIC 0x4D4F494EU   /* "MOIN" */

static struct {
    uint32_t magic;
    uint8_t  purpose;
    uint8_t  evt;          /* R2.6.0：PWR_EVT_*（调度事件；WAKE/NONE 无补刷意义） */
    uint16_t _rsv;
    uint32_t planned_s;
    int64_t  tgt_epoch;    /* R2.6.0：事件边界 epoch 秒 */
    /* ★R2.7.1：标记写入时刻 —— 写入后未睡下即复位（崩溃/掉电）会残留
       「从未兑现」的旧标记；唤醒侧用 planned_s 与实际流逝时间做合理性
       二次校验（见 power_boot_purpose）。 */
    int64_t  mark_epoch;
} s_rtc_wake RTC_NOINIT_ATTR;

/* ★R2.7.0 全功能唤醒时刻标记（RTC noinit）—— 轻链连续超过 PWR_SYNC_IV_MIN
 *（12h）时，power_enter_deep_sleep 把下一个 BOX 轻唤醒升格为 PWR_EVT_SYNC
 * 全功能唤醒（联网 + SNTP 重锚 + 蓝牙窗口）。有 REMOTE/CAROUSEL/MOVE/
 * wake_s 任一周期事件时永不触发（它们本身就是全功能唤醒，每次都刷新本
 * 标记）。魔数 + last_full > 0 双校验，掉电/乱码一律按从未全功能处理。 */
#define PWR_RTC_FULL_MAGIC 0x4D4F464Cu   /* "MOFL" */
static struct {
    uint32_t magic;
    int64_t  last_full_epoch;
} s_rtc_full RTC_NOINIT_ATTR;

static wake_purpose_t s_purpose = WAKE_PURPOSE_POWER_ON;   /* 本次开机用途 */
static uint32_t s_planned_s = 0;                            /* 入睡时计划的定时（秒） */
static int64_t s_busy_until_ms = 0;                         /* R2.5.0：忙到何时（esp_timer 单调钟） */
static bool s_light = false;           /* ★R2.7.0：本次开机是分钟局刷轻唤醒 */
static bool s_unattended_reboot = false; /* ★R2.7.0：崩溃/看门狗/掉电复位重启（无人） */

/* ★R2.7.2【修复1b】：「正在入睡」全局标志 —— 入睡序列开头置位、二次校验
 *   中止时清除（成功睡下随断电消亡）。置位窗口内 wifi_mgr 的掉线/慢重试/
 *   探测一律短路、display_task 暂缓 UI 事件（power_sleeping() 查询口在
 *   power.h）。单字节标志、只草向单方向翻转，无需加锁。 */
static volatile bool s_sleeping = false;

bool power_sleeping(void)
{
    return s_sleeping;
}

void power_busy_pulse(uint32_t seconds)
{
    /* 多源取最长：拉取 90s 脉冲叠加刷屏 15s 脉冲时按远的算。 */
    int64_t until = esp_timer_get_time() / 1000 + (int64_t)seconds * 1000;
    if (until > s_busy_until_ms) s_busy_until_ms = until;
}

void power_busy_cap(uint32_t seconds)
{
    /* R2.6.0：忙期收口（只减不增）——远端拉取完成后的尾部等待。 */
    int64_t until = esp_timer_get_time() / 1000 + (int64_t)seconds * 1000;
    if (until < s_busy_until_ms) s_busy_until_ms = until;
}

static bool busy_now(void)
{
    return esp_timer_get_time() / 1000 < s_busy_until_ms;
}

/* 电池分压 1M:1M => Vbat = Vpin * (1M+1M)/1M = Vpin * 2.0（比值与 100k:100k 相同）。
   ⚠️ 分压比是板级硬件事实：换板 / 改电阻必须同步改这里，否则电量整体偏移。
   ⚠️ 1M 高阻源（≈500k 输出阻抗）会让 ADC 读数偏低：ADC 端建议并联 100nF 到地，
      并在换板后按实测复核 BAT_FULLSCALE_MV。 */
#define BAT_DIV_NUM        200
#define BAT_DIV_DEN        100
#define BAT_ADC_MAX        4095
#define BAT_FULLSCALE_MV   3100   /* 12dB 满量程，按板实测标定（换分压后建议复核） */
/* 未连接判定：单节锂电物理范围 + 采样极差（见 power_battery_mv）。
   R1.3.4：改为「一次调用内多次采样」，见函数注释。
   ★ ESP32 移植版：无电池时 ADC 默认脚 GPIO34 悬空，靠极差检测返回「未连接」。 */
#define BAT_MV_MIN         2400
#define BAT_MV_MAX         4600
#define BAT_SAMPLES        12     /* 每次调用的采样点数（中位数抗单个坏点） */
#define BAT_SPREAD_MAX     500    /* mV：max-min 超过即判悬空（真实电池毫秒级不会跳这么多） */

static adc_oneshot_unit_handle_t s_adc;
static TickType_t s_last_activity;

/* R1.2.2：唤醒脚与电池 ADC 脚改为运行时从 settings_pins() 取。
   ★ ESP32 移植版：ADC1 通道与引脚不再是等值映射（C3 上 GPIO0..4=CH0..4），
   ESP32 上 GPIO32..36、39 = CH4..7、CH0、CH3，需查表换算。 */
static uint8_t s_wake_pin = 25;
static adc_channel_t s_adc_ch = ADC_CHANNEL_6;   /* 默认 GPIO34 = ADC1_CH6 */

/* GPIO 引脚号 -> ADC1 通道号（ESP32，仅限 pin_adc_allowed 白名单内的脚）。 */
static adc_channel_t gpio_to_adc1_ch(uint8_t io)
{
    switch (io) {
    case 36: return ADC_CHANNEL_0;
    case 39: return ADC_CHANNEL_3;
    case 32: return ADC_CHANNEL_4;
    case 33: return ADC_CHANNEL_5;
    case 34: return ADC_CHANNEL_6;
    case 35: return ADC_CHANNEL_7;
    default: return ADC_CHANNEL_6;
    }
}

void power_init(void)
{
    const pin_cfg_t *p = settings_pins();
    s_wake_pin = p->v[PIN_IDX_WAKE];
    s_adc_ch   = gpio_to_adc1_ch(p->v[PIN_IDX_ADC]);

    gpio_config_t btn = {
        .pin_bit_mask = 1ULL << s_wake_pin,
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    ESP_ERROR_CHECK(gpio_config(&btn));

    /* 电池 ADC：只用 ADC1（ADC2 与 WiFi 共用，不可用），通道随引脚。 */
    adc_oneshot_unit_init_cfg_t u = {
        .unit_id = ADC_UNIT_1,
        .ulp_mode = ADC_ULP_MODE_DISABLE,
    };
    ESP_ERROR_CHECK(adc_oneshot_new_unit(&u, &s_adc));
    adc_oneshot_chan_cfg_t c = {
        .atten = ADC_ATTEN_DB_12,
        .bitwidth = ADC_BITWIDTH_12,
    };
    ESP_ERROR_CHECK(adc_oneshot_config_channel(s_adc, s_adc_ch, &c));

    ESP_LOGI(TAG, "wake btn GPIO%u, battery ADC GPIO%u (ADC1_CH%d)",
             s_wake_pin, p->v[PIN_IDX_ADC], (int)s_adc_ch);

    power_activity();
}

void power_activity(void)
{
    s_last_activity = xTaskGetTickCount();
}

/* ---- R2.5.0：唤醒用途 ---- */

wake_purpose_t power_boot_purpose(bool woken_by_timer, bool woken_by_button)
{
    bool marker_ok = false;
    if (woken_by_timer) {
        if (s_rtc_wake.magic == PWR_RTC_MAGIC &&
            (s_rtc_wake.purpose == WAKE_PURPOSE_TIMER_EVENT ||
             s_rtc_wake.purpose == WAKE_PURPOSE_TIMER_HUMAN)) {
            /* ★R2.7.1 标记新鲜度二次校验：mark_epoch 到本次开机的实际流逝
               应 ≈ planned_s —— 写入后未睡下即复位会残留「从未兑现」的
               旧标记（elapsed ≈ 0 或离谱），差得远即作废。 */
            bool fresh = true;
            if (s_rtc_wake.mark_epoch != 0) {
                int64_t gone = (int64_t)time(NULL) - s_rtc_wake.mark_epoch;
                int64_t plan = (int64_t)s_rtc_wake.planned_s;
                if (gone < plan / 2 || gone > plan * 2 + 120) fresh = false;
            }
            if (fresh) {
                marker_ok   = true;
                s_purpose   = (wake_purpose_t)s_rtc_wake.purpose;
                s_planned_s = s_rtc_wake.planned_s;
            } else {
                ESP_LOGW(TAG, "stale wake marker (elapsed %llds vs planned %lus), drop",
                         (long long)((int64_t)time(NULL) - s_rtc_wake.mark_epoch),
                         (unsigned long)s_rtc_wake.planned_s);
            }
        }
        if (!marker_ok) {
            /* 标记丢失/不合法/过期：按老行为兜底（定时唤醒 = 等人窗口 + 自动切图）。 */
            s_rtc_wake.magic = 0;   /* ★R2.7.1：过期标记同时作废（evt/tgt 不再可信） */
            s_purpose   = WAKE_PURPOSE_TIMER_HUMAN;
            s_planned_s = 0;
        }
    } else {
        /* 非定时器唤醒：RTC 标记无意义（上电内容未定义 / 按键本来就不带标记）。 */
        s_purpose = woken_by_button ? WAKE_PURPOSE_BUTTON : WAKE_PURPOSE_POWER_ON;
    }

    /* ★R2.7.0 两档功耗状态机分流：TIMER_EVENT + BOX 目标事件 = 轻唤醒
       （分钟局刷：不起射频、门控捷径、4s 收尾）；其余（REMOTE/CAROUSEL/
       MOVE/SYNC/看护 evt=NONE、WAKE 等人、按键、上电）= 全功能唤醒。 */
    {
        uint8_t evt = PWR_EVT_NONE;
        s_light = (s_purpose == WAKE_PURPOSE_TIMER_EVENT) &&
                  power_wake_event(&evt, NULL) && (evt == PWR_EVT_BOX);
    }

    /* ★R2.7.1 崩溃自愈判据对【所有唤醒用途】生效（原仅查 WAKE_PURPOSE_POWER_ON）：
       定时唤醒运行期崩溃（TWDT/panic/brownout）复位后 noinit 标记仍有效、
       wake-cause 寄存器还可能残留 TIMER 位 → 被误判为轻唤醒（不起射频、
       时钟漂移无人重锚）。凡 PANIC/INT_WDT/TASK_WDT/WDT/BROWNOUT 复位
       一律按全功能收尾（60s 事件窗 + 起网校时，见 power_should_sleep）。 */
    s_unattended_reboot = false;
    switch (esp_reset_reason()) {
    case ESP_RST_PANIC:
    case ESP_RST_INT_WDT:
    case ESP_RST_TASK_WDT:
    case ESP_RST_WDT:
    case ESP_RST_BROWNOUT:
        s_unattended_reboot = true;
        break;
    default:
        break;
    }
    if (s_unattended_reboot && s_light) {
        s_light = false;   /* 崩溃复位不走轻唤醒：起射频 + SNTP 重锚 */
        ESP_LOGW(TAG, "crash/wdt/brownout reset: force full-function wake");
    }

    /* 全功能开机刷新校时保底标记（轻链由此起算 12h 升格）。 */
    if (!s_light) {
        s_rtc_full.magic = PWR_RTC_FULL_MAGIC;
        s_rtc_full.last_full_epoch = (int64_t)time(NULL);
    }
    return s_purpose;
}

const char *power_purpose_name(wake_purpose_t p)
{
    switch (p) {
    case WAKE_PURPOSE_BUTTON:        return "button";
    case WAKE_PURPOSE_TIMER_EVENT:   return "timer-event";
    case WAKE_PURPOSE_TIMER_HUMAN:   return "timer-human";
    default:                         return "power-on";
    }
}

uint32_t power_planned_sleep_s(void)
{
    return (s_rtc_wake.magic == PWR_RTC_MAGIC) ? s_rtc_wake.planned_s : 0;
}

wake_purpose_t power_wake_purpose(void)
{
    return s_purpose;
}

bool power_wake_is_light(void)
{
    return s_light;
}

/* ★R2.7.0：本次开机是否为无人attended的崩溃/看门狗/掉电复位重启
 *（有人插电/软重启为 false）。boot 门控据此走快速档（崩溃自愈不等人）。 */
bool power_unattended_reboot(void)
{
    return s_unattended_reboot;
}

void power_human_open_window(void)
{
    /* ★R2.7.0 轻唤醒期间有人按键：窗口升格「等人」档（BUTTON，sleep_s）——
       本次开机从此按「有人在用」收尾；配合 main 的按需起网（WiFi+HTTP），
       单击即可临时打开配置页，不必等下一个全功能唤醒。其余档位只续命。 */
    if (s_light) {
        s_light = false;
        s_purpose = WAKE_PURPOSE_BUTTON;
        ESP_LOGI(TAG, "human present during light wake: window -> sleep_s");
    }
    power_activity();
}

bool power_wake_event(uint8_t *evt, int64_t *tgt_epoch)
{
    if (s_rtc_wake.magic != PWR_RTC_MAGIC) {
        if (evt) *evt = PWR_EVT_NONE;
        if (tgt_epoch) *tgt_epoch = 0;
        return false;
    }
    if (evt) *evt = s_rtc_wake.evt;
    if (tgt_epoch) *tgt_epoch = s_rtc_wake.tgt_epoch;
    return s_rtc_wake.evt != PWR_EVT_NONE;
}

uint64_t power_wakeup_causes(void)
{
    return esp_sleep_get_wakeup_causes();
}

bool power_should_sleep(void)
{
    /* ★R2.7.1 boot 门控未完成绝不入睡：轻唤醒 4s 收尾窗可能在门控完成前
       到点（idle 自 power_init 起算），腰斩 boot_gate_task = 「永不清醒」
       循环；全功能门控最长 92s 同样不能被事件窗拦腰打断。 */
    if (!overlay_boot_done()) return false;

    const moink_settings_t *s = settings_get();
    uint32_t limit = s->sleep_s;

    /* R2.5.0：窗口按唤醒用途选。
       sleep_s = 0（不超时）仅剩两种睡法：定时唤醒后的短窗（维持
       wake_s 唤醒链不断）——否则永不睡、链断。 */
    if (s_purpose == WAKE_PURPOSE_TIMER_HUMAN) {
        if (limit == 0 || limit > AUTO_WAKE_WINDOW_S) limit = AUTO_WAKE_WINDOW_S;
    } else if (s_purpose == WAKE_PURPOSE_TIMER_EVENT) {
        /* ★R2.7.0 轻唤醒（分钟局刷）：固定 4s 收尾 —— 不起射频、无配置页
           可接管，没有可等的人，刷完即睡（忙脉冲仍生效，不会拦腰打断）。
           全功能事件窗自适应不变：planned_s ≈ 事件间隔 —— 间隔越密收尾
           越紧（1 分钟档 ≈ 常开，必须干完即睡；10 分钟档留满 60s）。 */
        uint32_t w = PWR_EVENT_WINDOW_S;
        if (s_light) {
            w = PWR_EVENT_WINDOW_LIGHT_S;
        } else if (s_planned_s != 0) {
            uint32_t adapt = s_planned_s / 4;
            if (adapt < PWR_EVENT_WINDOW_MIN_S) adapt = PWR_EVENT_WINDOW_MIN_S;
            if (adapt < w) w = adapt;
        }
        if (limit == 0 || limit > w) limit = w;
    }
    /* ★R2.7.1 崩溃自愈收尾窗对全部唤醒用途生效（原仅上电位）：无人
       attended 的复位重启没有配置页访客，按 60s 事件窗尽快回链校时。 */
    if (s_unattended_reboot) {
        if (limit == 0 || limit > PWR_EVENT_WINDOW_S) limit = PWR_EVENT_WINDOW_S;
    }
    if (limit == 0) return false;

    /* R2.5.0：忙期内不睡 —— 刷屏/拉取没有 HTTP 心跳，靠忙脉冲报备；
       防止整屏刷新进行到一半被深睡打断（面板序列波死中间）。 */
    if (busy_now()) return false;

    /* ★R2.7.2【修复2】：EPD 面板序列硬判据 —— 整刷/快刷/清屏进行中一律
       不睡。忙脉冲靠各任务「自觉上报」，而入睡序列自己触发的重画
       （R2.7.1 睡死：esp_wifi_stop → net_changed → 15s 全屏重画）发生在
       判闲之后、脉冲置位之前，旧判据完全拦不住；现在直接查驱动层
       面板忙标志（display 开始置位、refresh done/timeout 清除）。 */
    if (epd_panel_busy()) return false;

    TickType_t idle = xTaskGetTickCount() - s_last_activity;
    return idle >= pdMS_TO_TICKS(limit * 1000);
}

/* ★R2.7.2【修复1】：入睡序列核心（原 power_enter_deep_sleep 主体重构）。
 *   force = false（常规空闲入睡）：带二次校验，校验不过则中止入睡并返回；
 *   force = true（假唤醒直接回睡）：跳过校验（调用点已确认无活动可打断）。
 *   顺序硬约束（修复1c）：①先置 sleeping 标志 → ②评估唤醒计划 →
 *   ③再 esp_wifi_stop —— 标志先行，停 WiFi 异步触发的掉线事件才会被
 *   wifi_mgr 短路，不再引发「重开热点 + 重连 + net_changed 全屏重画」
 *   （R2.7.1 睡死根因链的起点）。 */
static void deep_sleep_seq(bool force)
{
    if (s_sleeping) return;            /* 防重入：已有入睡序列在途 */
    s_sleeping = true;                 /* 【修复1c】标志先行，短路一切重连/重画 */
    ESP_LOGI(TAG, "sleep sequence: armed (%s)",
             force ? "forced, spurious wake" : "idle timeout");

    /* R2.5.0：定时唤醒 = 「下一次调度事件」与用户 wake_s 里更早者；
       都没有则设看护唤醒（防一睡不醒 + 路由器恢复自愈）。
       ★R2.6.0：调度事件唤醒时把事件种类 + 边界时刻一并写入 RTC ——
       唤醒后 overlay 用它补发被上电门控吃掉的到点事件（时钟分钟刷新 /
       远端拉取不再因错过整分判据而 stale 一个周期）。
       ★R2.6.2：唤醒计划【先于】esp_wifi_stop() 评估 —— 停 WiFi 可能异步
       触发掉线事件（STA → AP 回退 + 重连），事件任务慢一步处理时
       overlay_next_wake_s 看到的 wifi_mgr_mode() 已翻成 AP：REMOTE 事件
       被从下次唤醒计划挤掉（唤醒落到 15min 看护档，远端拉取表现为
       「失败」）。睡前一刻的网络态才是「睡前真值」。 */
    const moink_settings_t *s = settings_get();
    uint8_t ev_evt = PWR_EVT_NONE;
    int64_t ev_at = 0;
    const uint32_t ev_s = overlay_next_wake_s(&ev_evt, &ev_at);
    uint32_t t = 0;
    wake_purpose_t p = WAKE_PURPOSE_TIMER_EVENT;

    if (s->wake_s != 0 && (ev_s == 0 || s->wake_s < ev_s)) {
        t = s->wake_s;
        p = WAKE_PURPOSE_TIMER_HUMAN;
    } else if (ev_s != 0) {
        t = ev_s;
    } else {
        t = PWR_FALLBACK_S;
        ESP_LOGI(TAG, "no scheduled event, fallback watchdog wake %us", t);
    }

    /* ★R2.7.0 校时保底：计划的唤醒是 BOX 轻唤醒、且距上次全功能唤醒已过
       PWR_SYNC_IV_MIN —— 轻链不能无限连跑（RC 慢漂没人重锚、蓝牙/远端
       永不更新）。升格为 PWR_EVT_SYNC 全功能唤醒：联网 + SNTP 重锚 +
       蓝牙窗口（唤醒侧 catch-up 顺带补一次分钟刷新）。定时长度不变
       （BOX 轻提前量 6s）：门控吃掉边界由 SYNC 补刷兜底。周期事件
       （REMOTE/CAROUSEL/MOVE/wake_s）本身就是全功能，升格永不触发。 */
    if (p == WAKE_PURPOSE_TIMER_EVENT && ev_evt == PWR_EVT_BOX &&
        s_rtc_full.magic == PWR_RTC_FULL_MAGIC && s_rtc_full.last_full_epoch > 0) {
        int64_t now = (int64_t)time(NULL);
        if (now - s_rtc_full.last_full_epoch >= (int64_t)PWR_SYNC_IV_MIN * 60) {
            ev_evt = PWR_EVT_SYNC;
            ESP_LOGI(TAG, "light chain ran %.1fh, upgrade next wake to time-sync full cycle",
                     (double)(now - s_rtc_full.last_full_epoch) / 3600.0);
        }
    }

    /* ★R2.7.2【修复1c/评审低项10】网络栈在位才停 WiFi：轻唤醒从未初始化
     * 射频，esp_wifi_stop() 对未 init 驱动只会报错（语义错误）且其异步
     * 事件仍会无谓地走一遍事件循环；全功能/按需起网的开机才真正停机。 */
    if (wifi_mgr_up()) {
        esp_wifi_stop();
        /* 【修复1a】200ms 收尾：让停机引发的异步掉线/STOP 事件落地 ——
         * 事件处理器此刻被 sleeping 标志短路（不重连、不重画），
         * 二次校验看到的是「真实的外部活动」而非入睡序列自己的噪声。 */
        vTaskDelay(pdMS_TO_TICKS(200));
        /* 【修复1a】入睡二次校验（睡死根治核心）：收尾后再看一次
         * power_should_sleep() —— 期间有任何活动（忙脉冲 / EPD 面板
         * 正在刷 / 有人刚续命 / boot 门控未完）则中止入睡并返回。
         * R2.7.1 及之前这里无任何校验，直接写标记断电 —— 正在进行的
         * 15s 全屏刷新被拦腰斩断、屏幕定格半刷状态即「睡死」。
         * 被停掉的 WiFi 交由 wifi_mgr slow_retry 的恢复分支拉起
         * （见 wifi_mgr.c R2.7.2 s_drv_stopped，最长 2 分钟）。 */
        if (!power_should_sleep()) {
            ESP_LOGW(TAG, "sleep aborted: activity during entry "
                          "(busy=%d panel=%d), staying awake",
                     (int)busy_now(), (int)epd_panel_busy());
            s_sleeping = false;    /* 解除短路，各任务恢复正常工作 */
            return;
        }
    }

    /* ---- 以下为「提交入睡」：不再回头，所有破坏性动作都在二次校验之后 ---- */

    overlay_zone_invalidate();   /* R2.4.0：深睡丢 RAM，快刷基准失效 */
    epd_panel_deep_sleep();

    /* ★ ESP32 移植版：ext0 深睡唤醒（RTC 域 GPIO，内部上拉，按键接 GND 低电平唤醒）。
       替换 C3 专用的 esp_sleep_enable_gpio_wakeup_on_hp_periph_powerdown()。 */
    gpio_pullup_en((gpio_num_t)s_wake_pin);
    gpio_pulldown_dis((gpio_num_t)s_wake_pin);
    gpio_set_direction((gpio_num_t)s_wake_pin, GPIO_MODE_INPUT);
    ESP_ERROR_CHECK(esp_sleep_enable_ext0_wakeup((gpio_num_t)s_wake_pin, 0));

    if (t != 0)
        esp_sleep_enable_timer_wakeup((uint64_t)t * 1000000ULL);
    else
        esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);

    const uint8_t wake_evt = (p == WAKE_PURPOSE_TIMER_EVENT) ? ev_evt
                                                             : (uint8_t)PWR_EVT_NONE;
    ESP_LOGI(TAG, "deep sleep (btn GPIO%u low, wake in %lus, %s%s%s)",
             s_wake_pin, (unsigned long)t, power_purpose_name(p),
             (wake_evt != PWR_EVT_NONE) ? " target=" : "",
             (wake_evt != PWR_EVT_NONE) ? pwr_sched_evt_name(wake_evt) : "");

    /* ★R2.7.1 标记在 esp_deep_sleep_start() 前最后一刻写入（含写入时刻
       mark_epoch）：原先写在 200ms 收尾延时空隙里，写入后未睡下即复位
       会残留「从未兑现」的标记；唤醒侧靠 mark_epoch 与 planned_s 的
       合理性二次校验兜底（见 power_boot_purpose）。
       ★R2.7.2：200ms 收尾延时已提前到二次校验之前（epd_panel_deep_sleep
       内部自带的 200ms 稳定等待保留），此处不再额外延时 —— 日志与标记
       都是「即将断电」的最后声明。 */
    s_rtc_wake.magic      = PWR_RTC_MAGIC;
    s_rtc_wake.purpose    = (uint8_t)p;
    s_rtc_wake.evt        = wake_evt;
    s_rtc_wake._rsv       = 0;
    s_rtc_wake.planned_s  = t;
    s_rtc_wake.tgt_epoch  = (p == WAKE_PURPOSE_TIMER_EVENT) ? ev_at : 0;
    s_rtc_wake.mark_epoch = (int64_t)time(NULL);
    esp_deep_sleep_start();
}

void power_enter_deep_sleep(void)
{
    /* ★R2.7.2【修复1a】：常规空闲入睡 —— 带二次校验，可能返回
     *（详见 power.h 契约注释与 deep_sleep_seq）。 */
    deep_sleep_seq(false);
}

void power_deep_sleep_now(void)
{
    /* ★R2.7.2【修复6】：强制入睡（无二次校验）—— 仅限 ext0 假唤醒去抖
     * 确认后直接回睡等「确认无活动可被打断」的调用点。 */
    deep_sleep_seq(true);
}

void power_self_lock_off(void)
{
    /* ★ ESP32 移植版：无 MOS 自锁电路（原 C3 版 GPIO2 自锁已删除，
       拉低 GPIO2 会影响下载模式，不可为），「关机」档直接退回深睡。
       ★R2.7.2：同样走带二次校验的入睡序列 —— 刷屏/拉取进行中的
       「关机」会被推迟到空闲后执行（idle_monitor 每秒重试），
       不再拦腰斩断正在进行的刷新。 */
    ESP_LOGW(TAG, "timeout action = off: no self-lock circuit on ESP32 port, "
                  "fallback to deep sleep");
    power_enter_deep_sleep();
}

int power_battery_mv(void)
{
    /* R1.3.4（FB-019）：**一次调用内完成全部采样**。
       旧实现要求「跨请求连续 3 次有效」才返回数值，而 /api/info 每次只调本函数一次、
       控制页又只在打开时请求一次 ⇒ 计数器永远到不了 3，首次打开必显示「未连接」，
       必须手动刷新数次才偶发出值（实测复现）。
       新做法：
       1. 连采 BAT_SAMPLES 次，取**中位数**（单个坏点不影响结果）；
       2. 用**极差 max-min** 判悬空：ADC 悬空时读数靠杂散耦合乱漂
          （实测 3.2/3.3/17.6V 交替），极差远大于真实电池；
       3. 中位数越界或极差超限 → 返回 -1（页面显示「未连接」）。
       这样单次 /api/info 即可出稳定电压，页面无需轮询
       （轮询会让 power_activity() 不断续命、永不休眠）。 */
    int v[BAT_SAMPLES];
    int n = 0;

    for (int i = 0; i < BAT_SAMPLES; i++) {
        int raw = 0;
        if (adc_oneshot_read(s_adc, s_adc_ch, &raw) != ESP_OK) continue;
        /* 注意乘法顺序：先除再乘，避免 raw*3100*200 溢出 int */
        v[n++] = raw * BAT_FULLSCALE_MV / BAT_ADC_MAX * BAT_DIV_NUM / BAT_DIV_DEN;
    }
    if (n < 3) return -1;

    /* 插入排序（最多 12 个元素），取中位数与极差 */
    for (int i = 1; i < n; i++) {
        int t = v[i], j = i - 1;
        while (j >= 0 && v[j] > t) { v[j + 1] = v[j]; j--; }
        v[j + 1] = t;
    }
    int med = v[n / 2];
    int spread = v[n - 1] - v[0];

    if (med < BAT_MV_MIN || med > BAT_MV_MAX) return -1;
    if (spread > BAT_SPREAD_MAX) return -1;
    return med;
}
