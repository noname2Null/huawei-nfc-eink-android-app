#ifndef MOINK_OVERLAY_H
#define MOINK_OVERLAY_H

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#include "settings.h"   /* R2.4.0：SETT_BOX_WG_BYTES（自定义控件 blob 尺寸） */

/*
 * R2.0.0 顶部信息框 + 分钟调度 + 密码重置屏。
 *
 * ★ R2.2.1 方向化几何（以屏幕排线为基准，settings.orient 0..3）：
 *   本模块一切坐标都在【用户视角画布】上（orient 0/2 = 552×768 竖屏，
 *   1/3 = 768×552 横屏；宽高运行时从 settings 同步，见 overlay_canvas_w/h）。
 *   条带缓冲 s_strip 为用户坐标行主序：160 行 × (画宽/4) 字节
 *   （竖屏 160×138，横屏 160×192，静态按最大 30720 分配）。
 *   载荷（552 行×192B，面板画布）与用户画布的旋转关系、条带在载荷里的
 *   区域、blend/capture 的搬移公式均由 scripts/sim_orient_geom.py 机器证明：
 *     orient 0 排线下：条带 = 每载荷行首 40B；blend 写 provider 字节 152..191
 *     orient 2 排线上：条带 = 每载荷行末 40B；blend 写 provider 字节 0..39
 *     orient 1 排线左：条带 = 载荷行 392..551 整行；blend 写 provider 行 0..159 逐字节原样
 *     orient 3 排线右：条带 = 载荷行 0..159 整行；blend 写 provider 行 392..551 整行镜像
 *   面板与载荷的映射（provider = 镜像(载荷行 551-r)，驱动再镜像）对方向零改动。
 *
 * ★ R2.0.1 内存架构：本模块不再借助整帧 RAM 缓冲（WROOM-32 无 PSRAM，
 *   120KB 连续堆不可得，见 frame.c）。信息框 / 密码屏只画用户画布顶部
 *   160 行，画进 overlay 自己的条带缓冲 s_strip：
 *     - 上传 / 图库切图时由 frame.c 逐段喂条带（overlay_strip_capture_row）；
 *     - 信息框到点重画时由 frame.c 从当前显示源重新截取干净条带；
 *     - 刷屏时 frame.c 的流式行合成把条带按方向替换进 provider 行
 *       （overlay_strip_blend）。
 *
 * ★ R2.0.6 信息框版式（数字 = 7 段数码管，中文 = 32px 思源宋体）：
 *   框 = 用户画布顶部 160 行满幅平角条带；左 = 大号时间 HH:MM 贴左缘，
 *   右 = 日期周X + 温湿两行贴右缘，中部留白；有 IP 行时底部居中（图标+IP）。
 *   全部文字带白描边（两遍渲染）。横屏方向版式求解器按画宽自适应。
 *   显示样式：叠加（白抖动框压照片，密度可调）/ 分割（新照片让出框区）。
 *
 * 调度：按**时间**对齐 —— 每逢 分钟数 % 间隔 == 0 的整分钟边刷新一次
 *（JDY79668 四色屏无局部刷新波形，间隔档 1/5/10/30/60 分钟可调）。
 *
 * 掉电防护：条带不备份照片副本，从 store 槽按需重截（flash 即“帧缓存”）。
 *
 * 密码重置屏（免认证接口触发）：
 *   阶段 1：条带白色铺底 + 红色加粗「重置密码中」整屏刷新；
 *   60 秒后阶段 2：同位置红色加粗「新密码 XXXXXX」。
 *   阶段期间暂停信息框刷新；结束后下一次信息框刷新自动恢复照片+信息框。
 */

/* 初始化：创建分钟调度定时器；post = main.c 的 ui_post（事件枚举 OV_EV_*）。 */
void overlay_init(void (*post)(int ev));

/* overlay → display_task 的事件号（与 main.c 的 ui_event_t 数值一致）。 */
enum {
    OV_EV_CAROUSEL_NEXT = 0, /* R2.1.0：图库自动轮播到点（信息栏不展示时） */
    OV_EV_BOX_TICK = 1,    /* 到点/数值变化：重画信息框（消耗 IP 周期） */
    OV_EV_PWD_RESET,       /* 忘记密码：画「重置密码中」并启动 60s 定时器 */
    OV_EV_PWD_SHOW,        /* 60s 到：生成新密码并画「新密码 XXXXXX」 */
    OV_EV_BOX_APPLY = 4,   /* R2.0.3：改设置触发重画（不消耗 IP 周期） */
    OV_EV_NET_CHANGED = 5, /* R2.1.0：网络状态变化（wifi_mgr 三连确认后投递） */
    /* 6 = R2.2.1 UI_EV_GEOM_CHANGED（屏幕方向变化）：main.c 自己投递 ——
       overlay 侧几何由 geom_sync 与 settings 实时同步，无须 overlay 转发。 */
    OV_EV_TIME_STEP = 7,   /* ★R2.6.1：NTP 步进时钟（wifi_mgr SNTP 回调投递）——
                               重排分钟定时器 + 时钟显示立即局刷校正 */
};

/* ---- 条带截取（frame.c 在帧锁下调用；见文件头「R2.2.1 方向化几何」） ---- */

/* 白底条带（无图源 / 图库为空时的干净起点）。 */
void overlay_strip_fill_white(void);

/* ★ R2.4.0：区化截取 —— 任意矩形区（上/下/左/右/自定义包围盒）。
 * frame.c 先取区的载荷行足迹 [r0,r1)，再逐行读完整 192B 载荷行喂入；
 * 摘取映射在 zone_core.c（与 R2.2.1 顶部条带公式对拍 + 往返自反测试）。
 * ★R2.6.0：换位让位生效时（框在「下」+分割式源）框区底下无照片，
 * 足迹返回空 [0,0) —— 上传完成性校验随之期望 0 段，截取完成走白底。 */
void overlay_capture_row_range(int *r0, int *r1);
void overlay_payload_capture_row(int row, const uint8_t *line192);
/* R2.4.1：区截取期望段数（= 载荷行足迹 r1-r0；段 = 一条完整 192B 载荷行）。
 * frame.c 上传完成性校验：实收段数不等 → 帧几何与当前区不符，判失败。 */
int  overlay_strip_capture_segs(void);

/* 截取完成：条带有效、回到“干净照片”状态（尚未画信息框）。 */
void overlay_strip_capture_done(void);



/* 刷屏行合成：把用户条带按方向写进 provider 行 row_rot（r = provider 行号
 *   0..551；竖屏写行内 40 字节段，横屏整行替换/镜像）。条带无效时不动。
 *   ★R2.6.0：换位让位生效时先对行做照片平移（zc_shift_row_bytes）再合成。 */
void overlay_strip_blend(uint8_t *row_rot, int r);

/* ---- ★R2.6.0 防烧屏换位让位（照片跟随框上移） ----
 * 生效条件（全部满足）：显示源为分割式（本地上传 split / 远端分割）、
 * 标准横向条带位于「下」、无自定义控件布局、非密码屏/远端全屏、
 * 信息框实际在画。竖向条带（左/右）无横向白边可消耗，不生效。
 * frame.c 行供数用：overlay_photo_shift_row 返回该 provider 行应读的
 * 载荷行号（不生效时原样返回 fallback；行属框区返回 -1 = 整行白）。 */
bool overlay_photo_shift_active(void);
int  overlay_photo_shift_row(int r, int fallback_row);

/* R2.2.1：方向几何（用户画布宽/高）。内部与 settings 同步；几何切换时
 *   条带自动失效，须重截后再刷屏（main.c GEOM_CHANGED 事件负责重截）。 */
int  overlay_canvas_w(void);
int  overlay_canvas_h(void);

/* R2.4.0：到点/数值变化统一入口 —— 可快刷（局刷，仅变更控件 ~30ms DRF）
 * 则快刷，否则整刷。count_cycle 语义同 overlay_box_redraw。 */
void overlay_box_tick(bool count_cycle);
/* ★R2.6.1：NTP 步进后再对齐 —— 重排分钟定时器到「新钟」的下一个整分；
 * 时钟控件显示值已落后一个分钟（步进跨分界）且快刷可用时立即局刷校正
 * （不消耗 IP 周期）；快刷不可用/基准丢失时只重排定时器（下一个到点
 * 刷新自然纠正，不为此强行整刷）。display_task 上下文。 */
void overlay_time_realign(void);
/* R2.4.0：深睡前调用 —— 区面板真值状态失效（深睡丢 RAM），醒后首刷整刷。
 * ★R2.6.0：只废 RAM 基准；RTC 持久化基准【刻意保留】（面板画面不变，
 * 唤醒后续用局刷，见 overlay.c「快刷基准 RTC 持久化」段）。 */
void overlay_zone_invalidate(void);

/* ★R2.6.0：面板框区真值未知（残影清理把整屏洗成纯色等）—— RAM + RTC
 * 快刷基准一并作废，下一次到点刷新回退整刷。区别于上面的深睡作废。 */
void overlay_box_basis_forget(void);

/* R2.4.0：自定义控件布局 HTTP 解析（main.c 调）。
 * str = "t:x,y,w,h;d:..;h:..;i:..;n:.."（当前方向组）或 "clear"；
 * 校验屏内/不重叠，违反返回 -1。blob 见 settings.h SETT_BOX_WG_BYTES。 */
int  overlay_box_wg_parse(const char *str, uint8_t blob[SETT_BOX_WG_BYTES]);

/* 立即重画一次信息框（含干净条带重截 + 合成 + 整屏刷新）。
 * 在 display_task 上下文调用。count_cycle = 本次刷新是否消耗一个 IP 显示
 * 周期（到点刷新 true；改设置触发的重画 false）。box_en 关闭时无动作。 */
void overlay_box_redraw(bool count_cycle);

/* 信息框从开改关：重截干净条带并整屏刷新（display_task 上下文）。 */
void overlay_box_clear(void);

/* R2.0.3：把信息框画进【当前】条带（不刷屏）—— 上传显示 / 图库切图 /
 * 条带还原后立即带上框（旧版只有到点重画才有框，上传后框内空白）。
 * box_en 关闭、密码重置中或条带无效时无动作。 */
void overlay_box_compose_strip(void);

/* R2.0.3：标记当前显示源是否为"分割式合成"（照片让出顶部 160 行、纯白）。
 * 由 frame.c 在切换显示源（上传 split=1 / 切图读帧头 hdr[15]）时设置。 */
void overlay_set_photo_split(bool on);

/* R2.0.3：STA 拿到 IP（入网成功）时重置 IP 行显示周期计数（wifi_mgr 调用）。 */
void overlay_ip_notify_joined(void);

/* R2.0.6：把 IP 行周期计数重置为当前设置值（main.c 在信息框设置变更时调用）——
 * 已入网状态下切到/改周期档，若不重置则计数为 0，IP 行要等下次重新入网才出现。 */
void overlay_ip_cycles_reset(void);

/* ---- R2.1.0：统一刷新触发 / 远端样式 / 上电门控 ----
 * 需求 7：网络状态变化触发 —— wifi_mgr 三连确认后经 main 投 OV_EV_NET_CHANGED，
 * display_task 调本函数：信息栏当前应显示则重画（不消耗 IP 周期），
 * 应隐藏（如断网且无蓝牙数据）则把条带还原成纯照片。 */
void overlay_box_refresh(void);

/* R2.1.0：信息栏当前是否应显示 —— 设置开启 且（已入局域网 或 蓝牙温湿度
 * 有效 或 ★R2.6.2 单机时钟态：时间控件开启且钟有效）且 非远端全屏样式。
 * R2.6.2 前第三档不存在：无网络无蓝牙 = 整栏隐藏（需求 12 原意是「假钟
 * --:-- 无可看内容」）—— 但 RTC 对过一次时后跨深睡永远走时，时钟离线
 * 完全可画；可见性绑死网络态会让入睡调度在单机/门控窗内丢分钟事件
 * （实测「局刷一次后睡死到 30/60min 边界」），故单机时钟态也算可见。 */
bool overlay_box_visible(void);

/* R2.1.0：远端拉取显示样式压制（remote.c 在提交远端帧时调用）：
 *   active=false —— 远端未接管，信息框按用户设置；
 *   active=true, split=true  —— 分割式：顶部 160 行 = 本地信息框（框底纯白），
 *                               下方为远端内容（设备自行拼接）；
 *   active=true, split=false —— 信息框关闭：全屏均为远端内容，信息框一律不画。 */
void overlay_set_remote(bool active, bool split);

/* R2.1.0：上电门控完成标记 —— 门控完成前分钟调度不触发任何重画/轮播
 *（需求 3：等网络→NTP→温湿度确认后才刷屏；期间屏幕保持旧画面）。
 * ★R2.6.0：门控完成即刻评估「补刷」—— 深睡定时唤醒所瞄准的到点事件
 *（分钟刷新/远端拉取/轮播/换位）若被门控期吃掉（边界已过但仍在同一
 * 对齐周期内），立即补发，不再等下一个整分边界（时钟/拉取 stale 一个周期）。 */
void overlay_set_boot_done(void);

/* ★R2.7.1：boot 门控是否已完成 —— power_should_sleep 的「门控未完成
 * 绝不入睡」判据用（腰斩 boot_gate_task = 「永不清醒」循环的防线）。 */
bool overlay_boot_done(void);

/* ---- R2.5.0：事件驱动休眠 ----
 * 入睡侧（power_enter_deep_sleep）问「下一次会刷屏的调度事件还有多久」。
 * 返回秒数；0 = 当前无调度事件（只剩按键 / wake_s / 看护唤醒）。
 * ★R2.6.0：evt_out / at_out（可 NULL）透传 pwr_sched 的事件种类与边界
 * epoch —— power 侧随入睡标记写 RTC，唤醒后补刷判定用。
 * 判据与 minute_cb 各触发器一一对应，但按【入睡时刻】的设置与状态评估
 *（唤醒后网络/温湿度可能已变，minute_cb 实判；判重最多浪费一个短窗口）。
 * 详见 pwr_sched.h 头注释。 */
uint32_t overlay_next_wake_s(uint8_t *evt_out, int64_t *at_out);

/* ---- 密码重置流程（HTTP 免认证入口触发，实际刷屏走 display_task） ----
 * 返回 false = 已有重置在进行中（拒绝重复触发）。 */
bool overlay_pwd_reset_request(void);
bool overlay_pwd_reset_active(void);

/* display_task 侧消费的内部动作（由定时器/队列驱动）。 */
void overlay_pwd_phase1_draw(void);     /* 画「重置密码中」 */
void overlay_pwd_phase2_draw(void);     /* 生成新密码并画「新密码 XXXXXX」 */
void overlay_pwd_timer_start(void);     /* 启动 60 秒阶段定时器 */

#endif /* MOINK_OVERLAY_H */
