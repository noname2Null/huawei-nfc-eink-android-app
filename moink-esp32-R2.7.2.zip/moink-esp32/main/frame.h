#ifndef MOINK_FRAME_H
#define MOINK_FRAME_H

#include "esp_http_server.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/*
 * 帧格式 v1/v2（api = 2）：16 字节头（大端）+ 2bpp 载荷。字段与偏移不变，
 * 只有 hdr[2] 与载荷几何在 v2 上扩展：
 *
 *   偏移 0-1   魔数 0xA5 0x5A
 *   偏移 2     格式版本：1 = 768x552 载荷；2 = A1 原生 800x600 载荷
 *   偏移 3     面板类型（0=A0 / 1=A1，信息性字段）
 *   偏移 4-5   宽（BE）
 *   偏移 6-7   高（BE）
 *   偏移 8-11  载荷长度（BE）
 *   偏移 12-13 CRC16/CCITT-FALSE（poly 0x1021, init 0xFFFF，载荷字节）
 *   偏移 14    帧头标志有效标记（0xA5 = hdr[15] 有效；旧帧无标记 = 0）
 *   偏移 15    标志位（R2.0.3）：bit0 = 1 = 分割式合成（照片让出顶部信息框区、
 *              框底纯白）；CRC 只覆盖载荷，不影响校验
 *
 * 载荷为 2bpp 位图（MSB 优先、行自下而上 = 180° 契约，与 epd_drv.c 一致），
 * 长度为 宽/4*高：768x552 → 105984；800x600 → 120000。
 * 固件按 hdr 里的宽高判定布局，几何由 epd_frame_geom_ok 校验（当前只收 768x552）。
 */

#define FRAME_HDR_LEN    16
#define FRAME_MAGIC0     0xA5
#define FRAME_MAGIC1     0x5A
#define FRAME_FMT_VERSION 1          /* 基础格式（768x552 载荷） */
#define FRAME_FMT_VERSION_NATIVE 2   /* A1 原生 800x600 载荷 */

/*
 * ★ R2.0.1：不再分配整帧 RAM 缓冲 —— 无 PSRAM 的 WROOM-32 上 120KB 连续堆
 * 不可得（R2.0.0 因此 frame_init 必然 OOM abort → 开机重启循环），且 WiFi +
 * BLE + HTTP 同时起后 105984 也放不下。store 分区槽就是帧缓存：
 *   显示 = 行回调逐行读 flash（epd_display_2bpp_wh_src）+ overlay 条带合成；
 *   上传 = 载荷边收边写暂存物理槽（store_stream_*），CRC 过了再入库。
 * 详见 frame.c 文件头。
 */

/* 初始化同步量 + 白底显示源（不再 malloc）。 */
void frame_init(void);

/* ---- R2.0.1 持锁段（overlay 合成用；语义同旧 frame_buf_lock/unlock，
 *      但不再有整帧缓冲指针 —— 画布 = overlay 自己的 21KB 条带） ----
 * 标准序列（display_task 上下文）：
 *     frame_lock(ms) -> frame_capture_strip_locked()（重截干净条带）
 *                    -> 往条带画信息框/密码屏 -> frame_display_locked()
 *                    -> frame_unlock()
 * 上传 / 图库切图 / 残影清理与持锁段互斥（同一把帧锁）。 */
bool frame_lock(uint32_t timeout_ms);
void frame_unlock(void);
bool frame_capture_strip_locked(void);   /* 须持锁：重截当前显示源干净条带 */
int  frame_display_locked(void);         /* 须持锁：整屏刷新当前显示源 */

/* 自带帧锁的便捷封装（超时/阻塞语义同上）。 */
int  frame_display_now(void);
bool frame_capture_strip(void);

/* R2.0.0：启动恢复 —— 图库非空时显示当前槽（掉电后仍有图可刷、可重建信息框）。 */
void frame_boot_restore(void);

/* ★R2.6.0：只恢复显示源与条带（不刷屏）—— 深睡事件唤醒且面板已显示
 * 当前槽时用：首屏交给分钟调度/补刷（快刷基准从 RTC 恢复则局刷），
 * 免去每次唤醒的无条件整刷闪屏。main.c boot gate 调用。 */
void frame_boot_restore_source(void);

/* 阻塞等待一帧就绪（由上传处理器触发）。 */
void frame_wait(void);

/* R1.0.8：残影清理（持帧锁，与传图/显示互斥）。成功返回 0。 */
int frame_clear_cycles(int cycles);

/* POST /api/frame 处理器：收头 -> 校验 -> 载荷边收边写暂存槽并算 CRC ->
   入库/触发显示。R1.3.0 轮播 query：
     save=1            存槽并显示
     save=1&noshow=1  只存不显示（批量上传前几张，避免逐张刷屏）
     无 save           只显示不存（写入暂存槽供显示，不入图库）
     split=1          R2.0.3 分割式合成（页面样式=分割时附带，入帧头 hdr[15]） */
esp_err_t frame_upload_handler(httpd_req_t *req);

/* R1.3.0 轮播：校验 store 槽 slot -> 重截条带 -> 整屏显示。
   成功返回 0，空/坏槽或几何不符返回非 0。 */
int frame_display_slot(int slot);

/* ---------------- R2.1.0 远端内容显示源（remote.c 用） ----------------
 * 远端 2bit 帧与上传共用暂存槽机制（无整帧 RAM）：
 *   ★R2.2.1：分割子帧的形状随屏幕方向（settings.orient，以排线为基准）：
 *     竖屏 0/2 = 552 段 x 152B（载荷行字节 40..191 / 0..151）；
 *     横屏 1/3 = 392 段 x 192B（载荷行 0..391 / 160..551 整行）。
 *     形状由远端在 MKRP 头 rows/rb 里给出，remote.c 按方向校验。
 *   frame_remote_stage_begin()  选空槽（避开当前显示源）。返回 >=0 暂存槽；
 *     STORE_ERR_FULL = 无空位；-1 = 其它失败。若返回槽 == frame_src_phys()
 *     则为原地复用（图库几乎满），流式写入期间须持帧锁。
 *   frame_remote_stage_put()    流式写入载荷（收到多少写多少）。
 *   frame_remote_stage_abort()  放弃（槽作废，显示源不动）。
 *   frame_remote_commit_locked() ★帧锁内★ 提交为显示源并整屏刷新：
 *     split=true  —— 远端分割子帧（152B/行 = 用户屏幕 160..767 行），
 *                    顶部 160 行由本地信息框条带拼接（设备自己拼本地+远端）；
 *     split=false —— 全屏帧（192B/行），信息框一律不画（远端关闭样式）。
 *   frame_remote_revert()       退出远端显示：回落图库当前槽（空则白底）+ 刷屏。
 *   frame_src_phys/frame_src_remote_split/frame_src_split —— 显示源状态查询。 */
int  frame_src_phys(void);
bool frame_src_remote_split(void);
bool frame_src_split(void);
int  frame_remote_stage_begin(void);
int  frame_remote_stage_put(const uint8_t *d, uint32_t n);
void frame_remote_stage_abort(void);
/* ★R2.6.0：深睡唤醒后恢复远端显示源（remote_init 调用，不刷屏 —— 面板
 *   本来就显示着这帧远端内容；phys = 睡前暂存槽，槽头校验失败返回 -1）。
 *   配合 remote 侧 cid 持久化：同内容 304 跳过 → 唤醒不再重复整刷。 */
int  frame_remote_restore(int phys, bool split);
int  frame_remote_commit_locked(int phys, bool split, const uint8_t hdr[16]);
void frame_remote_revert(void);

#endif /* MOINK_FRAME_H */
