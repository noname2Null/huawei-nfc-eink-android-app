#ifndef MOINK_AUTH_H
#define MOINK_AUTH_H

#include "esp_err.h"
#include "esp_http_server.h"
#include <stdbool.h>

/*
 * R2.0.0 配置页访问认证（HTTP Basic）。
 *
 * 密码规格（用户定案）：
 *   - 6 位纯数字；空 = 未设置 = 完全免认证（沿用旧行为）。
 *   - 未设置时控制页首屏弹「设置密码」引导，可跳过（localStorage 记住跳过）。
 *   - 已设置后所有配置接口必须带对密码（用户名任意，浏览器记住后无感）。
 *   - 「忘记密码」→ POST /api/pwdreset（免认证，属于物理旁路设计）：
 *     墨水屏顶部 1/5 红色加粗显示「重置密码中」，1 分钟后屏上显示随机新密码。
 */

/* 认证闸门：在业务 handler 开头调用。
 * 返回 ESP_OK = 放行（密码未设置 或 凭据正确），业务继续；
 * 返回非 OK = 已向客户端发完 401 + WWW-Authenticate，直接 return 该值。 */
esp_err_t auth_guard(httpd_req_t *req);

/* 当前是否已设置密码。 */
bool auth_pass_set(void);

#endif /* MOINK_AUTH_H */
