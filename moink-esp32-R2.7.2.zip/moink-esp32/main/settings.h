#ifndef MOINK_SETTINGS_H
#define MOINK_SETTINGS_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "esp_err.h"

/*
 * 持久化设置（NVS 命名空间 "moink"）。页面所有画面参数（风格 / 强度 / 文字 /
 * 旋转…）都留在手机 localStorage，固件只存会影响「传输与电源」的这几项。
 *
 * ★ R1.2.2：升级**不再强制重置设置** —— 只清理本版已废弃的键
 * （settings_reset_for_upgrade()），屏型 / 功率 / GPIO 接法 / 休眠 / 唤醒 /
 * 热点凭据全部原样保留。读取时仍不做「历史值归一」，越界值一律回落默认档。
 *
 * ★ R1.2.2：引脚（SPI 六线 + 电池 ADC + 唤醒键）改为运行时可配，随 NVS 持久化。
 * ★ ESP32 移植版：无自锁脚（原 C3 版的 GPIO2 MOS 自锁已随移植删除）。
 */

#define SETT_SSID_MAX 33
#define SETT_PASS_MAX 65

/* ---- R2.0.0 新增：STA 配网 / 网页密码 / 信息框 / 传感器 ---- */
#define SETT_WEB_PASS_LEN  7     /* 6 位纯数字 + NUL；空串 = 未设置（免认证） */
#define SETT_BLE_MAC_LEN   13    /* "AABBCCDDEEFF" 12 字符 + NUL */
#define SETT_BLE_KEY_LEN   33    /* bind key 32 个 hex 字符 + NUL */

/* 信息框刷新间隔档（分钟，按时间对齐：分钟数 % 间隔 == 0 时刷新）。 */
#define SETT_BOX_IV_1MIN    1
#define SETT_BOX_IV_5MIN     5
#define SETT_BOX_IV_10MIN    10
#define SETT_BOX_IV_30MIN   30
#define SETT_BOX_IV_60MIN   60

/* 信息框显示样式（R2.0.3）。 */
#define SETT_BOX_STYLE_OVERLAY  0   /* 叠加：白抖动框压在照片上（密度可调） */
#define SETT_BOX_STYLE_SPLIT    1   /* 分割：新上传照片让出框区，框底纯白 */

/* 信息框 IP 行显示模式（R2.0.3）。 */
#define SETT_BOX_IP_OFF     0       /* 不显示 */
#define SETT_BOX_IP_ALWAYS  1       /* 入网后常显 */
#define SETT_BOX_IP_CYCLES  2       /* 入网后显示 N 个刷新周期 */

#define SETT_BOX_IP_CYC_MIN 1       /* 周期档 N 的范围 */
#define SETT_BOX_IP_CYC_MAX 10

/* R2.1.0：信息框内容自定义 —— 元素开关位掩码（box_show）。 */
#define SETT_BOX_SHOW_TIME 0x01      /* 时间 */
#define SETT_BOX_SHOW_DATE 0x02      /* 日期 + 周X */
#define SETT_BOX_SHOW_TH   0x04      /* 温湿度 */
#define SETT_BOX_SHOW_ALL  0x07

/* R2.1.0：自定义布局的自动档哨兵值（0 = 按内容自适应）。 */
#define SETT_BOX_AUTO      0
#define SETT_BOX_TIME_H_MIN 48       /* 时间字高范围（手动档） */
#define SETT_BOX_TIME_H_MAX 150
#define SETT_BOX_ROW_H_MIN  22       /* 右侧行高范围（手动档） */
#define SETT_BOX_ROW_H_MAX  60
#define SETT_BOX_GAP_MIN    8        /* 中部留白范围（手动档） */
#define SETT_BOX_GAP_MAX    160
#define SETT_BOX_PAD_X_MAX  40       /* 左右内边距范围 */
#define SETT_BOX_PAD_Y_MAX  24       /* 上下内边距范围 */

/* R2.4.0：信息框位置（上/下/左/右）· 版式方向（横向/竖向）· 防老化换位间隔。 */
#define SETT_BOX_POS_TOP    0
#define SETT_BOX_POS_BOTTOM 1
#define SETT_BOX_POS_LEFT   2
#define SETT_BOX_POS_RIGHT  3
#define SETT_BOX_DIR_HORIZ  0     /* 横向条带（上/下边，控件沿屏幕宽排布） */
#define SETT_BOX_DIR_VERT   1     /* 竖向条带（左/右边，控件沿屏幕高堆叠） */
#define SETT_BOX_MV_OFF     0     /* 防老化换位间隔（分钟；0 = 关闭） */
#define SETT_BOX_MV_1H      60
#define SETT_BOX_MV_6H      360
#define SETT_BOX_MV_12H     720
#define SETT_BOX_MV_1D      1440
/* 自定义控件布局 blob（overlay.c box_wg_t 同层，勿改）：defined[2] +
 * rsv[2] + rect[2][5][4] i16 = 84B；组 0 = 竖屏(o0/o2)，组 1 = 横屏(o1/o3)。
 * overlay.c 有 _Static_assert(sizeof(box_wg_t) == SETT_BOX_WG_BYTES) 看守。 */
#define SETT_BOX_WG_BYTES   84

/* R2.1.0：图库自动轮播间隔（分钟，按时间对齐；0 = 关闭自动轮播）。 */
#define SETT_CARO_OFF   0
#define SETT_CARO_1MIN  1
#define SETT_CARO_5MIN  5
#define SETT_CARO_10MIN 10
#define SETT_CARO_30MIN 30
#define SETT_CARO_60MIN 60

/* R2.1.0：网络状态检测间隔（秒，页面可调，默认 30）。 */
#define SETT_NETCHECK_MIN_S 10
#define SETT_NETCHECK_MAX_S 600
#define SETT_NETCHECK_DEF_S 30

/* R2.1.0：远端拉取。host 形如 "192.168.1.10:8210" / "moink.example.com"
   （可选端口；域名走 DNS，支持局域网与广域网）。间隔档同 box（分钟）。 */
#define SETT_REMOTE_HOST_MAX 64
#define SETT_REMOTE_IV_DEF   SETT_BOX_IV_10MIN

/* R2.2.1：屏幕方向（以屏幕排线为基准，用户视角正立时排线所在边）。
 * 四档构成完整旋转群：任一物理安装都能找到正确档；若保存后画面方向不对，
 * 说明标签与实际排线方位不符，换选相邻档即可（页面提示同样说明）。
 * 几何已由 scripts/sim_orient_geom.py 机器证明（打包/条带/子帧三方一致）。 */
#define SETT_ORIENT_RIBBON_BOTTOM 0   /* 排线在下：竖屏 552×768（默认，与历史一致） */
#define SETT_ORIENT_RIBBON_LEFT   1   /* 排线在左：横屏 768×552 */
#define SETT_ORIENT_RIBBON_TOP    2   /* 排线在上：竖屏 552×768（180°） */
#define SETT_ORIENT_RIBBON_RIGHT  3   /* 排线在右：横屏 768×552 */
#define SETT_ORIENT_COUNT         4
/* 方向 -> 用户视角画布宽/高（overlay/页面/PC 工具三方同源）。 */
#define SETT_ORIENT_W(o) ((o) == SETT_ORIENT_RIBBON_LEFT || (o) == SETT_ORIENT_RIBBON_RIGHT ? 768 : 552)
#define SETT_ORIENT_H(o) ((o) == SETT_ORIENT_RIBBON_LEFT || (o) == SETT_ORIENT_RIBBON_RIGHT ? 552 : 768)

/* 休眠时长档位（秒）。0 = 不休眠。
   R2.5.0 起默认 5 分钟（上电/按键后无操作即入事件驱动深睡，见 power.h）。 */
#define SETT_SLEEP_OFF    0
#define SETT_SLEEP_1MIN   60
#define SETT_SLEEP_3MIN   180
#define SETT_SLEEP_5MIN   300
#define SETT_SLEEP_DEF    SETT_SLEEP_5MIN

/* 定时自动唤醒档位（秒）。0 = 关闭。 */
#define SETT_WAKE_OFF     0
#define SETT_WAKE_1H      3600
#define SETT_WAKE_12H     43200
#define SETT_WAKE_1D      86400

/* 超时动作（R1.3.3）：空闲达到「超时」时长后执行什么。 */
#define SETT_ACTION_SLEEP 0   /* 进入深睡（可配自动唤醒） */
#define SETT_ACTION_OFF   1   /* 关机档：ESP32 移植版无自锁电路，实际退回深睡 */

/* WiFi 发射功率档位。高 = 18dBm；中 = 10dBm；低 = 8.5dBm（R1.3.3 起为默认档）。 */
#define SETT_WIFI_PWR_HIGH  0
#define SETT_WIFI_PWR_MID   1
#define SETT_WIFI_PWR_LOW   2

/* ---------------- 引脚配置（R1.2.2；ESP32 移植版改写） ----------------
 *
 * ★ ESP32 (WROOM-32 / ESP32-D0WDQ6) 的硬边界（Espressif 官方 GPIO 表）：
 *   可用 GPIO        4, 5, 13..19, 21..23, 25..27, 32, 33（双向）；
 *                    34..39 仅输入（只能当 BUSY / 唤醒脚用）。
 *   不可用/不开放    6..11（片内 SPI flash，绝对禁止）、1/3（UART0 下载/日志）、
 *                    0（BOOT strapping）、2（strapping，保给下载模式）、
 *                    12（strapping，flash 电压选择，拉高会砖）、37/38（WROOM 未引出）。
 *   电池 ADC         只用 ADC1（ADC2 与 WiFi 冲突）：
 *                    GPIO32..36, 39 = ADC1_CH4..7, CH0, CH3（37/38 未引出）。
 *   深睡唤醒         ext0 唤醒仅 RTC 域 GPIO：4, 5, 13..15, 25..27, 32..36, 39。
 *   Strapping 脚     0 / 2 / 12 / 15 在复位瞬间被采样，除 15 外一律不开放。
 *
 * ★ 本移植版（USB 供电常开）已删除 C3 版的 GPIO2 MOS 自锁逻辑：
 *   在 ESP32 上拉高 GPIO2 会影响下次复位进入 UART 下载模式，反而刷不了机。
 */

/* 8 个功能的引脚索引；该顺序同时也是页面「自定义」菜单的排列顺序。 */
enum {
    PIN_IDX_ADC  = 0,   /* 电池 ADC   ：仅 GPIO32..36、39（仅输入，无电池时悬空显示「未连接」） */
    PIN_IDX_WAKE,       /* 深睡唤醒键 ：仅 RTC 域 GPIO（无按键时悬空无害，默认不休眠） */
    PIN_IDX_SCK,
    PIN_IDX_MOSI,
    PIN_IDX_CS,
    PIN_IDX_DC,
    PIN_IDX_RST,
    PIN_IDX_BUSY,
    PIN_IDX_COUNT
};

/* GPIO 预设（与页面下拉一一对应；取值即 gpio_preset）。 */
#define GPIO_PRESET_DEFAULT  0   /* 默认：现役接法 */
#define GPIO_PRESET_LINE     1   /* 排线 */
#define GPIO_PRESET_BOARD    2   /* 整合板 */
#define GPIO_PRESET_CUSTOM   3   /* 自定义 */
#define GPIO_PRESET_COUNT    4
#define GPIO_PRESET_NPRESET  3   /* 前 3 档为固定预设，第 4 档为用户自填 */

typedef struct { uint8_t v[PIN_IDX_COUNT]; } pin_cfg_t;

/* 固定预设表：[0] 默认 / [1] 排线 / [2] 整合板。 */
extern const pin_cfg_t PIN_PRESETS[GPIO_PRESET_NPRESET];

/* 引脚合法性（ESP32 白名单：SCK/MOSI/CS/DC/RST 需可输出，BUSY 亦复用同一白名单）。 */
bool pin_io_allowed(uint8_t io);
/* ADC 脚合法集合：GPIO32..36、39（ADC1 仅输入脚）。 */
bool pin_adc_allowed(uint8_t io);
/* 唤醒脚合法集合：GPIO0..5（RTC 域）。 */
bool pin_wake_allowed(uint8_t io);
/* 整表校验：每脚在各自合法域内、彼此不重复。合法返回 true。 */
bool pin_cfg_valid(const pin_cfg_t *c);
/* 取当前生效引脚表（永不为 NULL）。 */
const pin_cfg_t *settings_pins(void);

typedef struct {
    uint8_t  panel;      /* EPD_PANEL_A0 / EPD_PANEL_A1 */
    uint8_t  hflip;      /* 保留字段：800x600 对照档已删除，当前无生效档位 */
    uint8_t  wifi_pwr;   /* SETT_WIFI_PWR_HIGH / MID / LOW */
    uint8_t  gpio_preset;/* GPIO_PRESET_DEFAULT / LINE / BOARD / CUSTOM */
    pin_cfg_t pins;      /* 生效引脚表（CUSTOM 时即用户所填，否则等于对应预设） */
    uint32_t sleep_s;    /* 空闲超时时长；0 = 不超时（既不睡也不关） */
    uint8_t  timeout_action; /* SETT_ACTION_SLEEP / SETT_ACTION_OFF（R1.3.3） */
    uint32_t wake_s;     /* 定时自动唤醒间隔；0 = 关闭 */
    uint8_t  wake_show;  /* 定时唤醒后自动切到下一张；1 = 是（默认，R1.3.3） */
    char     ap_ssid[SETT_SSID_MAX];  /* 空 = 用默认 MoInk-XXXX */
    char     ap_pass[SETT_PASS_MAX];  /* 空 = 热点开放 */
    /* ---- R2.0.0：局域网配网 / 网页密码 ---- */
    char     sta_ssid[SETT_SSID_MAX]; /* 空 = 从不配网，纯热点模式 */
    char     sta_pass[SETT_PASS_MAX];
    char     web_pass[SETT_WEB_PASS_LEN]; /* 6 位数字；空 = 未设置（免认证） */
    /* ---- R2.0.0：信息框 + 米家温湿度计 ---- */
    uint8_t  box_en;         /* 信息框开关（0 关 / 1 开） */
    uint8_t  box_density;    /* 白色抖动密度 0..100（100 = 纯白底） */
    uint8_t  box_iv_min;     /* 刷新间隔（分钟档，见 SETT_BOX_IV_*） */
    uint8_t  box_style;      /* R2.0.3：SETT_BOX_STYLE_OVERLAY / SPLIT */
    uint8_t  box_ip_mode;    /* R2.0.3：SETT_BOX_IP_OFF / ALWAYS / CYCLES */
    uint8_t  box_ip_cyc;     /* R2.0.3：周期档的 N（1..10） */
    /* ---- R2.1.0：信息框内容自定义（元素开关 + 位置/大小） ---- */
    uint8_t  box_show;       /* SETT_BOX_SHOW_* 位掩码（缺省全开） */
    uint8_t  box_time_h;     /* 时间字高 px；0 = 自适应（SETT_BOX_AUTO） */
    uint8_t  box_row_h;      /* 右侧两行行高 px；0 = 自适应 */
    uint8_t  box_gap_mid;    /* 时间与右块之间留白 px；0 = 自适应(≥28) */
    uint8_t  box_pad_x;      /* 左右内边距 px（默认 12） */
    uint8_t  box_pad_y;      /* 上下内边距 px（默认 6） */
    /* ---- R2.1.0：网络 / 轮播 / 远端 ---- */
    uint8_t  caro_iv;        /* 图库自动轮播间隔分钟（0=关；信息栏不展示时生效） */
    uint16_t netcheck_iv;    /* 网络状态检测间隔秒（默认 30） */
    uint8_t  remote_en;      /* 远端拉取开关 */
    char     remote_host[SETT_REMOTE_HOST_MAX];  /* host[:port]，空 = 未配置 */
    uint8_t  remote_iv;      /* 远端拉取间隔分钟 */
    /* ---- R2.4.0：信息框位置 / 方向 / 防老化换位 / 自定义控件 ---- */
    uint8_t  box_pos;        /* SETT_BOX_POS_*（默认上） */
    uint8_t  box_dir;        /* SETT_BOX_DIR_*（默认横向） */
    uint32_t box_move_iv;    /* SETT_BOX_MV_* 分钟（默认 1 天换位） */
    uint8_t  box_wg[SETT_BOX_WG_BYTES];  /* 自定义控件布局（全 0 = 未定义） */
    /* ---- R2.2.1：屏幕方向（排线基准） ---- */
    uint8_t  orient;         /* SETT_ORIENT_*（0..3） */
    char     ble_mac[SETT_BLE_MAC_LEN];  /* 绑定传感器 MAC（大写 hex），空 = 未绑定 */
    char     ble_key[SETT_BLE_KEY_LEN];  /* bind key（hex），空 = 未设置 */
} moink_settings_t;

void settings_init(void);
const moink_settings_t *settings_get(void);

/* 各 setter 立即写 NVS；失败仅告警不影响 RAM 态。 */
esp_err_t settings_set_panel(uint8_t v);
esp_err_t settings_set_hflip(uint8_t v);
esp_err_t settings_set_wifi_pwr(uint8_t v);
esp_err_t settings_set_sleep(uint32_t v);
esp_err_t settings_set_wake(uint32_t v);
/* R1.3.3：空闲超时后的动作（休眠 / 关机断电）。 */
esp_err_t settings_set_timeout_action(uint8_t v);
/* R1.3.3：定时唤醒后是否自动切图（默认 1）。 */
esp_err_t settings_set_wake_show(uint8_t v);
/*
 * 设置引脚。preset 取 GPIO_PRESET_*：
 *   0/1/2 从固定预设表取（custom 被忽略）；
 *   3     使用 custom，必须通过 pin_cfg_valid()，否则返回 ESP_ERR_INVALID_ARG。
 * 引脚改动需重启才生效（SPI 总线在启动时按引脚初始化），调用方负责提示。
 */
esp_err_t settings_set_gpio(uint8_t preset, const pin_cfg_t *custom);
/* FB-014①：ssid / pass 任一为 NULL = 保持当前值；pass 为空串 = 清除密码（热点开放）。 */
esp_err_t settings_set_ap(const char *ssid, const char *pass);

/* ---- R2.0.0：STA 配网 ----
 * ssid=NULL 保持热点名不变；sta_ssid 传空串 = 清除配网（回纯热点模式）。
 * pass=NULL 保持密码。改动需重启生效（由页面引导）。 */
esp_err_t settings_set_sta(const char *ssid, const char *pass);

/* ---- R2.0.0：网页密码（6 位纯数字；空串 = 清除，恢复免认证） ---- */
esp_err_t settings_set_web_pass(const char *pass);
/* 忘记密码重置：随机生成 6 位数字并落盘，写回 out（不小于 8 字节缓冲）。 */
void settings_gen_web_pass(char *out, size_t n);

/* ---- R2.0.0：信息框 / 传感器（R2.0.3 扩展样式与 IP 行） ---- */
esp_err_t settings_set_box(uint8_t en, uint8_t density, uint8_t iv_min,
                           uint8_t style, uint8_t ip_mode, uint8_t ip_cyc);

/* ---- R2.1.0：信息框内容自定义（元素开关 + 位置/大小） ----
 * show = SETT_BOX_SHOW_* 位掩码；time_h/row_h/gap_mid 取 0 = 自适应；
 * pad_x/pad_y 直接给像素（0 合法）。越界一律拒绝（ESP_ERR_INVALID_ARG）。 */
esp_err_t settings_set_box_layout(uint8_t show, uint8_t time_h, uint8_t row_h,
                                  uint8_t gap_mid, uint8_t pad_x, uint8_t pad_y);

/* ---- R2.4.0：信息框位置 / 方向 / 换位间隔 / 自定义控件布局 ---- */
esp_err_t settings_set_box2(uint8_t pos, uint8_t dir, uint32_t move_iv);
esp_err_t settings_set_box_wg(const uint8_t *blob);   /* SETT_BOX_WG_BYTES；全 0 = 清除 */

/* ---- R2.1.0：图库自动轮播间隔（分钟，0=关） ---- */
esp_err_t settings_set_caro_iv(uint8_t iv_min);

/* ---- R2.1.0：网络状态检测间隔（秒） ---- */
esp_err_t settings_set_netcheck_iv(uint16_t sec);

/* ---- R2.1.0：远端拉取配置（host 为空串 = 清除；en=0 时 host 允许保留） ---- */
esp_err_t settings_set_remote(uint8_t en, const char *host, uint8_t iv_min);

/* ---- R2.2.1：屏幕方向（SETT_ORIENT_*；越界拒绝）。条带几何由 overlay 应用。 ---- */
esp_err_t settings_set_orient(uint8_t orient);
uint8_t   settings_get_orient(void);

/* ---- R2.1.0：米家传感器「曾经成功取到数据」标志（上电门控用，R2.1.0 需求 3）
 * 首次解密出温/湿度时置位；解绑时清除。 */
bool     settings_ble_ever_ok(void);
void     settings_set_ble_ever_ok(bool ok);

/* ---- R2.0.0：传感器绑定（R2.1.0：解绑时顺带清 ble_ok 标志） ---- */
esp_err_t settings_set_ble(const char *mac, const char *key);

/* 恢复出厂：擦除整个 NVS 命名空间（含热点凭据与页面热更标记）；调用方负责重启。 */
void settings_factory_reset(void);

/*
 * 固件升级收尾：**只清理已废弃的键**，不再重置用户设置（R1.2.2）。
 *   - 清理：a1_mode（A1 档位已删除）、a11_var（A1.1 诊断变体已删除）等旧版遗留键。
 *   - 保留：panel / hflip / wifi_pwr / gpio_preset + 8 个引脚键 / sleep_s / wake_s /
 *     ap_ssid / ap_pass —— 它们描述硬件与用户偏好，重置会把人挡在门外。
 *   - 页面热更标记（web_len / web_crc / page_ver）由 ota_web_clear() 负责清除。
 * 调用方在固件校验通过、确定要切槽重启之后调用。
 */
void settings_reset_for_upgrade(void);

#endif /* MOINK_SETTINGS_H */
