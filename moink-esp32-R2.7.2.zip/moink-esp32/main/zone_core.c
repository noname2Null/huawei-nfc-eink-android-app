/*
 * 墨印主固件 R2.4.0 —— 信息框区域引擎实现（纯 C）。
 *
 * ★ 通用方向映射的推导（与 overlay.c R2.2.1 已证明公式合成，零新假设）：
 *   链条：user(ux,uy) --orient--> PC(s,g) --pack--> payload(L,k,grp)
 *         --mirror--> provider(r,j,grp)
 *   1) user→PC（PC = 552 列 × 768 行的面板画布，PC[行s][列g]）：
 *        o0: s=uy,     g=ux          o1: s=767-ux, g=uy
 *        o2: s=767-uy, g=551-ux      o3: s=ux,     g=551-uy
 *   2) PC→payload（rotateCW 打包，payload 行 = PC 列）：L = 551-g，
 *      字节 k = s/4，组 grp = s%4（payload[L][k,grp] = PC(4k+grp, 551-L)）。
 *   3) payload→provider（provider 行 r = 镜像(载荷行 551-r)）：
 *      r = 551-L = g；provider 行内 j = 191-k，组 = 3-grp。
 *   合成即 zc_u2prov；对拍验证见 scripts/test_zone_geom_r240.c：
 *   对顶部条带（4 方向）与 R2.2.1 的 blend/capture 公式逐字节一致，
 *   另有 capture/blend 往返自反测试覆盖任意矩形区。
 */
#include "zone_core.h"
#include <string.h>

/* ---- 区状态 ---- */
static int       s_orient = 0;
static zc_rect_t s_zone = { 0, 0, 552, 160 };
static bool      s_valid = false;
static uint8_t   s_zbuf[ZC_BYTES_MAX];

/* 暂存位图（旧控件重渲染，1bpp：1=黑笔画） */
static bool      s_scr_on = false;
static zc_rect_t s_scr = { 0, 0, 0, 0 };
static int       s_scr_stride = 0;
static uint8_t   s_scratch[ZC_SCRATCH_MAX];
static bool      s_scr_used = false;    /* 本 tick 是否已产生暂存内容 */

void zc_u2prov(int orient, int ux, int uy, int *r, int *j, int *grp)
{
    int s, g;
    switch (orient) {
    case 1:  s = 767 - ux; g = uy;       break;
    case 2:  s = 767 - uy; g = 551 - ux; break;
    case 3:  s = ux;       g = 551 - uy; break;
    default: s = uy;       g = ux;       break;
    }
    *r = g;
    *j = 191 - (s >> 2);
    *grp = 3 - (s & 3);
}

void zc_prov2u(int orient, int r, int j, int grp, int *ux, int *uy)
{
    int s = 4 * (191 - j) + (3 - grp), g = r;
    switch (orient) {
    case 1:  *ux = 767 - s; *uy = g;       break;
    case 2:  *ux = 551 - g; *uy = 767 - s; break;
    case 3:  *ux = s;       *uy = 551 - g; break;
    default: *ux = g;       *uy = s;       break;
    }
}

void zc_zone_set(int orient, const zc_rect_t *z)
{
    if (z && z->w > 0 && z->h > 0 &&
        (size_t)z->w * (size_t)z->h / 4u <= ZC_BYTES_MAX) {
        s_zone = *z;
        s_orient = orient & 3;
        s_valid = false;               /* 新区内容未知，须重截/重画 */
    }
}

const zc_rect_t *zc_zone(void) { return &s_zone; }
uint8_t *zc_buf(void)          { return s_zbuf; }
bool zc_valid(void)            { return s_valid; }
void zc_invalidate(void)       { s_valid = false; }

static int zone_stride(void) { return s_zone.w / 4; }

void zc_px_set(int ux, int uy, int c)
{
    if (ux < s_zone.x || uy < s_zone.y) return;
    int lx = ux - s_zone.x, ly = uy - s_zone.y;
    if (lx >= s_zone.w || ly >= s_zone.h) return;
    int sh = 6 - 2 * (lx & 3);
    uint8_t *q = s_zbuf + (size_t)ly * zone_stride() + (lx >> 2);
    *q = (uint8_t)((*q & ~(3 << sh)) | ((c & 3) << sh));
}

int zc_px_get(int ux, int uy)
{
    if (ux < s_zone.x || uy < s_zone.y) return -1;
    int lx = ux - s_zone.x, ly = uy - s_zone.y;
    if (lx >= s_zone.w || ly >= s_zone.h) return -1;
    const uint8_t *q = s_zbuf + (size_t)ly * zone_stride() + (lx >> 2);
    return (*q >> (6 - 2 * (lx & 3))) & 3;
}

void zc_fill_white(void)
{
    memset(s_zbuf, 0x55, (size_t)zone_stride() * s_zone.h);
    s_valid = true;
}

/* ---- 截取 / 合成 ---- */

void zc_capture_range(int *r0, int *r1)
{
    int lo, hi;
    if (s_orient == 0) {          /* L = 551-ux */
        lo = ZC_RROWS - 1 - (s_zone.x + s_zone.w - 1);
        hi = ZC_RROWS - 1 - s_zone.x + 1;
    } else if (s_orient == 2) {   /* L = ux */
        lo = s_zone.x; hi = s_zone.x + s_zone.w;
    } else if (s_orient == 1) {   /* L = 551-uy */
        lo = ZC_RROWS - 1 - (s_zone.y + s_zone.h - 1);
        hi = ZC_RROWS - 1 - s_zone.y + 1;
    } else {                      /* L = uy */
        lo = s_zone.y; hi = s_zone.y + s_zone.h;
    }
    if (lo < 0) lo = 0;
    if (hi > ZC_RROWS) hi = ZC_RROWS;
    if (hi < lo) hi = lo;
    *r0 = lo; *r1 = hi;
}

void zc_capture_row(int row, const uint8_t *line192)
{
    if (row < 0 || row >= ZC_RROWS || !line192) return;
    int gcol = ZC_RROWS - 1 - row;         /* PC 列 g = 551-L */
    for (int k = 0; k < ZC_RBYTES; k++) {
        uint8_t sv = line192[k];
        for (int g = 0; g < 4; g++) {
            int v = (sv >> (6 - 2 * g)) & 3;
            int s = 4 * k + g;             /* PC 行 */
            int ux, uy;
            switch (s_orient) {
            case 1:  ux = 767 - s; uy = gcol;       break;
            case 2:  ux = 551 - gcol; uy = 767 - s; break;
            case 3:  ux = s;       uy = 551 - gcol; break;
            default: ux = gcol;   uy = s;           break;
            }
            zc_px_set(ux, uy, v);          /* 区外自动忽略 */
        }
    }
}

void zc_capture_done(void) { s_valid = true; }

void zc_blend_row(uint8_t *row_rot, int r)
{
    if (!s_valid || r < 0 || r >= ZC_RROWS) return;
    const zc_rect_t *z = &s_zone;

    if (s_orient == 0 || s_orient == 2) {
        /* provider 行 r = 用户列（o0: ux=r；o2: ux=551-r） */
        int ux = (s_orient == 0) ? r : (ZC_RROWS - 1 - r);
        if (ux < z->x || ux >= z->x + z->w) return;
        for (int uy = z->y; uy < z->y + z->h; uy++) {
            int rr, j, g;
            zc_u2prov(s_orient, ux, uy, &rr, &j, &g);
            int c = zc_px_get(ux, uy);
            if (c < 0) continue;
            int sh = 6 - 2 * g;
            row_rot[j] = (uint8_t)((row_rot[j] & ~(3 << sh)) | (c << sh));
        }
    } else {
        /* provider 行 r = 用户行（o1: uy=r；o3: uy=551-r） */
        int uy = (s_orient == 1) ? r : (ZC_RROWS - 1 - r);
        if (uy < z->y || uy >= z->y + z->h) return;
        for (int ux = z->x; ux < z->x + z->w; ux++) {
            int rr, j, g;
            zc_u2prov(s_orient, ux, uy, &rr, &j, &g);
            int c = zc_px_get(ux, uy);
            if (c < 0) continue;
            int sh = 6 - 2 * g;
            row_rot[j] = (uint8_t)((row_rot[j] & ~(3 << sh)) | (c << sh));
        }
    }
}

/* ---- ★R2.6.0 防烧屏换位让位（见 .h 头注释） ---- */

#define ZC_SHIFT_SEM  (ZC_HBAR_H / 4)          /* 160 用户行 = 40 载荷字节 */
#define ZC_SHIFT_PB   (ZC_RBYTES - ZC_SHIFT_SEM)  /* 照片段字节数 152 */

int zc_shift_payload_row(int orient, int r)
{
    if (r < 0 || r >= ZC_RROWS) return -1;
    switch (orient & 3) {
    case 1:
        /* o1：provider 行 r = 用户行 r；照片显示行 0..391 ← 载荷用户行
           160..551 = 载荷行 391..0（载荷行 = 551-用户行）。 */
        return (r <= ZC_RROWS - 1 - ZC_HBAR_H) ? (ZC_RROWS - 1 - r - ZC_HBAR_H)
                                               : -1;
    case 3:
        /* o3：provider 行 r = 用户行 551-r；照片显示用户行 0..391 ←
           载荷用户行 uy+160 = 载荷行 uy+160 = 711-r。 */
        return (r >= ZC_HBAR_H) ? (ZC_RROWS - 1 - r + ZC_HBAR_H) : -1;
    default:
        /* o0/o2：照片平移在行内字节级（zc_shift_row_bytes），行号不变 */
        return ZC_RROWS - 1 - r;
    }
}

void zc_shift_row_bytes(int orient, uint8_t *row_rot)
{
    if (!row_rot) return;
    switch (orient & 3) {
    case 0:
        /* o0：provider 字节 j ↔ 用户行 4*(191-j)..；显示用户行 uy ← 载荷
           用户行 uy+160 位于 j-40 —— 内容向高字节端平移，低 40B（框区）
           留给 blend（防御性填白，正常路径 blend 整段覆盖）。 */
        memmove(row_rot + ZC_SHIFT_SEM, row_rot, (size_t)ZC_SHIFT_PB);
        memset(row_rot, 0x55, (size_t)ZC_SHIFT_SEM);
        break;
    case 2:
        /* o2：镜像方向相反 —— 内容向低字节端平移，高 40B（框区）留给 blend。 */
        memmove(row_rot, row_rot + ZC_SHIFT_SEM, (size_t)ZC_SHIFT_PB);
        memset(row_rot + ZC_SHIFT_PB, 0x55, (size_t)ZC_SHIFT_SEM);
        break;
    default:
        break;                                  /* o1/o3：平移在行号级 */
    }
}

/* ---- 快刷 diff 引擎 ---- */

void zc_set_render_scratch(bool on) { s_scr_on = on; }
bool zc_scratch_active(void)        { return s_scr_on; }

void zc_scratch_begin(const zc_rect_t *u)
{
    if (!u || u->w <= 0 || u->h <= 0) { s_scr.w = 0; s_scr.h = 0; s_scr_used = false; return; }
    int bytes = ((u->w + 7) / 8) * u->h;
    if (bytes > ZC_SCRATCH_MAX) { s_scr.w = 0; s_scr.h = 0; s_scr_used = false; return; }
    s_scr = *u;
    s_scr_stride = (u->w + 7) / 8;
    memset(s_scratch, 0, (size_t)bytes);   /* 0 = 白（旧控件底） */
    s_scr_used = true;
}

void zc_scratch_px(int ux, int uy, int black)
{
    if (ux < s_scr.x || uy < s_scr.y) return;
    int lx = ux - s_scr.x, ly = uy - s_scr.y;
    if (lx >= s_scr.w || ly >= s_scr.h) return;
    uint8_t *q = s_scratch + (size_t)ly * s_scr_stride + (lx >> 3);
    if (black) *q |= (uint8_t)(0x80 >> (lx & 7));
    else       *q &= (uint8_t)~(0x80 >> (lx & 7));
}

static int scratch_bit(int ux, int uy)
{
    int lx = ux - s_scr.x, ly = uy - s_scr.y;
    if (lx < 0 || ly < 0 || lx >= s_scr.w || ly >= s_scr.h) return 0;
    return (s_scratch[(size_t)ly * s_scr_stride + (lx >> 3)] >> (7 - (lx & 7))) & 1;
}

void zc_action_row(int r, uint8_t *out192)
{
    memset(out192, 0, ZC_RBYTES);          /* 全保持码 00 */
    if (!s_scr_used || !s_valid || r < 0 || r >= ZC_RROWS) return;
    const zc_rect_t *z = &s_zone;

    /* 与 blend_row 同结构遍历，但只碰暂存窗内的像素 */
    if (s_orient == 0 || s_orient == 2) {
        int ux = (s_orient == 0) ? r : (ZC_RROWS - 1 - r);
        if (ux < s_scr.x || ux >= s_scr.x + s_scr.w) return;
        int y0 = s_scr.y > z->y ? s_scr.y : z->y;
        int y1 = s_scr.y + s_scr.h < z->y + z->h ? s_scr.y + s_scr.h : z->y + z->h;
        for (int uy = y0; uy < y1; uy++) {
            int rr, j, g;
            zc_u2prov(s_orient, ux, uy, &rr, &j, &g);
            int old_b = scratch_bit(ux, uy);
            int nc = zc_px_get(ux, uy);
            if (nc < 0) continue;
            int act = (old_b == (nc == 0)) ? 0 : (nc == 0 ? 1 : 2);
            if (act) {
                int sh = 6 - 2 * g;
                out192[j] = (uint8_t)((out192[j] & ~(3 << sh)) | (act << sh));
            }
        }
    } else {
        int uy = (s_orient == 1) ? r : (ZC_RROWS - 1 - r);
        if (uy < s_scr.y || uy >= s_scr.y + s_scr.h) return;
        int x0 = s_scr.x > z->x ? s_scr.x : z->x;
        int x1 = s_scr.x + s_scr.w < z->x + z->w ? s_scr.x + s_scr.w : z->x + z->w;
        for (int ux = x0; ux < x1; ux++) {
            int rr, j, g;
            zc_u2prov(s_orient, ux, uy, &rr, &j, &g);
            int old_b = scratch_bit(ux, uy);
            int nc = zc_px_get(ux, uy);
            if (nc < 0) continue;
            int act = (old_b == (nc == 0)) ? 0 : (nc == 0 ? 1 : 2);
            if (act) {
                int sh = 6 - 2 * g;
                out192[j] = (uint8_t)((out192[j] & ~(3 << sh)) | (act << sh));
            }
        }
    }
}

uint32_t zc_fingerprint(uint32_t extra)
{
    uint32_t h = 2166136261u;
    #define ZC_MIX(v) do { h ^= (uint32_t)(v); h *= 16777619u; } while (0)
    ZC_MIX(s_orient); ZC_MIX(s_zone.x); ZC_MIX(s_zone.y);
    ZC_MIX(s_zone.w); ZC_MIX(s_zone.h); ZC_MIX(extra);
    #undef ZC_MIX
    return h;
}

/* ---- 控件矩形工具 ---- */

bool zc_rect_valid(const zc_rect_t *r, int cw, int ch)
{
    return r && r->x >= 0 && r->y >= 0 && r->w >= 8 && r->h >= 8 &&
           r->x + r->w <= cw && r->y + r->h <= ch;
}

bool zc_rect_overlap(const zc_rect_t *a, const zc_rect_t *b)
{
    return a->x < b->x + b->w && b->x < a->x + a->w &&
           a->y < b->y + b->h && b->y < a->y + a->h;
}

void zc_rect_clamp(zc_rect_t *r, int cw, int ch)
{
    if (r->w > cw) r->w = cw;
    if (r->h > ch) r->h = ch;
    if (r->x < 0) r->x = 0;
    if (r->y < 0) r->y = 0;
    if (r->x + r->w > cw) r->x = cw - r->w;
    if (r->y + r->h > ch) r->y = ch - r->h;
}

void zc_rect_derive(const zc_rect_t *src, int wa, int ha, int wb, int hb,
                    zc_rect_t *dst)
{
    if (wa <= 0 || ha <= 0 || wb <= 0 || hb <= 0 || !src || !dst) return;
    dst->w = (int16_t)(src->w * wb / wa);
    dst->h = (int16_t)(src->h * hb / ha);
    if (dst->w < 8) dst->w = 8;
    if (dst->h < 8) dst->h = 8;
    dst->x = (int16_t)(src->x * wb / wa);
    dst->y = (int16_t)(src->y * hb / ha);

    /* 贴边锚定：控件边缘到画布四边距离最小者（需求：以控件边缘靠近哪边定） */
    int dl = src->x, dr = wa - src->x - src->w;
    int dt = src->y, db = ha - src->y - src->h;
    int m = dl, anchor = 0;                       /* 0左 1右 2上 3下 */
    if (dr < m) { m = dr; anchor = 1; }
    if (dt < m) { m = dt; anchor = 2; }
    if (db < m) { m = db; anchor = 3; }
    int mg = (anchor < 2) ? m * wb / wa : m * hb / ha;
    if (anchor == 0)      dst->x = (int16_t)mg;
    else if (anchor == 1) dst->x = (int16_t)(wb - dst->w - mg);
    else if (anchor == 2) dst->y = (int16_t)mg;
    else                  dst->y = (int16_t)(hb - dst->h - mg);
    zc_rect_clamp(dst, wb, hb);
}
