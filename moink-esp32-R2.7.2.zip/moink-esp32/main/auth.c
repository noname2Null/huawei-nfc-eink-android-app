#include "auth.h"
#include "settings.h"

#include "esp_log.h"
#include <string.h>
#include <stdlib.h>

static const char *TAG = "auth";

/* ---------------- 极简 base64 解码（无需引 mbedtls/base64 组件） ---------------- */

static int b64_val(char c)
{
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
}

/* 解码到 out（不含 NUL，调用方保证容量 > outlen）。返回实际字节数，失败 -1。 */
static int b64_decode(const char *in, size_t inlen, uint8_t *out, size_t cap)
{
    size_t o = 0;
    uint32_t acc = 0;
    int bits = 0;
    size_t pad = 0;

    for (size_t i = 0; i < inlen; i++) {
        char c = in[i];
        if (c == '=') { pad++; continue; }
        if (pad) return -1;                 /* '=' 之后不允许再出现数据字符 */
        int v = b64_val(c);
        if (v < 0) return -1;
        acc = (acc << 6) | (uint32_t)v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            if (o >= cap) return -1;
            out[o++] = (uint8_t)((acc >> bits) & 0xFF);
        }
    }
    if (pad > 2) return -1;
    return (int)o;
}

/* ---------------- 认证闸门 ---------------- */

static esp_err_t auth_reject(httpd_req_t *req)
{
    httpd_resp_set_status(req, "401 Unauthorized");
    /* charset=UTF-8：让部分浏览器/安卓 WebView 弹出中文友好界面。 */
    httpd_resp_set_hdr(req, "WWW-Authenticate",
                        "Basic realm=\"MoInk\", charset=\"UTF-8\"");
    httpd_resp_set_hdr(req, "Cache-Control", "no-store");
    httpd_resp_set_type(req, "text/plain; charset=utf-8");
    return httpd_resp_sendstr(req, "401: need access code");
}

esp_err_t auth_guard(httpd_req_t *req)
{
    const moink_settings_t *s = settings_get();

    /* 未设置密码 = 免认证（并让页面用 /api/settings 的 pass_set 引导首次设置）。 */
    if (s->web_pass[0] == '\0') return ESP_OK;

    size_t hlen = httpd_req_get_hdr_value_len(req, "Authorization");
    if (hlen == 0 || hlen > 128) return auth_reject(req);

    char hdr[144];
    if (httpd_req_get_hdr_value_str(req, "Authorization", hdr, sizeof(hdr)) != ESP_OK)
        return auth_reject(req);

    /* 只认 "Basic <base64>"。 */
    const size_t PFX = 6;
    if (hlen < PFX + 4 || strncmp(hdr, "Basic ", PFX) != 0)
        return auth_reject(req);

    uint8_t cred[96];
    int n = b64_decode(hdr + PFX, hlen - PFX, cred, sizeof(cred) - 1);
    if (n <= 0) return auth_reject(req);
    cred[n] = '\0';

    /* 用户名任意（“任意用户名 : 密码”里只校验密码段）。 */
    const char *colon = memchr(cred, ':', (size_t)n);
    if (!colon) return auth_reject(req);
    const char *pass = (const char *)colon + 1;

    /* 等长 + 双向比较（顺带把比较时间对齐，防止计时侧信道）。 */
    size_t plen = strlen(pass);
    bool ok = (plen == strlen(s->web_pass));
    if (ok) {
        for (size_t i = 0; i < plen; i++)
            if (pass[i] != s->web_pass[i]) ok = false;
        for (size_t i = 0; i < plen; i++)
            if (pass[plen - 1 - i] != s->web_pass[plen - 1 - i]) ok = false;
    }
    if (!ok) {
        ESP_LOGW(TAG, "auth failed (bad password, user '%.*s')",
                 (int)(colon - (char *)cred), (const char *)cred);
        return auth_reject(req);
    }
    return ESP_OK;
}

bool auth_pass_set(void)
{
    return settings_get()->web_pass[0] != '\0';
}
