#ifndef MOINK_POWER_H
#define MOINK_POWER_H

#include <stdint.h>
#include <stdbool.h>

/*
 * 电源管理：电池 ADC 粗测、深睡 / 唤醒源、空闲休眠判定。
 *
 * R2.5.0 起电源模型 = 「空闲入睡 + 事件唤醒」（主控常开太烫）：
 *   - sleep_s = 空闲超时（上电/按键唤醒后套用；R2.5.0 起默认 5 分钟，
 *     0 = 不超时 —— 常开档，浅睡降频仍在）；
 *   - 入睡前按「下一次会刷屏的调度事件」（信息框分钟刷新 / 远端拉取 /
 *     图库轮播 / 防老化换位）与用户 wake_s 里更早者设 RTC 定时唤醒；
 *   - 到点唤醒 = 一次完整重启（全任务起），干完活按用途窗口再睡；
 *   - 「关机」档在 ESP32 移植板（无自锁电路）实际退回深睡。
 *
 * ★ R2.7.0 两档功耗状态机（用户方案：分钟局刷低功耗 + 周期全功能）：
 *   唤醒分【轻 / 全功能】两档，按深睡前写入 RTC 的目标事件分流：
 *   - 轻唤醒（TIMER_EVENT + BOX，即分钟局刷）：不起射频（WiFi/BLE/
 *     HTTP 一概不初始化）、boot 门控走捷径（只恢复显示源 + 分钟调度
 *     接管，≈2~3s）、千完即睡（4s 收尾）；面板维持 0x02 断电级（局刷
 *     完成后驱动已断电，深睡前再发 0x07 面板深睡）；
 *   - 全功能唤醒（REMOTE/CAROUSEL/MOVE/SYNC/看护/wake_s/按键/上电）：
 *     开射频（STA 加入 + SNTP 重锚 + 蓝牙窗口 + 远端拉取）+ 全刷。
 *     轻链连续跑满 PWR_SYNC_IV_MIN（12h）后，下一个分钟唤醒升格为
 *     全功能（校时保底）；周期事件（换位/轮播/远端）本身就是全功能，
 *     永不触发升格。
 *   崩溃/看门狗/掉电复位重启（无人 attended）改按 15s 事件窗收尾
 *   （原 sleep_s 默认 5min，一次崩溃 = 时钟停 ≈6 分钟）。
 *
 * 唤醒用途（决定醒后多久没活动就再睡）：
 *   POWER_ON / BUTTON   → sleep_s（有人在用，默认 5 分钟）
 *   TIMER_EVENT         → PWR_EVENT_WINDOW_S（调度事件：刷完即睡，60s 收尾）
 *   TIMER_HUMAN         → AUTO_WAKE_WINDOW_S（wake_s 等人窗口，3 分钟）
 */

/* 配置唤醒键输入 + 电池 ADC。 */
void power_init(void);

/* 重置空闲计时（任何上传 / 请求 / 刷屏事件都调用）。 */
void power_activity(void);

/* R2.5.0：报「忙」脉冲 —— 刷屏 / 远端拉取这类没有 HTTP 心跳的活在进行中，
 * idle_monitor 在忙期内不入睡（防止整屏刷新被深睡拦腰打断）。秒级脉冲 +
 * 自然过期，无需精确配对 begin/end；多源脉冲取最远。★调度刷屏不调
 * power_activity()（那会无限续命空闲计时 —— 信息框 1 分钟档就永远睡不成了）。 */
void power_busy_pulse(uint32_t seconds);

/* R2.6.0：忙期收口 —— 把忙期限压到「现在 + seconds」（只减不增）。
 * 远端拉取按最坏情况报 90s 忙，但 304 同内容秒回；拉完收口避免每个唤醒
 * 周期白等 80+s（1 分钟档会变成常开）。并发的其它忙脉冲最多被提前
 * seconds（收口值 ≥ 常规刷屏时长，不会拦腰打断刷屏）。 */
void power_busy_cap(uint32_t seconds);

/* R2.5.0：唤醒用途。两个入参 = 本次唤醒原因（来自 main 的 wake_src）。
 * 开机时调一次：定时器唤醒则读深睡前写入 RTC 内存的标记解析用途，
 * 否则按按键/上电归类；并锁定 power_should_sleep() 的窗口选择。返回解析
 * 结果（供 main 记日志 / 分流「定时唤醒自动切图」）。标记丢失/校验不过时
 * 按 TIMER_HUMAN 兜底（等价 R2.5.0 之前「定时唤醒 = 等人窗口」的行为）。 */
typedef enum {
    WAKE_PURPOSE_POWER_ON = 0,   /* 上电 / 复位 / OTA 重启 */
    WAKE_PURPOSE_BUTTON,         /* 按键唤醒 */
    WAKE_PURPOSE_TIMER_EVENT,    /* 调度事件唤醒（分钟刷新 / 远端拉取 / 轮播 / 换位 / 看护） */
    WAKE_PURPOSE_TIMER_HUMAN,    /* wake_s 定时唤醒（等人的窗口） */
} wake_purpose_t;

wake_purpose_t power_boot_purpose(bool woken_by_timer, bool woken_by_button);

/* 唤醒用途短名（日志）。 */
const char *power_purpose_name(wake_purpose_t p);

/* 深睡前计划的下一次定时唤醒秒数（0 = 只留按键唤醒；排障日志用）。 */
uint32_t power_planned_sleep_s(void);

/* ★R2.6.0：本次开机的唤醒用途（power_boot_purpose 的解析结果缓存）。 */
wake_purpose_t power_wake_purpose(void);

/* ★R2.7.0 轻唤醒判定：本次开机是否为「分钟局刷轻唤醒」（TIMER_EVENT +
 * BOX 目标事件）。真 = 主控本次不起射频（main 据此跳过 WiFi/HTTP/BLE
 * 初始化）、boot 门控走捷径，收尾窗口 4s（power_should_sleep 套用）。 */
bool power_wake_is_light(void);

/* ★R2.7.0 轻唤醒期间有人按键：收尾窗口升格「等人」档（BUTTON，sleep_s
 * 默认 5min）—— 配合 main 的按需起网，轻唤醒中单击即可临时打开配置页。 */
void power_human_open_window(void);

/* ★R2.7.0：本次开机是否为无人attended的崩溃/看门狗/掉电复位重启
 *（有人插电/软重启为 false）。boot 门控据此走快速档（崩溃自愈不等人）。 */
bool power_unattended_reboot(void);

/* ★R2.6.0：深睡前写入 RTC 的「唤醒目标事件」标记。返回 true = 标记合法；
 * *evt = PWR_EVT_*（BOX/REMOTE/CAROUSEL/MOVE；WAKE/无事件返回 false 或
 * PWR_EVT_NONE）；*tgt_epoch = 事件边界 epoch 秒（补刷窗口判定用）。
 * 两个出参均可传 NULL。 */
bool power_wake_event(uint8_t *evt, int64_t *tgt_epoch);

/* 当前唤醒原因位图（esp_sleep_get_wakeup_causes()；★ ESP32 移植版为 64 位）。 */
uint64_t power_wakeup_causes(void);

/* 空闲是否已超时，应进入深睡。
 * ★R2.7.2 契约更新：判据 = boot 门控完成 && 按唤醒用途选择的窗口已到 &&
 *   无忙脉冲 && EPD 面板序列不在进行中（epd_panel_busy() 硬判据 —— R2.7.2
 *   起不再只依赖各任务自觉报 power_busy_pulse）&& 空闲时长超窗。任意一条
 *   不满足即返回 false。power_enter_deep_sleep() 的入睡序列在 200ms
 *   收尾后【再次调用本函数】做二次校验 —— 本函数在整个入睡窗口内必须
 *   保持可安全重入，且不得受 power_sleeping() 标志影响（入睡序列自身
 *   不得让自己看起来「忙」）。 */
bool power_should_sleep(void);

/* ★R2.7.2【修复1b】：入睡序列是否正在执行 —— power_enter_deep_sleep() /
 * power_deep_sleep_now() 开头置位，序列被二次校验中止时清除（成功睡下
 * 则随断电消亡）。置位窗口内：wifi_mgr 的 STA_DISCONNECTED / slow_retry /
 * probe 一律短路（不重连、不重配 AP、不重画），display_task 暂缓一切
 * UI 事件，overlay/remote 的网络触发同理不得启动物理序列。 */
bool power_sleeping(void);

/* 设唤醒源（含「下一次调度事件」定时器）并进入深睡。
 * ★R2.7.2 契约更新（睡死根治）：本函数【可能返回】！序列 =
 *   ①置 power_sleeping 标志 → ②评估唤醒计划（pwr_sched 分钟边界数学）→
 *   ③网络栈在位才 esp_wifi_stop()（轻唤醒从未起射频，不停）→ ④200ms
 *   收尾（异步掉线事件落地，被①短路）→ ⑤power_should_sleep() 二次校验：
 *   有活动（忙脉冲 / EPD 面板忙 / 有人刚续命）则中止入睡、清标志、返回
 *   （被停掉的 WiFi 交由 wifi_mgr slow_retry 的恢复分支拉起，最长
 *   STA_SLOW_RETRY_MS；调用方循环重试即可）→ ⑥校验通过才作废快刷基准、
 *   面板断电、写 RTC 标记、esp_deep_sleep_start()（此后不返回）。
 *   R2.7.1 及之前「无二次校验、永不返回」，入睡序列自己触发的重画/重连
 *   无法中止入睡 —— 即实测睡死（15s 整刷被拦腰斩断）的根因。 */
void power_enter_deep_sleep(void);

/* ★R2.7.2【修复6】：强制深睡 —— 跳过 power_should_sleep() 二次校验（唤醒
 * 源照常设置）。仅限确认「无任何活动可被打断」的调用点：ext0 按键假
 * 唤醒去抖确认后直接回睡（boot 早期：射频未起、无任务在刷屏、面板本身
 * 已在深睡态）。常规空闲入睡【禁止】走本口 —— 必须经 power_enter_deep
 * _sleep 的二次校验。 */
void power_deep_sleep_now(void);

/* R1.3.3：超时动作 = 关机 —— ★ ESP32 移植版无自锁电路，直接退回深睡，不返回。 */
void power_self_lock_off(void);

/* 电池电压 mV 粗测（分压 1M:1M，×2.0；满量程需按板实测标定）。 */
int power_battery_mv(void);

/* ★R2.7.0 校时保底间隔（分钟）：轻链（仅分钟局刷）连续跑满该时长后，
 * 下一个分钟唤醒升格为全功能（PWR_EVT_SYNC：联网 + SNTP 重锚 + 蓝牙
 * 窗口）。与 SNTP_RESYNC_MS（12h）同量级；有任一周期事件（换位/轮播/
 * 远端/wake_s）时永不触发 —— 它们本身就是全功能唤醒。 */
#define PWR_SYNC_IV_MIN 720

#endif /* MOINK_POWER_H */
